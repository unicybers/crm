# UniCybers Academy LMS 2.8.116

## Sidebar brand layout

- Uses the exact supplied master logo URL: `https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp`.
- Places the original globe mark on the left and a two-line wordmark on the right.
- Displays `UNICYBERS` in white and `ACADEMY` in UniCybers orange (`#FF6B1A`).
- Adds runtime width matching so the visible UNICYBERS and ACADEMY word lines have the same rendered width.
- Removes the previous centered, full-image lockup that pushed the wordmark below the emblem.
- No database changes; the existing LMS data and integrations remain untouched.

## Validation

PHP syntax, JavaScript syntax and ZIP integrity checks are run for this release. The live page must still be checked after cache purge.
