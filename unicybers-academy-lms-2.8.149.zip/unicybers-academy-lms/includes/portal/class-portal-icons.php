<?php
/**
 * UniCybers Academy LMS: Portal Icons & SVG UI Components.
 *
 * Isolated icon registry and decorative vector generators for the LMS Portal.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Icons {
    private static $icons = null;

    /**
     * Get SVG string for the specified icon key.
     *
     * @param string $key
     * @return string
     */
    public static function get($key) {
        if (self::$icons === null) {
            self::$icons = [
                'dashboard'     => '<path d="M4 13h6V4H4zM4 20h6v-4H4zM14 20h6v-9h-6zM14 4v4h6V4z"/>',
                'courses'       => '<path d="M5 5h5a2 2 0 0 1 2 2v12a2 2 0 0 0-2-2H5zM19 5h-5a2 2 0 0 0-2 2v12a2 2 0 0 1 2-2h5z"/>',
                'batches'       => '<path d="M4 7h16M4 12h16M4 17h10"/><circle cx="18" cy="17" r="2"/>',
                'classes'       => '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
                'practice'      => '<path d="M8 4h8l2 2v14H6V4zM9 9h6M9 13h6M9 17h3"/>',
                'materials'     => '<path d="M6 3h8l4 4v14H6zM14 3v4h4M9 12h6M9 16h6"/>',
                'people'        => '<circle cx="9" cy="8" r="3"/><path d="M3.5 19c.4-3.1 2.2-5 5.5-5s5.1 1.9 5.5 5M16 11a3 3 0 1 0 0-6M16.5 14c2.6.2 4.2 1.7 4.6 4.5"/>',
                'announcements' => '<path d="M4 11h4l8-4v10l-8-4H4zM8 15l1 4M19 10a3 3 0 0 1 0 4"/>',
                'messages'      => '<path d="M4 5h16v11H8l-4 4z"/><path d="M8 9h8M8 12h5"/>',
                'reports'       => '<path d="M5 19V10M12 19V5M19 19v-6M3 21h18"/>',
                'tenants'       => '<path d="M4 20V8l8-4 8 4v12M9 20v-6h6v6"/>',
                'profile'       => '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-4 3.1-6 7-6s6.4 2 7 6"/>',
                'audit'         => '<path d="M6 4h9l3 3v13H6zM14 4v4h4M8 12h8M8 16h6"/>',
                'inventory'     => '<path d="M9 5h11M9 12h11M9 19h11M4 5h.01M4 12h.01M4 19h.01"/>',
                'guide'         => '<path fill="currentColor" stroke="none" d="M6 2h11a1 1 0 0 1 1 1v16.2c0 .7-.7 1.2-1.4.9L12 17.6l-4.6 2.5c-.7.3-1.4-.2-1.4-.9V3a1 1 0 0 1 1-1zm2 5v2h8V7H8zm0 4v2h6v-2H8z"/>',
                'settings'      => '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.2M12 18.8V21M3 12h2.2M18.8 12H21M5.6 5.6l1.6 1.6M16.8 16.8l1.6 1.6M18.4 5.6l-1.6 1.6M7.2 16.8l-1.6 1.6"/>',
                'help'          => '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.4a2.5 2.5 0 1 1 4.2 1.8c-.9.8-1.8 1.1-1.8 2.3M12 17h.01"/>',
                'labs'          => '<path fill="currentColor" stroke="none" d="M9 3h6v2h-1v4.3l5.4 9.1A2 2 0 0 1 17.7 21H6.3a2 2 0 0 1-1.7-2.6L10 9.3V5H9V3zm1.2 8.2L7.2 16h9.6l-3-4.8H10.2z"/>',
                'signout'       => '<path d="M10 5H5v14h5M14 8l4 4-4 4M8 12h10"/>',
                'search'        => '<circle cx="11" cy="11" r="6"/><path d="m20 20-4.2-4.2"/>',
                'bell'          => '<path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4zM10 20a2 2 0 0 0 4 0"/>',
                'sun'           => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
                'moon'          => '<path d="M20 14.5A8 8 0 1 1 9.5 4 6.5 6.5 0 0 0 20 14.5z"/>',
                'chev'          => '<path d="m6 9 6 6 6-6"/>',
                'play'          => '<path d="m9 7 8 5-8 5z"/>',
                'user'          => '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-4 3.1-6 7-6s6.4 2 7 6"/>',
                'key'           => '<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l2 2"/>',
                'device'        => '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>',
                'wa'            => '<path fill="currentColor" stroke="none" d="M12.04 2.05A9.94 9.94 0 0 0 2.1 12c0 1.75.46 3.45 1.33 4.95L2 22l5.17-1.36A9.94 9.94 0 0 0 12.04 22 9.95 9.95 0 0 0 22 12.04 9.95 9.95 0 0 0 12.04 2.05zm5.76 14.2c-.24.67-1.39 1.28-1.92 1.36-.49.07-1.11.1-1.79-.11-.41-.13-1.05-.34-1.82-.67-3.2-1.39-5.28-4.62-5.44-4.84-.16-.22-1.28-1.7-1.28-3.24 0-1.54.81-2.29 1.1-2.6.28-.3.62-.38.83-.38h.6c.2 0 .46-.07.71.54.26.64.87 2.21.95 2.37.08.16.13.35.02.56-.1.22-.16.35-.31.54l-.47.56c-.16.16-.32.34-.14.66.19.32.83 1.37 1.78 2.22 1.23 1.1 2.26 1.44 2.58 1.6.32.16.5.13.69-.08.18-.22.79-1.02.97-1.37.22-.35.44-.29.74-.17.3.11 1.89.89 2.21 1.05.32.16.54.24.62.38.07.13.07.76-.17 1.43z"/>',
                'mail'          => '<path fill="currentColor" stroke="none" d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 3.2-8 5.1L4 7.2V6l8 5.1L20 6z"/>',
                'plus'          => '<path d="M12 5v14M5 12h14"/>',
                'alert'         => '<path d="M12 4 2.5 20h19zM12 10v4M12 17h.01"/>',
                'file'          => '<path d="M6 3h8l4 4v14H6zM14 3v4h4"/>',
                'dots'          => '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
                'shield'        => '<path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6z"/><path d="m9 12 2 2 4-4"/>',
                'copy'          => '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>',
                'placement'     => '<path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6z"/><path d="M9 12h6M12 9v6"/>',
                'x'             => '<path d="M6 6l12 12M18 6 6 18"/>',
            ];
        }

        return '<svg viewBox="0 0 24 24" aria-hidden="true">' . (self::$icons[$key] ?? '<circle cx="12" cy="12" r="5"/>') . '</svg>';
    }

    /**
     * Modal header renderer.
     *
     * @param string $eyebrow
     * @param string $title
     * @param bool $named
     * @param object|null $portal
     * @return string
     */
    public static function mhead($eyebrow, $title, $named = false, $portal = null) {
        $esc_e = function($val) use ($portal) {
            return $portal ? $portal->e($val) : esc_html((string)$val);
        };
        $h = $named ? '<h3 data-title>' . $esc_e($title) . '</h3>' : '<h3>' . $esc_e($title) . '</h3>';
        return '<div class="mhead"><div><span class="eyebrow">' . $esc_e($eyebrow) . '</span>' . $h . '</div><button type="button" class="iconbtn mclose" data-close aria-label="Close">' . self::get('x') . '</button></div>';
    }

    /**
     * Parse outline and syllabus bullet list items.
     *
     * @param string $text
     * @return array
     */
    public static function outline_items($text) {
        $text = trim((string)$text);
        if ($text === '') return [];
        $parts = preg_split('/\r\n|\n|\r|(?:\s*;\s+)/', $text);
        $out = [];
        foreach ($parts as $p) {
            $p = trim((string)$p);
            $p = preg_replace('/^(?:[\-\*\x{2022}]|\d+[\.\)])\s*/u', '', $p);
            $p = trim($p);
            if ($p !== '') $out[] = $p;
        }
        return $out;
    }

    /**
     * Decorative circuit traces for hero cards, drawn in SVG.
     *
     * @param string $cls
     * @return string
     */
    public static function circuit($cls = 'circuit') {
        return '<svg class="' . esc_attr($cls) . '" viewBox="0 0 480 120" aria-hidden="true" preserveAspectRatio="xMidYMid meet">'
            . '<g class="mesh"><path d="M4 28 H476"/><path d="M4 60 H168 L196 36 H476"/><path d="M4 92 H148 L176 60 H300 L328 92 H476"/><path d="M120 28 V92"/><path d="M360 28 V92"/></g>'
            . '<g class="nodes"><circle cx="120" cy="28" r="2.6"/><circle cx="120" cy="92" r="2.6"/><circle cx="196" cy="36" r="2.6"/><circle cx="360" cy="28" r="2.6"/><circle cx="360" cy="92" r="2.6"/><circle cx="176" cy="60" r="2.6"/></g>'
            . '<circle class="pkt p1" cx="12" cy="28" r="3.1"/><circle class="pkt p2" cx="12" cy="60" r="2.7"/><circle class="pkt p3" cx="12" cy="92" r="2.5"/>'
            . '</svg>';
    }
}
