<?php
/**
 * UniCybers Academy LMS: Security Shim.
 *
 * Forwards to the modular class in includes/core/class-security.php.
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/core/class-security.php';
