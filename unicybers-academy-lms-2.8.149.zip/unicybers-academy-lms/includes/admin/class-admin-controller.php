<?php
/**
 * UniCybers Academy LMS: WP-Admin Management Controller.
 *
 * Loaded exclusively inside wp-admin to ensure zero frontend footprint.
 * Manages courses, batches, students, trainers, sessions, and LMS settings.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Admin_Controller {
    private static $instance = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public static function init() {
        $inst = self::instance();
        add_action('admin_menu', [$inst, 'admin_menu']);
        add_action('admin_enqueue_scripts', [$inst, 'admin_assets']);
        add_action('admin_init', [$inst, 'register_settings']);
        add_action('admin_head', [$inst, 'admin_favicon'], 100);

        // Form post handlers
        $actions = [
            'save_course', 'update_course', 'delete_course',
            'save_batch', 'update_batch', 'delete_batch', 'generate_schedule',
            'save_student', 'enrol_student', 'remove_enrolment',
            'save_trainer', 'assign_trainer_batch',
            'save_session', 'update_session', 'delete_session',
            'save_attendance', 'save_material', 'delete_material',
            'save_announcement',
            'create_zoom', 'update_zoom', 'test_zoom', 'cleanup_duplicates',
            'sync_recording', 'sync_all_recordings'
        ];
        foreach ($actions as $a) {
            add_action('admin_post_uc_' . $a, [$inst, 'handle_' . $a]);
        }
    }

    private function can_manage() { return current_user_can('manage_options'); }
    private function table($n) { return UC_LMS_Database::table($n); }
    private function now() { return current_time('mysql'); }
    private function url($page, $args = []) { return add_query_arg(array_merge(['page' => $page], $args), admin_url('admin.php')); }
    private function redirect($page, $args = []) { wp_safe_redirect($this->url($page, $args)); exit; }
    private function notice($type, $message) { return ['uc_notice' => $type, 'uc_message' => rawurlencode($message)]; }

    private function render_notice() {
        if (empty($_GET['uc_notice'])) return;
        $type = sanitize_key(wp_unslash($_GET['uc_notice']));
        $msg = isset($_GET['uc_message']) ? rawurldecode(sanitize_text_field(wp_unslash($_GET['uc_message']))) : '';
        if ($msg) echo '<div class="notice ' . ($type === 'error' ? 'notice-error' : 'notice-success') . ' is-dismissible"><p>' . esc_html($msg) . '</p></div>';
    }

    private function audit($entity, $id, $action, $before = null, $after = null, $detail = '') {
        global $wpdb;
        $wpdb->insert($this->table('audit'), [
            'entity'      => $entity,
            'entity_id'   => $id,
            'action'      => $action,
            'by_user_id'  => get_current_user_id(),
            'at_time'     => $this->now(),
            'before_json' => $before ? wp_json_encode($before) : null,
            'after_json'  => $after ? wp_json_encode($after) : null,
            'detail'      => $detail
        ]);
    }

    public function register_settings() {
        // Branding & Identity
        register_setting('uc_lms_settings', 'uc_logo_url', ['sanitize_callback' => 'esc_url_raw']);
        register_setting('uc_lms_settings', 'uc_academy_name', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_academy_legal_name', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_product_label', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_tagline', ['sanitize_callback' => 'sanitize_text_field']);

        // General & Localization
        register_setting('uc_lms_settings', 'uc_default_timezone', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_attend_present_pct');
        register_setting('uc_lms_settings', 'uc_attend_partial_pct');
        register_setting('uc_lms_settings', 'uc_demo_open');

        // Zoom Credentials
        register_setting('uc_lms_settings', 'uc_zoom_account_id');
        register_setting('uc_lms_settings', 'uc_zoom_client_id');
        register_setting('uc_lms_settings', 'uc_zoom_client_secret', ['sanitize_callback' => ['UC_LMS_Zoom', 'keep_client_secret']]);
        register_setting('uc_lms_settings', 'uc_zoom_webhook_secret', ['sanitize_callback' => ['UC_LMS_Zoom', 'keep_webhook_secret']]);

        // Google Meet & Calendar
        register_setting('uc_lms_settings', 'uc_google_client_id');
        register_setting('uc_lms_settings', 'uc_google_client_secret', ['sanitize_callback' => ['UC_LMS_Meeting_Google', 'keep_google_secret']]);
        register_setting('uc_lms_settings', 'uc_google_calendar_id');

        // Microsoft Teams
        register_setting('uc_lms_settings', 'uc_ms_tenant');
        register_setting('uc_lms_settings', 'uc_ms_client_id');
        register_setting('uc_lms_settings', 'uc_ms_client_secret', ['sanitize_callback' => ['UC_LMS_Meeting_Teams', 'keep_ms_secret']]);
        register_setting('uc_lms_settings', 'uc_ms_user');

        // Lightweight Drive materials and Zoho Meeting connectors
        register_setting('uc_lms_settings', 'uc_drive_materials_folder', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_drive_sync_enabled');
        register_setting('uc_lms_settings', 'uc_drive_protect_downloads');
        register_setting('uc_lms_settings', 'uc_zoho_client_id', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_zoho_client_secret', ['sanitize_callback' => ['UC_LMS_Meeting_Zoho', 'keep_secret']]);
        register_setting('uc_lms_settings', 'uc_zoho_zsoid', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_zoho_presenter_id', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('uc_lms_settings', 'uc_zoho_dc', ['sanitize_callback' => ['UC_LMS_Meeting_Zoho', 'sanitize_dc']]);
        register_setting('uc_lms_settings', 'uc_ai_api_key', ['sanitize_callback' => function ($value) {
            $value = trim((string)$value);
            return $value === '' ? (string)get_option('uc_ai_api_key', '') : sanitize_text_field($value);
        }]);
        register_setting('uc_lms_settings', 'uc_ai_credit_balance', ['sanitize_callback' => function ($value) { return (string)max(0, (float)$value); }]);
        register_setting('uc_lms_settings', 'uc_jobs_api_url', ['sanitize_callback' => 'esc_url_raw']);
        register_setting('uc_lms_settings', 'uc_career_shared_token', ['sanitize_callback' => function ($value) {
            $value = trim((string)$value);
            return $value === '' ? (string)get_option('uc_career_shared_token', '') : sanitize_text_field($value);
        }]);
        register_setting('uc_lms_settings', 'uc_role_features', ['sanitize_callback' => function ($value) {
            $roles = ['coordinator','trainer','student'];
            $pages = ['dashboard','courses','batches','classes','practice','materials','people','placement','announcements','messages','reports','profile'];
            $posted = is_array($value) ? $value : [];
            $out = [];
            foreach ($roles as $role) {
                foreach ($pages as $page) $out[$role][$page] = empty($posted[$role][$page]) ? 0 : 1;
            }
            return $out;
        }]);
    }

    public function admin_assets($hook) {
        if (strpos($hook, 'uc-') === false && (empty($_GET['page']) || strpos($_GET['page'], 'uc-') === false)) return;
        if (strpos($hook, 'uc-settings') !== false || (isset($_GET['page']) && $_GET['page'] === 'uc-settings')) {
            wp_enqueue_media();
        }
        wp_register_style('uc-admin', false);
        wp_enqueue_style('uc-admin');
        wp_add_inline_style('uc-admin', '.uc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px}.uc-stat{background:#fff;border:1px solid #ddd;border-radius:10px;padding:20px}.uc-stat strong{display:block;font-size:28px;margin-top:6px}.uc-panel{background:#fff;border:1px solid #ddd;border-radius:10px;padding:20px;margin:16px 0}.uc-actions a{margin-right:8px}.uc-status{font-weight:600}.uc-ok{color:#15803d}.uc-warn{color:#b45309}.uc-danger{color:#b91c1c}.uc-small{font-size:12px;color:#666}.uc-branding-preview{display:inline-flex;align-items:center;justify-content:center;background:#0c1726;border:1px solid #1e293b;border-radius:12px;padding:12px 20px;min-width:140px;min-height:56px}');
    }

    public function admin_favicon() {
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if (strpos($page, 'uc-') === 0 || strpos($page, 'unicybers') === 0) {
            remove_action('admin_head', 'wp_site_icon', 99);
            echo class_exists('UC_LMS_Portal_Layout') ? UC_LMS_Portal_Layout::favicon_html() : '';
        }
    }

    public function admin_menu() {
        add_menu_page('UniCybers Academy', 'UniCybers LMS', 'manage_options', 'uc-lms', [$this, 'dashboard_page'], 'dashicons-welcome-learn-more', 26);
        add_submenu_page('uc-lms', 'Dashboard', 'Dashboard', 'manage_options', 'uc-lms', [$this, 'dashboard_page']);
        add_submenu_page('uc-lms', 'Courses', 'Courses', 'manage_options', 'uc-courses', [$this, 'courses_page']);
        add_submenu_page('uc-lms', 'Batches', 'Batches', 'manage_options', 'uc-batches', [$this, 'batches_page']);
        add_submenu_page('uc-lms', 'Students', 'Students', 'manage_options', 'uc-students', [$this, 'students_page']);
        add_submenu_page('uc-lms', 'Trainers', 'Trainers', 'manage_options', 'uc-trainers', [$this, 'trainers_page']);
        add_submenu_page('uc-lms', 'Live Classes', 'Live Classes', 'manage_options', 'uc-sessions', [$this, 'sessions_page']);
        add_submenu_page('uc-lms', 'Attendance', 'Attendance', 'manage_options', 'uc-attendance', [$this, 'attendance_page']);
        add_submenu_page('uc-lms', 'Materials', 'Materials', 'manage_options', 'uc-materials', [$this, 'materials_page']);
        add_submenu_page('uc-lms', 'Announcements', 'Announcements', 'manage_options', 'uc-announcements', [$this, 'announcements_page']);
        add_submenu_page('uc-lms', 'Settings', 'Settings', 'manage_options', 'uc-settings', [$this, 'settings_page']);
    }

    public function dashboard_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $counts = [
            'Courses'          => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $this->table('courses')),
            'Batches'          => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $this->table('batches')),
            'Students'         => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users} u INNER JOIN {$wpdb->usermeta} m ON m.user_id=u.ID WHERE m.meta_key='{$wpdb->prefix}capabilities' AND m.meta_value LIKE '%uc_student%'"),
            'Trainers'         => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users} u INNER JOIN {$wpdb->usermeta} m ON m.user_id=u.ID WHERE m.meta_key='{$wpdb->prefix}capabilities' AND m.meta_value LIKE '%uc_trainer%'"),
            'Upcoming Classes' => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $this->table('sessions') . " WHERE session_date>=CURDATE() AND status='scheduled'"),
            'Enrollments'      => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $this->table('enrolments') . " WHERE status='active'"),
        ];
        echo '<div class="wrap"><h1>UniCybers Academy LMS</h1><p>High-performance consolidated training operations dashboard.</p>';
        $this->render_notice();
        echo '<div class="uc-grid">';
        foreach ($counts as $k => $v) {
            echo '<div class="uc-stat"><span>' . esc_html($k) . '</span><strong>' . esc_html($v) . '</strong></div>';
        }
        echo '</div>';
        echo '<div class="uc-panel"><h2>Modular Architecture</h2><p>Refactored into dedicated high-performance domain modules with zero-overhead initialization.</p></div></div>';
    }

    public function courses_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $edit = absint($_GET['edit'] ?? 0);
        $course = $edit ? $wpdb->get_row($wpdb->prepare("SELECT * FROM " . $this->table('courses') . " WHERE id=%d", $edit)) : null;
        $rows = $wpdb->get_results("SELECT * FROM " . $this->table('courses') . " ORDER BY id DESC");

        echo '<div class="wrap"><h1>' . ($course ? 'Edit Course' : 'Courses') . '</h1>';
        $this->render_notice();
        echo '<div class="uc-panel"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field($course ? 'uc_update_course' : 'uc_save_course');
        echo '<input type="hidden" name="action" value="' . ($course ? 'uc_update_course' : 'uc_save_course') . '">';
        if ($course) echo '<input type="hidden" name="id" value="' . absint($course->id) . '">';
        echo '<table class="form-table">';
        echo '<tr><th>Name</th><td><input class="regular-text" name="name" required value="' . esc_attr($course->name ?? '') . '"></td></tr>';
        echo '<tr><th>Description</th><td><textarea name="description" rows="4" class="large-text">' . esc_textarea($course->description ?? '') . '</textarea></td></tr>';
        echo '<tr><th>Category</th><td><input class="regular-text" name="category" value="' . esc_attr($course->category ?? '') . '"></td></tr>';
        echo '<tr><th>Level</th><td><input class="regular-text" name="level" value="' . esc_attr($course->level ?? '') . '"></td></tr>';
        echo '<tr><th>Duration</th><td><input class="regular-text" name="duration" value="' . esc_attr($course->duration ?? '') . '" placeholder="Example: 8 weeks"></td></tr>';
        echo '<tr><th>Mode</th><td><select name="mode"><option value="live" ' . selected($course->mode ?? 'live', 'live', false) . '>Live</option><option value="self_paced" ' . selected($course->mode ?? '', 'self_paced', false) . '>Self paced</option><option value="blended" ' . selected($course->mode ?? '', 'blended', false) . '>Blended</option></select></td></tr>';
        echo '<tr><th>Outline</th><td><textarea name="outline" rows="5" class="large-text">' . esc_textarea($course->outline ?? '') . '</textarea></td></tr>';
        echo '</table>';
        submit_button($course ? 'Save Course' : 'Create Course');
        echo '</form></div>';

        echo '<h2>Existing Courses</h2><table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Mode</th><th>Status</th><th>Action</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $e = $this->url('uc-courses', ['edit' => $r->id]);
            $d = wp_nonce_url(admin_url('admin-post.php?action=uc_delete_course&id=' . $r->id), 'uc_delete_course_' . $r->id);
            echo '<tr><td>' . absint($r->id) . '</td><td>' . esc_html($r->name) . '</td><td>' . esc_html($r->category) . '</td><td>' . esc_html($r->mode) . '</td><td>' . esc_html($r->status) . '</td><td class="uc-actions"><a href="' . esc_url($e) . '">Edit</a><a href="' . esc_url($d) . '" onclick="return confirm(\'Delete course?\')">Delete</a></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function handle_save_course() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_course')) wp_die('Not allowed');
        global $wpdb;
        $name = sanitize_text_field($_POST['name'] ?? '');
        if (!$name) wp_die('Course name required');
        $slug = sanitize_title($name) . '-' . wp_rand(100, 999);
        $wpdb->insert($this->table('courses'), [
            'name'        => $name,
            'slug'        => $slug,
            'description' => wp_kses_post($_POST['description'] ?? ''),
            'category'    => sanitize_text_field($_POST['category'] ?? ''),
            'level'       => sanitize_text_field($_POST['level'] ?? ''),
            'duration'    => sanitize_text_field($_POST['duration'] ?? ''),
            'mode'        => sanitize_key($_POST['mode'] ?? 'live'),
            'outline'     => wp_kses_post($_POST['outline'] ?? ''),
            'created_at'  => $this->now(),
            'updated_at'  => $this->now()
        ]);
        $this->audit('course', $wpdb->insert_id, 'create', null, $_POST);
        $this->redirect('uc-courses', $this->notice('success', 'Course created.'));
    }

    public function handle_update_course() {
        if (!$this->can_manage() || !check_admin_referer('uc_update_course')) wp_die('Not allowed');
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        $before = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . $this->table('courses') . " WHERE id=%d", $id), ARRAY_A);
        $wpdb->update($this->table('courses'), [
            'name'        => sanitize_text_field($_POST['name'] ?? ''),
            'description' => wp_kses_post($_POST['description'] ?? ''),
            'category'    => sanitize_text_field($_POST['category'] ?? ''),
            'level'       => sanitize_text_field($_POST['level'] ?? ''),
            'duration'    => sanitize_text_field($_POST['duration'] ?? ''),
            'mode'        => sanitize_key($_POST['mode'] ?? 'live'),
            'outline'     => wp_kses_post($_POST['outline'] ?? ''),
            'updated_at'  => $this->now()
        ], ['id' => $id]);
        $this->audit('course', $id, 'update', $before, $_POST);
        $this->redirect('uc-courses', $this->notice('success', 'Course updated.'));
    }

    public function handle_delete_course() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_GET['id'] ?? 0);
        check_admin_referer('uc_delete_course_' . $id);
        global $wpdb;
        $used = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . $this->table('batches') . " WHERE course_id=%d", $id));
        if ($used) $this->redirect('uc-courses', $this->notice('error', 'Course has batches and cannot be deleted.'));
        $wpdb->delete($this->table('courses'), ['id' => $id], ['%d']);
        $this->audit('course', $id, 'delete');
        $this->redirect('uc-courses', $this->notice('success', 'Course deleted.'));
    }

    // Pass-through calls to remaining pages
    private function legacy() {
        if (class_exists('UC_LMS_Admin_Legacy_Handlers')) return UC_LMS_Admin_Legacy_Handlers::instance();
        if (class_exists('UC_Academy_LMS')) return UC_Academy_LMS::instance();
        return null;
    }

    public function batches_page() { if ($h = $this->legacy()) $h->batches_page(); }
    public function students_page() { if ($h = $this->legacy()) $h->students_page(); }
    public function trainers_page() { if ($h = $this->legacy()) $h->trainers_page(); }
    public function sessions_page() { if ($h = $this->legacy()) $h->sessions_page(); }
    public function attendance_page() { if ($h = $this->legacy()) $h->attendance_page(); }
    public function materials_page() { if ($h = $this->legacy()) $h->materials_page(); }
    public function announcements_page() { if ($h = $this->legacy()) $h->announcements_page(); }
    public function settings_page() { if ($h = $this->legacy()) $h->settings_page(); }

    public function handle_save_batch() { if ($h = $this->legacy()) $h->save_batch(); }
    public function handle_update_batch() { if ($h = $this->legacy()) $h->update_batch(); }
    public function handle_delete_batch() { if ($h = $this->legacy()) $h->delete_batch(); }
    public function handle_generate_schedule() { if ($h = $this->legacy()) $h->generate_schedule_action(); }
    public function handle_save_student() { if ($h = $this->legacy()) $h->save_student(); }
    public function handle_enrol_student() { if ($h = $this->legacy()) $h->enrol_student(); }
    public function handle_remove_enrolment() { if ($h = $this->legacy()) $h->remove_enrolment(); }
    public function handle_save_trainer() { if ($h = $this->legacy()) $h->save_trainer(); }
    public function handle_assign_trainer_batch() { if ($h = $this->legacy()) $h->assign_trainer_batch(); }
    public function handle_save_session() { if ($h = $this->legacy()) $h->save_session(); }
    public function handle_update_session() { if ($h = $this->legacy()) $h->update_session(); }
    public function handle_delete_session() { if ($h = $this->legacy()) $h->delete_session(); }
    public function handle_save_attendance() { if ($h = $this->legacy()) $h->save_attendance(); }
    public function handle_save_material() { if ($h = $this->legacy()) $h->save_material(); }
    public function handle_delete_material() { if ($h = $this->legacy()) $h->delete_material(); }
    public function handle_save_announcement() { if ($h = $this->legacy()) $h->save_announcement(); }
    public function handle_create_zoom() { if ($h = $this->legacy()) $h->create_zoom(); }
    public function handle_update_zoom() { if ($h = $this->legacy()) $h->update_zoom(); }
    public function handle_test_zoom() { if ($h = $this->legacy()) $h->test_zoom(); }
    public function handle_cleanup_duplicates() { if ($h = $this->legacy()) $h->cleanup_duplicates(); }
    public function handle_sync_recording() { if ($h = $this->legacy()) $h->sync_recording(); }
    public function handle_sync_all_recordings() { if ($h = $this->legacy()) $h->sync_all_recordings(); }
}
