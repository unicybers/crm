<?php
/**
 * UniCybers Academy LMS: Portal Document Layout & Shell Renderer.
 *
 * Orchestrates the application chrome: HTML document shell, responsive command rail,
 * top bar navigation, theme switcher, modal wrapper, and footer.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Layout {

    /**
     * Render the entire document chrome and page container.
     *
     * @param UC_LMS_Portal $portal
     * @param string $page
     */
    public static function render_shell($portal, $page) {
        $portal->forbid_cache();
        $user = wp_get_current_user();
        $name = $user->display_name ?: $user->user_login;
        $role = $portal->role();
        $role_label = [
            'super_admin' => 'Super Admin',
            'coordinator' => 'Coordinator',
            'hr'          => 'Placement HR',
            'trainer'     => 'Trainer',
            'student'     => 'Student'
        ][$role] ?? '';
        $asset = plugins_url('assets/', UC_LMS_FILE);
        $ver = UC_LMS_Portal::VERSION;

        $nav = '';
        foreach ($portal->nav_pages() as $p) {
            $on = ($p === $page || ($page === 'view' && $p === 'classes') || ($page === 'classroom' && $p === 'courses'));
            $nav .= '<a class="nav i-' . $p . ($on ? ' on' : '') . '" href="' . esc_url($portal->url($p)) . '"' . ($on ? ' aria-current="page"' : '') . '><span class="ico">' . $portal->icon($p) . '</span><span>' . $portal->e($portal->nav_label($p)) . '</span></a>';
        }
        $body = $portal->content($page);
        $title = $page === 'view' ? 'Viewer' : ($page === 'classroom' ? 'Class Room' : ($portal->nav_label($page) ?: 'Portal'));
        $notice_count = $portal->recent_notice_count();

        $brand = $portal->brand();
        $source_master_logo = 'https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp';
        $is_unicybers_home_brand = (!empty($brand->is_home) && (int)$brand->is_home === 1)
            || (strtolower((string)($brand->slug ?? '')) === 'unicybers')
            || (strtolower((string)($brand->name ?? '')) === 'unicybers' && strtoupper((string)($brand->product_label ?? 'ACADEMY')) === 'ACADEMY');
        $logo = esc_url($is_unicybers_home_brand ? $source_master_logo : ($brand->logo_url ?: $asset . 'unicybers-emblem.svg'));

        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<title>' . $portal->e($title) . ' · ' . $portal->e($brand->legal_name ?: $brand->name) . '</title>';
        echo '<script>try{document.documentElement.setAttribute("data-theme",localStorage.getItem("uc_lms_theme")||"dark")}catch(e){}</script>';
        echo self::favicon_html();
        echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
        echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@600;700&family=JetBrains+Mono:wght@500&display=swap">';
        echo '<link rel="stylesheet" href="' . esc_url($asset . 'portal.min.css?v=' . $ver) . '">';
        if (class_exists('UC_Academy_LMS')) {
            echo '<style>' . UC_Academy_LMS::instance()->brand_css($brand) . '</style>';
        }
        echo '</head><body class="pg-' . esc_attr($page) . '">';
        echo '<div class="app"><div class="scrim" id="scrim"></div>';

        /* Command rail */
        $labs_url = defined('UC_LMS_Portal::LABS') ? UC_LMS_Portal::LABS : 'https://labs.unicybers.com';
        $brand_line1 = strtoupper((string)($brand->name ?: 'UNICYBERS'));
        $brand_line2 = strtoupper((string)($brand->product_label ?: 'ACADEMY'));
        if ($is_unicybers_home_brand) {
            echo '<aside id="rail"><a class="brand" href="' . esc_url($portal->url('dashboard')) . '" aria-label="UniCybers Academy">';
            echo '<span class="brand-mark"><img src="' . esc_url($asset . 'unicybers-logo.png') . '" alt="" width="580" height="290" decoding="async"></span>';
            echo '<span class="brand-copy"><strong id="ucBrandName">UNICYBERS</strong><em id="ucBrandSub">ACADEMY</em></span></a>';
        } else {
            echo '<aside id="rail"><a class="brand" href="' . esc_url($portal->url('dashboard')) . '" aria-label="' . $portal->e($brand_line1 . ' ' . $brand_line2) . '">';
            echo '<span class="brand-mark"><img src="' . $logo . '" alt="" width="40" height="40" decoding="async"></span>';
            echo '<span class="brand-copy"><strong id="ucBrandName">' . $portal->e($brand_line1) . '</strong><em id="ucBrandSub">' . $portal->e($brand_line2) . '</em></span></a>';
        }
        echo '<nav class="navlist" aria-label="Main">' . $nav . '</nav>';
        echo '<div class="rail-foot"><a class="nav i-help' . ($page === 'help' ? ' on' : '') . '" href="' . esc_url($portal->url('help')) . '"><span class="ico">' . $portal->icon('help') . '</span><span>Help &amp; Support</span></a>';
        echo '<a class="nav i-labs" href="' . esc_url($labs_url) . '" target="_blank" rel="noopener"><span class="ico">' . $portal->icon('labs') . '</span><span>Labs Arena</span><i class="ext">↗</i></a></div>';
        echo '<div class="rail-me"><button class="rail-me-btn" id="meBtn" type="button" aria-haspopup="menu" aria-expanded="false"><span class="avatar">' . $portal->e($portal->initials($name)) . '</span><span class="me-copy"><strong>' . $portal->e($name) . '</strong><small>' . $portal->e($role_label) . '</small></span><span class="chev">' . $portal->icon('chev') . '</span></button>';
        echo '<div class="menu" id="meMenu" role="menu" hidden><div class="menu-head"><strong>' . $portal->e($name) . '</strong><small>' . $portal->e($user->user_email) . '</small></div>';
        echo '<a role="menuitem" href="' . esc_url($portal->url('help') . '#account') . '">' . $portal->icon('key') . 'Change password</a>';
        echo '<a role="menuitem" class="danger" href="' . esc_url($portal->url('logout')) . '">' . $portal->icon('signout') . 'Sign out</a></div></div></aside>';

        /* Top bar */
        echo '<main><header class="topbar"><button id="menu" class="iconbtn only-m" aria-label="Open navigation"><svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>';
        echo '<div class="pagehead"><h1>' . $portal->e($page === 'view' ? 'Viewer' : ($page === 'classroom' ? 'Class Room' : $portal->nav_label($page))) . '</h1></div>';
        if ($btn = self::page_action_button($portal, $page)) echo '<div class="page-actions">' . $btn . '</div>';
        echo '<div class="search-wrap"><label class="search"><span>' . $portal->icon('search') . '</span><input id="pageFilter" type="search" placeholder="Search portal &amp; pages..." aria-label="Search across all pages" autocomplete="off"><kbd>/</kbd></label><div id="globalSearchResults" class="search-popover" hidden></div></div>';
        echo '<div class="tools"><button class="iconbtn" id="themeToggle" type="button" aria-label="Switch theme"><span class="t-sun">' . $portal->icon('sun') . '</span><span class="t-moon">' . $portal->icon('moon') . '</span></button>';
        $demo_guest = class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo($user);
        if (!$demo_guest) echo '<a class="iconbtn bell" href="' . esc_url($portal->url('announcements')) . '" aria-label="Announcements">' . $portal->icon('bell') . ($notice_count ? '<b>' . (int)$notice_count . '</b>' : '') . '</a>';
        echo '</div></header>';

        echo '<section class="content c-' . esc_attr($page) . '" id="content">' . $portal->flash() . $body . self::footer($portal) . '</section></main></div>';
        echo '<dialog id="modal" class="modal"><div class="modal-in" id="modalIn"></div></dialog>';
        $search_api = function_exists('rest_url') ? rest_url(UC_LMS_Portal::REST_NS . '/global-search') : '';
        $esc_fn = function_exists('esc_url_raw') ? 'esc_url_raw' : 'esc_url';
        $guide = class_exists('UC_LMS_Module_Support') ? UC_LMS_Module_Support::guide_for($portal->role()) : [];
        echo '<script>window.UC_REST_SEARCH="' . $esc_fn($search_api) . '";window.UC_REST_NONCE="' . esc_js(wp_create_nonce('wp_rest')) . '";window.UC_GUIDE=' . wp_json_encode($guide) . ';window.UC_GUIDE_URL="' . esc_url($portal->url('help')) . '#guide";</script>';
        $alert = (string)get_option('uc_privacy_alert', '');
        if ($portal->role() === 'super_admin' && $alert !== '') {
            echo '<div class="flash warn">Privacy alert: '.esc_html($alert).'. It is also in the audit log.</div>';
        }
        echo '<script>window.UC_PRIVACY=' . wp_json_encode(['url'=>esc_url_raw(rest_url(UC_LMS_Portal::REST_NS.'/privacy-alert')),'nonce'=>wp_create_nonce('wp_rest')]) . ';</script>';
        echo '<script src="' . esc_url($asset . 'portal.min.js?v=' . $ver) . '" defer></script></body></html>';
    }

    /**
     * Render the topbar action button (Add Course, Add Batch, etc.).
     *
     * @param UC_LMS_Portal $portal
     * @param string $page
     * @return string
     */
    public static function page_action_button($portal, $page) {
        switch ($page) {
            case 'courses':
                return $portal->ops() ? '<button type="button" class="btn primary" data-edit-course=\'{"id":0,"mode":"live","status":"active","enrolment_open":1}\'>' . $portal->icon('plus') . 'Add Course</button>' : '';
            case 'batches':
                return $portal->ops() ? '<button type="button" class="btn primary" data-edit-batch=\'{"id":0,"mode":"online","status":"active","currency":"INR"}\'>' . $portal->icon('plus') . 'Add Batch</button>' : '';
            case 'classes':
                return $portal->staff() ? '<button type="button" class="btn primary" data-edit-class=\'{"id":0,"platform":"zoom"}\'>' . $portal->icon('plus') . 'Schedule Class</button>' : '';
            case 'materials': {
                $b = $portal->staff() ? '<button type="button" class="btn primary" data-edit-material=\'{"id":0}\'>' . $portal->icon('plus') . 'Add Material</button>' : '';
                if ($portal->ops()) {
                    $b = '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_drive_materials_sync">' . wp_nonce_field('uc_portal_drive_materials_sync', '_wpnonce', true, false) . '<button class="btn ghost" type="submit">' . $portal->icon('folder') . 'Sync Drive</button></form>' . '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_sync_recordings">' . wp_nonce_field('uc_portal_sync_recordings', '_wpnonce', true, false) . '<button class="btn ghost" type="submit">' . $portal->icon('play') . 'Sync Recordings</button></form>' . $b;
                }
                return $b;
            }
            case 'practice':
                return $portal->staff() ? '<button type="button" class="btn primary" data-edit-practice=\'{"id":0,"kind":"assignment"}\'>' . $portal->icon('plus') . 'Add Practice / Mock</button>' : '';
            case 'people':
                return '';
        }
        return '';
    }

    /**
     * Render portal footer.
     *
     * @param UC_LMS_Portal $portal
     * @return string
     */
    public static function footer($portal) {
        $links = '<a href="' . esc_url(home_url('/legal/')) . '">Legal</a>';
        $links .= '<a href="' . esc_url($portal->url('help')) . '">Support</a>';
        $legal = esc_html($portal->brand()->legal_name ?: $portal->brand()->name ?: 'UniCybers Academy');
        return '<footer class="foot"><span>© ' . esc_html(date('Y')) . ' ' . $legal . '</span><span class="foot-links">' . $links . '</span></footer>';
    }

    /**
     * Empty state component.
     *
     * @param UC_LMS_Portal $portal
     * @param string $title
     * @param string $text
     * @param string $icon
     * @return string
     */
    public static function empty_state($portal, $title, $text, $icon = 'file') {
        return '<div class="empty"><span class="empty-ico">' . $portal->icon($icon) . '</span><strong>' . $portal->e($title) . '</strong><p>' . $portal->e($text) . '</p></div>';
    }

    /**
     * Pill badge component.
     *
     * @param UC_LMS_Portal $portal
     * @param string $text
     * @param string $tone
     * @return string
     */
    public static function pill($portal, $text, $tone = 'mut') {
        return '<span class="pill p-' . esc_attr($tone) . '">' . $portal->e($text) . '</span>';
    }

    /**
     * Generate HTML favicon link tags using the custom uploaded logo or fallback logo.
     *
     * @return string
     */
    public static function favicon_html() {
        $logo_url = esc_url(plugins_url('assets/favicon.png', UC_LMS_FILE));
        return '<link rel="icon" type="image/png" href="' . $logo_url . '">' . "\n" .
               '<link rel="shortcut icon" href="' . $logo_url . '">' . "\n" .
               '<link rel="apple-touch-icon" href="' . $logo_url . '">' . "\n";
    }
}
