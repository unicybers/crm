<?php
if (!defined('ABSPATH')) exit;

class UC_CRM_Import {
    public static function master_path() {
        return UC_CRM_DIR . 'data/master.json';
    }

    public static function manifest_path() {
        return UC_CRM_DIR . 'data/manifest.json';
    }

    public static function bundled_manifest() {
        $path = self::manifest_path();
        if (!file_exists($path)) return array();
        $data = json_decode(file_get_contents($path), true);
        return is_array($data) ? $data : array();
    }

    public static function import_master(UC_CRM_Book $book) {
        $path = self::master_path();
        if (!file_exists($path)) {
            return new WP_Error('uc_crm_master', 'Master data file is missing from the plugin.');
        }
        $raw = file_get_contents($path);
        $data = json_decode($raw, true);
        if (!is_array($data) || empty($data['sheets']) || !is_array($data['sheets'])) {
            return new WP_Error('uc_crm_master', 'Master data file could not be read.');
        }
        $book->replace_all($data['sheets']);
        $manifest = self::bundled_manifest();
        $expected = isset($manifest['sheets']) ? $manifest['sheets'] : array();
        $actual = $book->counts();
        $mismatch = array();
        foreach ($expected as $name => $meta) {
            $want = isset($meta['rows']) ? (int) $meta['rows'] : 0;
            $got = isset($actual[$name]) ? (int) $actual[$name] : -1;
            if ($want !== $got) $mismatch[$name] = array('expected' => $want, 'imported' => $got);
        }
        $summary = array(
            'imported_at' => current_time('mysql'),
            'source' => isset($manifest['source']) ? $manifest['source'] : 'master.json',
            'sheets' => count($actual),
            'rows' => array_sum($actual),
            'counts' => $actual,
            'mismatch' => $mismatch,
        );
        update_option('uc_crm_import', $summary, false);
        if ($mismatch) {
            return new WP_Error('uc_crm_mismatch', 'Import finished, but some sheet counts do not match the workbook.', $summary);
        }
        return $summary;
    }
}
