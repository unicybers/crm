<?php
/**
 * UniCybers Academy LMS: Audit Trail & Equipment Inventory Module.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Audit {
    public static function render_audit($portal){
        global $wpdb;
        if ($portal->role()!=='super_admin') return $portal->empty_state('Not available','Audit log is Super Admin only.','shield');
        $rows = $portal->has_table('audit') ? $wpdb->get_results("SELECT a.*, u.display_name, u.user_email FROM {$portal->t('audit')} a LEFT JOIN {$wpdb->users} u ON u.ID=a.by_user_id ORDER BY a.id DESC LIMIT 500") : [];
        $o = '<section class="panel flush" id="audit"><div class="ph" style="padding:16px 18px 0"><div><span class="eyebrow">SUPER ADMIN</span><h3>Audit log</h3></div></div><div class="tablewrap people-scroll"><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Entity</th><th>Id</th><th>Detail</th></tr></thead><tbody>';
        if (!$rows) $o .= '<tr><td colspan="6">No audit rows yet. Creates, updates and deletes now write a full row.</td></tr>';
        foreach ($rows as $r) {
            $who = $r->display_name ?: ($r->user_email ?: 'System');
            $email = $r->user_email ?: '';
            $when = $r->at_time ?? '';
            $o .= '<tr data-q="'.esc_attr(strtolower($who.' '.$email.' '.$r->action.' '.$r->entity.' '.$r->detail)).'"><td class="mono-s">'.$portal->e($when).'</td><td><strong>'.$portal->e($who).'</strong><small class="sub">'.$portal->e($email).'</small></td><td>'.$portal->e($r->action).'</td><td>'.$portal->e($r->entity).'</td><td class="mono-s">'.$portal->e($r->entity_id).'</td><td>'.$portal->e($r->detail).'</td></tr>';
        }
        return $o.'</tbody></table></div></section>';
    }

    public static function render_inventory($portal){
        $items = ['Login','User accounts','Roles','Student profiles','Courses','Batches','Enrolments','Recurring schedules','Classes','Zoom','Google Meet','Recordings','Attendance','Materials','Announcements','Messaging','Access requests','Devices','Audit logs','Demo leads','Documents'];
        $o = '<section class="panel"><div class="ph"><div><span class="eyebrow">SOC TRAINING LMS</span><h3>Master feature inventory</h3></div></div><p class="muted">Checklist from UniCybers_Old_LMS_Master_Feature_Inventory. Plugin 2.8.10 keeps 2.8.6 chrome. Placement Desk is the Career ID / Job DNA MVP — not an employer portal.</p><ul class="gitem" style="list-style:none;padding:0">';
        foreach ($items as $it) $o .= '<li class="req"><strong>'.$portal->e($it).'</strong>'.$portal->pill('In portal','ok').'</li>';
        $o .= '<li class="req"><strong>Placement Desk</strong>'.$portal->pill('In portal','ok').'</li>';
        return $o.'</ul></section>';
    }
}
