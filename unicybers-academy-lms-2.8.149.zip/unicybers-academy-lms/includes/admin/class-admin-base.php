<?php
/**
 * UniCybers Academy LMS: Admin Base Controller.
 */
if (!defined('ABSPATH')) exit;

abstract class UC_LMS_Admin_Base {
    public function can_manage() { return current_user_can('manage_options'); }
    public function table($n) { return UC_LMS_Database::table($n); }
    public function now() { return current_time('mysql'); }
    public function url($page, $args = []) { return add_query_arg(array_merge(['page' => $page], $args), admin_url('admin.php')); }
    public function redirect($page, $args = []) { wp_safe_redirect($this->url($page, $args)); exit; }
    public function notice($type, $message) { return ['uc_notice' => $type, 'uc_message' => rawurlencode($message)]; }

    public function render_notice() {
        if (empty($_GET['uc_notice'])) return;
        $type = sanitize_key(wp_unslash($_GET['uc_notice']));
        $msg = isset($_GET['uc_message']) ? rawurldecode(sanitize_text_field(wp_unslash($_GET['uc_message']))) : '';
        if ($msg) echo '<div class="notice ' . ($type === 'error' ? 'notice-error' : 'notice-success') . ' is-dismissible"><p>' . esc_html($msg) . '</p></div>';
    }

    public function audit($entity, $id, $action, $before = null, $after = null, $detail = '') {
        global $wpdb;
        $wpdb->insert($this->table('audit'), [
            'entity'      => $entity,
            'entity_id'   => $id,
            'action'      => $action,
            'by_user_id'  => get_current_user_id(),
            'at_time'     => $this->now(),
            'before_json' => $before ? wp_json_encode($before) : null,
            'after_json'  => $after ? wp_json_encode($after) : null,
            'detail'      => $detail
        ]);
    }

    public function trainer_users() {
        return get_users(['role' => 'uc_trainer', 'orderby' => 'display_name', 'order' => 'ASC']);
    }

    public function student_users() {
        return get_users(['role' => 'uc_student', 'orderby' => 'display_name', 'order' => 'ASC']);
    }

    public function refresh_session_links($batch_id) {
        if (class_exists('UC_LMS_Admin_Batches')) {
            return UC_LMS_Admin_Batches::instance()->refresh_session_links($batch_id);
        }
    }
}
