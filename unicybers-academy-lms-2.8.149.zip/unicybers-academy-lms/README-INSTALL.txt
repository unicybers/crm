UniCybers Academy LMS 2.8.117 — Sidebar Brand Alignment Correction
====================================================================

This is a complete plugin package based on the consolidated UniCybers LMS 2.8.115 master and the subsequent 2.8.116 sidebar layout update.

SIDEBAR BRANDING
- Uses only the supplied master image URL: https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp
- Correctly treats the supplied source as a square image.
- Crops the original globe area to the left side of the sidebar lockup.
- Places UNICYBERS above orange ACADEMY to the right of the globe.
- Measures both word lines at runtime and scales the shorter line to the same visible width.
- No generated or substitute logo asset is used.

INSTALLATION
1. Back up the complete WordPress database and the existing plugin directory.
2. Replace the files in /wp-content/plugins/unicybers-academy-lms/ with this ZIP, preserving the plugin folder name.
3. Do not uninstall the plugin or delete its database tables.
4. Purge LiteSpeed and Cloudflare caches, then hard-refresh the browser.
5. Confirm the plugin version is 2.8.117.

This package has undergone PHP and JavaScript syntax checks and ZIP integrity validation. Confirm the final appearance on the production site after cache purge.
