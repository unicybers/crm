/* Edit this file when you want prices on the page again.
   show: false hides every amount. Set show: true, then change the numbers.
   Yearly is ten months. books is the Finance card. campus is unused on the page. */
window.UC_PRICES = {
  show: false,
  academy:   { monthUsd: 29,  yearUsd: 290,  monthInr: 1499,  yearInr: 14990 },
  placement: { monthUsd: 15,  yearUsd: 150,  monthInr: 999,   yearInr: 9990 },
  books:     { monthUsd: 15,  yearUsd: 150,  monthInr: 999,   yearInr: 9990 },
  crm:       { monthUsd: 19,  yearUsd: 190,  monthInr: 1249,  yearInr: 12490 },
  suite:     { monthUsd: 59,  yearUsd: 590,  monthInr: 3499,  yearInr: 34990 },
  campus:    { monthUsd: 199, yearUsd: 1990, monthInr: 12999, yearInr: 129990 }
};
