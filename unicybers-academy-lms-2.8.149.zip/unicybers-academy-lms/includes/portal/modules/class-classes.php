<?php
/**
 * UniCybers Academy LMS: Classes Schedule Module.
 *
 * Manages live sessions, upcoming batches classes, past recordings,
 * attendance heartbeat tracker, and recurring schedule creator.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Classes {
    public static function render($portal) {
        if (class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo(wp_get_current_user())) {
            return UC_LMS_Module_Dashboard::demo_card($portal);
        }
        $editable = UC_LMS_Portal_Context::staff();
        // Limit to 120 sessions to maintain fast query response time
        $rows = $portal->sessions('1=1', 's.session_date,s.start_time', 120);

        $o = '';
        if (!$rows) {
            return $o . ($editable ? self::modal_tpl($portal) : '') . $portal->empty_state('No classes yet', 'Scheduled classes will appear here.', 'classes');
        }

        $live = [];
        $up   = [];
        $done = [];

        foreach ($rows as $s) {
            $w = $portal->window($s);
            if ($portal->cancelled($s) || $w['done']) {
                $done[] = $s;
            } elseif ($w['open']) {
                $live[] = $s;
            } else {
                $up[] = $s;
            }
        }

        if ($live) {
            $o .= '<section class="panel accent-live"><div class="ph"><div><span class="eyebrow"><i class="dot live"></i>HAPPENING NOW</span><h3>Live classes</h3></div></div>' . $portal->class_rows($live, $editable) . '</section>';
        }

        $o .= '<div class="groups">';
        if ($done) {
            $past = array_reverse($done);
            $batch_opts = [];
            foreach ($past as $s) $batch_opts[(int)$s->batch_id] = (string)$s->batch_name;
            $tools = '<div class="class-tools"><label>Batch <select data-class-batch><option value="">All batches</option>';
            foreach ($batch_opts as $bid => $bname) $tools .= '<option value="'.(int)$bid.'">'.$portal->e($bname).'</option>';
            $tools .= '</select></label><label>Sort <select data-class-sort aria-label="Sort"><option value="date-desc">Newest to oldest</option><option value="date-asc">Oldest to newest</option><option value="name-asc">Name, A to Z</option><option value="name-desc">Name, Z to A</option><option value="batch-asc">Batch, A to Z</option></select></label></div>';
            $o .= '<details class="grp"><summary><span class="g-dot"></span><span class="g-copy"><strong>Class Room</strong><small>' . count($done) . ' finished classes. Click to expand.</small></span><span class="chev">' . $portal->icon('chev') . '</span></summary>' . $tools . $portal->class_rows($past, $editable) . '</details>';
        }

        $groups = [];
        foreach ($up as $s) {
            $groups[$s->batch_name][] = $s;
        }

        foreach ($groups as $bn => $list) {
            $o .= '<details class="grp"><summary><span class="g-dot"></span><span class="g-copy"><strong>' . $portal->e($bn) . '</strong><small>' . count($list) . ' upcoming · next ' . $portal->e($portal->fdate($list[0]->session_date)) . '</small></span><span class="chev">' . $portal->icon('chev') . '</span></summary>' . $portal->class_rows($list, $editable) . '</details>';
        }
        $o .= '</div>';

        if (UC_LMS_Portal_Context::role() === 'student' && $live) {
            $o .= '<script>window.UC_HEARTBEAT=' . wp_json_encode([
                'url'   => esc_url_raw(rest_url('uc-lms/v1/attendance/heartbeat')),
                'nonce' => wp_create_nonce('wp_rest'),
                'ids'   => array_map(function($s) { return (int)$s->id; }, $live)
            ]) . ';</script>';
        }

        if ($editable) {
            $o .= self::modal_tpl($portal);
        }

        return $o;
    }

    public static function modal_tpl($portal) {
        global $wpdb;
        $ids = UC_LMS_Portal_Context::batch_ids();
        $tb_batches = UC_LMS_Database::table('batches');
        $in_ids = UC_LMS_Portal_Context::in_ids($ids);

        $batches = $ids ? $wpdb->get_results("SELECT id, name, default_meeting_provider, mode FROM `$tb_batches` WHERE id IN ({$in_ids}) ORDER BY name") : [];

        $o = '<template id="tplClass"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="form"><input type="hidden" name="action" value="uc_portal_session_save">' . wp_nonce_field('uc_portal_session_save', '_wpnonce', true, false) . '<input type="hidden" name="id"><input type="hidden" name="do" value="save">';
        $o .= $portal->mhead('SCHEDULE', 'Add Class', true) . '<div class="class-grid">';
        $o .= '<label>Batch<select name="batch_id" required><option value="">Select a batch</option>';
        foreach ($batches as $b) {
            $o .= '<option value="' . (int)$b->id . '" data-provider="' . esc_attr($b->default_meeting_provider ?: 'zoom') . '" data-mode="' . esc_attr($b->mode ?: 'online') . '">' . $portal->e($b->name) . '</option>';
        }
        $o .= '</select></label><label>Title<input name="title" required placeholder="Training · Incident triage"></label>';
        $o .= '<label>Date<input type="date" name="session_date" required></label><label>Repeat through<input type="date" name="repeat_until"></label>';
        $o .= '<label>Platform<select name="platform"><option value="zoom">Zoom</option><option value="google_meet">Google Meet</option><option value="teams">Microsoft Teams</option><option value="zoho">Zoho Meeting</option><option value="offline">Classroom</option></select></label>';
        $o .= '<label>Start time<input type="time" name="start_time" required></label><label>End time<input type="time" name="end_time"></label>';
        $o .= '<label>Timezone<select name="timezone">' . $portal->tz_options('Asia/Kolkata') . '</select></label><label>Meeting link<input name="join_url" placeholder="Paste Zoom, Meet, Teams or Zoho link"></label>';
        $o .= '<label>Passcode (optional)<input name="passcode"></label><label data-editonly>Status<select name="status"><option value="scheduled">Scheduled</option><option value="live">Live</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></label>';
        $o .= '<label class="span-2" data-editonly>Recording link (optional)<input name="recording_url" placeholder="Google Drive file link (Anyone with the link → Viewer)"></label></div>';
        $o .= '<div data-newonly class="repeat-panel"><div class="msub">Recurring days</div><div class="check-row weekday-picker" role="group" aria-label="Recurring weekdays">';
        $days = ['2'=>'Monday','3'=>'Tuesday','4'=>'Wednesday','5'=>'Thursday','6'=>'Friday','7'=>'Saturday','1'=>'Sunday'];
        foreach ($days as $k => $label) {
            $short = substr($label, 0, 3);
            $o .= '<label class="daychk" title="'.$portal->e($label).'"><input type="checkbox" name="repeat_days[]" value="' . esc_attr($k) . '"><span class="day-short">' . esc_html($short) . '</span><span class="day-full">' . esc_html($label) . '</span></label>';
        }
        $o .= '</div></div>';
        $o .= '<input type="hidden" name="recurring_group" value=""><input type="hidden" name="recurring_days" value=""><input type="hidden" name="recurring_until" value="">';
        $o .= '<div class="recurrence-edit-controls" hidden><div class="msub">Recurring schedule <span class="sub">Choose which classes to change</span></div><div class="recurrence-scope"><label><input type="radio" name="edit_scope" value="single" checked><span><strong>This class only</strong><small>Separate it from the series</small></span></label><label><input type="radio" name="edit_scope" value="future"><span><strong>This and future classes</strong><small>Keep earlier sessions unchanged</small></span></label><label><input type="radio" name="edit_scope" value="series"><span><strong>Entire series</strong><small>Apply changes to every linked session</small></span></label></div></div>';

        $mfootL = '';
        if (UC_LMS_Portal_Context::ops()) {
            $mfootL = '<button type="button" class="btn danger sm" data-do="delete" data-confirm="Delete the classes selected above? This class only deletes one. This and future, or the entire series, deletes every matching class. Attendance for those classes is removed too.">Delete</button>';
        }

        $o .= '<div class="mfoot"><div class="mfoot-l" data-editonly>' . $mfootL . '</div><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary">Save</button></div></form></template>';

        return $o;
    }
}
