<?php
/**
 * UniCybers Academy LMS: User Guide, Help & Support Module.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Support {
    const WA = '918688022686';
    const SUPPORT_EMAIL = 'support@unicybers.com';
    const LABS = 'https://labs.unicybers.com';

    public static function guide_for($role){
        $file = dirname(UC_LMS_FILE).'/docs/unicybers-lms-guide.md';
        $raw = is_readable($file) ? (string)file_get_contents($file) : '';
        $staff = in_array($role, ['super_admin','coordinator','trainer'], true);
        $desk = in_array($role, ['super_admin','coordinator','hr'], true);
        $out = [];
        foreach (preg_split('/^## /m', $raw) as $part) {
            $part = trim($part);
            if (!preg_match('/^(.+)\Rrole:\s*(all|student|staff|super|hr)\R([\s\S]+)$/', $part, $m)) continue;
            $need = $m[2];
            $ok = $need === 'all'
                || ($need === 'student' && ($role === 'student' || $staff))
                || ($need === 'staff' && $staff)
                || ($need === 'hr' && $desk)
                || ($need === 'super' && $role === 'super_admin');
            if (!$ok) continue;
            $out[] = ['title'=>trim($m[1]), 'body'=>trim($m[3])];
        }
        return $out;
    }

    public static function render_guide($portal){
        $o = '<section class="panel" id="guide"><div class="ph"><div><span class="eyebrow">HOW TO USE</span><h3>Academy guide</h3></div></div>';
        $i = 0;
        foreach (self::guide_for($portal->role()) as $it) {
            $i++;
            $o .= '<details class="gitem"'.($i===1?' open':'').'><summary><span class="step">'.$i.'</span> '.$portal->e($it['title']).'<span class="chev">'.$portal->icon('chev').'</span></summary><p>'.nl2br($portal->e($it['body'])).'</p></details>';
        }
        if (!$i) $o .= '<p class="muted">The guide file is not in this copy.</p>';
        return $o.'</section>';
    }

    public static function rida_box($portal){
        return '<section class="panel" id="rida"><div class="ph"><div><span class="eyebrow">RIDA</span><h3>Ask the academy guide</h3></div></div><div class="rida-box"><label class="search rida-search"><span>'.$portal->icon('search').'</span><input id="ridaQ" type="search" placeholder="How do I schedule a class?" aria-label="Ask Rida"></label><div id="ridaA"><p class="muted">Rida answers from this academy guide only, and only the parts your role can see.</p></div></div></section>';
    }

    public static function render_help($portal){
        global $wpdb;
        $u = wp_get_current_user(); $ref = $portal->support_ref($u->user_email);
        $wa = 'https://wa.me/'.self::WA.'?text='.rawurlencode('LMS SUPPORT '.$ref.' - ');
        $mail = 'mailto:'.self::SUPPORT_EMAIL.'?subject='.rawurlencode('LMS SUPPORT '.$ref);
        $o = '<section class="panel" id="account"><div class="ph"><div><span class="eyebrow">ACCOUNT</span><h3>Change password</h3></div></div>';
        $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form"><input type="hidden" name="action" value="uc_portal_password">'.wp_nonce_field('uc_portal_password','_wpnonce',true,false);
        $o .= '<label>Current password<input type="password" name="old" autocomplete="current-password" required></label><div class="fgrid"><label>New password<input type="password" name="new" minlength="8" autocomplete="new-password" required></label><label>Repeat new password<input type="password" name="new2" minlength="8" autocomplete="new-password" required></label></div><div class="right"><button class="btn primary">Save password</button></div></form></section>';
        $o .= self::rida_box($portal).self::render_guide($portal);
        $o .= '<section class="panel" id="reach"><div class="ph"><div><span class="eyebrow">REACH THE ACADEMY</span><h3>Contact Super Admin</h3></div></div>';
        $o .= '<p class="muted">Students and staff use this to reach the academy. Quote the reference so the message is tied to your account without putting your email in the chat.</p>';
        $o .= '<div class="support">';
        $o .= '<a class="sup-card s-wa" href="'.esc_url($wa).'" target="_blank" rel="noopener"><span class="sup-ico">'.$portal->icon('wa').'</span><span><strong>WhatsApp</strong><small>Fastest for urgent help</small></span><i>›</i></a>';
        $o .= '<a class="sup-card s-mail" href="'.esc_url($mail).'"><span class="sup-ico">'.$portal->icon('mail').'</span><span><strong>Email</strong><small>'.$portal->e(self::SUPPORT_EMAIL).'</small></span><i>›</i></a>';
        $o .= '<div class="sup-card s-ref"><span class="sup-ico">'.$portal->icon('copy').'</span><span><strong>Your reference</strong><small id="refCode">'.$portal->e($ref).'</small></span><button type="button" class="btn ghost sm" data-copy="#refCode">Copy</button></div></div></section>';

        $devs = $portal->has_table('devices') ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$portal->t('devices')} WHERE user_id=%d ORDER BY last_seen DESC", $u->ID)) : [];
        $cur = $_COOKIE[UC_LMS_Security::COOKIE] ?? '';
        $o .= '<details class="set-fold" id="devices"><summary>Your devices</summary><div class="set-fold-body account-fold">';
        $o .= '<div class="span-2"><p class="muted">'.count($devs).' of '.UC_LMS_Security::device_limit($u->ID).' devices'.(user_can($u,'manage_options') ? '. Super Admin is exempt from the limit.' : '.').'</p>';
        if (!$devs) $o .= $portal->empty_state('No devices registered','Devices are added when you sign in.','device');
        foreach ($devs as $d) $o .= '<div class="dev"><span class="dev-ico">'.$portal->icon('device').'</span><span><strong>'.$portal->e($d->label ?: 'Device').($d->device_id===$cur?' '.$portal->pill('This device','ok'):'').'</strong><small>Last used '.$portal->e($portal->fdate($d->last_seen,'j M Y, g:i A')).'</small></span><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uc_portal_device_remove">'.wp_nonce_field('uc_portal_device_remove','_wpnonce',true,false).'<input type="hidden" name="id" value="'.(int)$d->id.'"><input type="hidden" name="self" value="1"><button class="btn ghost sm">Remove</button></form></div>';
        $o .= '</div></div></details>';
        return $o;
    }

    public static function demo_fold($portal){
        $open = !UC_LMS_Security::demo_closed();
        $meet = (string)get_option('uc_demo_meet_url');
        $link = home_url('/try-demo/');
        $rows = self::demo_rows();
        $o = '<div class="span-2"><p>Turn the public demo on, copy the link, and paste the trainer\'s Google Meet address. Guests use their own email and are numbered Demo 1 onward, up to 500. '.$portal->pill($open ? 'On' : 'Off', $open ? 'ok' : 'mut').'</p>';
        $o .= '<p>Public link: <code id="demoLink">'.$portal->e($link).'</code> <button type="button" class="btn ghost sm" data-copy="#demoLink">Copy</button></p>';
        $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form"><input type="hidden" name="action" value="uc_portal_demo_gate">'.wp_nonce_field('uc_portal_demo_gate','_wpnonce',true,false);
        $hours = (int)get_option('uc_demo_hours', 2);
        if (!in_array($hours, [1,2,3], true)) $hours = 2;
        $until = (int)get_option('uc_demo_until', 0);
        $o .= '<label>Trainer Google Meet link<input type="url" name="meet_url" value="'.esc_attr($meet).'" placeholder="https://meet.google.com/..."></label>';
        $o .= '<label>Session length<select name="hours"><option value="1"'.selected($hours,1,false).'>1 hour</option><option value="2"'.selected($hours,2,false).'>2 hours</option><option value="3"'.selected($hours,3,false).'>3 hours</option></select></label>';
        if ($open && $until) $o .= '<p class="hint">This demo closes at '.$portal->e(wp_date('g:i A', $until)).'. Guests are signed out then. It does not stay open for the day.</p>';
        $o .= '<div class="right"><button class="btn ghost" name="do" value="meet">Save Meet link</button>';
        if ($open) $o .= '<button class="btn danger" name="do" value="off">Turn demo off</button>';
        else $o .= '<button class="btn primary" name="do" value="on">Turn demo on</button>';
        $o .= '</div></form>';
        $o .= '<div class="tablewrap"><table><thead><tr><th>Demo</th><th>Guest</th><th>Course</th><th>Place</th><th>Join date</th><th>Purpose</th><th></th></tr></thead><tbody>';
        if (!$rows) $o .= '<tr><td colspan="7">No guest registrations yet.</td></tr>';
        foreach (array_reverse($rows) as $row) {
            $o .= '<tr><td>Demo '.(int)$row['slot'].'</td><td><strong>'.$portal->e($row['name']).'</strong><small class="sub">'.$portal->e($row['email']).'</small><small class="sub">'.$portal->e($row['phone']).'</small></td>';
            $o .= '<td>'.$portal->e($row['course']).'</td><td>'.$portal->e($row['place']).'</td><td>'.$portal->e($row['join_date']).'</td><td>'.$portal->e($row['purpose']==='look'?'Looking':'Joining').'</td><td>';
            if (!empty($row['archived'])) $o .= $portal->pill('Archived','mut');
            elseif (!empty($row['verified'])) $o .= $portal->pill('Verified','ok');
            else $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form"><input type="hidden" name="action" value="uc_portal_demo_gate">'.wp_nonce_field('uc_portal_demo_gate','_wpnonce',true,false).'<input type="hidden" name="do" value="verify"><input type="hidden" name="slot" value="'.(int)$row['slot'].'"><input type="hidden" name="back" value="settings"><button class="btn ghost sm">Verify</button></form>';
            $o .= self::demo_lead_actions($portal, $row, 'settings');
            $o .= '</td></tr>';
        }
        return $o.'</tbody></table></div></div>';
    }

    public static function training_catalog(){
        return [
            'certification' => [
                'CompTIA Security+','CompTIA CySA+','CompTIA CASP+','CompTIA Network+',
                'EC-Council CEH','EC-Council CPENT','EC-Council CHFI',
                'ISC2 CISSP','ISC2 SSCP','ISC2 CC',
                'ISACA CISM','ISACA CISA','ISACA CRISC',
                'SOC Analyst','Ethical Hacking','Penetration Testing','Digital Forensics and Incident Response',
                'Cloud Security','Network Security','Security Fundamentals','Network Defence Fundamentals',
                'Java Full Stack','Python Full Stack','Data Science and AI','MERN Stack','Cloud Computing Fundamentals','Android App Development',
                'AI and ML Security','DevSecOps','IoT and OT Security','Blockchain and Web3 Security','Threat Intelligence','Python for Cybersecurity',
            ],
            'lab' => [
                'SOC lab pack','Ethical hacking lab pack','Penetration testing lab pack',
                'Digital forensics lab pack','Cloud security lab pack','Network defence lab pack',
            ],
        ];
    }

    public static function training_form($portal){
        $cat = self::training_catalog();
        $o = '<section class="panel" id="interest"><div class="ph"><div><span class="eyebrow">ASK THE ACADEMY</span><h3>Certification or lab interest</h3></div></div>';
        $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form"><input type="hidden" name="action" value="uc_portal_training_interest">'.wp_nonce_field('uc_portal_training_interest','_wpnonce',true,false);
        $o .= '<label>Which one<select name="item" required><optgroup label="Certifications">';
        foreach ($cat['certification'] as $item) $o .= '<option value="'.esc_attr($item).'">'.$portal->e($item).'</option>';
        $o .= '</optgroup><optgroup label="Extra lab packs">';
        foreach ($cat['lab'] as $item) $o .= '<option value="'.esc_attr($item).'">'.$portal->e($item).'</option>';
        $o .= '</optgroup></select></label>';
        $o .= '<label>What should we tell you<textarea name="note" rows="3" placeholder="Pricing, dates, or the detail you want."></textarea></label>';
        $o .= '<div class="right"><button class="btn primary" type="submit">Send interest</button></div></form></section>';
        return $o;
    }

    public static function training_queue($portal, $back = 'dashboard'){
        $rows = get_option('uc_training_interest', []);
        if (!is_array($rows)) $rows = [];
        $open = []; $closed = [];
        foreach ($rows as $r) {
            if (($r['status'] ?? 'open') === 'open') $open[] = $r; else $closed[] = $r;
        }
        $legacy = get_users(['meta_key'=>'uc_exam_choice','number'=>200]);
        foreach ($legacy as $u) {
            if (get_user_meta($u->ID, 'uc_interest_state', true) === 'archived') {
                $parts = explode('|', (string)get_user_meta($u->ID, 'uc_exam_choice', true), 2);
                $closed[] = ['id'=>'legacy-'.$u->ID,'name'=>$u->display_name,'email'=>$u->user_email,'kind'=>'certification','item'=>trim(($parts[0] ?? '').' '.($parts[1] ?? '')),'note'=>'Sent from the profile','at'=>'','status'=>'archived','legacy'=>1];
                continue;
            }
            $parts = explode('|', (string)get_user_meta($u->ID, 'uc_exam_choice', true), 2);
            $open[] = ['id'=>'legacy-'.$u->ID,'name'=>$u->display_name,'email'=>$u->user_email,'kind'=>'certification','item'=>trim(($parts[0] ?? '').' '.($parts[1] ?? '')),'note'=>'Sent from the profile','at'=>'','status'=>'open','legacy'=>1];
        }
        $post = esc_url(admin_url('admin-post.php'));
        $nonce = wp_nonce_field('uc_portal_training_interest_status','_wpnonce',true,false);
        $can_delete = $portal->role() === 'super_admin';
        $o = '<section class="panel flush"><div class="ph" style="padding:16px 18px 0"><div><span class="eyebrow">FOLLOW UP</span><h3>Certification and lab interest</h3></div></div>';
        $o .= '<p class="hint" style="padding:0 18px">Students asked for pricing or dates. Archive the ones who are not moving. Delete is for Super Admin only. No price is stored.</p>';
        $o .= '<div class="tablewrap"><table><thead><tr><th>When</th><th>Student</th><th>Kind</th><th>Item</th><th>Note</th><th></th></tr></thead><tbody>';
        if (!$open) $o .= '<tr><td colspan="6">No open interest.</td></tr>';
        foreach (array_reverse($open) as $r) {
            $o .= '<tr><td>'.$portal->e($r['at'] ?? '').'</td><td><strong>'.$portal->e($r['name'] ?? '').'</strong><small class="sub">'.$portal->e($r['email'] ?? '').'</small></td><td>'.$portal->e(($r['kind'] ?? '') === 'lab' ? 'Lab' : 'Certification').'</td><td>'.$portal->e($r['item'] ?? '').'</td><td>'.$portal->e($r['note'] ?? '').'</td><td class="acts">';
            $o .= '<form method="post" action="'.$post.'" class="inline-form"><input type="hidden" name="action" value="uc_portal_training_interest_status">'.$nonce.'<input type="hidden" name="back" value="'.esc_attr($back).'"><input type="hidden" name="id" value="'.esc_attr($r['id']).'"><button class="btn ghost sm" name="status" value="archived">Archive</button>';
            if ($can_delete) $o .= '<button class="btn danger sm" name="status" value="delete" data-confirm="Delete this interest?">Delete</button>';
            $o .= '</form></td></tr>';
        }
        $o .= '</tbody></table></div>';
        if ($closed) {
            $o .= '<details class="lib-inner" style="margin:0 18px 14px"><summary>Archived <span class="count">'.count($closed).'</span></summary>';
            foreach (array_reverse($closed) as $r) {
                $o .= '<div class="req"><div><strong>'.$portal->e($r['name'] ?? '').'</strong><small>'.$portal->e($r['item'] ?? '').' · '.$portal->e($r['email'] ?? '').'</small></div>';
                $o .= '<form method="post" action="'.$post.'" class="inline-form"><input type="hidden" name="action" value="uc_portal_training_interest_status">'.$nonce.'<input type="hidden" name="back" value="'.esc_attr($back).'"><input type="hidden" name="id" value="'.esc_attr($r['id']).'"><button class="btn ghost sm" name="status" value="open">Restore</button></form></div>';
            }
            $o .= '</details>';
        }
        return $o.'</section>';
    }

    public static function exam_fold($portal){
        return self::training_queue($portal, 'settings');
    }

    public static function staff_desk($portal){
        return '';
    }

    public static function preview_desk($portal){
        global $wpdb;
        $row = $portal->has_table('tenants') ? $wpdb->get_row("SELECT * FROM {$portal->t('tenants')} WHERE slug='client-preview' LIMIT 1") : null;
        $name = $row->name ?? '';
        $accent = $row->accent ?? '#FF6B1A';
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', (string)$accent)) $accent = '#FF6B1A';
        $logo = $row->logo_url ?? '';
        $swatches = ['#FF6B1A','#1D4ED8','#0F766E','#6D28D9','#B45309','#0F172A'];
        $roles = [1=>'Any role',2=>'Any role',3=>'Any role',4=>'Any role',5=>'Any role'];
        $o = '<section class="panel"><div class="ph"><div><span class="eyebrow">CLIENT PREVIEW</span><h3>Five seats</h3></div></div>';
        $o .= '<p>Five preview seats. Each one can switch Student, Trainer, Coordinator, Placement HR, and Super Admin from View as. They see sample data only.</p>';
        $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form" enctype="multipart/form-data"><input type="hidden" name="action" value="uc_portal_client_preview">'.wp_nonce_field('uc_portal_client_preview','_wpnonce',true,false);
        $o .= '<div class="fgrid"><label>Academy name<input name="name" required value="'.esc_attr($name).'" placeholder="Client academy"></label>';
        $o .= '<div><span class="eyebrow">Colour</span><div class="colour-row">';
        foreach ($swatches as $hex) {
            $on = strcasecmp($hex, $accent) === 0 ? ' on' : '';
            $o .= '<button type="button" class="colour-swatch'.$on.'" style="background:'.esc_attr($hex).'" data-colour="'.esc_attr($hex).'" aria-label="'.esc_attr($hex).'"></button>';
        }
        $o .= '<span class="colour-chip" id="previewChip" style="background:'.esc_attr($accent).'"></span>';
        $o .= '<input class="colour-hex" id="previewAccent" name="accent" value="'.esc_attr(strtoupper($accent)).'" spellcheck="false" maxlength="7" aria-label="Colour hex">';
        $o .= '<button type="button" class="btn ghost sm" id="previewEyedrop">Pick from screen</button></div>';
        $o .= '<p class="hint">Click a colour, type a hex code such as #FF6B1A, click the logo, or pick any colour on the screen in Chrome or Edge.</p>';
        $o .= '<label>Logo'.$portal->file_control('logo', 'image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp').'</label>';
        if ($logo) $o .= '<img class="preview-logo" id="previewLogo" src="'.esc_url($logo).'" alt="Current logo">';
        $o .= '</div></div>';
        $o .= '<div class="right"><button class="btn ghost" name="do" value="brand">Save brand</button><button class="btn primary" name="do" value="seats">Save and issue 5 passwords</button></div></form>';
        $o .= '<div class="tablewrap" style="margin-top:14px"><table><thead><tr><th>Seat</th><th>Role</th><th>Password</th></tr></thead><tbody>';
        for ($i = 1; $i <= 5; $i++) {
            $email = 'preview'.$i.'@unicybers.com';
            $user = get_user_by('email', $email);
            $pw = $user ? (string)get_user_meta($user->ID, 'uc_preview_password', true) : '';
            $o .= '<tr><td>'.$portal->e($email).'</td><td>'.$portal->e($roles[$i]).'</td><td class="preview-pass">'.($pw !== '' ? $portal->e($pw) : 'Issue passwords to store one').'</td></tr>';
        }
        $o .= '</tbody></table></div>';
        $o .= '<p class="hint">Passwords already handed out before this update cannot be recovered. Issue a fresh set, then this table keeps them for the next time a client loses one.</p></section>';
        $o .= '<script>(function(){var input=document.getElementById("previewAccent"),chip=document.getElementById("previewChip"),logo=document.getElementById("previewLogo"),eye=document.getElementById("previewEyedrop");if(!input||!chip)return;function paint(hex){hex=String(hex||"").trim();if(hex.charAt(0)!=="#")hex="#"+hex;if(!/^#[0-9A-Fa-f]{6}$/.test(hex))return;hex=hex.toUpperCase();input.value=hex;chip.style.background=hex;document.querySelectorAll("[data-colour]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-colour").toUpperCase()===hex);});}document.querySelectorAll("[data-colour]").forEach(function(b){b.addEventListener("click",function(){paint(b.getAttribute("data-colour"));});});input.addEventListener("input",function(){paint(input.value);});if(logo){logo.addEventListener("click",function(ev){var canvas=document.createElement("canvas"),ctx=canvas.getContext("2d");canvas.width=logo.naturalWidth||logo.width;canvas.height=logo.naturalHeight||logo.height;try{ctx.drawImage(logo,0,0,canvas.width,canvas.height);var box=logo.getBoundingClientRect();var x=Math.floor((ev.clientX-box.left)*(canvas.width/box.width));var y=Math.floor((ev.clientY-box.top)*(canvas.height/box.height));var p=ctx.getImageData(x,y,1,1).data;var hex="#"+[p[0],p[1],p[2]].map(function(n){return ("0"+n.toString(16)).slice(-2);}).join("");paint(hex);}catch(e){eye.focus();}});}if(eye){if(!window.EyeDropper){eye.title="Pick from screen needs Chrome or Edge";}eye.addEventListener("click",function(){if(!window.EyeDropper)return;new EyeDropper().open().then(function(res){paint(res.sRGBHex);}).catch(function(){});});}})();</script>';
        return $o;
    }

    public static function demo_lead_actions($portal, $row, $back){
        $slot = (int)($row['slot'] ?? 0);
        $post = esc_url(admin_url('admin-post.php'));
        $nonce = wp_nonce_field('uc_portal_demo_gate','_wpnonce',true,false);
        $base = '<form method="post" action="'.$post.'" class="inline-form"><input type="hidden" name="action" value="uc_portal_demo_gate">'.$nonce.'<input type="hidden" name="slot" value="'.$slot.'"><input type="hidden" name="back" value="'.esc_attr($back).'">';
        $o = '';
        if (!empty($row['archived'])) $o .= $base.'<input type="hidden" name="do" value="restore"><button class="btn ghost sm">Restore</button></form>';
        else $o .= $base.'<input type="hidden" name="do" value="archive"><button class="btn ghost sm">Archive</button></form>';
        $o .= $base.'<input type="hidden" name="do" value="delete"><button class="btn danger sm" data-confirm="Delete this demo lead and their demo sign-in? This cannot be undone.">Delete</button></form>';
        return $o;
    }

    public static function demo_rows(){
        $rows = get_option('uc_demo_visits', []);
        return is_array($rows) ? $rows : [];
    }

    public static function public_demo(){
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') self::demo_join();
        $open = !UC_LMS_Security::demo_closed();
        $meet = esc_url((string)get_option('uc_demo_meet_url'));
        $err = sanitize_key($_GET['demo_error'] ?? '');
        $welcome = sanitize_text_field($_GET['welcome'] ?? '');
        $pass = $welcome ? get_transient('uc_demo_welcome_'.$welcome) : false;
        $msg = '';
        if ($err === 'closed') $msg = 'Demo access is closed.';
        if ($err === 'full') $msg = 'This demo is full.';
        if ($err === 'fields') $msg = 'Fill every required field.';
        if ($err === 'email') $msg = 'That email cannot be used for a demo seat.';
        if ($err === 'rate') $msg = 'Too many attempts from this network. Wait and try again.';
        $body = '';
        if (is_array($pass)) {
            $body .= '<h1>You are Demo '.(int)$pass['slot'].'</h1><p>Sign in with <strong>'.esc_html($pass['email']).'</strong></p><p>Password: <strong>'.esc_html($pass['password']).'</strong></p><p>This password is only for the demo. You do not need to change it.</p>';
            if (!empty($pass['meet'])) $body .= '<p><a href="'.esc_url($pass['meet']).'">Open the trainer\'s Google Meet</a></p>';
            $body .= '<p><a href="'.esc_url(home_url('/student-login/')).'">Go to sign in</a></p>';
        } elseif (!$open) {
            $body .= '<h1>Demo is closed</h1><p>Ask the trainer when the next session opens.</p>';
        } else {
            $body .= '<h1>Join the UniCybers demo</h1>';
            if ($msg) $body .= '<p>'.esc_html($msg).'</p>';
            if ($meet) $body .= '<p><a href="'.$meet.'">Google Meet for this session</a></p>';
            $nonce = wp_create_nonce('uc_portal_demo_join');
            $body .= '<form method="post" action="'.esc_url(home_url('/try-demo/')).'"><input type="hidden" name="action" value="uc_portal_demo_join"><input type="hidden" name="_wpnonce" value="'.esc_attr($nonce).'">';
            $body .= '<label>Name<input name="guest_name" required></label><label>Email<input name="guest_email" type="email" required></label><label>Phone<input name="guest_phone" required></label><label>Course<input name="guest_course" required></label><label>Place<input name="guest_place" required></label><label>Expected join date<input name="guest_join" type="date"></label><label>I am here to<select name="guest_purpose"><option value="join">Join a course</option><option value="look">See the demo</option></select></label>';
            $body .= '<label class="hp">Website<input name="guest_website" tabindex="-1" autocomplete="off"></label><button type="submit">Register</button></form>';
        }
        status_header(200);
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>UniCybers demo</title>'.UC_LMS_Portal_Layout::favicon_html().'<style>body{margin:0;font:500 16px/1.5 Figtree,sans-serif;background:#05080D;color:#F2F6FC}main{max-width:460px;margin:32px auto;padding:24px;background:#0B121C;border:1px solid rgba(160,190,240,.2);border-radius:16px}label{display:flex;flex-direction:column;gap:4px;margin:10px 0;font-size:13px}input,select,button{height:40px;border-radius:12px;border:1px solid rgba(160,190,240,.25);background:#0F1826;color:#F2F6FC;padding:0 12px;font:600 14px Figtree,sans-serif}button{background:#FF6B1A;color:#1A0B02;border:0;cursor:pointer;margin-top:8px}.hp{position:absolute;left:-9999px}a{color:#FF9A5C}</style></head><body><main>'.$body.'</main></body></html>';
        exit;
    }

    public static function demo_join(){
        $back = home_url('/try-demo/');
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'uc_portal_demo_join')) {
            wp_safe_redirect(add_query_arg('demo_error','fields',$back)); exit;
        }
        if (trim((string)wp_unslash($_POST['guest_website'] ?? '')) !== '') { wp_safe_redirect($back); exit; }
        if (UC_LMS_Security::demo_closed()) { wp_safe_redirect(add_query_arg('demo_error','closed',$back)); exit; }
        $ip = md5((string)($_SERVER['REMOTE_ADDR'] ?? '0'));
        $hits = (int)get_transient('uc_demo_ip_'.$ip);
        if ($hits > 8) { wp_safe_redirect(add_query_arg('demo_error','rate',$back)); exit; }
        set_transient('uc_demo_ip_'.$ip, $hits + 1, HOUR_IN_SECONDS);
        $name = sanitize_text_field(wp_unslash($_POST['guest_name'] ?? ''));
        $email = sanitize_email(wp_unslash($_POST['guest_email'] ?? ''));
        $phone = sanitize_text_field(wp_unslash($_POST['guest_phone'] ?? ''));
        $course = sanitize_text_field(wp_unslash($_POST['guest_course'] ?? ''));
        $place = sanitize_text_field(wp_unslash($_POST['guest_place'] ?? ''));
        $join = sanitize_text_field(wp_unslash($_POST['guest_join'] ?? ''));
        $purpose = sanitize_key($_POST['guest_purpose'] ?? 'look') === 'join' ? 'join' : 'look';
        if ($name === '' || !$email || $phone === '' || $course === '' || $place === '') {
            wp_safe_redirect(add_query_arg('demo_error','fields',$back)); exit;
        }
        $existing = get_user_by('email', $email);
        if ($existing && get_user_meta($existing->ID, 'uc_demo_guest', true) !== '1') {
            wp_safe_redirect(add_query_arg('demo_error','email',$back)); exit;
        }
        $rows = self::demo_rows();
        $max = 0;
        foreach ($rows as $row) $max = max($max, (int)($row['slot'] ?? 0));
        if ($existing) {
            $slot = (int)get_user_meta($existing->ID, 'uc_demo_slot', true);
            if ($slot < 1) $slot = $max + 1;
        } else {
            if ($max >= 500) { wp_safe_redirect(add_query_arg('demo_error','full',$back)); exit; }
            $slot = $max + 1;
        }
        $pw = class_exists('UC_LMS_Security') ? UC_LMS_Security::temp_password() : wp_generate_password(12, true);
        if ($existing) {
            wp_set_password($pw, $existing->ID);
            $uid = $existing->ID;
            wp_update_user(['ID'=>$uid,'display_name'=>$name]);
        } else {
            $login = sanitize_user(strstr($email, '@', true) ?: 'demo', true);
            if (!$login || username_exists($login)) $login = sanitize_user('demo'.$slot, true);
            $uid = wp_insert_user(['user_login'=>$login,'user_email'=>$email,'user_pass'=>$pw,'display_name'=>$name,'role'=>'uc_student']);
            if (is_wp_error($uid)) { wp_safe_redirect(add_query_arg('demo_error','email',$back)); exit; }
        }
        update_user_meta($uid, 'uc_demo_guest', '1');
        update_user_meta($uid, 'uc_demo_slot', $slot);
        delete_user_meta($uid, 'uc_must_change');
        update_user_meta($uid, 'uc_phone', $phone);
        $found = false;
        foreach ($rows as &$row) {
            if ((int)$row['slot'] === $slot) { $row = array_merge($row, compact('name','email','phone','course','place','purpose') + ['join_date'=>$join,'verified'=>0]); $found = true; }
        }
        unset($row);
        if (!$found) $rows[] = ['slot'=>$slot,'name'=>$name,'email'=>$email,'phone'=>$phone,'course'=>$course,'place'=>$place,'join_date'=>$join,'purpose'=>$purpose,'verified'=>0,'created'=>current_time('mysql')];
        update_option('uc_demo_visits', $rows, false);
        $meet = esc_url_raw((string)get_option('uc_demo_meet_url'));
        $token = wp_generate_password(20, false, false);
        set_transient('uc_demo_welcome_'.$token, ['slot'=>$slot,'email'=>$email,'password'=>$pw,'meet'=>$meet], 20 * MINUTE_IN_SECONDS);
        if (function_exists('wp_mail')) wp_mail($email, 'UniCybers demo '. $slot, "You are Demo {$slot}.\nSign in: ".home_url('/student-login/')."\nEmail: {$email}\nPassword: {$pw}\n".($meet ? "Meet: {$meet}\n" : ''));
        wp_safe_redirect(add_query_arg('welcome', $token, $back));
        exit;
    }
}
