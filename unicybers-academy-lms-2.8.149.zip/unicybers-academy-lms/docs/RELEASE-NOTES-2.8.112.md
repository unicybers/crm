# UniCybers Academy LMS 2.8.112

## Brand lockup correction

- Uses the exact UniCybers logo URL supplied by the owner: https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp
- Keeps the original globe and embedded UNICYBERS artwork.
- Visually covers the original image tagline and replaces it with orange ACADEMY.
- ACADEMY is rendered in a fixed-width flex row matching the embedded UNICYBERS wordmark width.
- Removes the previous cropped emblem plus separately generated wordmark treatment.
- Updates the portal stylesheet version so browsers do not retain the old sidebar logo styling.
- Leaves tenant-specific white-label logos unchanged.

## Files changed

- `includes/portal/class-portal-layout.php`
- `includes/admin/class-admin-settings.php`
- `assets/portal.css`
- `assets/portal.min.css`
- `includes/class-portal.php`
- `unicybers-academy-lms.php`
- `readme.txt`
