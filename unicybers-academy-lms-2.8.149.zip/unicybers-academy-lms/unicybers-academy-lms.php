<?php
/**
 * Plugin Name:       UniCybers Academy LMS
 * Plugin URI:        https://unicybers.com/
 * Description:       UniCybers training operations LMS for courses, batches, trainers, students, live classes, meetings, attendance, recordings, materials and reporting.
 * Version:           2.8.149
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            UniCybers
 * Author URI:        https://unicybers.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       unicybers-academy-lms
 */

if (!defined('ABSPATH')) exit;

define('UC_LMS_FILE', __FILE__);
define('UC_LMS_DIR', __DIR__);
define('UC_LMS_URL', plugin_dir_url(__FILE__));

require_once __DIR__ . '/includes/class-landing.php';
UC_LMS_Landing::maybe_serve();
add_action('admin_init', ['UC_LMS_Landing', 'purge_cached_miss']);

// Autoloader for on-demand modular loading
require_once __DIR__ . '/includes/class-autoloader.php';
UC_LMS_Autoloader::register(__DIR__);

// Core Subsystems Boot
UC_LMS_Security::instance();
UC_LMS_Login::init();
UC_LMS_Cron::init();
UC_LMS_Rest::init();

// Admin Isolation (Zero overhead on frontend requests)
if (is_admin()) {
    UC_LMS_Admin_Controller::init();
    UC_LMS_Admin_Legacy_Handlers::init();
    add_action('admin_init', ['UC_Academy_LMS', 'maybe_upgrade']);
    add_action('admin_post_uc_google_connect', function() {
        if (class_exists('UC_LMS_Meeting')) UC_LMS_Meeting::instance()->google_connect();
    });
    add_action('admin_post_uc_google_oauth', function() {
        if (class_exists('UC_LMS_Meeting')) UC_LMS_Meeting::instance()->google_oauth();
    });
    add_action('admin_post_uc_zoho_connect', function() {
        if (class_exists('UC_LMS_Meeting_Zoho')) UC_LMS_Meeting_Zoho::connect();
    });
    add_action('admin_post_uc_zoho_oauth', function() {
        if (class_exists('UC_LMS_Meeting_Zoho')) UC_LMS_Meeting_Zoho::oauth();
    });
}

// Specialized Modules
require_once __DIR__ . '/includes/core/class-addons.php';
require_once __DIR__ . '/includes/class-career-bridge.php';
require_once __DIR__ . '/includes/class-intelligence.php';
require_once __DIR__ . '/includes/class-portal.php';

if (class_exists('UC_LMS_Intelligence')) {
    UC_LMS_Intelligence::instance()->boot();
}

if (class_exists('UC_LMS_Portal')) {
    UC_LMS_Portal::instance();
}

// Plugin Lifecycle Hooks
register_activation_hook(__FILE__, ['UC_Academy_LMS', 'activate']);
register_deactivation_hook(__FILE__, ['UC_Academy_LMS', 'deactivate']);

// Quick Access Settings Link on Plugins List
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=uc-settings')) . '">' . esc_html__('Settings', 'unicybers-academy-lms') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
});

/**
 * Backwards-Compatibility Shim for Legacy & Companion Plugin Invocations.
 *
 * Transparently proxies method calls to specialized subsystems to preserve
 * 100% compatibility with older extensions and direct class calls.
 */
final class UC_Academy_LMS {
    const VERSION = '2.8.149';
    // Landing page is served from this plugin. Database schema stays at 2.8.127.
    const DB_VERSION = '2.8.135';
    const ZOOM_LICENSE_EMAIL = 'training@unicybers.com';
    const LOGO_URL = 'https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp';

    private static $instance = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public static function activate() {
        global $wpdb;
        $suppress = $wpdb ? $wpdb->suppress_errors(true) : false;
        ob_start();

        UC_LMS_Database::run_full_migration();
        UC_LMS_Database::install_roles();
        UC_LMS_Login::instance()->ensure_login_page();
        UC_LMS_Database::clear_staff_password_wall();
        UC_LMS_Database::ensure_noori_coordinator();
        UC_LMS_Cron::instance()->ensure_recording_sync_cron();
        UC_LMS_Cron::instance()->ensure_weekly_report_cron();
        UC_LMS_Cron::instance()->ensure_monthly_report_cron();
        if (class_exists('UC_LMS_Intelligence')) {
            UC_LMS_Intelligence::instance()->install();
        }
        if (class_exists('UC_LMS_Portal')) {
            UC_LMS_Portal::instance()->activate();
        }
        update_option('uc_lms_version', self::VERSION);
        update_option('uc_lms_db_version', self::DB_VERSION);

        ob_end_clean();
        if ($wpdb) $wpdb->suppress_errors($suppress);
    }

    public static function deactivate() {
        UC_LMS_Cron::unschedule_all();
        if (function_exists('flush_rewrite_rules')) flush_rewrite_rules();
    }

    public static function maybe_upgrade() {
        UC_LMS_Database::install_roles();
        UC_LMS_Database::maybe_upgrade(self::DB_VERSION);
    }

    public function table($name) {
        return UC_LMS_Database::table($name);
    }

    public function now() {
        return current_time('mysql');
    }

    public function portal_day_labels() {
        if (class_exists('UC_LMS_Admin_Legacy_Handlers')) {
            return UC_LMS_Admin_Legacy_Handlers::instance()->day_labels();
        }
        return ['1' => 'Sun', '2' => 'Mon', '3' => 'Tue', '4' => 'Wed', '5' => 'Thu', '6' => 'Fri', '7' => 'Sat'];
    }

    public function clear_staff_password_wall_now() {
        UC_LMS_Database::clear_staff_password_wall();
    }

    public function normalize_host($value) {
        $h = strtolower(trim((string)$value));
        $h = preg_replace('#^https?://#', '', $h);
        $h = preg_replace('#/.*$#', '', $h);
        $h = preg_replace('/:\d+$/', '', $h);
        $h = preg_replace('/^www\./', '', $h);
        return $h;
    }

    public function default_brand() {
        $custom_name = get_option('uc_academy_name', '');
        $custom_legal = get_option('uc_academy_legal_name', '');
        $custom_product = get_option('uc_product_label', '');
        $custom_tagline = get_option('uc_tagline', '');
        $custom_logo = get_option('uc_logo_url', '');

        return (object) [
            'id' => 0,
            'slug' => 'unicybers',
            'name' => $custom_name ?: 'UniCybers',
            'legal_name' => $custom_legal ?: ($custom_name ? $custom_name . ' Academy' : 'UniCybers Academy'),
            'tagline' => $custom_tagline ?: 'Learn · Practice · Prove · Advance',
            'product_label' => $custom_product ?: 'ACADEMY',
            'logo_url' => $custom_logo ?: 'https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp',
            'accent' => '#FF6B1A',
            'accent2' => '#FF8A3D',
            'support_email' => 'support@unicybers.com',
            'mail_from' => 'academy@unicybers.com',
            'website' => 'https://unicybers.com',
            'portal_domain' => '',
            'timezone' => get_option('uc_default_timezone', 'Asia/Kolkata'),
            'phone' => '',
            'status' => 'live',
            'is_home' => 1,
        ];
    }

    public function brand_pack($user_id = 0) {
        global $wpdb;
        $fallback = $this->default_brand();

        $apply_overrides = function ($row) use ($fallback) {
            if (!$row) return $fallback;
            $custom_name = get_option('uc_academy_name');
            $custom_legal = get_option('uc_academy_legal_name');
            $custom_product = get_option('uc_product_label');
            $custom_tagline = get_option('uc_tagline');
            $custom_logo = get_option('uc_logo_url');

            if (!empty($custom_name)) $row->name = $custom_name;
            if (!empty($custom_legal)) $row->legal_name = $custom_legal;
            if (!empty($custom_product)) $row->product_label = $custom_product;
            if (!empty($custom_tagline)) $row->tagline = $custom_tagline;
            if (!empty($custom_logo)) $row->logo_url = $custom_logo;
            return $row;
        };

        $table = $this->table('tenants');
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($exists !== $table) return $fallback;

        $pick = function ($id) use ($wpdb, $table) {
            $id = absint($id);
            if (!$id) return null;
            return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $id));
        };

        $preview = isset($_COOKIE['uc_preview_tenant']) ? absint($_COOKIE['uc_preview_tenant']) : 0;
        $can_preview = $user_id && user_can($user_id, 'manage_options');
        if ($preview && $can_preview) {
            $row = $pick($preview);
            if ($row) return $row;
        }

        $slug = sanitize_title(wp_unslash($_GET['academy'] ?? ''));
        if ($slug) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE slug=%s", $slug));
            if ($row) return $row;
        }

        $host = $this->normalize_host($_SERVER['HTTP_HOST'] ?? '');
        if ($host && $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM $table LIKE %s", 'portal_domain'))) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE portal_domain=%s LIMIT 1", $host));
            if ($row) return $row;
        }

        if ($user_id) {
            $tid = (int) get_user_meta($user_id, 'uc_tenant_id', true);
            $row = $pick($tid);
            if ($row) return $row;
        }

        $home = $pick((int) get_option('uc_home_tenant_id'));
        if ($home) return $apply_overrides($home);
        $row = $wpdb->get_row("SELECT * FROM $table WHERE is_home=1 ORDER BY id ASC LIMIT 1");
        return $row ? $apply_overrides($row) : $fallback;
    }

    public function brand_css($brand) {
        $a = sanitize_hex_color((string)($brand->accent ?? '')) ?: '#FF6B1A';
        $b = sanitize_hex_color((string)($brand->accent2 ?? '')) ?: '#FF8A3D';
        return ':root{--accent:'.$a.';--accent2:'.$b.';--uc-accent:'.$a.';--uc-accent-2:'.$b.';}';
    }

    public function safe_get_results($sql, $args = []) {
        global $wpdb;
        if ($args) $sql = $wpdb->prepare($sql, ...$args);
        $rows = $wpdb->get_results($sql);
        return is_array($rows) ? $rows : [];
    }

    public function ensure_home_tenant() {
        if (class_exists('UC_LMS_Database')) UC_LMS_Database::seed_home_tenant();
    }

    public function portal_sync_batch_schedule($batch_id) {
        if (class_exists('UC_LMS_Admin_Legacy_Handlers')) {
            return UC_LMS_Admin_Legacy_Handlers::instance()->sync_batch_schedule($batch_id);
        }
        return false;
    }

    public function portal_generate_sessions($batch_id) {
        if (class_exists('UC_LMS_Admin_Legacy_Handlers')) {
            $h = UC_LMS_Admin_Legacy_Handlers::instance();
            $h->sync_batch_schedule($batch_id);
            return $h->generate_sessions($batch_id);
        }
        return 0;
    }

    public function portal_provision_zoom($batch_id) {
        return class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::provision_batch_zoom($batch_id) : false;
    }

    public function portal_cached_recording_path($session, $file_id = '', $ensure_dir = false) {
        return class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::portal_cached_recording_path($session, $file_id, $ensure_dir) : '';
    }

    public function portal_zoom_request($method, $path, $body = null) {
        return class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::request($method, $path, $body) : new WP_Error('zoom', 'Zoom subsystem missing.');
    }

    public function portal_zoom_uuid_path($uuid) {
        return class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::uuid_path($uuid) : str_replace(['/', '+'], ['%2F', '%2B'], $uuid);
    }

    /**
     * Magic call proxy routing to subsystems.
     */
    public function __call($name, $arguments) {
        if (method_exists('UC_LMS_Database', $name)) {
            return call_user_func_array(['UC_LMS_Database', $name], $arguments);
        }
        if (method_exists('UC_LMS_Zoom', $name)) {
            return call_user_func_array(['UC_LMS_Zoom', $name], $arguments);
        }
        if (class_exists('UC_LMS_Meeting') && method_exists('UC_LMS_Meeting', $name)) {
            return call_user_func_array([UC_LMS_Meeting::instance(), $name], $arguments);
        }
        if (class_exists('UC_LMS_Admin_Legacy_Handlers') && method_exists('UC_LMS_Admin_Legacy_Handlers', $name)) {
            return call_user_func_array([UC_LMS_Admin_Legacy_Handlers::instance(), $name], $arguments);
        }
        if (class_exists('UC_LMS_Admin_Controller') && method_exists('UC_LMS_Admin_Controller', $name)) {
            return call_user_func_array([UC_LMS_Admin_Controller::instance(), $name], $arguments);
        }
        if (class_exists('UC_LMS_Login') && method_exists('UC_LMS_Login', $name)) {
            return call_user_func_array([UC_LMS_Login::instance(), $name], $arguments);
        }
        if (class_exists('UC_LMS_Cron') && method_exists('UC_LMS_Cron', $name)) {
            return call_user_func_array([UC_LMS_Cron::instance(), $name], $arguments);
        }
        return null;
    }
}

// Bootstrap Singleton Instantiation
UC_Academy_LMS::instance();
