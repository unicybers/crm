<?php
/**
 * UniCybers Academy LMS: Google Drive Meet Notes Ingestion Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Meeting_Drive_Notes {

    public static function google_access_token() {
        return UC_LMS_Meeting_Google::google_access_token();
    }

    public static function meet_file_day($file) {
        return UC_LMS_Meeting_Drive::meet_file_day($file);
    }

    public static function meet_name_tokens($text) {
        return UC_LMS_Meeting_Drive::meet_name_tokens($text);
    }

    public static function meet_token_overlap($a, $b) {
        return UC_LMS_Meeting_Drive::meet_token_overlap($a, $b);
    }

public static function portal_sync_meet_notes($only_id = 0){
            $token = self::google_access_token();
            if (is_wp_error($token)) return $token;
            $folder = trim((string)get_option('uc_google_meet_folder', '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi'));
            if ($folder === '') $folder = '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi';
            $docs = self::drive_folder_docs($token, $folder, 0);
            if (is_wp_error($docs)) return $docs;
            $found = self::drive_search_note_docs($token);
            if (!is_wp_error($found)) {
                $seen = [];
                foreach ($docs as $d) $seen[(string)($d['id'] ?? '')] = 1;
                foreach ($found as $d) {
                    $id = (string)($d['id'] ?? '');
                    if ($id !== '' && empty($seen[$id])) $docs[] = $d;
                }
            }
            global $wpdb;
            $sessions = $wpdb->get_results("SELECT * FROM {UC_LMS_Meeting::instance()->table('sessions')} WHERE hidden=0 AND LOWER(IFNULL(status,''))<>'cancelled' AND LOWER(IFNULL(platform,'')) IN ('google_meet','meet') AND session_date >= CURDATE() - INTERVAL 120 DAY ORDER BY session_date DESC");
            if ($only_id) {
                $sessions = array_values(array_filter((array)$sessions, function ($s) use ($only_id) {
                    return (int)$s->id === (int)$only_id;
                }));
            }
            $saved = 0;
            $used = [];
            foreach ((array)$docs as $file) {
                $id = (string)($file['id'] ?? '');
                if ($id === '' || isset($used[$id])) continue;
                $session = self::match_meet_note_to_session($file, $sessions);
                if (!$session) continue;
                $text = self::drive_export_text($token, $id);
                if (self::save_meet_note($session, $text)) $saved++;
                $used[$id] = (int)$session->id;
            }
            return $saved;
        }

public static function drive_folder_docs($token, $folder, $depth){
            $out = [];
            $page = '';
            for ($i = 0; $i < 4; $i++) {
                $q = "'".$folder."' in parents and trashed = false";
                $url = 'https://www.googleapis.com/drive/v3/files?supportsAllDrives=true&includeItemsFromAllDrives=true&pageSize=100&fields='.rawurlencode('nextPageToken,files(id,name,mimeType,createdTime)').'&q='.rawurlencode($q);
                if ($page !== '') $url .= '&pageToken='.rawurlencode($page);
                $r = wp_remote_get($url, ['timeout'=>25, 'headers'=>['Authorization'=>'Bearer '.$token]]);
                if (is_wp_error($r)) return $r;
                $code = (int)wp_remote_retrieve_response_code($r);
                $data = json_decode(wp_remote_retrieve_body($r), true);
                if ($code === 401 || $code === 403) return new WP_Error('google', 'Reconnect rafi@unicybers.com so Sync recordings can read Meet notes.');
                if ($code < 200 || $code >= 300) return new WP_Error('google', 'Drive could not list Meet notes.');
                foreach ((array)($data['files'] ?? []) as $file) {
                    $mime = (string)($file['mimeType'] ?? '');
                    if ($mime === 'application/vnd.google-apps.folder' && $depth < 1) {
                        $nested = self::drive_folder_docs($token, $file['id'], $depth + 1);
                        if (!is_wp_error($nested)) $out = array_merge($out, $nested);
                        continue;
                    }
                    if ($mime === 'application/vnd.google-apps.document') $out[] = $file;
                }
                $page = (string)($data['nextPageToken'] ?? '');
                if ($page === '') break;
            }
            return $out;
        }

public static function drive_search_note_docs($token){
            $from = gmdate('Y-m-d\T00:00:00\Z', time() - 120 * 86400);
            $q = "mimeType = 'application/vnd.google-apps.document' and trashed = false and modifiedTime > '".$from."' and (name contains 'Gemini' or name contains 'Notes' or name contains 'Transcript' or name contains 'summary')";
            $url = 'https://www.googleapis.com/drive/v3/files?supportsAllDrives=true&includeItemsFromAllDrives=true&pageSize=50&fields='.rawurlencode('files(id,name,mimeType,createdTime)').'&q='.rawurlencode($q);
            $r = wp_remote_get($url, ['timeout'=>25, 'headers'=>['Authorization'=>'Bearer '.$token]]);
            if (is_wp_error($r)) return $r;
            $code = (int)wp_remote_retrieve_response_code($r);
            if ($code < 200 || $code >= 300) return [];
            $data = json_decode(wp_remote_retrieve_body($r), true);
            return (array)($data['files'] ?? []);
        }

public static function drive_export_text($token, $id){
            $url = 'https://www.googleapis.com/drive/v3/files/'.rawurlencode($id).'/export?mimeType='.rawurlencode('text/plain');
            $r = wp_remote_get($url, ['timeout'=>30, 'headers'=>['Authorization'=>'Bearer '.$token]]);
            if (is_wp_error($r)) return '';
            $code = (int)wp_remote_retrieve_response_code($r);
            if ($code < 200 || $code >= 300) return '';
            return (string)wp_remote_retrieve_body($r);
        }

public static function match_meet_note_to_session($file, $sessions){
            $day = self::meet_file_day($file);
            if ($day === '') return null;
            $candidates = [];
            foreach ((array)$sessions as $s) {
                if ((string)$s->session_date !== $day) continue;
                $candidates[] = $s;
            }
            if (!$candidates) return null;
            $name = (string)($file['name'] ?? '');
            $noteish = (bool)preg_match('~\b(note|notes|gemini|transcript|summary)\b~i', $name);
            $tokens = self::meet_name_tokens($name);
            $best = null;
            $score = 0;
            foreach ($candidates as $s) {
                $sc = self::meet_token_overlap($tokens, self::meet_name_tokens((string)$s->title.' '.(string)($s->recording_label ?? '')));
                if ($sc > $score) { $score = $sc; $best = $s; }
            }
            if (count($candidates) === 1 && ($noteish || $score >= 2)) return $candidates[0];
            if ($best && ($score >= 2 || ($noteish && $score >= 1))) return $best;
            return null;
        }

public static function save_meet_note($session, $text){
            global $wpdb;
            $text = trim(wp_strip_all_tags((string)$text));
            if (strlen($text) < 40) return false;
            if (strlen($text) > 20000) $text = substr($text, 0, 20000);
            $table = $wpdb->prefix.'uc_intel_summaries';
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) !== $table) return false;
            $sid = (int)$session->id;
            $was = $wpdb->get_row($wpdb->prepare("SELECT published, recap FROM {$table} WHERE session_id=%d", $sid));
            if ($was && (int)$was->published === 1 && strlen(trim((string)$was->recap)) > 40) return false;
            $ok = $wpdb->replace($table, [
                'session_id' => $sid,
                'recap' => wp_kses_post($text),
                'topics' => '[]',
                'next_steps' => '[]',
                'published' => $was ? (int)$was->published : 0,
                'updated_at' => UC_LMS_Meeting::instance()->now(),
            ]);
            if ($ok === false) return false;
            $status = $wpdb->prefix.'uc_intel_status';
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($status))) === $status) {
                $wpdb->query($wpdb->prepare("INSERT INTO {$status} (session_id, summary_state, last_sync, last_error) VALUES (%d, 'available', %s, NULL) ON DUPLICATE KEY UPDATE summary_state='available', last_error=NULL, last_sync=VALUES(last_sync)", $sid, UC_LMS_Meeting::instance()->now()));
            }
            return true;
        }
}
