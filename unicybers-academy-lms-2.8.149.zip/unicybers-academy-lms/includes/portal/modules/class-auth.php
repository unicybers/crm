<?php
/**
 * UniCybers Academy LMS: Portal Authentication & Set Password Module.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Auth {
    public static function render_setpassword($portal){
        return '<section class="panel narrow"><div class="ph"><div><span class="eyebrow">WELCOME</span><h3>Choose your own password</h3></div></div><p class="muted">You are signed in with a temporary password. Set your own to continue. Minimum eight characters.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form"><input type="hidden" name="action" value="uc_portal_password">'.wp_nonce_field('uc_portal_password','_wpnonce',true,false).'<label>Temporary password<input type="password" name="old" required autocomplete="current-password"></label><label>New password<input type="password" name="new" minlength="8" required autocomplete="new-password"></label><label>Repeat new password<input type="password" name="new2" minlength="8" required autocomplete="new-password"></label><div class="right"><button class="btn primary">Save and continue</button></div></form></section>';
    }
}
