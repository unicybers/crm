<?php
/**
 * UniCybers Academy LMS: Class Intelligence Coordinator & Facade.
 *
 * Coordinates Zoom meeting artefacts, AI summaries, transcripts,
 * quiz/polls extraction, and attendance engagement.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Intelligence {
    const VERSION = '2.8.100';

    public static function instance() {
        static $i = null;
        if (!$i) $i = new self();
        return $i;
    }

    public function boot() {
        add_action('uc_lms_session_recording_synced', [$this, 'sync_session']);
        add_action('rest_api_init', ['UC_LMS_Intelligence_Handlers', 'routes']);
        add_action('admin_post_uc_portal_intel_sync', ['UC_LMS_Intelligence_Handlers', 'h_sync']);
        add_action('admin_post_uc_portal_intel_publish', ['UC_LMS_Intelligence_Handlers', 'h_publish']);
        add_action('admin_post_uc_portal_intel_task', ['UC_LMS_Intelligence_Handlers', 'h_task']);
        add_action('admin_post_uc_portal_intel_csv', ['UC_LMS_Intelligence_Handlers', 'h_csv']);
        add_action('admin_post_uc_portal_intel_summary', ['UC_LMS_Intelligence_Handlers', 'h_summary']);
    }

    public function install() {
        return UC_LMS_Intelligence_Schema::install();
    }

    public function t($n) {
        return UC_LMS_Intelligence_Schema::t($n);
    }

    public function has($n) {
        return UC_LMS_Intelligence_Schema::has($n);
    }

    public function sync_session($session) {
        return UC_LMS_Intelligence_Sync::sync_session($session);
    }

    public function api($method, $path) {
        return UC_LMS_Intelligence_Sync::api($method, $path);
    }

    public function mark_view($sid, $uid) {
        return UC_LMS_Intelligence_Pack::mark_view($sid, $uid);
    }

    public function clock($sec) {
        return UC_LMS_Intelligence_Pack::clock($sec);
    }

    public function state_label($st) {
        return UC_LMS_Intelligence_Pack::state_label($st);
    }

    public function pack($session, $staff, $uid) {
        return UC_LMS_Intelligence_Pack::pack($session, $staff, $uid);
    }

    public function status($sid) {
        return UC_LMS_Intelligence_Pack::status($sid);
    }

    public function scheduled_seconds($session) {
        return UC_LMS_Intelligence_Pack::scheduled_seconds($session);
    }

    public function staff_user() {
        return UC_LMS_Intelligence_Handlers::staff_user();
    }

    public function routes() {
        return UC_LMS_Intelligence_Handlers::routes();
    }

    public function webhook(WP_REST_Request $req) {
        return UC_LMS_Intelligence_Handlers::webhook($req);
    }

    public function h_sync() {
        UC_LMS_Intelligence_Handlers::h_sync();
    }

    public function h_publish() {
        UC_LMS_Intelligence_Handlers::h_publish();
    }

    public function h_summary() {
        UC_LMS_Intelligence_Handlers::h_summary();
    }

    public function h_task() {
        UC_LMS_Intelligence_Handlers::h_task();
    }

    public function h_csv() {
        UC_LMS_Intelligence_Handlers::h_csv();
    }
}
