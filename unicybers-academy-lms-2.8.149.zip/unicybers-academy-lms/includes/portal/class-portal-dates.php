<?php
/**
 * UniCybers Academy LMS: Portal Timezone & Date Formatting Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Dates {

    public static function academy_tz(){ return 'Asia/Kolkata'; }

    public static function valid_tz($tz){
        $tz = trim((string)$tz);
        $key = strtolower($tz);
        $utc = ['', 'utc', 'gmt', 'gmt+0', 'gmt0', 'etc/utc', 'etc/gmt', 'etc/gmt+0', 'utc+0', 'utc+00', '+00:00', '+00', '0', 'z'];
        if (in_array($key, $utc, true) || $key === 'ist' || $key === 'india' || $key === 'asia/calcutta') {
            return self::academy_tz();
        }
        try { new DateTimeZone($tz); return $tz; } catch (Exception $e) { return self::academy_tz(); }
    }

    public static function session_tz($portal, $s){
        $tz = '';
        if (is_object($s)) {
            $tz = (string)($s->batch_timezone ?? '');
            if ($tz === '' && !empty($s->batch_id)) {
                static $cache = [];
                $bid = (int)$s->batch_id;
                if (!array_key_exists($bid, $cache)) {
                    global $wpdb;
                    $cache[$bid] = (string)$wpdb->get_var($wpdb->prepare("SELECT timezone FROM {$portal->t('batches')} WHERE id=%d", $bid));
                }
                $tz = $cache[$bid];
            }
        }
        return self::valid_tz($tz);
    }

    public static function now_in_tz($tz=''){
        try { return new DateTime('now', new DateTimeZone(self::valid_tz($tz ?: self::academy_tz()))); }
        catch (Exception $e) { return new DateTime('now', new DateTimeZone('Asia/Kolkata')); }
    }

    public static function ts($date,$time,$tz=''){
        $tz = self::valid_tz($tz ?: self::academy_tz());
        try { return (new DateTime(trim($date.' '.($time?:'00:00:00')), new DateTimeZone($tz)))->getTimestamp(); }
        catch (Exception $e) { return 0; }
    }

    public static function class_finished_sql($alias='s'){
        $n = self::now_in_tz();
        $date = esc_sql($n->format('Y-m-d'));
        $time = esc_sql($n->format('H:i:s'));
        return "(LOWER({$alias}.status) IN ('completed','finished') OR {$alias}.session_date < '{$date}' OR ({$alias}.session_date='{$date}' AND IFNULL({$alias}.end_time,'23:59:00') < '{$time}'))";
    }

    public static function ymd($raw){
        $s = sanitize_text_field(wp_unslash($raw));
        if ($s === '') return '';
        $d = DateTime::createFromFormat('!Y-m-d', $s);
        return ($d && $d->format('Y-m-d') === $s) ? $s : null;
    }

    public static function fdate($d,$f='D, j M'){ $ts=strtotime((string)$d); return $ts?date_i18n($f,$ts):''; }

    public static function t12($t){ if(!$t) return ''; $ts=strtotime('2000-01-01 '.$t); return $ts?date('g:i A',$ts):''; }
}
