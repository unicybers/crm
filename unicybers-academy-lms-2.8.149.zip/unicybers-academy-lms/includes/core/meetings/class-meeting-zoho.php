<?php
/** Lightweight Zoho Meeting OAuth, meeting creation and recording sync. */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Meeting_Zoho {
    public static function sanitize_dc($value) {
        $dc = strtolower(trim(sanitize_text_field((string)$value)));
        return in_array($dc, ['com','in','eu','com.au','jp','ca','sa'], true) ? $dc : 'in';
    }

    private static function dc() {
        return self::sanitize_dc(get_option('uc_zoho_dc', 'in'));
    }
    private static function accounts_host() { return 'https://accounts.zoho.'.self::dc(); }
    private static function meeting_host() { return 'https://meeting.zoho.'.self::dc(); }

    public static function connect() {
        if (!current_user_can('manage_options') && !current_user_can('uc_coordinator')) wp_die('Not allowed', 403);
        check_admin_referer('uc_zoho_connect');
        $ref = wp_get_referer();
        if ($ref && strpos($ref, '/settings') !== false) update_user_meta(get_current_user_id(), 'uc_oauth_return', esc_url_raw($ref));
        $client = trim((string)get_option('uc_zoho_client_id', ''));
        $secret = trim((string)get_option('uc_zoho_client_secret', ''));
        if (!$client || !$secret) wp_die('Save the Zoho Client ID and Client Secret first.');
        $redirect = admin_url('admin-post.php?action=uc_zoho_oauth');
        $url = self::accounts_host().'/oauth/v2/auth?'.http_build_query([
            'scope'=>'ZohoMeeting.meeting.CREATE,ZohoMeeting.meeting.UPDATE,ZohoMeeting.recording.READ',
            'client_id'=>$client,
            'response_type'=>'code',
            'access_type'=>'offline',
            'prompt'=>'consent',
            'redirect_uri'=>$redirect,
        ]);
        wp_redirect($url);
        exit;
    }

    public static function oauth() {
        if (!current_user_can('manage_options') && !current_user_can('uc_coordinator')) wp_die('Not allowed', 403);
        $code = sanitize_text_field(wp_unslash($_GET['code'] ?? ''));
        if (!$code) wp_die('Zoho did not return an authorization code.');
        $response = wp_remote_post(self::accounts_host().'/oauth/v2/token', ['timeout'=>25, 'body'=>[
            'grant_type'=>'authorization_code',
            'client_id'=>trim((string)get_option('uc_zoho_client_id','')),
            'client_secret'=>trim((string)get_option('uc_zoho_client_secret','')),
            'redirect_uri'=>admin_url('admin-post.php?action=uc_zoho_oauth'),
            'code'=>$code,
        ]]);
        $data = is_wp_error($response) ? [] : json_decode(wp_remote_retrieve_body($response), true);
        if (empty($data['refresh_token']) && empty($data['access_token'])) {
            $message = is_wp_error($response) ? $response->get_error_message() : (string)($data['error'] ?? 'Zoho authorization failed.');
            wp_die(esc_html($message));
        }
        if (!empty($data['refresh_token'])) update_option('uc_zoho_refresh_token', sanitize_text_field($data['refresh_token']), false);
        if (!empty($data['access_token'])) set_transient('uc_zoho_access_token', sanitize_text_field($data['access_token']), max(60, (int)($data['expires_in'] ?? 3600)-120));
        $back = (string)get_user_meta(get_current_user_id(), 'uc_oauth_return', true);
        delete_user_meta(get_current_user_id(), 'uc_oauth_return');
        if ($back && wp_validate_redirect($back, '') === $back) {
            wp_safe_redirect(add_query_arg('zoho_connected', '1', $back));
        } else {
            wp_safe_redirect(admin_url('admin.php?page=uc-settings&zoho_connected=1'));
        }
        exit;
    }

    public static function access_token() {
        $cached = get_transient('uc_zoho_access_token');
        if (is_string($cached) && $cached !== '') return $cached;
        $refresh = trim((string)get_option('uc_zoho_refresh_token',''));
        $client = trim((string)get_option('uc_zoho_client_id',''));
        $secret = trim((string)get_option('uc_zoho_client_secret',''));
        if (!$refresh || !$client || !$secret) return new WP_Error('zoho_config', 'Connect Zoho Meeting in LMS Settings before creating Zoho classes.');
        $response = wp_remote_post(self::accounts_host().'/oauth/v2/token', ['timeout'=>20, 'body'=>[
            'grant_type'=>'refresh_token','refresh_token'=>$refresh,'client_id'=>$client,'client_secret'=>$secret,
        ]]);
        $data = is_wp_error($response) ? [] : json_decode(wp_remote_retrieve_body($response), true);
        if (empty($data['access_token'])) {
            $message = is_wp_error($response) ? $response->get_error_message() : (string)($data['error'] ?? 'Zoho token refresh failed.');
            return new WP_Error('zoho_token', $message);
        }
        $token = sanitize_text_field($data['access_token']);
        set_transient('uc_zoho_access_token', $token, max(60, (int)($data['expires_in'] ?? 3600)-120));
        return $token;
    }

    private static function request($method, $path, $payload = null) {
        $token = self::access_token();
        if (is_wp_error($token)) return $token;
        $args = ['method'=>$method, 'timeout'=>30, 'headers'=>['Authorization'=>'Zoho-oauthtoken '.$token, 'Accept'=>'application/json']];
        if ($payload !== null) {
            $args['headers']['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
            $args['body'] = ['JSONString'=>wp_json_encode($payload)];
        }
        $response = wp_remote_request(self::meeting_host().$path, $args);
        if (is_wp_error($response)) return $response;
        $status = (int)wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300) {
            $message = is_array($data) ? (string)($data['message'] ?? $data['error']['message'] ?? 'Zoho Meeting API request failed.') : 'Zoho Meeting API request failed.';
            return new WP_Error('zoho_api', $message.' (HTTP '.$status.')');
        }
        return is_array($data) ? $data : [];
    }

    public static function create_meeting($title, $date, $start, $end, $tz) {
        $org = trim((string)get_option('uc_zoho_zsoid',''));
        $presenter = trim((string)get_option('uc_zoho_presenter_id',''));
        if (!$org || !$presenter) return new WP_Error('zoho_config', 'Add the Zoho Organization ID and Presenter User ID in LMS Settings.');
        $zone = $tz ?: 'Asia/Kolkata';
        try { $dtz = new DateTimeZone($zone); } catch (Exception $e) { $dtz = new DateTimeZone('Asia/Kolkata'); $zone = 'Asia/Kolkata'; }
        $start_dt = DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$start,0,5), $dtz);
        if (!$start_dt) return new WP_Error('zoho_date', 'Class date or time is invalid.');
        $end_dt = $end ? DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$end,0,5), $dtz) : false;
        if (!$end_dt || $end_dt <= $start_dt) { $end_dt = clone $start_dt; $end_dt->modify('+90 minutes'); }
        $duration = max(30, ($end_dt->getTimestamp()-$start_dt->getTimestamp())) * 1000;
        $payload = ['session'=>[
            'topic'=>'UniCybers: '.$title,
            'agenda'=>'Scheduled and managed through UniCybers Academy LMS.',
            'presenter'=>$presenter,
            'startTime'=>$start_dt->format('M d, Y h:i A'),
            'duration'=>$duration,
            'timezone'=>$zone,
        ]];
        $response = self::request('POST','/api/v2/'.rawurlencode($org).'/sessions.json',$payload);
        if (is_wp_error($response)) return $response;
        $session = $response['session'] ?? [];
        if (empty($session['joinLink'])) return new WP_Error('zoho_create', 'Zoho did not return a meeting join link.');
        return [
            'join_url'=>esc_url_raw($session['joinLink']),
            'provider_meeting_id'=>sanitize_text_field((string)($session['meetingKey'] ?? '')),
            'provider_data'=>['provider'=>'zoho','start_url'=>esc_url_raw((string)($session['startLink'] ?? '')),'passcode'=>sanitize_text_field((string)($session['pwd'] ?? ''))],
            'passcode'=>sanitize_text_field((string)($session['pwd'] ?? '')),
        ];
    }


    public static function update_meeting($meeting_key, $title, $date, $start, $end, $tz) {
        $org = trim((string)get_option('uc_zoho_zsoid',''));
        $presenter = trim((string)get_option('uc_zoho_presenter_id',''));
        if (!$org || !$presenter || !$meeting_key) return new WP_Error('zoho_config', 'Zoho Organization ID, Presenter ID or Meeting Key is missing.');
        $zone = $tz ?: 'Asia/Kolkata';
        try { $dtz = new DateTimeZone($zone); } catch (Exception $e) { $dtz = new DateTimeZone('Asia/Kolkata'); $zone = 'Asia/Kolkata'; }
        $start_dt = DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$start,0,5), $dtz);
        if (!$start_dt) return new WP_Error('zoho_date', 'Class date or time is invalid.');
        $end_dt = $end ? DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$end,0,5), $dtz) : false;
        if (!$end_dt || $end_dt <= $start_dt) { $end_dt = clone $start_dt; $end_dt->modify('+90 minutes'); }
        $duration = max(30, ($end_dt->getTimestamp()-$start_dt->getTimestamp())) * 1000;
        $payload = ['session'=>[
            'topic'=>'UniCybers: '.$title,
            'presenter'=>$presenter,
            'startTime'=>$start_dt->format('M d, Y h:i A'),
            'duration'=>$duration,
            'timezone'=>$zone,
        ]];
        $response = self::request('PUT','/api/v2/'.rawurlencode($org).'/sessions/'.rawurlencode((string)$meeting_key).'.json',$payload);
        if (is_wp_error($response)) return $response;
        $session = $response['session'] ?? [];
        return [
            'join_url'=>esc_url_raw((string)($session['joinLink'] ?? '')),
            'provider_meeting_id'=>sanitize_text_field((string)($session['meetingKey'] ?? $meeting_key)),
            'provider_data'=>['provider'=>'zoho','start_url'=>esc_url_raw((string)($session['startLink'] ?? '')),'passcode'=>sanitize_text_field((string)($session['pwd'] ?? ''))],
            'passcode'=>sanitize_text_field((string)($session['pwd'] ?? '')),
        ];
    }

    public static function keep_secret($value) {
        $value = is_string($value) ? trim($value) : '';
        return $value !== '' ? $value : (string)get_option('uc_zoho_client_secret', '');
    }

    public static function sync_recordings() {
        global $wpdb;
        if (get_transient('uc_lms_zoho_recording_lock')) return 0;
        $org = trim((string)get_option('uc_zoho_zsoid',''));
        if (!$org || !get_option('uc_zoho_refresh_token')) return 0;
        set_transient('uc_lms_zoho_recording_lock',1,4*MINUTE_IN_SECONDS);
        $found = self::request('GET','/meeting/api/v2/'.rawurlencode($org).'/recordings.json');
        if (is_wp_error($found)) { delete_transient('uc_lms_zoho_recording_lock'); return $found; }
        $count = 0;
        $sessions = UC_LMS_Database::table('sessions');
        foreach ((array)($found['recordings'] ?? []) as $recording) {
            $meeting_key = sanitize_text_field((string)($recording['meetingKey'] ?? ''));
            $play = esc_url_raw((string)($recording['playUrl'] ?? ''));
            if (!$meeting_key || !$play || strtoupper((string)($recording['status'] ?? '')) !== 'UPLOADED') continue;
            $session = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$sessions} WHERE provider_meeting_id=%s AND platform='zoho' ORDER BY session_date DESC LIMIT 1", $meeting_key));
            if (!$session) continue;
            $ok = $wpdb->update($sessions, ['recording_url'=>$play,'recording_status'=>'available','recording_notes'=>sanitize_text_field((string)($recording['topic'] ?? 'Zoho Meeting recording')),'recording_at'=>!empty($recording['startTimeinMs']) ? gmdate('Y-m-d H:i:s', (int)$recording['startTimeinMs']/1000) : current_time('mysql')], ['id'=>(int)$session->id]);
            if ($ok !== false && $ok > 0) $count++;
        }
        delete_transient('uc_lms_zoho_recording_lock');
        return $count;
    }
}
