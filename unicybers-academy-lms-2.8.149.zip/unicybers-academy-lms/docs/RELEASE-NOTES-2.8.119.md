# UniCybers Academy LMS 2.8.119

## Sidebar logo

- Uses the original logo at https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp.
- Shows that artwork in the sidebar: globe on the left, UNICYBERS on the top line.
- Covers the old tagline with orange ACADEMY at the same width as UNICYBERS.
- No border and no replacement emblem.
- No database changes.
