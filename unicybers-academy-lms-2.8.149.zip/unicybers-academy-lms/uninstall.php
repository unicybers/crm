<?php
/**
 * UniCybers Academy LMS: Uninstall Handler.
 *
 * Executed only when the plugin is deleted via the WordPress Admin Plugins screen.
 * Retains historical student records and database tables to prevent catastrophic data loss.
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clear runtime transients
delete_transient('uc_tables_cache');
delete_transient('uc_default_counts_cache');
delete_option('uc_portal_rules');

// Flush rewrite rules
flush_rewrite_rules(false);
