<?php
/**
 * UniCybers Academy LMS: Admin Legacy Handlers Facade & Router.
 *
 * Coordinates backward compatibility for all WP-Admin pages and form POST actions
 * by delegating to specialized Admin Batches, Students, Operations, and Settings controllers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Admin_Legacy_Handlers extends UC_LMS_Admin_Base {
    public static function instance() {
        static $i = null;
        if (!$i) $i = new self();
        return $i;
    }

    public static function init() {}

    // Batches & Sessions Delegations
    public function day_labels() { return UC_LMS_Admin_Batches::instance()->day_labels(); }
    public function batch_form($batch = null) { UC_LMS_Admin_Batches::instance()->batch_form($batch); }
    public function batches_page() { UC_LMS_Admin_Batches::instance()->batches_page(); }
    public function batch_payload() { return UC_LMS_Admin_Batches::instance()->batch_payload(); }
    public function save_batch() { UC_LMS_Admin_Batches::instance()->save_batch(); }
    public function update_batch() { UC_LMS_Admin_Batches::instance()->update_batch(); }
    public function sync_batch_schedule($batch_id, $data = null) { return UC_LMS_Admin_Batches::instance()->sync_batch_schedule($batch_id); }
    public function generate_sessions($batch_id, $data = null) { return UC_LMS_Admin_Batches::instance()->generate_sessions($batch_id); }
    public function refresh_session_links($batch_id, $join_url = '', $platform = '') { return UC_LMS_Admin_Batches::instance()->refresh_session_links($batch_id); }
    public function delete_batch() { UC_LMS_Admin_Batches::instance()->delete_batch(); }
    public function generate_schedule_action() { UC_LMS_Admin_Batches::instance()->generate_schedule_action(); }
    public function sessions_page() { UC_LMS_Admin_Batches::instance()->sessions_page(); }
    public function save_session() { UC_LMS_Admin_Batches::instance()->save_session(); }
    public function update_session() { UC_LMS_Admin_Batches::instance()->update_session(); }
    public function delete_session() { UC_LMS_Admin_Batches::instance()->delete_session(); }

    // Students & Trainers Delegations
    public function student_users() { return UC_LMS_Admin_Students::instance()->student_users(); }
    public function trainer_users() { return UC_LMS_Admin_Students::instance()->trainer_users(); }
    public function students_page() { UC_LMS_Admin_Students::instance()->students_page(); }
    public function save_student() { UC_LMS_Admin_Students::instance()->save_student(); }
    public function enrol_student() { UC_LMS_Admin_Students::instance()->enrol_student(); }
    public function remove_enrolment() { UC_LMS_Admin_Students::instance()->remove_enrolment(); }
    public function trainers_page() { UC_LMS_Admin_Students::instance()->trainers_page(); }
    public function assign_trainer_batch() { UC_LMS_Admin_Students::instance()->assign_trainer_batch(); }
    public function save_trainer() { UC_LMS_Admin_Students::instance()->save_trainer(); }

    // Operations Delegations
    public function attendance_page() { UC_LMS_Admin_Operations::instance()->attendance_page(); }
    public function save_attendance() { UC_LMS_Admin_Operations::instance()->save_attendance(); }
    public function materials_page() { UC_LMS_Admin_Operations::instance()->materials_page(); }
    public function save_material() { UC_LMS_Admin_Operations::instance()->save_material(); }
    public function delete_material() { UC_LMS_Admin_Operations::instance()->delete_material(); }
    public function announcements_page() { UC_LMS_Admin_Operations::instance()->announcements_page(); }
    public function save_announcement() { UC_LMS_Admin_Operations::instance()->save_announcement(); }

    // Settings & Zoom Delegations
    public function settings_page() { UC_LMS_Admin_Settings::instance()->settings_page(); }
    public function integrity_page() { UC_LMS_Admin_Settings::instance()->integrity_page(); }
    public function migration_page() { UC_LMS_Admin_Settings::instance()->migration_page(); }
    public function create_zoom() { UC_LMS_Admin_Settings::instance()->create_zoom(); }
    public function update_zoom() { UC_LMS_Admin_Settings::instance()->update_zoom(); }
    public function test_zoom() { UC_LMS_Admin_Settings::instance()->test_zoom(); }
    public function sync_recording() { UC_LMS_Admin_Settings::instance()->sync_recording(); }
    public function sync_all_recordings() { UC_LMS_Admin_Settings::instance()->sync_all_recordings(); }
    public function cleanup_duplicates() { UC_LMS_Admin_Settings::instance()->cleanup_duplicates(); }
}
