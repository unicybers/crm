# UniCybers Academy LMS 2.8.110 — Consolidated Stable Release

## Consolidated features

- Preserves the existing LMS core, portal, classes, batches, attendance, materials and Zoom integration.
- Includes Google Drive recursive batch/category materials indexing and incremental Changes API synchronization.
- Includes Google Meet link creation, requested auto-recording configuration and Drive-based session recording matching.
- Includes Zoho Meeting OAuth, session meeting creation/update and uploaded recording lookup.
- Includes Microsoft Teams meeting creation/update, Graph recording lookup and authenticated recording streaming.
- Includes an extensible provider registry for future meeting platform adapters.
- Includes recurring-series edit scopes and polished weekday selection.
- Includes per-viewer repeated watermark and best-effort viewer restrictions.
- Includes the enlarged UniCybers sidebar branding.
- Excludes Finance UI, handlers and Finance-only module files, with one-time migration of legacy Finance records/fields.
- Includes idempotent device table/index creation to avoid duplicate `user_device` key warnings.

## Release validation

This package is validated with PHP syntax checks for every PHP file, JavaScript syntax checks for both portal scripts, ZIP integrity checks, and static audits for Finance module references and device-index schema paths. It has not been run against the user's live WordPress database, Google Workspace, Zoom, Microsoft 365 or Zoho accounts. Complete provider setup and live acceptance tests are still required after installation.

## Backward compatibility

The upgrade replaces plugin files in place and uses the existing WordPress database. The plugin does not uninstall or recreate the LMS tables. The Finance cleanup is intentionally destructive and runs only once when its completion marker is absent. Make a full database and uploads backup before upgrading.

## 2.8.111 correction

- Corrected the default UniCybers sidebar lockup to display `UNICYBERS` on the first line and orange `ACADEMY` on the second line.
- Uses the user-supplied master logo URL and crops the globe symbol only in the sidebar. The embedded legacy tagline is not shown.
- Migrates only known previous default branding values. Custom white-label tenant names and logos are preserved.
- Restored the existing Zoom Server-to-Server OAuth fields and Test Zoom Connection control in LMS Settings. Existing Zoom option names, class creation, meeting IDs and recording synchronization are retained.
- Added Zoom to the common meeting-provider registry through an adapter to the existing Zoom class-meeting handler.
- No new database tables are required for these changes.
