<?php
/**
 * UniCybers Academy LMS: Portal Login Action Handler & Security Guards.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Login_Handler {

    public static function handle_front_login() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return;
        if (empty($_POST['action']) || $_POST['action'] !== 'uc_lms_login') return;
        $target = UC_LMS_Login::instance()->login_page_url();
        if (!isset($_POST['uc_login_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['uc_login_nonce'])), 'uc_front_login')) {
            wp_safe_redirect(add_query_arg('uc_login_error', 'invalid_request', $target)); exit;
        }
        $email = sanitize_email(wp_unslash($_POST['uc_email'] ?? ''));
        $password = (string)wp_unslash($_POST['uc_password'] ?? '');
        if (!$email || $password === '') { wp_safe_redirect(add_query_arg('uc_login_error', 'missing', $target)); exit; }
        $user = self::resolve_login_user($email);
        $ok_role = $user && (user_can($user, 'manage_options') || array_intersect(['uc_student','uc_trainer','uc_coordinator','uc_hr'], (array)$user->roles));
        if (!$ok_role) { do_action('wp_login_failed', $email, new WP_Error('invalid')); wp_safe_redirect(add_query_arg('uc_login_error', 'invalid', $target)); exit; }
        $signed = wp_signon(['user_login'=>$user->user_login, 'user_password'=>$password, 'remember'=>!empty($_POST['uc_remember'])], is_ssl());
        if (is_wp_error($signed)) {
            $map = ['uc_locked'=>'locked', 'uc_devices'=>'devices', 'uc_disabled'=>'disabled', 'uc_demo_closed'=>'closed', 'uc_demo_retired'=>'retired'];
            $code = $map[$signed->get_error_code()] ?? 'invalid';
            wp_safe_redirect(add_query_arg('uc_login_error', $code, $target)); exit;
        }
        wp_set_current_user($signed->ID);
        wp_safe_redirect(self::role_dashboard_url($signed)); exit;
    }

    public static function resolve_login_user($email) {
        $email = strtolower(trim((string)$email));
        if ($email === '') return false;
        $user = get_user_by('email', $email);
        if ($user) return $user;
        if (preg_match('/@unicybers\\.online$/', $email)) {
            $com = preg_replace('/@unicybers\\.online$/', '@unicybers.com', $email);
            $user = get_user_by('email', $com);
            if ($user) return $user;
        }
        if (preg_match('/@unicybers\\.com$/', $email)) {
            $online = preg_replace('/@unicybers\\.com$/', '@unicybers.online', $email);
            $user = get_user_by('email', $online);
            if ($user) return $user;
        }
        $by_meta = get_users(['meta_key'=>'uc_email_alias','meta_value'=>$email,'number'=>1]);
        return $by_meta ? $by_meta[0] : false;
    }

    public static function login_redirect($redirect_to, $requested_redirect_to, $user) {
        if (is_wp_error($user) || !$user instanceof WP_User) return $redirect_to;
        return self::role_dashboard_url($user) !== home_url('/') ? self::role_dashboard_url($user) : $redirect_to;
    }

    public static function protect_wp_login_entry() {
        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
        if (in_array($action, ['logout','postpass','lostpassword','retrievepassword','resetpass','rp','confirmaction'], true)) return;
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            if (in_array('uc_student', (array)$user->roles, true) || in_array('uc_trainer', (array)$user->roles, true) || in_array('uc_coordinator', (array)$user->roles, true) || in_array('uc_hr', (array)$user->roles, true)) {
                wp_safe_redirect(self::role_dashboard_url($user));
                exit;
            }
        }
        if (!empty($_REQUEST['action']) && $_REQUEST['action'] !== 'login') return;
        if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_REQUEST['loggedout']) && empty($_REQUEST['reauth'])) {
            if (wp_doing_ajax()) return;
            $ref = wp_get_referer();
            if ($ref && strpos($ref, '/wp-admin') === false) {
                wp_safe_redirect(UC_LMS_Login::instance()->login_page_url());
                exit;
            }
        }
    }

    public static function restrict_frontend_roles() {
        if (!is_admin() || !is_user_logged_in() || wp_doing_ajax()) return;
        $action = isset($_REQUEST['action']) ? (string) $_REQUEST['action'] : '';
        if ($action !== '' && (strpos($action, 'uc_portal_') === 0 || strpos($action, 'uc_') === 0)) return;
        $user = wp_get_current_user();
        if (in_array('uc_hr', (array) $user->roles, true)) {
            wp_safe_redirect(self::hr_home());
            exit;
        }
        if (in_array('uc_student', (array) $user->roles, true) || in_array('uc_trainer', (array) $user->roles, true) || in_array('uc_coordinator', (array) $user->roles, true)) {
            wp_safe_redirect(home_url('/dashboard/'));
            exit;
        }
    }

    public static function role_dashboard_url($user) {
        if (!$user instanceof WP_User) return home_url('/login/');

        $roles = (array) $user->roles;
        if (
            user_can($user, 'manage_options') ||
            in_array('uc_student', $roles, true) ||
            in_array('uc_trainer', $roles, true) ||
            in_array('uc_coordinator', $roles, true)
        ) {
            return home_url('/dashboard/');
        }
        if (in_array('uc_hr', $roles, true)) return self::hr_home();

        return home_url('/login/');
    }

    private static function hr_home() {
        $desk = class_exists('UC_LMS_Addons') && UC_LMS_Addons::active('placement');
        return home_url($desk ? '/placement/' : '/help/');
    }
}
