# UniCybers Academy LMS 2.8.120 revision report

Date: 31 October 2026
Package: unicybers-academy-lms-2.8.120.zip
Base: lightweight plugin from 2.8.117. This build does not replace the original 2.8.81 archive.

## What changed

1. Sidebar logo. The globe is a 36px emblem beside the words. UNICYBERS sits above ACADEMY. The shorter line is scaled so both lines share one width. The words are not inside the logo image. There is no border and no crop of the oval lockup.
2. Add Class. Date and Repeat through sit side by side. Repeat through is only for a recurring class. Recurring days copy the class on those weekdays. Custom dates add extra one-off days. Class Room and each batch group start collapsed. Click a group to expand it.
3. Class attendance. The percentage and the words "Attendance rate" are normal HTML text under the ring, so 0% stays readable.
4. Schedules and recording cards use the real platform name only: Zoom, Meet, Teams, or Zoho.
5. Practice mocks. The same mock can be repeated with weekdays, a repeat-through date, and custom dates. One save can create several mocks at the same time.
6. New material files are sent to Google Drive, into a folder named for the batch inside the default materials folder. The folder id can be changed on the form. If Drive refuses the file, it is not kept on WordPress.
7. Recording players block the download control, picture in picture, right click, copy, cut, and drag. A blocked attempt is written to the audit log and shown to the Super Admin as a privacy alert. A browser cannot block an operating-system screenshot.
8. Placement Desk, for Super Admin, shows the saved AI credit balance, an add-credits box, and Pull jobs. The balance is the number you record. The pull uses the jobs API when one is saved, and openings still need a review.
9. LMS Settings stays on the WordPress admin screen, which only administrators can open. Super Admin can save the AI key, credit balance, jobs API URL, shared token, and which menus Coordinator, Trainer, and Student can see. Super Admin keeps every menu.
10. Help and Support includes this revision and an updated short guide. Download this file from Help to keep a copy.

## Settings suggestion

LMS Settings should stay with the Super Admin only. That is already how this screen works: WordPress shows it to administrators, and coordinators, trainers, and students do not get it. Use the new checkboxes to hide a menu from a role. Leave a box checked to keep that feature. Do not give coordinators the Settings screen.

## What this build does not do

- It does not install itself on lms.unicybers.com.
- It does not invent meeting links, recordings, jobs, or an AI credit balance.
- Drive upload needs a Google connection that can create files. A read-only connection will refuse the upload.
- PHP syntax was not checked on this machine because PHP is not installed. portal.js was checked with Node.
