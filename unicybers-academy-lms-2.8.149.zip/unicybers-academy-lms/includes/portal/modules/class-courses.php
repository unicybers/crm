<?php
/**
 * UniCybers Academy LMS: Courses Catalogue Module.
 *
 * Manages course listings, level/category filtering, enrolment status,
 * sharing programme links, and course enquiry interest tracking.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Courses {
    public static function render($portal) {
        global $wpdb;
        $ids = UC_LMS_Portal_Context::in_ids();
        $is_student = UC_LMS_Portal_Context::role() === 'student';
        $is_ops = UC_LMS_Portal_Context::ops();

        $tb_courses    = UC_LMS_Database::table('courses');
        $tb_batches    = UC_LMS_Database::table('batches');
        $tb_enrolments = UC_LMS_Database::table('enrolments');

        $where = $is_student 
            ? "WHERE c.id IN (SELECT course_id FROM `$tb_batches` WHERE id IN ({$ids}))" 
            : ($is_ops ? '' : "WHERE c.id IN (SELECT course_id FROM `$tb_batches` WHERE id IN ({$ids}))");

        $demo_filter = $portal->demo_sql();

        $rows = $wpdb->get_results(
            "SELECT c.*, 
                (SELECT COUNT(*) FROM `$tb_batches` b WHERE b.course_id=c.id AND b.status='active') batches, 
                (SELECT COUNT(DISTINCT e.user_id) FROM `$tb_enrolments` e JOIN `$tb_batches` b2 ON b2.id=e.batch_id JOIN {$wpdb->users} u ON u.ID=e.user_id WHERE b2.course_id=c.id AND e.status='active' AND {$demo_filter}) learners 
            FROM `$tb_courses` c {$where} 
            ORDER BY c.status='active' DESC, c.name"
        );

        $o = '';
        $levels = [];
        $cats = [];
        foreach ($rows as $c) {
            if ($c->level) $levels[$c->level] = 1;
            if ($c->category) $cats[$c->category] = 1;
        }

        $o .= '<div class="course-filters"><span>Level</span>';
        $o .= '<button type="button" class="on" data-filter="level" data-value="">All</button>';
        foreach (array_keys($levels) as $lv) {
            $o .= '<button type="button" data-filter="level" data-value="' . esc_attr($lv) . '">' . $portal->e($lv) . '</button>';
        }
        $o .= '<span>Category</span><button type="button" class="on" data-filter="cat" data-value="">All</button>';
        foreach (array_keys($cats) as $cat) {
            $o .= '<button type="button" data-filter="cat" data-value="' . esc_attr($cat) . '">' . $portal->e($cat) . '</button>';
        }
        $o .= '</div>';

        if (!$rows) {
            return $o . ($is_ops ? self::modal_tpl($portal) : '') . $portal->empty_state('No courses yet', 'Courses you create will appear here.', 'courses');
        }

        $nonce = $is_ops ? wp_create_nonce('uc_portal_course_save') : '';
        $o .= '<div class="cards">';
        foreach ($rows as $c) {
            $meta = implode(' · ', array_filter([$c->level, $c->mode ? ucfirst((string)$c->mode) : '', $c->duration]));
            $st = strtolower($c->status) === 'active' ? $portal->pill('Active', 'ok') : $portal->pill(ucfirst($c->status), 'mut');
            $blurb = trim((string)($c->description ?: ''));
            $o .= '<article class="ccard" data-q="' . esc_attr(strtolower($c->name . ' ' . $c->category . ' ' . $blurb)) . '" data-level="' . esc_attr((string)$c->level) . '" data-cat="' . esc_attr((string)$c->category) . '"><div class="cbody"><span class="cat">' . $portal->e($c->category ?: 'Programme') . '</span><h3>' . $portal->e($c->name) . '</h3>';
            $o .= ($meta ? '<p class="cmeta">' . $portal->e($meta) . '</p>' : '');
            if ($blurb) $o .= '<p class="cblurb">' . $portal->e($blurb) . '</p>';
            $o .= '</div><div class="cfoot"><div class="cstats"><span><b>' . (int)$c->batches . '</b> batches</span><span><b>' . (int)$c->learners . '</b> learners</span>' . $st . '</div>';
            if ($is_ops) {
                $share = home_url('/programme/' . (int)$c->id . '/');
                $edit = [
                    'id'            => (int)$c->id,
                    'name'          => $c->name,
                    'category'      => $c->category,
                    'level'         => $c->level,
                    'duration'      => $c->duration,
                    'mode'          => $c->mode,
                    'status'        => $c->status,
                    'enrolment_open'=> isset($c->enrolment_open) ? (int)$c->enrolment_open : 1,
                    'description'   => $c->description,
                    'outline'       => isset($c->outline) ? $c->outline : ''
                ];
                $o .= '<div class="cacts"><button type="button" class="btn ghost sm" data-share="' . esc_attr($share) . '" data-share-title="' . esc_attr($c->name) . '">Share</button>';
                $o .= '<button type="button" class="btn ghost sm" data-edit-course=\'' . esc_attr(wp_json_encode($edit)) . '\'>Edit</button>';
                $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_course_save"><input type="hidden" name="_wpnonce" value="' . $nonce . '"><input type="hidden" name="id" value="' . (int)$c->id . '"><input type="hidden" name="do" value="delete"><button type="submit" class="btn ghost sm danger-hover" data-confirm="Delete this course? It is removed from the catalogue. Batches keep running and show Unassigned until you pick another course.">Delete</button></form></div>';
            }
            $o .= '</div></article>';
        }
        $o .= '</div>';
        if ($is_ops) {
            $o .= self::modal_tpl($portal) . self::interest_list($portal);
        }
        return $o;
    }

    public static function modal_tpl($portal) {
        $o = '<template id="tplCourse"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="form"><input type="hidden" name="action" value="uc_portal_course_save">' . wp_nonce_field('uc_portal_course_save', '_wpnonce', true, false) . '<input type="hidden" name="id"><input type="hidden" name="do" value="save">';
        $o .= $portal->mhead('CATALOGUE', 'Add Course', true) . '<div class="fgrid">';
        $o .= '<label>Course name<input name="name" required></label><label>Category<input name="category" placeholder="Security Operations…"></label>';
        $o .= '<label>Level<select name="level"><option value="">Not set</option><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></label><label>Duration<input name="duration" placeholder="12 weeks"></label>';
        $o .= '<label>Mode<select name="mode"><option value="live">Live</option><option value="online">Online</option><option value="hybrid">Hybrid</option></select></label><label>Status<select name="status"><option value="active">Active</option><option value="draft">Draft</option><option value="archived">Archived</option></select></label></div>';
        $o .= '<label>About this course<textarea name="description" rows="2" placeholder="Short description shown on the course card"></textarea></label><label>Outline<textarea name="outline" rows="2" placeholder="What the course covers, module by module"></textarea></label>';
        $o .= '<label class="check"><input type="checkbox" name="enrolment_open" value="1"> Open for enrolment</label>';
        $o .= '<div class="mfoot"><div class="mfoot-l" data-editonly><button type="button" class="btn danger sm" data-do="delete" data-confirm="Delete this course? It is removed from the catalogue. Batches keep running and show Unassigned until you pick another course.">Delete</button></div><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary">Save</button></div></form></template>';
        return $o;
    }

    public static function interest_list($portal) {
        $rows = get_option('uc_course_enquiries');
        if (!is_array($rows)) $rows = [];
        $open = [];
        $closed = [];
        foreach ($rows as $i => $r) {
            if (empty($r['id'])) $r['id'] = 'e' . $i;
            $st = $r['status'] ?? 'open';
            if ($st === 'open') $open[] = $r; else $closed[] = $r;
        }
        $post = esc_url(admin_url('admin-post.php'));
        $nonce = wp_nonce_field('uc_portal_enquiry_status', '_wpnonce', true, false);
        $o = '<section class="panel flush"><div class="ph" style="padding:16px 18px 0"><div><span class="eyebrow">ENQUIRIES</span><h3>Course interest</h3></div></div>';
        $o .= '<p class="hint" style="padding:0 18px">These arrive when someone opens a programme link you shared and asks to enrol. Archive a row, or mark it not interested, when they go quiet or say no.</p>';
        $o .= '<div class="tablewrap"><table><thead><tr><th>When</th><th>Course</th><th>Name</th><th>Email</th><th>Phone</th><th>Note</th><th></th></tr></thead><tbody>';
        if (!$open) $o .= '<tr><td colspan="7">No open interest.</td></tr>';
        foreach (array_reverse($open) as $r) {
            $o .= '<tr><td>' . $portal->e($r['at'] ?? '') . '</td><td>' . $portal->e($r['course'] ?? '') . '</td><td>' . $portal->e($r['name'] ?? '') . '</td><td>' . $portal->e($r['email'] ?? '') . '</td><td>' . $portal->e($r['phone'] ?? '') . '</td><td>' . $portal->e($r['note'] ?? '') . '</td><td class="acts">';
            $o .= '<form method="post" action="' . $post . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_enquiry_status">' . $nonce . '<input type="hidden" name="id" value="' . esc_attr($r['id']) . '"><button class="btn ghost sm" name="status" value="archived">Archive</button><button class="btn ghost sm" name="status" value="not_interested">Not interested</button></form></td></tr>';
        }
        $o .= '</tbody></table></div>';
        if ($closed) {
            $o .= '<details class="lib-inner" style="margin:0 18px 14px"><summary>Archived and not interested <span class="count">' . count($closed) . '</span></summary>';
            foreach (array_reverse($closed) as $r) {
                $lab = ($r['status'] ?? '') === 'archived' ? 'Archived' : 'Not interested';
                $o .= '<div class="req"><div><strong>' . $portal->e($r['name'] ?? '') . '</strong><small>' . $portal->e($r['course'] ?? '') . ' · ' . $portal->e($r['email'] ?? '') . ' · ' . $lab . '</small></div>';
                $o .= '<form method="post" action="' . $post . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_enquiry_status">' . $nonce . '<input type="hidden" name="id" value="' . esc_attr($r['id']) . '"><button class="btn ghost sm" name="status" value="open">Restore</button></form></div>';
            }
            $o .= '</details>';
        }
        return $o . '</section>';
    }
}
