(function () {
  var bill = 'year';
  function money(n, cur) {
    if (cur === 'INR') return '₹' + Number(n).toLocaleString('en-IN');
    return '$' + Number(n).toLocaleString('en-US');
  }
  function paint() {
    var P = window.UC_PRICES;
    if (!P) return;
    var on = P.show === true;
    var billBox = document.getElementById('bill');
    if (billBox) billBox.hidden = !on;
    document.querySelectorAll('.price-note,.amt,.inr').forEach(function (el) { el.hidden = !on; });
    if (!on) return;
    document.querySelectorAll('[data-plan]').forEach(function (el) {
      var row = P[el.getAttribute('data-plan')];
      if (!row) return;
      var usd = bill === 'year' ? row.yearUsd : row.monthUsd;
      var inr = bill === 'year' ? row.yearInr : row.monthInr;
      var per = bill === 'year' ? ' / year' : ' / month';
      var amt = el.querySelector('[data-amt]');
      var sub = el.querySelector('[data-inr]');
      if (amt) { amt.innerHTML = money(usd, 'USD') + '<small>' + per + '</small>'; amt.classList.remove('tick'); void amt.offsetWidth; amt.classList.add('tick'); }
      if (sub) sub.textContent = money(inr, 'INR') + per;
    });
  }
  var sw = document.getElementById('bill');
  if (sw) sw.addEventListener('click', function (e) {
    var b = e.target.closest('button');
    if (!b) return;
    bill = b.getAttribute('data-bill');
    sw.querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); });
    paint();
  });
  paint();

  function fitTour() {
    var frame = document.getElementById('look');
    if (frame) frame.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  document.querySelectorAll('a[href="#look"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      fitTour();
      if (history.replaceState) history.replaceState(null, '', '#look');
    });
  });
  if (location.hash === '#look') fitTour();

  var fsBtn = document.getElementById('demoFs');
  var stage = document.getElementById('stage');
  function fsLabel() {
    if (!fsBtn) return;
    fsBtn.textContent = document.fullscreenElement ? 'Exit' : 'Full screen';
  }
  if (fsBtn && stage) {
    fsBtn.addEventListener('click', function () {
      if (document.fullscreenElement) document.exitFullscreen();
      else if (stage.requestFullscreen) stage.requestFullscreen();
    });
    document.addEventListener('fullscreenchange', fsLabel);
  }

  document.body.addEventListener('click', function (e) {
    var jump = e.target.closest('[data-demo]');
    if (jump) {
      var frame = document.getElementById('demo');
      if (frame && frame.contentWindow) {
        frame.contentWindow.postMessage({ type: 'uc-demo', page: jump.getAttribute('data-demo'), role: jump.getAttribute('data-demo-role') || '' }, '*');
      }
      var dock = jump.parentElement;
      if (dock && dock.classList.contains('dock')) {
        dock.querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === jump); });
      }
      var stage = document.getElementById('stage') || document.getElementById('look');
      if (stage && !stage.contains(jump)) stage.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (e.target.closest('[data-open="connect"]')) {
      var box = document.getElementById('connect');
      if (box && box.showModal) box.showModal();
    }
    if (e.target.closest('[data-close]')) {
      var open = document.getElementById('connect');
      if (open && open.close) open.close();
    }
  });

  if (location.hash === '#connect') {
    var start = document.getElementById('connect');
    if (start && start.showModal) start.showModal();
  }
  var form = document.getElementById('connectForm');
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    var data = new FormData(form);
    var body = 'Name: ' + data.get('name') + '\nAcademy: ' + data.get('academy') + '\nEmail: ' + data.get('email') + '\nTopic: ' + data.get('topic') + '\n\n' + (data.get('note') || '');
    location.href = 'mailto:info@unicybers.com?subject=' + encodeURIComponent('Academy LMS · ' + data.get('topic')) + '&body=' + encodeURIComponent(body);
  });
})();
