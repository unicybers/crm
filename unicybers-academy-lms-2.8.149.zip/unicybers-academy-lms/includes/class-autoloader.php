<?php
/**
 * UniCybers Academy LMS Autoloader.
 *
 * Provides instant zero-overhead class loading on demand.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Autoloader {
    private static $class_map = [];
    private static $base_dir = '';

    public static function register($base_dir) {
        self::$base_dir = trailingslashit($base_dir);
        self::init_map();
        spl_autoload_register([__CLASS__, 'autoload']);
    }

    private static function init_map() {
        self::$class_map = [
            // Core Services
            'UC_LMS_Database'            => 'includes/core/class-database.php',
            'UC_LMS_Database_Schema'     => 'includes/core/database/class-database-schema.php',
            'UC_LMS_Database_Migrations' => 'includes/core/database/class-database-migrations.php',
            'UC_LMS_Addons'              => 'includes/core/class-addons.php',
            'UC_LMS_Security'            => 'includes/core/class-security.php',
            'UC_LMS_Zoom'                => 'includes/core/class-zoom.php',
            'UC_LMS_Zoom_Client'         => 'includes/core/zoom/class-zoom-client.php',
            'UC_LMS_Zoom_Meeting'        => 'includes/core/zoom/class-zoom-meeting.php',
            'UC_LMS_Zoom_Recordings'     => 'includes/core/zoom/class-zoom-recordings.php',
            'UC_LMS_Zoom_Storage'        => 'includes/core/zoom/class-zoom-storage.php',
            'UC_LMS_Meeting'             => 'includes/core/class-meeting.php',
            'UC_LMS_Meeting_Google'      => 'includes/core/meetings/class-meeting-google.php',
            'UC_LMS_Meeting_Drive'       => 'includes/core/meetings/class-meeting-drive.php',
            'UC_LMS_Meeting_Drive_Notes' => 'includes/core/meetings/class-meeting-drive-notes.php',
            'UC_LMS_Meeting_Teams'       => 'includes/core/meetings/class-meeting-teams.php',
            'UC_LMS_Cron'                => 'includes/core/class-cron.php',
            'UC_LMS_Rest'                => 'includes/core/class-rest.php',

            // Admin Modules
            'UC_LMS_Admin_Base'          => 'includes/admin/class-admin-base.php',
            'UC_LMS_Admin_Controller'    => 'includes/admin/class-admin-controller.php',
            'UC_LMS_Admin_Legacy_Handlers' => 'includes/admin/class-admin-legacy-handlers.php',
            'UC_LMS_Admin_Courses'       => 'includes/admin/class-admin-courses.php',
            'UC_LMS_Admin_Batches'       => 'includes/admin/class-admin-batches.php',
            'UC_LMS_Admin_Students'      => 'includes/admin/class-admin-students.php',
            'UC_LMS_Admin_Settings'      => 'includes/admin/class-admin-settings.php',
            'UC_LMS_Admin_Operations'    => 'includes/admin/class-admin-operations.php',

            // Portal System
            'UC_LMS_Login'               => 'includes/portal/class-login.php',
            'UC_LMS_Login_Assets'        => 'includes/portal/auth/class-login-assets.php',
            'UC_LMS_Login_View'          => 'includes/portal/auth/class-login-view.php',
            'UC_LMS_Login_Handler'       => 'includes/portal/auth/class-login-handler.php',
            'UC_LMS_Portal'              => 'includes/class-portal.php',
            'UC_LMS_Portal_Router'       => 'includes/class-portal.php',
            'UC_LMS_Portal_Facade'       => 'includes/portal/trait-portal-facade.php',
            'UC_LMS_Portal_Helpers'      => 'includes/portal/class-portal-helpers.php',
            'UC_LMS_Portal_Dates'        => 'includes/portal/class-portal-dates.php',
            'UC_LMS_Portal_Flash'        => 'includes/portal/class-portal-flash.php',
            'UC_LMS_Portal_Context'      => 'includes/portal/class-portal-context.php',
            'UC_LMS_Portal_Icons'        => 'includes/portal/class-portal-icons.php',
            'UC_LMS_Portal_Layout'       => 'includes/portal/class-portal-layout.php',

            // Portal Domain Services
            'UC_LMS_Portal_Stream'       => 'includes/portal/services/class-portal-stream.php',
            'UC_LMS_Portal_Reports_Engine' => 'includes/portal/services/class-portal-reports.php',
            'UC_LMS_Portal_Mailer'       => 'includes/portal/services/class-portal-mailer.php',
            'UC_LMS_Portal_Library'      => 'includes/portal/services/class-portal-library.php',
            'UC_LMS_Portal_Library_Views' => 'includes/portal/services/class-portal-library-views.php',
            'UC_LMS_Portal_Schedule'     => 'includes/portal/services/class-portal-schedule.php',
            'UC_LMS_Portal_Search'       => 'includes/portal/services/class-portal-search.php',
            'UC_LMS_Portal_Public'       => 'includes/portal/services/class-portal-public.php',

            // Portal Modules
            'UC_LMS_Module_Dashboard'    => 'includes/portal/modules/class-dashboard.php',
            'UC_LMS_Module_Classroom'    => 'includes/portal/modules/class-classroom.php',
            'UC_LMS_Classroom_Cards'     => 'includes/portal/modules/class-classroom-cards.php',
            'UC_LMS_Module_Courses'      => 'includes/portal/modules/class-courses.php',
            'UC_LMS_Module_Batches'      => 'includes/portal/modules/class-batches.php',
            'UC_LMS_Module_Classes'      => 'includes/portal/modules/class-classes.php',
            'UC_LMS_Module_Practice'     => 'includes/portal/modules/class-practice.php',
            'UC_LMS_Module_Materials'    => 'includes/portal/modules/class-materials.php',
            'UC_LMS_Module_People'       => 'includes/portal/modules/class-people.php',
            'UC_LMS_Module_Tenants'      => 'includes/portal/modules/class-tenants.php',
            'UC_LMS_Module_Messages'     => 'includes/portal/modules/class-messages.php',
            'UC_LMS_Module_Reports'      => 'includes/portal/modules/class-reports.php',
            'UC_LMS_Module_Viewer'       => 'includes/portal/modules/class-viewer.php',
            'UC_LMS_Module_Support'      => 'includes/portal/modules/class-support.php',
            'UC_LMS_Module_Preview'      => 'includes/portal/modules/class-preview.php',
            'UC_LMS_Module_Settings'     => 'includes/portal/modules/class-settings.php',
            'UC_LMS_Module_Profile'      => 'includes/portal/modules/class-profile.php',
            'UC_LMS_Module_Audit'        => 'includes/portal/modules/class-audit.php',
            'UC_LMS_Module_Auth'         => 'includes/portal/modules/class-auth.php',

            // Portal Action Handlers
            'UC_LMS_Handler_Academic'    => 'includes/portal/handlers/class-handler-academic.php',
            'UC_LMS_Handler_Sessions'    => 'includes/portal/handlers/class-handler-sessions.php',
            'UC_LMS_Handler_Media'       => 'includes/portal/handlers/class-handler-media.php',
            'UC_LMS_Handler_Materials'   => 'includes/portal/handlers/class-handler-materials.php',
            'UC_LMS_Handler_People'      => 'includes/portal/handlers/class-handler-people.php',
            'UC_LMS_Handler_Tenants'     => 'includes/portal/handlers/class-handler-tenants.php',
            'UC_LMS_Handler_Reports'     => 'includes/portal/handlers/class-handler-reports.php',

            // Existing Specialized Modules
            'UC_LMS_Intelligence'        => 'includes/class-intelligence.php',
            'UC_LMS_Intelligence_Schema'   => 'includes/intelligence/class-intelligence-schema.php',
            'UC_LMS_Intelligence_Sync'     => 'includes/intelligence/class-intelligence-sync.php',
            'UC_LMS_Intelligence_Ingest'   => 'includes/intelligence/class-intelligence-ingest.php',
            'UC_LMS_Intelligence_Pack'     => 'includes/intelligence/class-intelligence-pack.php',
            'UC_LMS_Intelligence_Handlers' => 'includes/intelligence/class-intelligence-handlers.php',
            'UC_LMS_Career_Bridge'       => 'includes/class-career-bridge.php',
        ];
    }

    public static function autoload($class) {
        if (isset(self::$class_map[$class])) {
            $file = self::$base_dir . self::$class_map[$class];
            if (file_exists($file)) {
                require_once $file;
                return true;
            }
        }

        // Dynamic fallback for any additional UC_LMS_* classes
        if (strpos($class, 'UC_LMS_') === 0) {
            $clean = strtolower(str_replace('_', '-', substr($class, 7)));
            $candidates = [
                self::$base_dir . 'includes/core/class-' . $clean . '.php',
                self::$base_dir . 'includes/core/meetings/class-' . $clean . '.php',
                self::$base_dir . 'includes/core/zoom/class-' . $clean . '.php',
                self::$base_dir . 'includes/core/database/class-' . $clean . '.php',
                self::$base_dir . 'includes/admin/class-' . $clean . '.php',
                self::$base_dir . 'includes/portal/class-' . $clean . '.php',
                self::$base_dir . 'includes/portal/auth/class-' . $clean . '.php',
                self::$base_dir . 'includes/portal/modules/class-' . $clean . '.php',
                self::$base_dir . 'includes/portal/handlers/class-' . $clean . '.php',
                self::$base_dir . 'includes/portal/services/class-' . $clean . '.php',
                self::$base_dir . 'includes/intelligence/class-' . $clean . '.php',
                self::$base_dir . 'includes/class-' . $clean . '.php',
            ];
            foreach ($candidates as $candidate) {
                if (file_exists($candidate)) {
                    require_once $candidate;
                    return true;
                }
            }
        }

        return false;
    }
}
