<?php
/**
 * UniCybers Academy LMS: Zoom Recording Cache, Upload Storage & Streamer.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Zoom_Storage {

    public static function cached_recording_path($session) {
        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) return '';
        return rtrim((string)$uploads['basedir'], '/') . '/uc-lms-recordings/' . (int)$session->id . '.mp4';
    }

    public static function uuid_path($uuid) {
        $uuid = (string)$uuid;
        return strpos($uuid, '/') !== false ? rawurlencode(rawurlencode($uuid)) : rawurlencode($uuid);
    }

    public static function zoom_recording_for_session($session) {
        return UC_LMS_Zoom_Recordings::zoom_recording_for_session($session);
    }

    public static function sync_one_recording($session) {
        return UC_LMS_Zoom_Recordings::sync_one_recording($session);
    }

    public static function portal_recording_fetch_url($session) {
        $data = self::zoom_recording_for_session($session);
        if (is_wp_error($data)) return '';
        $rank = ['shared_screen_with_speaker_view' => 5, 'shared_screen_with_gallery_view' => 4, 'active_speaker' => 3, 'shared_screen' => 2, 'gallery_view' => 1];
        $pick = ''; $best = -1; $alt = ''; $altbest = -1;
        foreach ((array)($data['recording_files'] ?? []) as $f) {
            if (strtolower((string)($f['file_type'] ?? '')) !== 'mp4' || empty($f['download_url'])) continue;
            if (strtolower((string)($f['status'] ?? 'completed')) !== 'completed') continue;
            $size = (int)($f['file_size'] ?? 0);
            $score = $rank[strtolower((string)($f['recording_type'] ?? ''))] ?? 0;
            if ($size && $size < 400000) {
                if ($score > $altbest) { $altbest = $score; $alt = (string)$f['download_url']; }
                continue;
            }
            if ($score > $best) { $best = $score; $pick = (string)$f['download_url']; }
        }
        if ($pick === '') $pick = $alt;
        if ($pick === '') return '';
        if (!empty($data['download_access_token'])) $pick .= (strpos($pick, '?') === false ? '?' : '&') . 'access_token=' . rawurlencode((string)$data['download_access_token']);
        return $pick;
    }

    public static function portal_discard_recording($session) {
        $path = self::cached_recording_path($session);
        if ($path && is_file($path)) @unlink($path);
        if ($path && is_file($path . '.part')) @unlink($path . '.part');
        global $wpdb;
        $now = current_time('mysql');
        $wpdb->update(UC_LMS_Database::table('sessions'), [
            'recording_url'      => null,
            'recording_status'   => 'discarded',
            'recording_duration' => 0,
            'recording_passcode' => null,
            'zoom_uuid'          => null,
            'recording_at'       => null,
            'updated_at'         => $now,
        ], ['id' => (int)$session->id]);
    }

    public static function portal_pull_recording($session) {
        if (strtolower((string)($session->recording_status ?? '')) === 'discarded') return new WP_Error('recording', 'This recording was removed from the library.');
        $session = UC_LMS_Zoom_Meeting::portal_ensure_meeting_id($session);
        $why = '';
        if (empty($session->zoom_meeting_id)) {
            $why = 'This class only has a Zoom share webpage, not a meeting ID, so the MP4 cannot be downloaded.';
        } else {
            $r = self::sync_one_recording($session);
            if (is_wp_error($r)) $why = $r->get_error_message();
        }
        global $wpdb;
        $fresh = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . UC_LMS_Database::table('sessions') . " WHERE id=%d", (int)$session->id));
        if ($fresh) $session = $fresh;
        $path = self::portal_cache_recording($session);
        if ($path) return $path;
        if ($why === '') $why = 'Zoom did not return a video file for this class.';
        return new WP_Error('recording', $why);
    }

    public static function portal_cache_recording($session) {
        $path = self::cached_recording_path($session);
        if ($path && is_file($path) && filesize($path) > 50000) return $path;
        $url = self::portal_recording_fetch_url($session);
        if ($url === '' || !function_exists('curl_init') || !$path) return '';
        $dir = dirname($path);
        if (!wp_mkdir_p($dir)) return '';
        $ht = $dir . '/.htaccess';
        if (!is_file($ht)) @file_put_contents($ht, "Require all denied\n");
        $token = UC_LMS_Zoom_Client::token();
        $access = is_wp_error($token) ? '' : (string)$token;
        $tmp = $path . '.part';
        $fp = fopen($tmp, 'wb');
        if (!$fp) return '';
        $headers = ['User-Agent: UniCybersLMS'];
        if ($access && stripos($url, 'zoom.us') !== false && strpos($url, 'access_token=') === false) $headers[] = 'Authorization: Bearer ' . $access;
        $ch = curl_init($url);
        $type = '';
        curl_setopt_array($ch, [
            CURLOPT_FILE            => $fp,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_UNRESTRICTED_AUTH => false,
            CURLOPT_MAXREDIRS       => 8,
            CURLOPT_CONNECTTIMEOUT  => 20,
            CURLOPT_TIMEOUT         => 180,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_HEADERFUNCTION  => function($ch, $h) use (&$type) {
                $p = strpos($h, ':');
                if ($p && strtolower(trim(substr($h, 0, $p))) === 'content-type') $type = trim(substr($h, $p + 1));
                return strlen($h);
            },
        ]);
        $ok = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);
        $size = is_file($tmp) ? filesize($tmp) : 0;
        $html = $type && (stripos($type, 'text/html') !== false || stripos($type, 'json') !== false);
        if (!$ok || $code >= 400 || $html || $size < 50000) { @unlink($tmp); return ''; }
        @rename($tmp, $path);
        return (is_file($path) && filesize($path) > 50000) ? $path : '';
    }

    public static function portal_store_uploaded_recording($session, $file) {
        if (!is_array($file) || empty($file['tmp_name'])) return new WP_Error('recording', 'Choose an MP4 file first.');
        $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err !== UPLOAD_ERR_OK) {
            $lim = size_format((int)wp_max_upload_size());
            if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) return new WP_Error('recording', 'The host rejected that upload. Current limit is ' . $lim . '.');
            return new WP_Error('recording', 'The file did not upload. Try again.');
        }
        $name = strtolower((string)($file['name'] ?? ''));
        if (!preg_match('/\.(mp4|m4v|webm)$/', $name)) return new WP_Error('recording', 'Upload an MP4 (or WebM) from Zoom Recordings.');
        if ((int)$file['size'] < 50000) return new WP_Error('recording', 'That file is too small to be a class recording.');
        $path = self::cached_recording_path($session);
        if ($path === '') return new WP_Error('recording', 'The uploads folder is not writable.');
        $dir = dirname($path);
        if (!wp_mkdir_p($dir)) return new WP_Error('recording', 'Could not create the recordings folder.');
        $ht = $dir . '/.htaccess';
        if (!is_file($ht)) @file_put_contents($ht, "Require all denied\n");
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $move = wp_handle_upload($file, ['test_form' => false, 'mimes' => ['mp4' => 'video/mp4', 'm4v' => 'video/x-m4v', 'webm' => 'video/webm']]);
        if (!empty($move['error'])) return new WP_Error('recording', (string)$move['error']);
        $from = (string)($move['file'] ?? '');
        if ($from === '' || !is_file($from)) return new WP_Error('recording', 'The file did not land on the server.');
        if (is_file($path)) @unlink($path);
        if (!@rename($from, $path)) {
            $copied = @copy($from, $path);
            @unlink($from);
            if (!$copied) return new WP_Error('recording', 'Could not store the recording file.');
        }
        if (!is_file($path) || filesize($path) < 50000) {
            @unlink($path);
            return new WP_Error('recording', 'That file could not be stored as a recording.');
        }
        global $wpdb;
        $now = current_time('mysql');
        $url = home_url('/lms-media/recording/' . (int)$session->id . '/');
        $wpdb->update(UC_LMS_Database::table('sessions'), [
            'recording_url'    => esc_url_raw($url),
            'recording_status' => 'available',
            'recording_at'     => $now,
            'updated_at'       => $now,
        ], ['id' => (int)$session->id]);
        return $path;
    }

    private static function stream_local_mp4($path) {
        $size = filesize($path);
        $start = 0; $end = $size - 1; $code = 200;
        if (!empty($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d+)-(\d*)/', (string)$_SERVER['HTTP_RANGE'], $m)) {
            $start = (int)$m[1];
            if ($m[2] !== '') $end = (int)$m[2];
            if ($end >= $size) $end = $size - 1;
            if ($start > $end) { $start = 0; $end = $size - 1; }
            else $code = 206;
        }
        if (!headers_sent()) {
            http_response_code($code);
            header('Content-Type: video/mp4');
            header('Accept-Ranges: bytes');
            header('Content-Length: ' . ($end - $start + 1));
            if ($code === 206) header("Content-Range: bytes {$start}-{$end}/{$size}");
            header('Cache-Control: private, no-store');
            header('X-Content-Type-Options: nosniff');
        }
        $fp = fopen($path, 'rb');
        if (!$fp) { status_header(404); exit; }
        fseek($fp, $start);
        $left = $end - $start + 1;
        while ($left > 0 && !feof($fp)) {
            $chunk = fread($fp, min(8192, $left));
            if ($chunk === false) break;
            echo $chunk;
            $left -= strlen($chunk);
        }
        fclose($fp);
        exit;
    }

    public static function portal_stream_recording($session) {
        $path = self::cached_recording_path($session);
        if (!$path || !is_file($path) || filesize($path) < 50000) $path = self::portal_cache_recording($session);
        if ($path && is_file($path) && filesize($path) > 50000) self::stream_local_mp4($path);
        $url = self::portal_recording_fetch_url($session);
        if ($url === '' || !function_exists('curl_init')) {
            status_header(404); header('Content-Type: text/plain; charset=utf-8'); echo 'Recording file is not available.'; exit;
        }
        @set_time_limit(0);
        if (function_exists('ignore_user_abort')) ignore_user_abort(true);
        while (ob_get_level() > 0) @ob_end_clean();
        $range = isset($_SERVER['HTTP_RANGE']) ? (string)$_SERVER['HTTP_RANGE'] : '';
        $token = UC_LMS_Zoom_Client::token();
        $access = is_wp_error($token) ? '' : (string)$token;
        $req = ['User-Agent: UniCybersLMS'];
        if ($access && stripos($url, 'zoom.us') !== false && strpos($url, 'access_token=') === false) $req[] = 'Authorization: Bearer ' . $access;
        if ($range !== '') $req[] = 'Range: ' . $range;
        $ch = curl_init($url);
        $meta = ['code' => 200, 'type' => 'video/mp4', 'len' => '', 'crange' => '', 'html' => false, 'started' => false];
        curl_setopt_array($ch, [
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_UNRESTRICTED_AUTH => false,
            CURLOPT_MAXREDIRS       => 8,
            CURLOPT_CONNECTTIMEOUT  => 20,
            CURLOPT_TIMEOUT         => 0,
            CURLOPT_HTTPHEADER      => $req,
            CURLOPT_HEADERFUNCTION  => function($ch, $h) use (&$meta) {
                $trim = trim($h);
                if (preg_match('#^HTTP/\S+\s+(\d+)#', $trim, $m)) $meta['code'] = (int)$m[1];
                $p = strpos($h, ':');
                if ($p) {
                    $k = strtolower(trim(substr($h, 0, $p))); $v = trim(substr($h, $p + 1));
                    if ($k === 'content-type') $meta['type'] = $v;
                    if ($k === 'content-length') $meta['len'] = $v;
                    if ($k === 'content-range') $meta['crange'] = $v;
                }
                if ($trim === '' && !$meta['started']) {
                    $meta['started'] = true;
                    $type = strtolower($meta['type']);
                    $meta['html'] = (strpos($type, 'text/html') !== false) || (strpos($type, 'json') !== false) || ($meta['code'] >= 400 && strpos($type, 'video') === false && strpos($type, 'octet-stream') === false && strpos($type, 'mp4') === false);
                    if ($meta['html']) return -1;
                    if (!headers_sent()) {
                        http_response_code($meta['code'] ?: 200);
                        $send = (strpos($type, 'video') !== false || strpos($type, 'octet-stream') !== false || strpos($type, 'mp4') !== false) ? $meta['type'] : 'video/mp4';
                        header('Content-Type: ' . $send);
                        if ($meta['len'] !== '') header('Content-Length: ' . $meta['len']);
                        if ($meta['crange'] !== '') header('Content-Range: ' . $meta['crange']);
                        header('Accept-Ranges: bytes');
                        header('Cache-Control: private, no-store');
                        header('X-Content-Type-Options: nosniff');
                    }
                }
                return strlen($h);
            },
            CURLOPT_WRITEFUNCTION   => function($ch, $data) use (&$meta) {
                if (!empty($meta['html'])) return 0;
                echo $data;
                return strlen($data);
            },
        ]);
        curl_exec($ch);
        curl_close($ch);
        if (!empty($meta['html']) || empty($meta['started'])) {
            if (!headers_sent()) { status_header(404); header('Content-Type: text/plain; charset=utf-8'); echo 'Recording file is not available.'; }
        }
        exit;
    }
}
