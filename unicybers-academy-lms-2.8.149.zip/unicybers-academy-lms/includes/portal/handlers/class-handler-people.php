<?php
/**
 * UniCybers Academy LMS: People, Devices & Access Handlers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Handler_People {

    public static function demo_password_make($portal){
        $words = ['Kite','Nest','Oak','Pine','Lane','Moss','Reef','Vale'];
        $letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        return $words[random_int(0, count($words)-1)].'-'.random_int(2, 9).$letters[random_int(0, strlen($letters)-1)].'-'.str_pad((string)random_int(10, 99), 2, '0', STR_PAD_LEFT);
    }

    public static function ensure_demo_seats($portal, $password){
        return;
    }

    public static function reset_password($portal, $user, $send = false){
        $pw = UC_LMS_Security::temp_password();
        wp_set_password($pw, $user->ID);
        update_user_meta($user->ID,'uc_must_change',1);
        $sent = $send ? UC_LMS_Security::send_credentials($user, $pw, 'This replaces your previous password.') : false;
        $portal->set_flash('New temporary password for '.$user->display_name.'.'.($sent?' It was emailed to them.':' Share it with them:'), 'ok', $sent ? '' : $pw);
        $portal->back('people');
    }

    public static function person_save($portal){
        $portal->guard('uc_portal_person_save',['super_admin']);
        global $wpdb;
        $id = absint($_POST['id'] ?? 0); $do = sanitize_key($_POST['do'] ?? 'save');
        $target = $id ? get_user_by('id',$id) : null;
        if ($id && !$target) { $portal->set_flash('That account was not found.','warn'); $portal->back('people'); }
        $protected = $target && $portal->is_protected_sa($target);
        if ($do==='delete' && $target) {
            if ($id === get_current_user_id()) { $portal->set_flash('You cannot delete your own account.','warn'); $portal->back('people'); }
            if ($protected) { $portal->set_flash('Rafi’s Super Admin account cannot be deleted.','warn'); $portal->back('people'); }
            if (UC_LMS_Security::is_demo($target)) { $portal->set_flash('Demo seats cannot be deleted.','warn'); $portal->back('people'); }
            require_once ABSPATH.'wp-admin/includes/user.php';
            $wpdb->delete($portal->t('enrolments'),['user_id'=>$id]); if ($portal->has_table('devices')) $wpdb->delete($portal->t('devices'),['user_id'=>$id]);
            wp_delete_user($id);
            $portal->set_flash($target->display_name.' was removed. Attendance history is kept.'); $portal->back('people');
        }
        if ($do==='reset' && $target) { $portal->reset_password($target, !empty($_POST['send'])); }

        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? '')); $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
        $allowed_roles = ['student','trainer','coordinator','hr','super_admin'];
        $role = in_array($_POST['role'] ?? '', $allowed_roles, true) ? $_POST['role'] : 'student';
        if ($protected && $role !== 'super_admin') { $portal->set_flash('Rafi stays Super Admin.','warn'); $portal->back('people'); }
        if (!$name || !is_email($email)) { $portal->set_flash('Enter a name and a valid email.','warn'); $portal->back('people'); }
        $wp_role = $role === 'super_admin' ? 'administrator' : 'uc_'.$role;
        $pw = '';
        if (!$target) {
            if (email_exists($email)) { $portal->set_flash('An account with that email already exists.','warn'); $portal->back('people'); }
            $pw = UC_LMS_Security::temp_password();
            $id = wp_insert_user(['user_login'=>sanitize_user(current(explode('@',$email)).'_'.wp_generate_password(4,false,false),true),'user_email'=>$email,'user_pass'=>$pw,'display_name'=>$name,'first_name'=>strtok($name,' '),'role'=>$wp_role]);
            if (is_wp_error($id)) { $portal->set_flash($id->get_error_message(),'warn'); $portal->back('people'); }
            update_user_meta($id,'uc_must_change',1);
            $target = get_user_by('id',$id);
        } else {
            $upd = ['ID'=>$id,'display_name'=>$name];
            if (strtolower($email) !== strtolower($target->user_email)) { if (email_exists($email)) { $portal->set_flash('Another account already uses that email.','warn'); $portal->back('people'); } $upd['user_email'] = $email; }
            wp_update_user($upd);
            $target->set_role($wp_role);
        }
        foreach (['phone'=>'uc_phone','country'=>'uc_country'] as $f=>$k) update_user_meta($id,$k,sanitize_text_field(wp_unslash($_POST[$f] ?? '')));
        update_user_meta($id,'uc_device_limit', (int)($_POST['limit'] ?? 3) === 5 ? 5 : 3);
        $internal = !empty($_POST['internal_test']) || in_array(strtolower($email), $portal->tester_emails(), true);
        if ($internal) update_user_meta($id,'uc_internal_test',1); else delete_user_meta($id,'uc_internal_test');
        if (!empty($_POST['disabled'])) { update_user_meta($id,'uc_disabled',1); if (class_exists('WP_Session_Tokens')) WP_Session_Tokens::get_instance($id)->destroy_all(); } else delete_user_meta($id,'uc_disabled');
        $batch = absint($_POST['batch'] ?? 0);
        if ($batch && $role==='student') $wpdb->query($wpdb->prepare("INSERT INTO {$portal->t('enrolments')} (batch_id,user_id,status,enrolled_at) VALUES (%d,%d,'active',%s) ON DUPLICATE KEY UPDATE status='active'", $batch, $id, current_time('mysql')));
        if ($pw) {
            $sent = !empty($_POST['send']) ? UC_LMS_Security::send_credentials($target, $pw) : false;
            $portal->set_flash('Account created for '.$name.'.'.($sent?' Sign in details were emailed.':' Share this temporary password with them:'), 'ok', $sent ? '' : $pw);
        } else $portal->set_flash('Saved '.$name.'.');
        $portal->back('people');
    }

    public static function person_delete($portal){ $portal->back('people'); }

    public static function person_reset($portal){ $portal->guard('uc_portal_person_reset',['super_admin']); $u=get_user_by('id',absint($_POST['id']??0)); if($u && !$portal->is_protected_sa($u)) $portal->reset_password($u,!empty($_POST['send'])); $portal->back('people'); }

    public static function person_archive($portal){
        $portal->guard('uc_portal_person_archive',['super_admin']);
        $u = get_user_by('id', absint($_POST['id'] ?? 0));
        $do = sanitize_key($_POST['do'] ?? 'archive');
        if (!$u || $portal->is_protected_sa($u) || UC_LMS_Security::is_demo($u)) { $portal->set_flash('That account cannot be archived.','warn'); $portal->back('people'); }
        if ($do === 'restore') {
            delete_user_meta($u->ID, 'uc_archived');
            delete_user_meta($u->ID, 'uc_disabled');
            $portal->set_flash($u->display_name.' was restored. They can sign in again.');
            $r = $portal->lms_role_of($u);
            $portal->back('people', ['seg'=>($r==='student'?'students':'staff')]);
        }
        update_user_meta($u->ID, 'uc_archived', 1);
        update_user_meta($u->ID, 'uc_disabled', 1);
        if (class_exists('WP_Session_Tokens')) WP_Session_Tokens::get_instance($u->ID)->destroy_all();
        $portal->set_flash($u->display_name.' was archived. Login is off. Restore from Archived when they enrol.');
        $portal->back('people', ['seg'=>'archived']);
    }

    public static function person_remind($portal){
        $portal->guard('uc_portal_person_remind',['super_admin']);
        $note = 'Reminder: use these details to activate your academy login.';
        if (!empty($_POST['pending'])) {
            $n = 0; $wa_n = 0;
            foreach (get_users(['role'=>'uc_student','number'=>2000]) as $u) {
                if (UC_LMS_Security::is_demo($u)) continue;
                if (get_user_meta($u->ID,'uc_archived',true) || get_user_meta($u->ID,'uc_disabled',true)) continue;
                if (get_user_meta($u->ID,'uc_last_login',true)) continue;
                list($pw,$sent,$wa) = $portal->issue_credentials($u, $note);
                if ($sent) $n++;
                if ($wa) $wa_n++;
            }
            $portal->set_flash('Reminded '.$n.' student'.($n===1?'':'s').' by email from academy@unicybers.com.'.($wa_n?' Open each Remind row to send WhatsApp where a phone is saved.':''));
            $portal->back('people', ['seg'=>'students']);
        }
        $u = get_user_by('id', absint($_POST['id'] ?? 0));
        if (!$u) { $portal->set_flash('That account was not found.','warn'); $portal->back('people'); }
        list($pw,$sent,$wa) = $portal->issue_credentials($u, $note);
        $msg = $sent ? 'Credentials emailed to '.$u->user_email.' from academy@unicybers.com.' : 'Email did not send. Share this temporary password.';
        if ($wa) $msg .= ' WhatsApp is ready if they cannot use email.';
        elseif (!$sent) $msg .= ' Add a phone on their profile to send WhatsApp next time.';
        $portal->set_flash($msg, $sent?'ok':'warn', $sent?'':$pw, $wa);
        $portal->back('people', ['seg'=>'students']);
    }

    public static function password($portal){
        if (!is_user_logged_in()) wp_die('Not allowed',403);
        check_admin_referer('uc_portal_password');
        $u = wp_get_current_user(); $must = get_user_meta($u->ID,'uc_must_change',true);
        $old = (string)wp_unslash($_POST['old'] ?? ''); $new = (string)wp_unslash($_POST['new'] ?? ''); $new2 = (string)wp_unslash($_POST['new2'] ?? '');
        $page = $must ? 'setpassword' : 'help';
        if (!wp_check_password($old, $u->user_pass, $u->ID)) { $portal->set_flash('Your current password is not correct.','warn'); $portal->back($page); }
        if (strlen($new) < 8) { $portal->set_flash('Choose at least eight characters.','warn'); $portal->back($page); }
        if ($new !== $new2) { $portal->set_flash('The two new passwords do not match.','warn'); $portal->back($page); }
        if ($new === $old) { $portal->set_flash('Choose something different from your temporary password.','warn'); $portal->back($page); }
        wp_set_password($new, $u->ID);
        delete_user_meta($u->ID,'uc_must_change');
        wp_set_current_user($u->ID); wp_set_auth_cookie($u->ID, true);
        $portal->set_flash('Password updated. Other sessions were signed out.');
        $portal->back($must ? 'dashboard' : 'help');
    }

    public static function device_remove($portal){
        if (!is_user_logged_in()) wp_die('Not allowed',403);
        check_admin_referer('uc_portal_device_remove');
        global $wpdb; $id = absint($_POST['id'] ?? 0);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('devices')} WHERE id=%d", $id));
        $own = $row && (int)$row->user_id === get_current_user_id();
        if ($row && ($own || $portal->ops())) { $wpdb->delete($portal->t('devices'),['id'=>$id]); $portal->set_flash('Device removed.'); }
        $portal->back(!empty($_POST['self']) ? 'help' : 'people');
    }

    public static function device_reset($portal){
        $portal->guard('uc_portal_device_reset',['super_admin','coordinator']);
        global $wpdb; $uid = absint($_POST['user'] ?? 0);
        $wpdb->delete($portal->t('devices'),['user_id'=>$uid]);
        $u = get_user_by('id',$uid); if ($u) { delete_transient('uc_lock_'.md5(strtolower($u->user_email))); delete_transient('uc_fail_'.md5(strtolower($u->user_email))); }
        $portal->set_flash('Devices reset. They can sign in on a new device now.'); $portal->back('people');
    }

    public static function device_limit($portal){
        $portal->guard('uc_portal_device_limit',['super_admin']);
        update_user_meta(absint($_POST['user'] ?? 0),'uc_device_limit', (int)($_POST['limit'] ?? 3) === 5 ? 5 : 3);
        $portal->set_flash('Device limit saved.'); $portal->back('people');
    }

    public static function request_resolve($portal){
        $portal->guard('uc_portal_request_resolve',['super_admin','coordinator']);
        global $wpdb; $id = absint($_POST['id'] ?? 0);
        $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('access_requests')} WHERE id=%d", $id));
        if ($r) {
            if (!empty($_POST['reset']) && $r->user_id) { $wpdb->delete($portal->t('devices'),['user_id'=>(int)$r->user_id]); delete_transient('uc_lock_'.md5(strtolower($r->email))); }
            $wpdb->update($portal->t('access_requests'),['status'=>'resolved','handled_by'=>get_current_user_id(),'handled_at'=>current_time('mysql')],['id'=>$id]);
            $portal->set_flash(!empty($_POST['reset']) ? 'Devices reset and request closed.' : 'Request closed.');
        }
        wp_safe_redirect($portal->url('people').'#requests'); exit;
    }

    public static function student_add($portal){
        $portal->guard('uc_portal_student_add', ['super_admin','coordinator']);
        global $wpdb;
        $batch = absint($_POST['batch_id'] ?? 0);
        if (!in_array($batch, $portal->batch_ids(), true)) wp_die('That batch is not yours.',403);
        $ids = array_map('absint', (array)($_POST['user_ids'] ?? []));
        $added = 0;
        foreach ($ids as $uid) {
            if (!$uid) continue;
            $user = get_user_by('id', $uid);
            if (!$user || $portal->lms_role_of($user) !== 'student') continue;
            if (class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo($user)) continue;
            $on = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('enrolments')} WHERE batch_id=%d AND user_id=%d AND status='active'", $batch, $uid));
            if ($on) continue;
            $wpdb->query($wpdb->prepare("INSERT INTO {$portal->t('enrolments')} (batch_id,user_id,status,enrolled_at) VALUES (%d,%d,'active',%s) ON DUPLICATE KEY UPDATE status='active'", $batch, $uid, current_time('mysql')));
            $added++;
        }
        $portal->set_flash($added ? $added.' student'.($added===1?'':'s').' added to this batch.' : 'Select a student who is not already on this batch.', $added ? 'ok' : 'warn');
        $from = sanitize_key($_POST['from'] ?? 'batches');
        $portal->back($from === 'people' ? 'people' : 'batches', $from === 'people' ? [] : ['students'=>$batch]);
    }

    public static function student_remove($portal){
        $portal->guard('uc_portal_student_remove', ['super_admin','coordinator']);
        global $wpdb;
        $batch = absint($_POST['batch_id'] ?? 0);
        $uid = absint($_POST['user_id'] ?? 0);
        if (!in_array($batch, $portal->batch_ids(), true)) wp_die('That batch is not yours.',403);
        $user = $uid ? get_user_by('id', $uid) : null;
        if (!$user || $portal->lms_role_of($user) !== 'student' || $portal->is_protected_sa($user) || (class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo($user))) {
            $portal->set_flash('Only a student who has stopped classes can be removed here.','warn');
            $portal->back('batches', ['students'=>$batch]);
        }
        $wpdb->update($portal->t('enrolments'), ['status'=>'removed'], ['batch_id'=>$batch,'user_id'=>$uid]);
        update_user_meta($uid, 'uc_disabled', 1);
        if (class_exists('WP_Session_Tokens')) WP_Session_Tokens::get_instance($uid)->destroy_all();
        $portal->log_audit('student',$uid,'remove','Removed from batch '.$batch.' and sign-in revoked');
        $portal->set_flash($user->display_name.' is off this batch. Sign-in is revoked.');
        $portal->back('batches', ['students'=>$batch]);
    }

    public static function student_import($portal){
        $portal->guard('uc_portal_student_import', ['super_admin','coordinator']);
        global $wpdb;
        $batch = absint($_POST['batch_id'] ?? 0);
        if (!in_array($batch, $portal->batch_ids(), true)) wp_die('That batch is not yours.',403);
        $lines = preg_split('/\r\n|\r|\n/', (string)wp_unslash($_POST['rows'] ?? ''));
        $added = 0; $already = 0; $failed = 0; $secrets = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = str_getcsv($line);
            $name = sanitize_text_field($parts[0] ?? '');
            $email = sanitize_email($parts[1] ?? '');
            $phone = sanitize_text_field($parts[2] ?? '');
            if (!$name || !is_email($email)) { $failed++; continue; }
            $user = get_user_by('email', $email);
            $fresh = false;
            if (!$user) {
                $pw = UC_LMS_Security::temp_password();
                $login = sanitize_user(strstr($email, '@', true) ?: 'student', true);
                if (!$login || username_exists($login)) $login = sanitize_user($login.wp_generate_password(4, false, false), true);
                $id = wp_insert_user(['user_login'=>$login,'user_email'=>$email,'user_pass'=>$pw,'display_name'=>$name,'role'=>'uc_student']);
                if (is_wp_error($id)) { $failed++; continue; }
                $user = get_user_by('id', $id);
                update_user_meta($id, 'uc_must_change', 1);
                if ($phone) update_user_meta($id, 'uc_phone', $phone);
                $fresh = true;
                if (!empty($_POST['send'])) UC_LMS_Security::send_credentials($user, $pw);
                else $secrets[] = $email.' '.$pw;
            }
            $on = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('enrolments')} WHERE batch_id=%d AND user_id=%d AND status='active'", $batch, $user->ID));
            if ($on && !$fresh) { $already++; continue; }
            $wpdb->query($wpdb->prepare("INSERT INTO {$portal->t('enrolments')} (batch_id,user_id,status,enrolled_at) VALUES (%d,%d,'active',%s) ON DUPLICATE KEY UPDATE status='active'", $batch, $user->ID, current_time('mysql')));
            $added++;
        }
        $msg = $added.' added. '.$already.' already on this batch.';
        if ($failed) $msg .= ' '.$failed.' rows could not be read.';
        $portal->set_flash($msg, 'ok', $secrets ? implode("\n", $secrets) : '');
        $portal->back('batches', ['students'=>$batch]);
    }

    public static function demo_gate($portal){
        $portal->guard('uc_portal_demo_gate', ['super_admin']);
        $do = sanitize_key($_POST['do'] ?? 'on');
        $meet = esc_url_raw(wp_unslash($_POST['meet_url'] ?? ''));
        if ($do === 'meet') {
            update_option('uc_demo_meet_url', $meet, false);
            $portal->set_flash('Meet link saved. Share the public demo link from this page.');
            $portal->back('settings', ['_hash'=>'demo']);
        }
        if (in_array($do, ['archive','restore','delete'], true)) {
            $slot = (int)($_POST['slot'] ?? 0);
            $rows = UC_LMS_Module_Support::demo_rows();
            $next = [];
            $name = 'Demo '.$slot;
            foreach ($rows as $row) {
                if ((int)($row['slot'] ?? 0) !== $slot) { $next[] = $row; continue; }
                $name = (string)($row['name'] ?? $name);
                if ($do === 'delete') {
                    $user = get_user_by('email', (string)($row['email'] ?? ''));
                    if ($user && UC_LMS_Security::is_demo($user)) {
                        require_once ABSPATH.'wp-admin/includes/user.php';
                        wp_delete_user($user->ID);
                    }
                    continue;
                }
                $row['archived'] = $do === 'archive' ? 1 : 0;
                $next[] = $row;
            }
            update_option('uc_demo_visits', $next, false);
            $portal->set_flash($do === 'delete' ? $name.' was deleted.' : ($do === 'archive' ? $name.' was archived.' : $name.' is back on the lead list.'));
            $back = sanitize_key($_POST['back'] ?? 'settings');
            $portal->back($back === 'people' ? 'people' : 'settings', $back === 'people' ? [] : ['_hash'=>'demo']);
        }
        if (in_array($do, ['archive','restore','delete'], true)) {
            $slot = (int)($_POST['slot'] ?? 0);
            $rows = UC_LMS_Module_Support::demo_rows();
            $next = [];
            $name = 'Demo '.$slot;
            foreach ($rows as $row) {
                if ((int)($row['slot'] ?? 0) !== $slot) { $next[] = $row; continue; }
                $name = (string)($row['name'] ?? $name);
                if ($do === 'delete') {
                    $user = get_user_by('email', (string)($row['email'] ?? ''));
                    if ($user && UC_LMS_Security::is_demo($user)) {
                        require_once ABSPATH.'wp-admin/includes/user.php';
                        wp_delete_user($user->ID);
                    }
                    continue;
                }
                $row['archived'] = $do === 'archive' ? 1 : 0;
                $next[] = $row;
            }
            update_option('uc_demo_visits', $next, false);
            $portal->set_flash($do === 'delete' ? $name.' was deleted.' : ($do === 'archive' ? $name.' was archived.' : $name.' is back on the lead list.'));
            $back = sanitize_key($_POST['back'] ?? 'settings');
            $portal->back($back === 'people' ? 'people' : 'settings', $back === 'people' ? [] : ['_hash'=>'demo']);
        }
        if ($do === 'verify') {
            $slot = (int)($_POST['slot'] ?? 0);
            $rows = UC_LMS_Module_Support::demo_rows();
            foreach ($rows as &$row) {
                if ((int)($row['slot'] ?? 0) === $slot) $row['verified'] = 1;
            }
            unset($row);
            update_option('uc_demo_visits', $rows, false);
            $portal->set_flash('Demo '.$slot.' marked verified.');
            $portal->back('settings', ['_hash'=>'demo']);
        }
        if ($do === 'rotate') {
            $portal->set_flash('The shared demo01 to demo20 seats are retired. Guests use the public link and their own email.', 'warn');
            $portal->back('settings', ['_hash'=>'demo']);
        }
        if ($meet !== '') update_option('uc_demo_meet_url', $meet, false);
        $hours = (int)($_POST['hours'] ?? 2);
        if (!in_array($hours, [1,2,3], true)) $hours = 2;
        if ($do === 'off') {
            update_option('uc_demo_open', '0', false);
            update_option('uc_demo_until', 0, false);
            $portal->set_flash('Demo access is closed. New guests cannot register, and existing demo guests cannot sign in.');
            $portal->back('settings', ['_hash'=>'demo']);
        }
        update_option('uc_demo_hours', $hours, false);
        update_option('uc_demo_open', '1', false);
        update_option('uc_demo_until', current_time('timestamp') + ($hours * HOUR_IN_SECONDS), false);
        $portal->set_flash('Demo is on for '.$hours.' hour'.($hours===1?'':'s').'. It closes itself after that. Guests sign up as Demo 1 onward with their own email.');
        $portal->back('settings', ['_hash'=>'demo']);
    }

    public static function profile_save($portal){
        $portal->guard('uc_portal_profile_save',['super_admin','coordinator','student']);
        global $wpdb;
        $uid = absint($_POST['user_id'] ?? 0);
        if ($portal->role()==='student') $uid = get_current_user_id();
        if (!$uid || !$portal->has_table('student_profiles')) { $portal->set_flash('Could not save profile.','warn'); $portal->back('profile'); }
        $fields = ['phone','whatsapp','country','city','state','postal_code','nationality','linkedin','github','portfolio','highest_qualification','field_of_study','institution','graduation_year','certifications','skills','tools','languages','experience_years','relevant_experience','employment_status','employer','current_job_title','headline','current_ctc','expected_salary','expected_salary_currency','preferred_role','preferred_location','work_preference','willing_to_relocate','shift_preference','availability','notice_period','work_authorization','key_projects','professional_summary'];
        $data = ['user_id'=>$uid,'updated_at'=>current_time('mysql'),'updated_by'=>get_current_user_id()];
        foreach ($fields as $f) $data[$f] = sanitize_textarea_field(wp_unslash($_POST[$f] ?? ''));
        $pay = preg_replace('/[^0-9.]/', '', (string)($data['expected_salary'] ?? ''));
        $data['expected_salary'] = $pay === '' ? null : $pay;
        $vendor = sanitize_text_field(wp_unslash($_POST['exam_vendor'] ?? ''));
        $exam = sanitize_text_field(wp_unslash($_POST['exam_name'] ?? ''));
        if ($vendor && $exam) update_user_meta($uid, 'uc_exam_choice', $vendor.'|'.$exam);
        elseif (isset($_POST['exam_vendor'])) delete_user_meta($uid, 'uc_exam_choice');
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$portal->t('student_profiles')} WHERE user_id=%d",$uid));
        if ($exists) $wpdb->update($portal->t('student_profiles'), $data, ['user_id'=>$uid]);
        else $wpdb->insert($portal->t('student_profiles'), $data);
        if (class_exists('UC_LMS_Placement')) UC_LMS_Placement::ensure_career_id($uid);
        $saved = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('student_profiles')} WHERE user_id=%d", $uid));
        $miss = $portal->pack_missing($saved, $uid);
        $locked = $saved && in_array((string)($saved->placement_status ?? ''), ['interviewing','offered','placed','on_hold'], true);
        if (!$locked && $saved) $wpdb->update($portal->t('student_profiles'), ['placement_status'=> $miss ? 'profile_incomplete' : 'ready'], ['user_id'=>$uid]);
        if (!$miss && method_exists($portal, 'pack_token')) $portal->pack_token($uid);
        $portal->set_flash($miss ? 'Saved. Still incomplete: '.implode(', ', array_slice($miss, 0, 8)).'.' : 'Pack is complete. A coordinator can share the client link.');
        $portal->back('profile', ($portal->ops() && $uid !== get_current_user_id()) ? ['user'=>$uid] : []);
    }

    public static function document_upload($portal){
        $portal->guard('uc_portal_document_upload', ['super_admin','coordinator','student']);
        $uid = absint($_POST['user_id'] ?? 0);
        if ($portal->role()==='student') $uid = get_current_user_id();
        $type = sanitize_key($_POST['document_type'] ?? '');
        $ret = ($portal->ops() && $uid !== get_current_user_id()) ? ['user'=>$uid] : [];
        if (!in_array($type, ['resume','id_proof','degree','certificate'], true)) { $portal->set_flash('Choose a document type.','warn'); $portal->back('profile', $ret); }
        if (empty($_FILES['file']['name'])) { $portal->set_flash('Choose a file.','warn'); $portal->back('profile', $ret); }
        if ((int)$_FILES['file']['size'] > 15 * 1024 * 1024) { $portal->set_flash('That file is over 15 MB.','warn'); $portal->back('profile', $ret); }
        require_once ABSPATH.'wp-admin/includes/file.php';
        $move = wp_handle_upload($_FILES['file'], ['test_form'=>false]);
        if (!empty($move['error'])) { $portal->set_flash($move['error'],'warn'); $portal->back('profile', $ret); }
        if (!$portal->has_table('student_documents')) { $portal->set_flash('Documents table is not ready.','warn'); $portal->back('profile', $ret); }
        $ok = $portal->insert_row('student_documents', [
            'user_id'=>$uid,'document_type'=>$type,'file_name'=>sanitize_file_name(wp_basename($move['file'])),'url'=>esc_url_raw($move['url']),
            'status'=>'pending','uploaded_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),
        ]);
        if (!$ok) $portal->db_fail('profile');
        $note = 'Document added.';
        $tone = 'ok';
        if ($type === 'resume' && class_exists('UC_LMS_Placement')) {
            $screen = UC_LMS_Placement::screen_user($uid);
            if (is_wp_error($screen)) { $note = 'Document added. '.$screen->get_error_message(); $tone = 'warn'; }
            else $note = 'Document added. CV screened.';
        }
        $portal->set_flash($note, $tone);
        $portal->back('profile', $ret);
    }
}
