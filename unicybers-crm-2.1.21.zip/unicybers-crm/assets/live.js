(function () {
  function list(rows, empty, line) {
    if (!rows || !rows.length) return '<div class="empty"><p>' + empty + '</p></div>';
    return rows.map(line).join('');
  }

  if (typeof paintDash === 'function') {
    var paint = paintDash;
    paintDash = function (d, I) {
      paint(d, I);
      var none = document.getElementById('dNoDate');
      var renew = document.getElementById('dRenew');
      var hand = document.getElementById('dHandoff');
      if (none) none.innerHTML = list(d.noFollowup, 'Every open lead has a next date', function (r) {
        return '<div class="li"><div class="li-name">' + esc(r.name || '') + '</div><div class="li-sub">' + esc(r.owner || '') + '</div></div>';
      });
      if (renew) renew.innerHTML = list(d.renewals, 'Nothing due in the next 30 days', function (r) {
        return '<div class="li"><div class="li-name">' + esc(r.name || 'Renewal') + '</div><div class="li-sub">' + esc(r.status || '') + ' ' + esc(r.due || '') + '</div></div>';
      });
      if (hand) hand.innerHTML = list(d.handoffs, 'No Academy leads waiting', function (r) {
        return '<div class="li"><div class="li-name">' + esc(r.name || r.id || '') + '</div><div class="li-sub">' + esc(r.status || '') + '</div></div>';
      });
    };
  }

  if (typeof openDrawer === 'function') {
    var open = openDrawer;
    openDrawer = function (id) {
      open(id);
      var phone = document.getElementById('dr-v-phone');
      if (phone && !document.getElementById('uc-wa')) {
        var btn = document.createElement('button');
        btn.id = 'uc-wa';
        btn.type = 'button';
        btn.className = 'btn btn-gho btn-sm';
        btn.style.marginTop = '8px';
        btn.textContent = 'Log WhatsApp';
        btn.onclick = function () {
          var note = window.prompt('What did you send on WhatsApp?');
          if (!note || !drawerLeadId) return;
          ucCRM.run.withSuccessHandler(function () {
            showAlert('drawer-alert', 'WhatsApp note saved on the lead.', 'ok');
            openDrawer(drawerLeadId);
          }).withFailureHandler(function (e) {
            showAlert('drawer-alert', (e && e.message) || 'Could not save the note', 'err');
          }).logWhatsApp(TOKEN, drawerLeadId, note);
        };
        phone.parentNode.appendChild(btn);
      }
      ucCRM.run.withSuccessHandler(function (items) {
        var host = document.getElementById('dr-tl');
        if (!host || !items || !items.length) return;
        var extra = items.map(function (it) {
          return '<div class="tl-i"><div class="tl-dot"></div><div class="tl-name">' + esc(it.kind || 'Note') + '</div><div class="tl-meta">' + esc(it.text || '') + (it.at ? ' · ' + esc(it.at) : '') + '</div></div>';
        }).join('');
        host.insertAdjacentHTML('afterbegin', extra);
      }).withFailureHandler(function () {}).getLeadTimeline(TOKEN, id);
    };
  }

  if (typeof colEdit === 'function') {
    var edit = colEdit;
    colEdit = function (rowNum) {
      edit(rowNum);
      var nameEl = document.getElementById('c-name');
      var host = document.getElementById('uc-inst');
      if (!host && nameEl) {
        host = document.createElement('div');
        host.id = 'uc-inst';
        host.style.marginTop = '14px';
        nameEl.parentNode.parentNode.appendChild(host);
      }
      if (!host || !nameEl) return;
      host.innerHTML = '<div class="li-sub">Loading the institution file…</div>';
      ucCRM.run.withSuccessHandler(function (file) {
        file = file || {};
        var leads = (file.leads || []).map(function (r) {
          return '<div class="li"><div class="li-name">' + esc(r.name || r.id) + '</div><div class="li-sub">' + esc(r.status || '') + ' · ' + esc(r.owner || '') + '</div></div>';
        }).join('') || '<div class="li-sub">No leads for this institution</div>';
        var visits = (file.visits || []).map(function (r) {
          return '<div class="li"><div class="li-name">' + esc(r.purpose || 'Visit') + '</div><div class="li-sub">' + esc(r.date || '') + ' · ' + esc(r.status || '') + '</div></div>';
        }).join('') || '<div class="li-sub">No visits yet</div>';
        host.innerHTML = '<div class="fdiv">On this institution</div>' + leads + '<div class="fdiv">Visits</div>' + visits;
      }).withFailureHandler(function () {
        host.innerHTML = '';
      }).getInstitutionFile(TOKEN, nameEl.value || '');
    };
  }
})();


/* Page titles and view controls stay off the top bar. */
(function () {
  var stray = document.querySelector('.topbar .tb-l .ph-act');
  if (stray && stray.parentNode) stray.parentNode.removeChild(stray);
})();


/* UniCybers CRM 1.4.0: accessible horizontal table navigation on desktop and touch devices. */
(function(){
  if(window.__ucTableScroll140)return;window.__ucTableScroll140=true;
  document.addEventListener('wheel',function(e){
    var box=e.target&&e.target.closest?e.target.closest('.tscroll'):null;
    if(!box)return;
    if(e.shiftKey||Math.abs(e.deltaX)>Math.abs(e.deltaY)){
      var delta=e.shiftKey?e.deltaY:e.deltaX;
      if(delta){box.scrollLeft+=delta;e.preventDefault();}
    }
  },{passive:false});
  var drag=null;
  document.addEventListener('pointerdown',function(e){
    var box=e.target&&e.target.closest?e.target.closest('.tscroll'):null;
    if(!box||e.button!==0||e.target.closest('button,a,input,select,textarea,label,.uc-rz'))return;
    drag={box:box,x:e.clientX,left:box.scrollLeft,moved:false,id:e.pointerId};
  });
  document.addEventListener('pointermove',function(e){
    if(!drag||drag.id!==e.pointerId)return;
    var dx=e.clientX-drag.x;
    if(Math.abs(dx)>4)drag.moved=true;
    if(drag.moved){drag.box.scrollLeft=drag.left-dx;}
  });
  ['pointerup','pointercancel'].forEach(function(n){document.addEventListener(n,function(e){if(drag&&drag.id===e.pointerId){drag=null;}});});
})();
