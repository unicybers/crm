<?php
/**
 * UniCybers Academy LMS: Super Admin settings inside the portal.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Settings {
    public static function render($portal){
        if ($portal->role() !== 'super_admin') return $portal->empty_state('Not available','Settings stay with the Super Admin.','settings');
        $post = esc_url(admin_url('admin-post.php'));
        $provider = sanitize_key((string)get_option('uc_ai_provider', 'openai'));
        $o = '<form method="post" action="'.$post.'" class="form"><div class="set-folds">'.wp_nonce_field('uc_portal_settings_save','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_settings_save">';
        $ai = '<label>Desk uses<select name="uc_ai_provider">';
        foreach (['openai'=>'OpenAI','claude'=>'Claude','grok'=>'Grok'] as $v=>$label) $ai .= '<option value="'.$v.'"'.selected($provider,$v,false).'>'.$label.'</option>';
        $ai .= '</select></label>';
        $ai .= self::secret('OpenAI key','uc_openai_key').self::secret('Claude key','uc_claude_key').self::secret('Grok key','uc_grok_key');
        $ai .= '<div class="set-calls span-2"><span>OpenAI '.(int)get_option('uc_ai_calls_openai',0).'</span><span>Claude '.(int)get_option('uc_ai_calls_claude',0).'</span><span>Grok '.(int)get_option('uc_ai_calls_grok',0).'</span></div>';
        $ai .= self::field('Recorded balance','uc_ai_credit_balance', (string)get_option('uc_ai_credit_balance','0'));
        $apis = get_option('uc_job_apis', []);
        if (!is_array($apis) || !$apis) {
            $legacy = trim((string)get_option('uc_jobs_api_url', ''));
            $apis = $legacy !== '' ? [['name'=>'Jobs','url'=>$legacy,'token'=>'']] : [['name'=>'','url'=>'','token'=>'']];
        }
        $ai .= '<div class="job-line span-2"><button type="button" class="btn ghost sm" id="addJobApi">Add API</button><div class="job-apis" id="jobApis">';
        foreach ($apis as $api) {
            $ai .= '<div class="job-api"><input name="job_api_name[]" value="'.esc_attr((string)($api['name'] ?? '')).'" placeholder="Name"><input name="job_api_url[]" value="'.esc_attr((string)($api['url'] ?? '')).'" placeholder="https://"><input type="password" name="job_api_token[]" value="" placeholder="'.(!empty($api['token']) ? 'Saved token' : 'Token').'" autocomplete="new-password"><button type="button" class="btn ghost sm" data-remove-api>Remove</button></div>';
        }
        $ai .= '</div></div>';
        $o .= self::fold('Brand', self::field('Watermark','uc_watermark_text', (string)get_option('uc_watermark_text','UNICYBERS')), true);
        $o .= self::fold('AI credits', $ai, $provider);
        $o .= self::fold('Zoom', self::field('Account ID','uc_zoom_account_id').self::field('Client ID','uc_zoom_client_id').self::secret('Client secret','uc_zoom_client_secret').self::secret('Webhook secret','uc_zoom_webhook_secret'), get_option('uc_zoom_account_id') && get_option('uc_zoom_client_id') && get_option('uc_zoom_client_secret'));
        $o .= self::fold('Google and Drive', self::field('OAuth client ID','uc_google_client_id').self::secret('OAuth client secret','uc_google_client_secret').self::field('Calendar ID','uc_google_calendar_id', get_option('uc_google_calendar_id','primary')).self::field('Materials folder ID','uc_drive_materials_folder', get_option('uc_drive_materials_folder','1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi')).'<div class="drive-line span-2">'.self::check('uc_drive_sync_enabled','Sync Drive materials every 10 minutes','1').self::check('uc_drive_protect_downloads','Ask Drive to block download, print and copy','1').'</div>', get_option('uc_google_refresh_token'));
        $o .= self::fold('Microsoft Teams', self::field('Tenant ID','uc_ms_tenant').self::field('Application client ID','uc_ms_client_id').self::secret('Application secret','uc_ms_client_secret').self::field('Organizer user','uc_ms_user'), get_option('uc_ms_tenant') && get_option('uc_ms_client_id') && get_option('uc_ms_client_secret'));
        $dc = (string)get_option('uc_zoho_dc','in');
        $zoho = '<label>Data centre<select name="uc_zoho_dc">';
        foreach (['in'=>'India','com'=>'United States','eu'=>'Europe','com.au'=>'Australia','jp'=>'Japan','ca'=>'Canada','sa'=>'Saudi Arabia'] as $v=>$label) $zoho .= '<option value="'.esc_attr($v).'"'.selected($dc,$v,false).'>'.esc_html($label).'</option>';
        $zoho .= '</select></label>'.self::field('OAuth client ID','uc_zoho_client_id').self::secret('OAuth client secret','uc_zoho_client_secret').self::field('Organization ID','uc_zoho_zsoid').self::field('Presenter user ID','uc_zoho_presenter_id');
        $o .= self::fold('Zoho Meeting', $zoho, get_option('uc_zoho_refresh_token'));
        $flags = get_option('uc_role_features', []);
        if (!is_array($flags)) $flags = [];
        $roles = ['super_admin'=>'Super Admin','coordinator'=>'Coordinator','trainer'=>'Trainer','hr'=>'Placement HR','student'=>'Student'];
        $pages = ['dashboard'=>'Dashboard','courses'=>'Courses','batches'=>'Batches','classes'=>'Classes','practice'=>'Practice','materials'=>'Materials','people'=>'People','placement'=>'Placement','announcements'=>'Announcements','messages'=>'Messages','reports'=>'Reports','profile'=>'Profile','settings'=>'Settings'];
        $roles_html = '<label class="role-pick">Role<select id="ucRolePick">';
        foreach ($roles as $role=>$label) $roles_html .= '<option value="'.esc_attr($role).'">'.esc_html($label).'</option>';
        $roles_html .= '</select></label>';
        foreach ($roles as $role=>$label) {
            $roles_html .= '<div class="role-flags role-panel span-2" data-role-panel="'.esc_attr($role).'"'.($role==='super_admin'?'':' hidden').'>';
            foreach ($pages as $page=>$name) {
                if ($role !== 'super_admin' && $page === 'settings') continue;
                if ($role === 'super_admin' && $page === 'profile') continue;
                if ($role === 'student' && in_array($page, ['batches','people'], true)) continue;
                if ($role === 'trainer' && in_array($page, ['people','placement'], true)) continue;
                if ($role === 'hr' && $page !== 'placement') continue;
                if ($role === 'super_admin' && $page === 'settings') {
                    $roles_html .= '<label><input type="checkbox" checked disabled> '.esc_html($name).'</label><input type="hidden" name="uc_role_features[super_admin][settings]" value="1">';
                    continue;
                }
                $on = !isset($flags[$role][$page]) || !empty($flags[$role][$page]);
                $roles_html .= '<label><input type="checkbox" name="uc_role_features['.esc_attr($role).']['.esc_attr($page).']" value="1" '.checked($on, true, false).'> '.esc_html($name).'</label>';
            }
            $roles_html .= '</div>';
        }
        $o .= self::fold('Menus by role', $roles_html, false);
        $o .= '<div class="mfoot"><button class="btn primary" type="submit">Save settings</button></div></div></form>';
        $o .= '<div class="page-actions" style="margin-top:12px">';
        $o .= '<form method="post" action="'.$post.'">'.wp_nonce_field('uc_test_zoom','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_test_zoom"><button class="btn ghost sm" type="submit">Test Zoom</button></form>';
        $o .= '<form method="post" action="'.$post.'">'.wp_nonce_field('uc_google_connect','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_google_connect"><button class="btn ghost sm" type="submit">Connect Google</button></form>';
        $o .= '<form method="post" action="'.$post.'">'.wp_nonce_field('uc_zoho_connect','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_zoho_connect"><button class="btn ghost sm" type="submit">Connect Zoho</button></form>';
        $o .= '<form method="post" action="'.$post.'">'.wp_nonce_field('uc_portal_job_feed','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_job_feed"><input type="hidden" name="do" value="sync"><button class="btn ghost sm" type="submit">Pull jobs</button></form></div>';
        $o .= '<script>(function(){var pick=document.getElementById("ucRolePick");if(pick){function go(){document.querySelectorAll("[data-role-panel]").forEach(function(el){el.hidden=el.getAttribute("data-role-panel")!==pick.value})}pick.addEventListener("change",go);go()}var box=document.getElementById("jobApis"),add=document.getElementById("addJobApi");if(box&&add){add.addEventListener("click",function(){var row=box.querySelector(".job-api");if(!row)return;var next=row.cloneNode(true);next.querySelectorAll("input").forEach(function(i){i.value=""});box.appendChild(next)});box.addEventListener("click",function(e){var b=e.target.closest("[data-remove-api]");if(!b)return;var rows=box.querySelectorAll(".job-api");if(rows.length<2){b.parentNode.querySelectorAll("input").forEach(function(i){i.value=""});return}b.parentNode.remove()})}})();</script>';
        $o .= '<div class="set-manage">';
        $o .= '<details class="set-fold" id="demo"><summary>Demo access</summary><div class="set-fold-body">'.UC_LMS_Module_Support::demo_fold($portal).'</div></details>';
        $o .= '<details class="set-fold" id="client-preview"><summary>Client preview</summary><div class="set-fold-body">'.UC_LMS_Module_Support::preview_desk($portal).'</div></details>';
        $o .= '<details class="set-fold" id="exam-choices"><summary>Certification interest</summary><div class="set-fold-body">'.UC_LMS_Module_Support::exam_fold($portal).'</div></details>';
        $o .= '<details class="set-fold" id="footer-links"><summary>Footer links</summary><div class="set-fold-body"><form method="post" action="'.$post.'" class="form span-2"><input type="hidden" name="action" value="uc_portal_footer_links">'.wp_nonce_field('uc_portal_footer_links','_wpnonce',true,false).'<div class="fgrid"><label>Privacy policy URL<input type="url" name="privacy" value="'.esc_attr(get_option('uc_privacy_url')).'" placeholder="Uses the WordPress privacy page if empty"></label><label>Terms URL<input type="url" name="terms" value="'.esc_attr(get_option('uc_terms_url')).'" placeholder="Hidden from the footer if empty"></label></div><div class="right"><button class="btn ghost">Save links</button></div></form></div></details>';
        $o .= '<details class="set-fold" id="audit"><summary>Audit log</summary><div class="set-fold-body">'.$portal->audit().'</div></details>';
        $o .= '</div>';
        return $o;
    }

    private static function fold($title, $body, $ready = false){
        return '<details class="set-fold"><summary>'.esc_html($title).($ready ? '<b class="set-status is-on">Ready</b>' : '').'</summary><div class="set-fold-body">'.$body.'</div></details>';
    }

    private static function status($on){
        return '<p class="set-status '.($on ? 'is-on' : '').'">'.($on ? 'Ready' : 'Needs details').'</p>';
    }

    private static function field($label, $name, $value = null){
        if ($value === null) $value = (string)get_option($name, '');
        return '<label>'.esc_html($label).'<input name="'.esc_attr($name).'" value="'.esc_attr($value).'"></label>';
    }

    private static function secret($label, $name){
        $saved = trim((string)get_option($name, '')) !== '';
        return '<label>'.esc_html($label).'<input type="password" name="'.esc_attr($name).'" value="" placeholder="'.($saved ? 'Saved. Enter only to replace.' : 'Not saved yet').'" autocomplete="new-password"></label>';
    }

    private static function check($name, $label, $default){
        $on = (string)get_option($name, $default) === '1';
        return '<input type="hidden" name="'.esc_attr($name).'" value="0"><label class="set-check"><input type="checkbox" name="'.esc_attr($name).'" value="1" '.checked($on, true, false).'> '.esc_html($label).'</label>';
    }

    public static function save($portal){
        $portal->guard('uc_portal_settings_save', ['super_admin']);
        foreach (['uc_zoom_account_id','uc_zoom_client_id','uc_google_client_id','uc_google_calendar_id','uc_drive_materials_folder','uc_ms_tenant','uc_ms_client_id','uc_ms_user','uc_zoho_client_id','uc_zoho_zsoid','uc_zoho_presenter_id','uc_watermark_text'] as $key) {
            update_option($key, sanitize_text_field(wp_unslash($_POST[$key] ?? '')), false);
        }
        $dc = (string)wp_unslash($_POST['uc_zoho_dc'] ?? 'in');
        if (!in_array($dc, ['in','com','eu','com.au','jp','ca','sa'], true)) $dc = 'in';
        update_option('uc_zoho_dc', $dc, false);
        $names = (array)($_POST['job_api_name'] ?? []);
        $urls = (array)($_POST['job_api_url'] ?? []);
        $tokens = (array)($_POST['job_api_token'] ?? []);
        $prev = get_option('uc_job_apis', []);
        if (!is_array($prev)) $prev = [];
        $apis = [];
        foreach ($urls as $i => $url) {
            $url = esc_url_raw(wp_unslash($url));
            if ($url === '') continue;
            $token = trim((string)wp_unslash($tokens[$i] ?? ''));
            if ($token === '' && !empty($prev[$i]['token'])) $token = (string)$prev[$i]['token'];
            $apis[] = ['name'=>sanitize_text_field(wp_unslash($names[$i] ?? '')), 'url'=>$url, 'token'=>sanitize_text_field($token)];
        }
        update_option('uc_job_apis', $apis, false);
        update_option('uc_jobs_api_url', $apis[0]['url'] ?? '', false);
        if (!empty($apis[0]['token'])) update_option('uc_career_shared_token', $apis[0]['token'], false);
        if (!empty($apis[0]['url'])) update_option('uc_career_exec_url', $apis[0]['url'], false);
        $provider = sanitize_key((string)wp_unslash($_POST['uc_ai_provider'] ?? 'openai'));
        if (!in_array($provider, ['openai','claude','grok'], true)) $provider = 'openai';
        update_option('uc_ai_provider', $provider, false);
        if (isset($_POST['uc_ai_credit_balance'])) update_option('uc_ai_credit_balance', (string)max(0, (float)wp_unslash($_POST['uc_ai_credit_balance'])), false);
        foreach (['uc_zoom_client_secret','uc_zoom_webhook_secret','uc_google_client_secret','uc_ms_client_secret','uc_zoho_client_secret','uc_openai_key','uc_claude_key','uc_grok_key','uc_career_shared_token'] as $key) {
            $value = trim((string)wp_unslash($_POST[$key] ?? ''));
            if ($value !== '') update_option($key, sanitize_text_field($value), false);
        }
        update_option('uc_drive_sync_enabled', empty($_POST['uc_drive_sync_enabled']) ? '0' : '1', false);
        update_option('uc_drive_protect_downloads', empty($_POST['uc_drive_protect_downloads']) ? '0' : '1', false);
        $roles = ['super_admin','coordinator','trainer','hr','student'];
        $pages = ['dashboard','courses','batches','classes','practice','materials','people','placement','announcements','messages','reports','profile','settings'];
        $posted = is_array($_POST['uc_role_features'] ?? null) ? $_POST['uc_role_features'] : [];
        $out = [];
        foreach ($roles as $role) {
            foreach ($pages as $page) $out[$role][$page] = empty($posted[$role][$page]) ? 0 : 1;
        }
        $out['super_admin']['settings'] = 1;
        foreach ($pages as $page) $out['hr'][$page] = $page === 'placement' ? 1 : 0;
        update_option('uc_role_features', $out, false);
        $portal->set_flash('Settings saved.');
        $portal->back('settings');
    }
}
