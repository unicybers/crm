<?php
/**
 * Serves the public academy landing page from inside the plugin.
 * The site root does not need a separate folder.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Landing {
    public static function maybe_serve() {
        $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
        $path = (string) wp_parse_url($uri, PHP_URL_PATH);
        $home = (string) wp_parse_url(home_url('/'), PHP_URL_PATH);
        $home = '/' . trim($home, '/');
        if ($home !== '/' && strpos($path, $home) === 0) {
            $path = substr($path, strlen($home));
            if ($path === '') $path = '/';
        }
        $path = '/' . trim($path, '/');
        if ($path === '/') {
            $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
            $qs = (string) wp_parse_url($uri, PHP_URL_QUERY);
            $editing = $qs !== '' && preg_match('/(?:^|&)(?:preview|elementor-preview|page_id|rest_route|customize_changeset_uuid)=/', $qs);
            if ($method === 'GET' && !$editing) {
                self::serve_front();
            }
        }
        if ($path !== '/academy-landing' && strpos($path, '/academy-landing/') !== 0) return;

        $rel = trim(substr($path, strlen('/academy-landing')), '/');
        if ($rel === '') $rel = 'index.html';
        $rel = str_replace('\\', '/', $rel);
        if (strpos($rel, '..') !== false || strpos($rel, "\0") !== false || stripos($rel, 'tickets') === 0) {
            status_header(404);
            exit;
        }

        $base = realpath(UC_LMS_DIR . '/landing');
        $full = $base ? realpath($base . '/' . $rel) : false;
        if (!$base || !$full || !is_file($full) || strpos($full, $base . DIRECTORY_SEPARATOR) !== 0) {
            status_header(404);
            exit;
        }

        $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
        if ($ext === 'php') {
            include $full;
            exit;
        }
        $types = [
            'html' => 'text/html; charset=UTF-8',
            'css' => 'text/css; charset=UTF-8',
            'js' => 'application/javascript; charset=UTF-8',
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'webp' => 'image/webp',
            'svg' => 'image/svg+xml',
            'gif' => 'image/gif',
        ];
        if (!isset($types[$ext])) {
            status_header(404);
            exit;
        }
        status_header(200);
        nocache_headers();
        header('Content-Type: ' . $types[$ext]);
        header('X-LiteSpeed-Cache-Control: no-cache');
        readfile($full);
        exit;
    }

    public static function purge_cached_miss() {
        if (get_option('uc_lms_landing_served') === '2.8.147') return;
        if (class_exists('LiteSpeed_Cache_API') && method_exists('LiteSpeed_Cache_API', 'purge_all')) {
            LiteSpeed_Cache_API::purge_all();
        }
        do_action('litespeed_purge_all');
        update_option('uc_lms_landing_served', '2.8.147', false);
    }

    private static function serve_front() {
        status_header(200);
        nocache_headers();
        header('Content-Type: text/html; charset=UTF-8');
        header('X-LiteSpeed-Cache-Control: no-cache');
        $src = esc_url(home_url('/academy-landing/index.html'));
        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>UniCybers Academy LMS</title><style>html,body{margin:0;height:100%;background:#05080D;overflow:hidden}iframe{position:fixed;inset:0;width:100vw;height:100vh;border:0;display:block}</style></head><body><iframe src="' . $src . '" title="UniCybers Academy LMS"></iframe></body></html>';
        exit;
    }
}
