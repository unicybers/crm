  /* UniCybers Academy LMS 2.8.100 · portal behaviour */
(function(){
  var d=document, b=d.body, $=function(s,r){return (r||d).querySelector(s)}, $$=function(s,r){return Array.prototype.slice.call((r||d).querySelectorAll(s))};
  function theme(t){d.documentElement.setAttribute('data-theme',t);try{localStorage.setItem('uc_lms_theme',t)}catch(e){}}
  var tt=$('#themeToggle'); if(tt) tt.addEventListener('click',function(){theme(d.documentElement.getAttribute('data-theme')==='dark'?'light':'dark')});

  /* Mobile rail */
  var rail=$('#rail'),scrim=$('#scrim');
  function rail_(on){rail.classList.toggle('open',on);scrim.classList.toggle('on',on)}
  if($('#menu')) $('#menu').addEventListener('click',function(){rail_(true)});
  try {
    if (/\/materials\/?(\?|$)/.test(location.pathname + location.search)) {
      sessionStorage.setItem('uc_library', location.href);
    }
  } catch (err) {}
  d.addEventListener('click',function(e){
    var a=e.target.closest('[data-back-library]');
    if(!a) return;
    e.preventDefault();
    var dest='';
    try { dest=sessionStorage.getItem('uc_library')||''; } catch (err) {}
    if (dest) { location.assign(dest); return; }
    location.assign(a.getAttribute('href') || '/materials/');
  });
  if(scrim) scrim.addEventListener('click',function(){rail_(false)});

  /* Profile menu. The rail clips overflow, so the menu is placed on the page. */
  var mb=$('#meBtn'),mm=$('#meMenu');
  function placeMenu(){
    if(!mb||!mm) return;
    var r=mb.getBoundingClientRect();
    var width=Math.max(r.width, 220);
    mm.style.position='fixed';
    mm.style.left=Math.max(8, Math.min(r.left, window.innerWidth-width-8))+'px';
    mm.style.width=width+'px';
    mm.style.right='auto';
    mm.style.top='auto';
    mm.style.bottom=(window.innerHeight-r.top+8)+'px';
    mm.style.zIndex='90';
    if(mm.parentNode!==d.body) d.body.appendChild(mm);
  }
  function menu(on){
    if(!mm||!mb) return;
    if(on){ mm.hidden=false; placeMenu(); } else mm.hidden=true;
    mb.setAttribute('aria-expanded',on?'true':'false');
  }
  if(mb){mb.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();menu(mm.hidden)});d.addEventListener('click',function(e){if(mm&&!mm.hidden&&!mm.contains(e.target)&&e.target!==mb)menu(false)});d.addEventListener('keydown',function(e){if(e.key==='Escape')menu(false)});window.addEventListener('resize',function(){if(mm&&!mm.hidden)placeMenu()})}

  /* Page filter: hides rows and cards that do not match */
  var pf=$('#pageFilter'), seg=(window.UC_SEG||'students'), st='', batchf='';
  var libcat={};
  var hash=String(location.hash||'').replace('#','');
  if(['demo','staff','students','disabled','archived','preview','all'].indexOf(hash)>-1) seg=hash;
  if(hash){
    var opened=document.getElementById(hash);
    if(opened){
      var fold=opened.tagName==='DETAILS'?opened:opened.closest('details');
      if(fold) fold.open=true;
    }
  }
  $$('.seg button').forEach(function(x){x.classList.toggle('on',x.getAttribute('data-seg')===seg)});
  function apply(){
    var q=pf?pf.value.trim().toLowerCase():'', n=0, shown=0;
    $$('[data-q]').forEach(function(el){
      var ok=(!q||el.getAttribute('data-q').indexOf(q)>-1);
      if(el.classList.contains('ccard')) ok=ok&&(!lv||el.getAttribute('data-level')===lv)&&(!catv||el.getAttribute('data-cat')===catv);
      if(el.hasAttribute('data-seg')){
        var s=el.getAttribute('data-seg');
        if(seg==='all') ok=ok&&s!=='demo'&&s!=='preview';
        else ok=ok&&s===seg;
        if(st) ok=ok&&el.getAttribute('data-st')===st;
        n++;if(ok)shown++;
      }
      if(el.hasAttribute('data-batch') && batchf) ok=ok&&el.getAttribute('data-batch')===batchf;
      if(el.hasAttribute('data-libcat') && el.hasAttribute('data-shelf')){
        var want=libcat[el.getAttribute('data-shelf')]||'all';
        ok=ok&&(want==='all'||el.getAttribute('data-libcat')===want);
      }
      el.classList.toggle('is-hidden',!ok);
    });
    var c=$('#shown'); if(c) c.textContent=shown+' of '+n+' shown';
  }
  $$('.lib-sort,.lib-tabs').forEach(function(nav){
    nav.addEventListener('click',function(e){
      var btn=e.target.closest('button[data-libcat]');
      if(!btn) return;
      nav.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b===btn)});
      libcat[nav.getAttribute('data-shelf')||'docs']=btn.getAttribute('data-libcat');
      apply();
    });
  });
  /* Global cross-portal search popover */
  var searchTimer = null;
  var popover = $('#globalSearchResults');
  function closePopover(){ if(popover){ popover.hidden=true; popover.classList.remove('is-open'); popover.innerHTML=''; } }
  function guideHits(q){
    var skip={how:1,the:1,for:1,you:1,can:1,does:1,what:1,where:1,when:1,why:1,and:1,with:1,from:1,that:1,this:1,your:1,are:1};
    var words=q.toLowerCase().split(/\s+/).filter(function(w){return w.length>2 && !skip[w];});
    if(!words.length) return [];
    return (window.UC_GUIDE||[]).filter(function(g){
      var hay=(g.title+' '+g.body).toLowerCase();
      return words.every(function(w){return hay.indexOf(w)!==-1});
    }).slice(0,5);
  }
  function renderGlobalSearch(q, groups){
    if (!popover) return;
    var keys = groups ? Object.keys(groups).filter(function(k){ return groups[k] && groups[k].length; }) : [];
    popover.hidden=false;
    if (!q || !keys.length) {
      popover.innerHTML = '<div class="search-empty">No results found across the portal for "'+q.replace(/[&<>"']/g,'')+'"</div>';
      popover.classList.add('is-open');
      return;
    }
    var html = '';
    keys.forEach(function(cat){
      var items = groups[cat];
      html += '<div class="search-group"><div class="search-group-title">'+cat+' ('+items.length+')</div>';
      items.forEach(function(it){
        var title = String(it.title||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});
        var sub = String(it.sub||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});
        var page = String(it.page||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});
        var url = String(it.url||'#').replace(/"/g,'&quot;');
        html += '<a class="search-item" href="'+url+'"><span class="search-item-info"><strong class="search-item-title">'+title+'</strong>';
        if (sub) html += '<span class="search-item-sub">'+sub+'</span>';
        html += '</span><span class="search-item-badge">'+page+'</span></a>';
      });
      html += '</div>';
    });
    popover.innerHTML = html;
    popover.classList.add('is-open');
  }

  function fetchGlobalSearch(q){
    if (q.length < 2) { closePopover(); return; }
    if (!window.UC_REST_SEARCH) {
      var only={};
      guideHits(q).forEach(function(g){ (only.Rida=only.Rida||[]).push({title:g.title, sub:g.body.slice(0,180), page:'Guide', url:window.UC_GUIDE_URL||'#guide'}); });
      renderGlobalSearch(q, only);
      return;
    }
    var url = window.UC_REST_SEARCH + (window.UC_REST_SEARCH.indexOf('?')>-1 ? '&' : '?') + 'q=' + encodeURIComponent(q);
    fetch(url, {
      method: 'GET',
      headers: { 'X-WP-Nonce': window.UC_REST_NONCE || '', 'Accept': 'application/json' },
      credentials: 'same-origin'
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
      var groups = {};
      var list = (res && res.results) ? res.results : [];
      list.forEach(function(it){
        var cat = it.category || it.page || 'Portal';
        (groups[cat] = groups[cat] || []).push({title:it.title, sub:it.meta||it.sub||'', page:it.page||'', url:it.url||'#'});
      });
      guideHits(q).forEach(function(g){
        (groups.Rida = groups.Rida || []).push({title:g.title, sub:g.body.slice(0,180), page:'Guide', url:window.UC_GUIDE_URL||'#guide'});
      });
      renderGlobalSearch(q, groups);
    })
    .catch(function(){
      var groups={};
      guideHits(q).forEach(function(g){
        (groups.Rida = groups.Rida || []).push({title:g.title, sub:g.body.slice(0,180), page:'Guide', url:window.UC_GUIDE_URL||'#guide'});
      });
      renderGlobalSearch(q, groups);
    });
  }
  var ridaQ=$('#ridaQ'), ridaA=$('#ridaA');
  function escGuide(s){return String(s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  if(ridaQ&&ridaA){
    ridaQ.addEventListener('input', function(){
      var q=ridaQ.value.trim();
      var hits=guideHits(q);
      if(q.length<3){ ridaA.innerHTML='<p class="muted">Ask in a few words. For example: schedule a class.</p>'; return; }
      if(!hits.length){ ridaA.innerHTML='<p class="muted">That is not in the academy guide. Rida does not answer from outside it.</p>'; return; }
      ridaA.innerHTML=hits.map(function(g){return '<article class="rida-hit"><strong>'+escGuide(g.title)+'</strong><p>'+escGuide(g.body)+'</p></article>';}).join('');
    });
  }

  if(pf){
    pf.addEventListener('input', function(){
      apply();
      var q = pf.value.trim();
      clearTimeout(searchTimer);
      if (q.length < 2) closePopover();
      else searchTimer = setTimeout(function(){ fetchGlobalSearch(q); }, 250);
    });
    d.addEventListener('click', function(e){ if(!e.target.closest('.search-wrap')) closePopover(); });
    d.addEventListener('keydown',function(e){
      if(e.key==='Escape') closePopover();
      if(e.key==='/'&&d.activeElement.tagName!=='INPUT'&&d.activeElement.tagName!=='TEXTAREA'){e.preventDefault();pf.focus();}
    });
  }
  $$('.seg button').forEach(function(x){x.addEventListener('click',function(){$$('.seg button').forEach(function(y){y.classList.remove('on')});x.classList.add('on');seg=x.getAttribute('data-seg');syncSt();apply()})});
  function syncSt(){
    var stf=$('#stFilter');
    if(!stf) return;
    var show=seg==='students'||seg==='all';
    stf.style.display=show?'':'none';
    if(!show){st='';stf.value='';}
  }
  syncSt();
  if($('#stFilter')) $('#stFilter').addEventListener('change',function(){st=this.value;apply()});
  if($('#batchFilter')){
    batchf=$('#batchFilter').value||'';
    $('#batchFilter').addEventListener('change',function(){batchf=this.value;apply()});
  }
  apply();

  /* Course level and category chips. Empty value means all. */
  var lv='', catv='';
  $$('.course-filters button').forEach(function(btn){
    btn.addEventListener('click',function(){
      var g=btn.getAttribute('data-filter');
      $$('.course-filters button[data-filter="'+g+'"]').forEach(function(x){x.classList.remove('on')});
      btn.classList.add('on');
      if(g==='level') lv=btn.getAttribute('data-value')||'';
      else catv=btn.getAttribute('data-value')||'';
      apply();
    });
  });

  /* Show or hide a password. Does not submit the form. */
  $$('input[type=password]').forEach(function(input){
    if(input.closest('.pw-field')||input.id==='ucLoginPassword') return;
    var wrap=d.createElement('span');
    wrap.className='pw-field';
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    var eye=d.createElement('button');
    eye.type='button';
    eye.className='pw-eye';
    eye.setAttribute('aria-label','Show password');
    eye.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
    eye.addEventListener('click',function(ev){
      ev.preventDefault();
      var on=input.type==='password';
      input.type=on?'text':'password';
      eye.setAttribute('aria-label', on?'Hide password':'Show password');
      eye.classList.toggle('is-open', on);
    });
    wrap.appendChild(eye);
  });

  /* Flash + copy. Notices without a secret password fade after 6.5s. */
  $$('.flash-x').forEach(function(x){x.addEventListener('click',function(){x.closest('.flash').remove()})});
  $$('.flash').forEach(function(f){
    if (f.querySelector('.secret')) return;
    setTimeout(function(){ if (f.parentNode) f.remove(); }, 6500);
  });
  d.addEventListener('click',function(e){var c=e.target.closest('[data-copy]');if(!c)return;var t=$(c.getAttribute('data-copy'));if(!t)return;navigator.clipboard&&navigator.clipboard.writeText(t.textContent.trim()).then(function(){var o=c.innerHTML;c.textContent='Copied';setTimeout(function(){c.innerHTML=o},1400)})});
  d.addEventListener('click',function(e){var c=e.target.closest('[data-copy-text]');if(!c)return;var text=c.getAttribute('data-copy-text')||'';if(!text)return;navigator.clipboard&&navigator.clipboard.writeText(text).then(function(){var o=c.textContent;c.textContent='Copied';setTimeout(function(){c.textContent=o},1400)})});
  d.addEventListener('click',function(e){
    var b=e.target.closest('[data-share]');
    if(!b||!dlg||!box) return;
    var url=b.getAttribute('data-share')||'', title=b.getAttribute('data-share-title')||'UniCybers programme';
    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
    var enc=encodeURIComponent, text=title+' — '+url;
    var html='<div class="mhead"><div><span class="eyebrow">SHARE</span><h3>'+esc(title)+'</h3></div><button type="button" class="iconbtn mclose" data-close aria-label="Close"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>';
    html+='<p class="hint">Send the programme page. The person sees the course, modules and the interest form.</p>';
    html+='<div class="share-grid">';
    html+='<a class="share-ch wa" target="_blank" rel="noopener" href="https://wa.me/?text='+enc(text)+'">WhatsApp</a>';
    html+='<a class="share-ch mail" href="mailto:?subject='+enc(title)+'&body='+enc(text)+'">Email</a>';
    html+='<a class="share-ch tg" target="_blank" rel="noopener" href="https://t.me/share/url?url='+enc(url)+'&text='+enc(title)+'">Telegram</a>';
    html+='<button type="button" class="share-ch copy" data-copy-text="'+esc(url)+'">Copy link</button>';
    html+='</div>';
    if(navigator.share){
      html+='<button type="button" class="btn primary" id="nativeShare" style="margin-top:12px;width:100%">More apps on this device</button>';
    }
    box.innerHTML=html;
    if(dlg.showModal)dlg.showModal(); else dlg.setAttribute('open','');
    var ns=$('#nativeShare',box);
    if(ns) ns.addEventListener('click',function(){navigator.share({title:title,text:title,url:url}).catch(function(){})});
  });
  d.addEventListener('change',function(e){var inp=e.target;if(!inp||inp.type!=='file')return;var box=inp.closest&&inp.closest('.file-btn');if(!box)return;var lab=box.querySelector('[data-file-name]');if(lab)lab.textContent=(inp.files&&inp.files[0])?inp.files[0].name:'No file chosen'});
  var board=$('.desk-board');if(board){$$('.desk-row',board).sort(function(a,b){var r=(+(b.getAttribute('data-ready')||0))-(+(a.getAttribute('data-ready')||0));if(r)return r;return (a.getAttribute('data-name')||'').localeCompare(b.getAttribute('data-name')||'')}).forEach(function(row){board.appendChild(row)})}

  /* Confirm destructive buttons */
  d.addEventListener('click',function(e){var c=e.target.closest('[data-confirm]');if(c&&!window.confirm(c.getAttribute('data-confirm'))){e.preventDefault();e.stopPropagation()}},true);

  /* Modal */
  var dlg=$('#modal'),box=$('#modalIn');
  function dressSelects(root){
    (root||d).querySelectorAll('select').forEach(function(sel){
      if(sel.dataset.dressed||sel.multiple||sel.closest('.daychk')) return;
      sel.dataset.dressed='1';
      var w=sel.getBoundingClientRect().width;
      var wrap=d.createElement('div');
      wrap.className='uc-dd';
      if(w>48) wrap.style.minWidth=Math.ceil(w)+'px';
      sel.parentNode.insertBefore(wrap, sel);
      wrap.appendChild(sel);
      sel.classList.add('uc-dd-native');
      var btn=d.createElement('button');
      btn.type='button';
      btn.className='uc-dd-btn';
      var list=d.createElement('div');
      list.className='uc-dd-list';
      list.hidden=true;
      function paint(){
        var opt=sel.options[sel.selectedIndex];
        btn.textContent=opt?opt.textContent:'';
        list.innerHTML='';
        Array.prototype.forEach.call(sel.options, function(o,i){
          if(o.hidden) return;
          var b=d.createElement('button');
          b.type='button';
          b.className='uc-dd-opt'+(o.selected?' on':'');
          b.textContent=o.textContent;
          b.addEventListener('click', function(ev){
            ev.preventDefault();
            ev.stopPropagation();
            sel.selectedIndex=i;
            sel.dispatchEvent(new Event('change',{bubbles:true}));
            paint();
            list.hidden=true;
          });
          list.appendChild(b);
        });
      }
      function place(){
        var r=btn.getBoundingClientRect();
        var width=Math.max(r.width, 220);
        var left=Math.min(Math.max(8, r.left), window.innerWidth - width - 8);
        list.style.width=width+'px';
        list.style.left=left+'px';
        var below=window.innerHeight - r.bottom;
        if(below<160 && r.top>below){
          list.style.top='auto';
          list.style.bottom=(window.innerHeight - r.top + 6)+'px';
        } else {
          list.style.bottom='auto';
          list.style.top=(r.bottom + 6)+'px';
        }
      }
      btn.addEventListener('click', function(ev){
        ev.preventDefault();
        ev.stopPropagation();
        var was=list.hidden;
        d.querySelectorAll('.uc-dd-list').forEach(function(l){l.hidden=true});
        if(was){
          var host=sel.closest('dialog')||d.body;
          if(list.parentNode!==host) host.appendChild(list);
          list.hidden=false;
          place();
        }
      });
      list._place = place;
      list.addEventListener('click', function(ev){ ev.stopPropagation(); });
      wrap.appendChild(btn);
      wrap.appendChild(list);
      paint();
    });
  }
  function closeMenus(ev){
    if(ev && ev.target && ev.target.closest && ev.target.closest('.uc-dd, .uc-dd-list')) return;
    d.querySelectorAll('.uc-dd-list').forEach(function(l){l.hidden=true});
  }
  d.addEventListener('click', closeMenus);
  window.addEventListener('scroll', function(){
    d.querySelectorAll('.uc-dd-list').forEach(function(l){ if(!l.hidden && l._place) l._place(); });
  }, true);
  function open(tpl){box.innerHTML='';box.appendChild(tpl.content.cloneNode(true));if(dlg.showModal)dlg.showModal();else dlg.setAttribute('open',''); wireDo($('form',box)); dressSelects(box); return box}
  dressSelects(d);
  function wireDo(form){
    if(!form) return;
    var hid=form.querySelector('input[name=do][type=hidden]');
    $$('[data-do]',form).forEach(function(btn){
      btn.addEventListener('click',function(e){
        e.preventDefault();
        var conf=btn.getAttribute('data-confirm');
        if(conf && !window.confirm(conf)) return;
        if(hid) hid.value=btn.getAttribute('data-do');
        if(form.requestSubmit) form.requestSubmit(); else form.submit();
      });
    });
  }
  if(dlg){dlg.addEventListener('click',function(e){if(e.target.closest('[data-close]'))dlg.close()})}
  var extra=$('#batch-students');
  if(extra) extra.addEventListener('click',function(e){if(e.target===extra){var x=$('.mclose',extra); if(x&&x.href) location.href=x.href}});
  $$('[data-edit]').forEach(function(btn){btn.addEventListener('click',function(){
    var p=JSON.parse(btn.getAttribute('data-edit')),m=open($('#tplPerson')),f=$('form',m),isNew=!p.id;
    $('[data-title]',m).textContent=isNew?'Add person':'Edit '+p.name;
    ['id','name','email','phone','country'].forEach(function(k){if(f[k])f[k].value=p[k]||(k==='id'?0:'')});
    if(f.role){var rv=(p.role||'student').replace(/\s+/g,'_'); if(rv==='superadmin') rv='super_admin'; f.role.value=rv;}
    if(p.protected){ $$('.btn.danger',m).forEach(function(x){x.style.display='none'}); if(f.role) f.role.disabled=true; }
if(f.limit)f.limit.value=String(p.limit||3); if(f.disabled)f.disabled.checked=!!p.disabled; if(f.internal_test)f.internal_test.checked=!!p.internal;
    $$('[data-newonly]',m).forEach(function(x){x.style.display=isNew?'':'none'}); $$('[data-editonly]',m).forEach(function(x){x.style.display=isNew?'none':''});
    if(!isNew&&f.send){f.send.checked=true;var lab=f.send.closest('label');lab.style.display='';lab.lastChild.textContent=' Email the new password when I issue one';}
    setTimeout(function(){f.name.focus()},30);
  })});
  $$('[data-devices]').forEach(function(btn){btn.addEventListener('click',function(){
    var uid=btn.getAttribute('data-devices'),m=open($('#tplDevices'));
    $('[data-name]',m).textContent=btn.getAttribute('data-name');
    $$('input[name=user]',m).forEach(function(i){i.value=uid}); var ls=$('select[name=limit]',m); if(ls) ls.value=btn.getAttribute('data-limit');
    var list=(window.UC_DEVICES||{})[uid]||[],h='';
    if(!list.length)h='<p class="hint">No devices registered yet.</p>';
    list.forEach(function(x){h+='<div class="dev"><span class="dev-ico"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/></svg></span><span><strong></strong><small>Last used '+x.last+'</small></span><form method="post" action="'+window.UC_POST+'"><input type="hidden" name="action" value="uc_portal_device_remove"><input type="hidden" name="_wpnonce" value="'+window.UC_NONCE_RM+'"><input type="hidden" name="id" value="'+x.id+'"><button class="btn ghost sm">Remove</button></form></div>'});
    $('[data-list]',m).innerHTML=h; $$('[data-list] .dev strong',m).forEach(function(s,i){s.textContent=list[i].label});
  })});
  $$('[data-open]').forEach(function(x){x.addEventListener('click',function(){var t=$(x.getAttribute('data-open'));if(!t)return;if(t.tagName==='DETAILS')t.open=true;t.scrollIntoView({behavior:'smooth',block:'start'})})});

  /* Job DNA view. The row is a record saved on this desk. */
  d.addEventListener('click',function(e){
    var b=e.target.closest('[data-job]');
    if(!b||!dlg||!box) return;
    var j; try{ j=JSON.parse(b.getAttribute('data-job')); }catch(err){ return; }
    function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
    var rows=[['Role',j.title],['Track',j.track],['Company',j.company],['Location',j.location],['Source',j.source],['Required skills',j.skills],['Min years',j.years],['Education',j.education],['CTC',j.ctc],['Status',j.status]];
    var html='<div class="job-sheet"><div class="mhead"><div><span class="eyebrow">JOB DNA</span><h3>'+esc(j.title||'Opening')+'</h3></div><button type="button" class="iconbtn mclose" data-close aria-label="Close"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div><p class="muted">Saved on this desk.</p><dl>';
    rows.forEach(function(r){ html+='<dt>'+esc(r[0])+'</dt><dd>'+esc(r[1]||'Not set')+'</dd>'; });
    html+='</dl>';
    if(j.post && j.nonce){
      html+='<form method="post" action="'+esc(j.post)+'"><input type="hidden" name="action" value="uc_portal_job_delete"><input type="hidden" name="_wpnonce" value="'+esc(j.nonce)+'"><input type="hidden" name="id" value="'+esc(j.id||'')+'"><div class="right" style="gap:8px"><button type="button" class="btn ghost" data-close>Close</button><button class="btn danger" data-confirm="Delete this Job DNA opening?">Delete opening</button></div></form>';
    } else html+='<div class="right"><button type="button" class="btn ghost" data-close>Close</button></div>';
    html+='</div>';
    box.innerHTML=html;
    if(dlg.showModal) dlg.showModal(); else dlg.setAttribute('open','');
  });

  $$('.tenant-swatch input[type=color]').forEach(function(c){
    c.addEventListener('input',function(){
      var n=c.parentNode.querySelector('input:not([type=color])');
      if(n) n.value=c.value;
    });
  });

  /* Generic add/edit modal for Courses, Batches, Classes and Materials.
     Each trigger carries data-edit-<entity>='{...json...}'; the matching
     field in the form is filled from that JSON by name. */
  function genericModal(entity, tplId, newTitle, editPrefix, nameKey){
    $$('[data-edit-'+entity+']').forEach(function(btn){
      btn.addEventListener('click',function(){
        var p=JSON.parse(btn.getAttribute('data-edit-'+entity)), tpl=$(tplId);
        if(!tpl) return;
        var m=open(tpl), f=$('form',m), isNew=!p.id;
        Object.keys(p).forEach(function(k){
          if(k==='do') return;
          if(Array.isArray(p[k])){
            $$('input[name="'+k+'[]"]',m).forEach(function(cb){cb.checked = p[k].indexOf(cb.value)>-1 || p[k].indexOf(+cb.value)>-1});
            return;
          }
          if(!f[k]) return;
          if(f[k].type==='checkbox') f[k].checked=!!p[k];
          else f[k].value = p[k]==null ? '' : p[k];
        });
        var t=$('[data-title]',m); if(t) t.textContent=isNew?newTitle:editPrefix+(p[nameKey]||'');
        $$('[data-newonly]',m).forEach(function(x){x.style.display=isNew?'':'none'});
        $$('[data-editonly]',m).forEach(function(x){x.style.display=isNew?'none':''});
        var recurrence=$('.recurrence-edit-controls',m);
        if(recurrence){ recurrence.hidden = isNew || !p.recurring_group; }
        if(!isNew && p.recurring_group && f.edit_scope){ f.edit_scope.value='single'; }
      });
    });
  }
  genericModal('course','#tplCourse','Add course','Edit ','name');
  // Use the batch's configured meeting provider as the default for new class sessions.
  d.addEventListener('change',function(e){
    var batch=e.target.closest('select[name=\"batch_id\"]'); if(!batch) return;
    var form=batch.closest('form'); if(!form) return;
    var opt=batch.options[batch.selectedIndex]; var provider=opt&&opt.getAttribute('data-provider'); var mode=opt&&opt.getAttribute('data-mode');
    var platform=form.querySelector('select[name=\"platform\"]');
    if(platform&&!form.querySelector('input[name=\"id\"]').value){ if(mode==='classroom') platform.value='offline'; else if(provider) platform.value=provider; }
  });
  genericModal('batch','#tplBatch','Add batch','Edit ','name');
  genericModal('class','#tplClass','Add class','Edit ','title');
  genericModal('material','#tplMaterial','Add material','Edit ','title');
  genericModal('practice','#tplPractice','Add assignment or mock','Edit ','title');
  var paperPresets = {
    apt: [
      {type:'mcq', q:'A train covers 60 km in 45 minutes. What is its speed in km/h?', options:['80','75','90','60'], key:'80'},
      {type:'mcq', q:'All SOC analysts read logs. Ravi is a SOC analyst. Which must be true?', options:['Ravi reads logs','Ravi is on call','All log readers are SOC analysts','Ravi writes the rules'], key:'Ravi reads logs'},
      {type:'mcq', q:'Choose the word closest to “brief”.', options:['Short','Late','Loud','Hidden'], key:'Short'},
      {type:'mcq', q:'If a password is changed every 90 days, how many changes happen in a 360-day year?', options:['4','3','6','2'], key:'4'}
    ],
    soc: [
      {type:'mcq', q:'An alert shows 400 failed logins, then one success. What is the first L1 action?', options:['Close it as a false positive','Contain the account and escalate as brute force','Wait for the user to call','Turn the SIEM off'], key:'Contain the account and escalate as brute force'},
      {type:'short', q:'A Sentinel incident shows an encoded PowerShell command on one host. Write the triage note: what you checked, the severity, and who you escalate to.'},
      {type:'diagram', q:'Label the path: Internet, firewall, web server, EDR agent, SIEM. Say where the alert is raised and where you block the source.'}
    ],
    ceh: [
      {type:'mcq', q:'Banner grabbing and whois belong to which CEH phase?', options:['Reconnaissance','Gaining access','Covering tracks','Maintaining access'], key:'Reconnaissance'},
      {type:'mcq', q:'Which tool intercepts and changes browser traffic in a web test?', options:['Nmap','Burp Suite','Splunk','Only Wireshark'], key:'Burp Suite'},
      {type:'short', q:'Ports 80, 443 and 22 are open. What do you test next, and what must you not attack without written scope?'},
      {type:'diagram', q:'Describe the lab path: attacker, public web server, database. Mark where the test stops.'}
    ],
    net: [
      {type:'diagram', q:'Draw the office: Internet, perimeter firewall, DMZ web server, internal switch, user LAN, SOC sensor. Name the zone of each box.'},
      {type:'mcq', q:'What stops a user PC from reaching a database in another zone?', options:['A firewall policy between zones','A longer password','Disabling DNS','Opening every port'], key:'A firewall policy between zones'},
      {type:'short', q:'A VPN user can open the file server but not the SIEM. Where do you look first?'}
    ]
  };
  function practiceQuestion(q){
    q = q || {type:'short', q:'', options:['','','',''], key:''};
    var box = document.createElement('div');
    box.className = 'q-build';
    box.setAttribute('data-q','');
    box.setAttribute('data-type', q.type || 'short');
    var label = q.type==='mcq' ? 'Multiple choice' : (q.type==='diagram' ? 'Network diagram' : 'Short answer');
    var html = '<div class="q-build-h"><strong>'+label+'</strong><button type="button" class="btn ghost sm" data-del-q>Remove</button></div>';
    html += '<label>Question<textarea data-prompt rows="2"></textarea></label>';
    if (q.type==='mcq') {
      html += '<div class="fgrid">';
      for (var i=0;i<4;i++) html += '<label>Option '+(i+1)+'<input data-opt></label>';
      html += '</div><label>Correct option<input data-key placeholder="Must match one option exactly"></label>';
    }
    box.innerHTML = html;
    box.querySelector('[data-prompt]').value = q.q || '';
    if (q.type==='mcq') {
      var opts = q.options || [];
      $$('[data-opt]', box).forEach(function(inp, i){ inp.value = opts[i] || ''; });
      var key = box.querySelector('[data-key]');
      if (key) key.value = q.key || '';
    }
    return box;
  }
  function practiceSync(form){
    if (!form) return;
    var kind = form.querySelector('[name=kind]');
    var val = kind ? kind.value : 'assignment';
    var m = form.querySelector('[data-mock]'), a = form.querySelector('[data-asg]'), p = form.querySelector('[data-apt]');
    if (m) m.hidden = val !== 'mock';
    if (p) p.hidden = val !== 'aptitude';
    if (a) a.hidden = val === 'mock';
    form.querySelectorAll('[data-asg-only]').forEach(function(el){ el.hidden = val !== 'assignment'; });
  }
  document.addEventListener('change', function(e){
    if (e.target && e.target.matches && e.target.matches('[data-practice-kind]')) practiceSync(e.target.form);
  });
  document.addEventListener('click', function(e){
    var open = e.target.closest && e.target.closest('[data-edit-practice]');
    if (open) setTimeout(function(){ practiceSync($('#modal form')); }, 0);
    var t = e.target.closest && e.target.closest('[data-add-q],[data-preset],[data-del-q]');
    if (!t) return;
    var form = t.closest('form');
    if (!form) return;
    if (t.hasAttribute('data-del-q')) { var row = t.closest('[data-q]'); if (row) row.remove(); return; }
    e.preventDefault();
    var host = form.querySelector('[data-questions]');
    if (!host) return;
    if (t.hasAttribute('data-preset')) {
      host.innerHTML = '';
      (paperPresets[t.getAttribute('data-preset')] || []).forEach(function(q){ host.appendChild(practiceQuestion(q)); });
      return;
    }
    host.appendChild(practiceQuestion({type:t.getAttribute('data-add-q')}));
  });
  document.addEventListener('submit', function(e){
    var form = e.target;
    var slot = form.querySelector && form.querySelector('[name=paper]');
    var action = form.querySelector && form.querySelector('[name=action]');
    if (!slot || !action || action.value!=='uc_portal_practice_save') return;
    var paper = [];
    $$('[data-q]', form).forEach(function(row){
      var prompt = row.querySelector('[data-prompt]');
      var item = {type: row.getAttribute('data-type') || 'short', q: prompt ? prompt.value : ''};
      if (item.type==='mcq') {
        item.options = [];
        $$('[data-opt]', row).forEach(function(inp){ item.options.push(inp.value); });
        var key = row.querySelector('[data-key]');
        item.key = key ? key.value : '';
      }
      paper.push(item);
    });
    slot.value = JSON.stringify(paper);
  });
  genericModal('recording','#tplRecording','Recording details','Recording details','zoom_title');

  /* Countdown to the next class */
  var cd=$('.cd');
  if(cd){var s=+cd.getAttribute('data-start'),en=+cd.getAttribute('data-end'),p=function(n){return (n<10?'0':'')+n};
    (function tick(){var now=Date.now(),t=now<s?s-now:(now<en?en-now:0),x=Math.floor(t/1000);
      $('[data-u=d]',cd).textContent=Math.floor(x/86400);$('[data-u=h]',cd).textContent=p(Math.floor(x%86400/3600));$('[data-u=m]',cd).textContent=p(Math.floor(x%3600/60));$('[data-u=s]',cd).textContent=p(x%60);
      if(t>0)setTimeout(tick,1000)})();}

  /* Attendance heartbeat while a student has the Classes page open */
  var hb=window.UC_HEARTBEAT;
  if(hb&&hb.ids&&hb.ids.length){var beat=function(){hb.ids.forEach(function(id){fetch(hb.url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':hb.nonce},body:JSON.stringify({session_id:id})}).catch(function(){})})};$$('[data-join]').forEach(function(a){a.addEventListener('click',function(){setTimeout(beat,4000)})});setInterval(beat,120000)}

  var player=$('#ucClassPlayer');
  if(player){
    var poster=$$('[data-cr-poster], .cr-poster, .cr-play-caption');
    var hide=function(){poster.forEach(function(n){n.style.display='none'})};
    var show=function(){poster.forEach(function(n){n.style.display=''})};
    player.addEventListener('play',hide);
    player.addEventListener('pause',show);
  }
  var tabs=document.querySelector('[data-cr-tabs]');
  if(tabs){
    $$('button[data-cr]',tabs).forEach(function(btn){
      btn.addEventListener('click',function(){
        $$('button[data-cr]',tabs).forEach(function(b){b.classList.toggle('on',b===btn)});
        var k=btn.getAttribute('data-cr');
        $$('[data-cr-panel]').forEach(function(p){p.hidden=p.getAttribute('data-cr-panel')!==k});
      });
    });
  }
  d.addEventListener('click',function(e){
    var b=e.target.closest('.cr-seek');
    if(!b) return;
    var t=+b.getAttribute('data-t')||0;
    var v=$('#ucClassPlayer');
    if(v && typeof v.currentTime==='number'){ v.currentTime=t; if(v.play) v.play(); }
  });
  var tf=$('[data-cr-filter]');
  if(tf) tf.addEventListener('input',function(){
    var q=tf.value.trim().toLowerCase();
    $$('.cr-tr li').forEach(function(li){
      li.hidden=!!(q && (li.getAttribute('data-q')||'').indexOf(q)<0);
    });
  });
  $$('[data-sum-tabs]').forEach(function(nav){
    nav.addEventListener('click',function(e){
      var btn=e.target.closest('[data-sum]');
      if(!btn) return;
      var k=btn.getAttribute('data-sum');
      var root=nav.closest('.cr-sum')||nav.parentNode;
      $$('[data-sum]',nav).forEach(function(b){b.classList.toggle('on',b===btn)});
      $$('[data-sum-panel]',root).forEach(function(p){p.hidden=p.getAttribute('data-sum-panel')!==k});
    });
  });
  /* Viewer focus deterrence. Browsers cannot reliably detect OS-level screenshots or screen recording. */
  $$('.v-frame').forEach(function(vFrame){
    ['copy','cut','contextmenu','dragstart'].forEach(function(type){
      vFrame.addEventListener(type,function(e){
        e.preventDefault();
        if(window.UC_PRIVACY){
          fetch(window.UC_PRIVACY.url,{method:'POST',headers:{'Content-Type':'application/json','X-WP-Nonce':window.UC_PRIVACY.nonce},body:JSON.stringify({kind:type,page:location.pathname})}).catch(function(){});
        }
      });
    });
    vFrame.addEventListener('keydown',function(e){
      var key=(e.key||'').toLowerCase();
      if((e.ctrlKey||e.metaKey)&&['c','x','p','s','u'].indexOf(key)!==-1){
        e.preventDefault();
        if(window.UC_PRIVACY) fetch(window.UC_PRIVACY.url,{method:'POST',headers:{'Content-Type':'application/json','X-WP-Nonce':window.UC_PRIVACY.nonce},body:JSON.stringify({kind:'shortcut',page:location.pathname})}).catch(function(){});
      }
    });
    vFrame.querySelectorAll('video').forEach(function(video){
      video.setAttribute('controlsList','nodownload noplaybackrate');
      video.setAttribute('disablePictureInPicture','');
      video.addEventListener('contextmenu',function(e){ e.preventDefault(); });
    });
  });
  if($$('.v-frame').length){
    function paintBlackout(on){ $$('.v-frame').forEach(function(frame){ frame.classList.toggle('drm-blackout', !!on); frame.querySelectorAll('video').forEach(function(v){ if(on && v.pause) v.pause(); }); }); }
    d.addEventListener('visibilitychange', function(){ paintBlackout(d.hidden); });
    paintBlackout(false);
  }

  d.addEventListener('click', function(e){
    var add = e.target.closest('[data-extra-add]');
    var remove = e.target.closest('[data-chip-remove]');
    if(add){
      var box = add.closest('[data-extra-dates]');
      var input = box.querySelector('[data-extra-input]');
      var day = input && input.value;
      if(!day) return;
      var hidden = box.querySelector('[name=extra_dates]');
      var list = hidden.value ? hidden.value.split(',').filter(Boolean) : [];
      if(list.indexOf(day) === -1) list.push(day);
      hidden.value = list.join(',');
      input.value = '';
      paintDates(box);
    }
    if(remove){
      var chipBox = remove.closest('[data-extra-dates]');
      var hidden2 = chipBox.querySelector('[name=extra_dates]');
      var drop = remove.getAttribute('data-chip-remove');
      hidden2.value = hidden2.value.split(',').filter(function(v){ return v && v !== drop; }).join(',');
      paintDates(chipBox);
    }
  });
  function paintDates(box){
    var hidden = box.querySelector('[name=extra_dates]');
    var chips = box.querySelector('[data-extra-chips]');
    chips.innerHTML = '';
    (hidden.value ? hidden.value.split(',') : []).filter(Boolean).forEach(function(day){
      var chip = d.createElement('span');
      chip.className = 'date-chip';
      chip.textContent = day;
      var btn = d.createElement('button');
      btn.type = 'button';
      btn.setAttribute('data-chip-remove', day);
      btn.setAttribute('aria-label', 'Remove '+day);
      btn.textContent = '×';
      chip.appendChild(btn);
      chips.appendChild(chip);
    });
  }

  function matchBrand(){
    function textWidth(el){
      var r=document.createRange();
      r.selectNodeContents(el);
      var n=r.getBoundingClientRect().width;
      if(r.detach) r.detach();
      return n;
    }
    function equalize(strong, em){
      if(!strong || !em) return;
      strong.style.width='max-content';
      em.style.width='max-content';
      em.style.minWidth='0';
      strong.style.letterSpacing='0px';
      em.style.letterSpacing='0px';
      var sw=textWidth(strong), ew=textWidth(em);
      if(sw<=8 || ew<=8) return;
      var emCount=Math.max(1,(em.textContent||'').trim().length);
      if(Math.abs(sw-ew)<0.4) return;
      em.style.letterSpacing=((sw-ew)/emCount)+'px';
      var now=textWidth(em);
      if(Math.abs(now-sw)>0.4){
        var cur=parseFloat(em.style.letterSpacing)||0;
        em.style.letterSpacing=(cur+((sw-now)/emCount))+'px';
      }
    }
    var source=document.querySelector('.brand-source-cover');
    var sourceText=source?source.querySelector('span'):null;
    if(source && sourceText){
      sourceText.style.transform='none';
      sourceText.style.letterSpacing='0';
      var tw=textWidth(sourceText), target=source.clientWidth;
      if(tw>8 && target>8){
        sourceText.style.transformOrigin='left center';
        sourceText.style.transform='scaleX('+(target/tw)+')';
      }
    } else {
      equalize(document.getElementById('ucBrandName'),document.getElementById('ucBrandSub'));
    }
  }
  d.addEventListener('change', function(e){
    var sort=e.target.closest('[data-lib-sort]');
    if(sort){
      var body=sort.closest('.lib-desk').querySelector('tbody');
      if(body){
        var bits=(sort.value||'date-desc').split('-');
        var key=bits[0]||'date';
        var desc=bits[1]!=='asc';
        Array.prototype.slice.call(body.querySelectorAll('tr')).sort(function(a,b){
          var av=a.getAttribute('data-'+key)||'', bv=b.getAttribute('data-'+key)||'';
          var n=av.localeCompare(bv, undefined, {numeric:true, sensitivity:'base'});
          return desc ? -n : n;
        }).forEach(function(row){ body.appendChild(row); });
      }
    }
    var batch=e.target.closest('[data-class-batch]');
    if(batch){
      var box=batch.closest('.grp')||d;
      $$('.crow', box).forEach(function(row){ row.hidden=!!(batch.value && row.getAttribute('data-batch')!==batch.value); });
    }
    var csort=e.target.closest('[data-class-sort]');
    if(csort){
      var wrap=csort.closest('.grp');
      var grid=wrap&&wrap.querySelector('.crows');
      if(grid){
        var bits=(csort.value||'date-desc').split('-');
        var key=bits[0]==='name'?'name':(bits[0]==='batch'?'batch':'date');
        var desc=bits[1]!=='asc';
        Array.prototype.slice.call(grid.querySelectorAll('.crow')).sort(function(a,b){
          var av=a.getAttribute('data-'+key)||'', bv=b.getAttribute('data-'+key)||'';
          var n=av.localeCompare(bv, undefined, {numeric:true, sensitivity:'base'});
          return desc ? -n : n;
        }).forEach(function(row){ grid.appendChild(row); });
      }
    }
  });
  function deskApply(){
    var b=$('#deskBatch'), l=$('#deskLane'), p=$('#deskPack');
    if(!b&&!l&&!p) return;
    var bv=b?b.value:'', lv=l?l.value:'', pv=p?p.value:'';
    $$('.desk-card').forEach(function(card){
      var ok=(!bv||card.getAttribute('data-batch')===bv)&&(!lv||card.getAttribute('data-lane')===lv)&&(!pv||card.getAttribute('data-pack')===pv);
      card.hidden=!ok;
    });
  }
  ['deskBatch','deskLane','deskPack'].forEach(function(id){ var el=d.getElementById(id); if(el) el.addEventListener('change', deskApply); });
  matchBrand();
  requestAnimationFrame(matchBrand);
  window.addEventListener('resize', matchBrand);
  if(document.fonts && document.fonts.ready) document.fonts.ready.then(function(){ matchBrand(); requestAnimationFrame(matchBrand); });

})();
