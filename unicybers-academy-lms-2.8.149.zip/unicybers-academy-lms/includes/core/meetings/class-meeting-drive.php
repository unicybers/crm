<?php
/**
 * UniCybers Academy LMS: Google Drive Sync & Recording Ingestion Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Meeting_Drive {

    public static function google_access_token() {
        return UC_LMS_Meeting_Google::google_access_token();
    }

    public static function portal_sync_meet_folder(&$used = []){
            $token = self::google_access_token();
            if (is_wp_error($token)) return $token;
            $folder = trim((string)get_option('uc_google_meet_folder', '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi'));
            if ($folder === '') $folder = '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi';
            // Keep class recordings separate from batch teaching materials. The
            // shared root may contain batch/Recordings folders; only scan the
            // dedicated root-level Meet Recordings folder when it exists.
            $meet_recordings_folder = self::drive_child_folder_id($token, $folder, 'Meet Recordings');
            if (is_wp_error($meet_recordings_folder)) return $meet_recordings_folder;
            if ($meet_recordings_folder !== '') $folder = $meet_recordings_folder;
            $files = self::drive_folder_videos($token, $folder, 0);
            if (is_wp_error($files)) return $files;
            global $wpdb;
            $table = UC_LMS_Meeting::instance()->table('sessions');
            $sessions = $wpdb->get_results("SELECT * FROM {$table} WHERE hidden=0 AND LOWER(IFNULL(status,''))<>'cancelled' AND LOWER(IFNULL(recording_status,''))<>'discarded' AND session_date >= CURDATE() - INTERVAL 120 DAY ORDER BY session_date DESC");
            $added = 0;
            foreach ((array)$files as $file) {
                $id = (string)($file['id'] ?? '');
                if ($id === '' || isset($used[$id])) continue;
                $session = self::match_meet_file_to_session($file, $sessions);
                if (!$session) continue;
                $existing = (string)($session->recording_url ?? '');
                if ($existing !== '' && strpos($existing, $id) !== false) { $used[$id] = (int)$session->id; continue; }
                if ($existing !== '' && stripos($existing, 'zoom.us') !== false) continue;
                $url = 'https://drive.google.com/file/d/'.$id.'/view';
                $wpdb->update(UC_LMS_Meeting::instance()->table('sessions'), [
                    'recording_url' => $url,
                    'recording_status' => 'available',
                    'recording_at' => UC_LMS_Meeting::instance()->now(),
                    'updated_at' => UC_LMS_Meeting::instance()->now(),
                ], ['id' => (int)$session->id]);
                $session->recording_url = $url;
                $used[$id] = (int)$session->id;
                $added++;
            }
            return $added;
        }

    public static function portal_sync_meet_notes($folder_id = '') {
        return UC_LMS_Meeting_Drive_Notes::portal_sync_meet_notes($folder_id);
    }

    public static function drive_folder_docs($token, $folder_id, $q = '') {
        return UC_LMS_Meeting_Drive_Notes::drive_folder_docs($token, $folder_id, $q);
    }

    public static function drive_search_note_docs($token, $title = '', $day = '') {
        return UC_LMS_Meeting_Drive_Notes::drive_search_note_docs($token, $title, $day);
    }

    public static function drive_export_text($token, $file_id) {
        return UC_LMS_Meeting_Drive_Notes::drive_export_text($token, $file_id);
    }

    public static function match_meet_note_to_session($doc, $sessions) {
        return UC_LMS_Meeting_Drive_Notes::match_meet_note_to_session($doc, $sessions);
    }

    public static function save_meet_note($session, $doc, $text = '') {
        return UC_LMS_Meeting_Drive_Notes::save_meet_note($session, $doc, $text);
    }











    private static function drive_child_folder_id($token, $parent_id, $folder_name) {
            $query = [
                'q' => "'".str_replace("'", "\\'", (string)$parent_id)."' in parents and name = '".str_replace("'", "\\'", (string)$folder_name)."' and mimeType = 'application/vnd.google-apps.folder' and trashed = false",
                'pageSize' => 20,
                'fields' => 'files(id,name,mimeType)',
                'supportsAllDrives' => 'true',
                'includeItemsFromAllDrives' => 'true',
            ];
            $response = wp_remote_get('https://www.googleapis.com/drive/v3/files?'.http_build_query($query), [
                'timeout' => 20,
                'headers' => ['Authorization' => 'Bearer '.$token],
            ]);
            if (is_wp_error($response)) return $response;
            $code = (int)wp_remote_retrieve_response_code($response);
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if ($code < 200 || $code >= 300) {
                $message = is_array($data) ? (string)($data['error']['message'] ?? 'Google Drive could not inspect the Meet Recordings folder.') : 'Google Drive could not inspect the Meet Recordings folder.';
                return new WP_Error('google_drive_folder', $message);
            }
            foreach ((array)($data['files'] ?? []) as $file) {
                if (!empty($file['id']) && (string)($file['name'] ?? '') === (string)$folder_name) return (string)$file['id'];
            }
            return '';
        }

    public static function drive_folder_videos($token, $folder, $depth){
            $out = [];
            $page = '';
            for ($i = 0; $i < 6; $i++) {
                $query = ["q" => "'".str_replace("'", "\\'", $folder)."' in parents and trashed = false", "pageSize" => 100, "fields" => "nextPageToken,files(id,name,mimeType,createdTime)", "supportsAllDrives" => "true", "includeItemsFromAllDrives" => "true"];
                if ($page !== '') $query["pageToken"] = $page;
                $response = wp_remote_get("https://www.googleapis.com/drive/v3/files?".http_build_query($query), ["timeout" => 25, "headers" => ["Authorization" => "Bearer ".$token]]);
                if (is_wp_error($response)) return $response;
                $code = (int)wp_remote_retrieve_response_code($response);
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if ($code === 401 || $code === 403) return new WP_Error("google", "Sync cannot read the Meet recordings folder yet. In LMS Settings press Connect rafi@unicybers.com again so Drive read access is granted.");
                if ($code < 200 || $code >= 300) {
                    $msg = is_array($data) ? (string)($data["error"]["message"] ?? "Google Drive did not open the Meet recordings folder.") : "Google Drive did not open the Meet recordings folder.";
                    return new WP_Error("google", $msg);
                }
                foreach ((array)($data["files"] ?? []) as $file) {
                    $mime = (string)($file["mimeType"] ?? "");
                    $name = (string)($file["name"] ?? "");
                    if ($mime === "application/vnd.google-apps.folder" && $depth < 4 && !empty($file["id"])) {
                        $nested = self::drive_folder_videos($token, $file["id"], $depth + 1);
                        if (!is_wp_error($nested)) $out = array_merge($out, $nested);
                        continue;
                    }
                    if (strpos($mime, "video/") === 0 || preg_match("~\.(mp4|webm|m4v)$~i", $name)) $out[] = $file;
                }
                $page = (string)($data["nextPageToken"] ?? "");
                if ($page === "") break;
            }
            return $out;
        }

    public static function match_meet_file_to_session($file, $sessions){
            $day = self::meet_file_day($file);
            if ($day === "") return null;
            $id = (string)($file["id"] ?? "");
            $candidates = [];
            foreach ((array)$sessions as $s) {
                if ((string)$s->session_date !== $day) continue;
                $existing = (string)($s->recording_url ?? "");
                if ($existing !== "" && strpos($existing, $id) === false && stripos($existing, "drive.google.com") === false) continue;
                $candidates[] = $s;
            }
            if (!$candidates) return null;
            $meet_only = [];
            foreach ($candidates as $s) {
                $plat = strtolower((string)($s->platform ?? ""));
                if ($plat === "google_meet" || $plat === "meet" || $plat === "google meet") $meet_only[] = $s;
            }
            // This importer is dedicated to Google Meet files. Never attach a
            // Meet recording to a Zoom, Teams or Zoho session on the same date.
            if (!$meet_only) return null;
            $candidates = $meet_only;
            if (count($candidates) === 1) return $candidates[0];
            $best = null;
            $score = 0;
            $tokens = self::meet_name_tokens((string)($file["name"] ?? ""));
            foreach ($candidates as $s) {
                $sc = self::meet_token_overlap($tokens, self::meet_name_tokens((string)$s->title." ".(string)($s->recording_label ?? "")));
                $plat = strtolower((string)($s->platform ?? ""));
                if ($plat === "google_meet" || $plat === "meet" || $plat === "google meet") $sc += 2;
                if ($sc > $score) { $score = $sc; $best = $s; }
            }
            return $score >= 1 ? $best : null;
        }

    public static function meet_file_day($file){
            $name = (string)($file["name"] ?? "");
            if (preg_match("~(20\\d{2})[./-](\\d{1,2})[./-](\\d{1,2})~", $name, $m)) return sprintf("%04d-%02d-%02d", $m[1], $m[2], $m[3]);
            if (preg_match("~(\\d{1,2})[./-](\\d{1,2})[./-](20\\d{2})~", $name, $m)) return sprintf("%04d-%02d-%02d", $m[3], $m[2], $m[1]);
            if (preg_match("~\\b(\\d{1,2})\\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\\s+(20\\d{2})~i", $name, $m)) {
                $dt = DateTime::createFromFormat("j M Y", $m[1]." ".substr($m[2], 0, 3)." ".$m[3]);
                if ($dt) return $dt->format("Y-m-d");
            }
            if (!empty($file["createdTime"])) {
                try {
                    $dt = new DateTime((string)$file["createdTime"]);
                    $dt->setTimezone(new DateTimeZone("Asia/Kolkata"));
                    return $dt->format("Y-m-d");
                } catch (Exception $e) {}
            }
            return "";
        }

    public static function meet_name_tokens($text){
            $text = strtolower((string)$text);
            $text = preg_replace("~\\.(mp4|webm|m4v)$~", "", $text);
            $text = preg_replace("~\\b(recording|meet|google|unicybers|ist|gmt)\\b~", " ", $text);
            $parts = preg_split("~[^a-z0-9]+~", $text);
            $out = [];
            foreach ((array)$parts as $p) if (strlen($p) > 2) $out[$p] = 1;
            return $out;
        }

    public static function meet_token_overlap($a, $b){
            $n = 0;
            foreach ($a as $k => $_) if (isset($b[$k])) $n++;
            return $n;
        }

    public static function meet_code_from_session($session){
            $saved = strtolower(trim((string)($session->meet_code ?? '')));
            if ($saved !== '') return $saved;
            return UC_LMS_Meeting_Google::meet_code_from_url((string)($session->join_url ?? ''));
        }

    public static function portal_sync_meet_recording($session, &$used = []){
            if (strtolower((string)($session->recording_status ?? '')) === 'discarded') return 'kept';
            if (trim((string)($session->recording_url ?? '')) !== '') return 'kept';
            $token = self::google_access_token();
            if (is_wp_error($token)) return $token;
            $code = self::meet_code_from_session($session);
            $file = $code !== '' ? self::meet_recording_from_api($token, $code) : '';
            if ($file === '' || isset($used[$file])) $file = self::meet_recording_from_drive($token, $session, $code, $used);
            if ($file === '' || isset($used[$file])) return new WP_Error('processing', 'Google is still saving the Meet recording to Drive.');
            $used[$file] = (int)$session->id;
            global $wpdb;
            $url = 'https://drive.google.com/file/d/'.rawurlencode($file).'/view';
            $wpdb->update(UC_LMS_Meeting::instance()->table('sessions'), [
                'recording_url' => $url,
                'recording_status' => 'available',
                'recording_at' => UC_LMS_Meeting::instance()->now(),
                'meet_code' => $code !== '' ? $code : null,
                'updated_at' => UC_LMS_Meeting::instance()->now(),
            ], ['id'=>(int)$session->id]);
            return 'linked';
        }

    public static function meet_recording_from_api($token, $code){
            $list = wp_remote_get('https://meet.googleapis.com/v2/conferenceRecords?'.http_build_query([
                'pageSize' => 10,
                'filter' => 'space.meeting_code="'.$code.'"',
            ]), ['timeout'=>25, 'headers'=>['Authorization'=>'Bearer '.$token]]);
            if (is_wp_error($list)) return '';
            $data = json_decode(wp_remote_retrieve_body($list), true);
            foreach ((array)($data['conferenceRecords'] ?? []) as $rec) {
                $name = (string)($rec['name'] ?? '');
                if ($name === '') continue;
                $recs = wp_remote_get('https://meet.googleapis.com/v2/'.ltrim($name, '/').'/recordings', ['timeout'=>25, 'headers'=>['Authorization'=>'Bearer '.$token]]);
                if (is_wp_error($recs)) continue;
                $body = json_decode(wp_remote_retrieve_body($recs), true);
                foreach ((array)($body['recordings'] ?? []) as $row) {
                    if (strtoupper((string)($row['state'] ?? '')) !== 'FILE_GENERATED') continue;
                    $id = self::drive_id_from_meet_destination($row['driveDestination'] ?? []);
                    if ($id !== '') return $id;
                }
            }
            return '';
        }

    public static function drive_id_from_meet_destination($dest){
            $file = (string)($dest['file'] ?? '');
            if (preg_match('~([A-Za-z0-9_-]{20,})$~', $file, $m)) return $m[1];
            $uri = (string)($dest['exportUri'] ?? '');
            if (preg_match('~/file/d/([A-Za-z0-9_-]{10,})~', $uri, $m)) return $m[1];
            return '';
        }

    public static function meet_recording_from_drive($token, $session, $code, $used){
            $parts = ["trashed = false", "mimeType contains 'video/'"];
            if ($code !== '') $parts[] = "name contains '".str_replace("'", "\\'", $code)."'";
            else {
                $title = trim(preg_replace('/\s+/', ' ', (string)($session->title ?? '')));
                $title = substr($title, 0, 40);
                if ($title !== '') $parts[] = "name contains '".str_replace("'", "\\'", $title)."'";
            }
            $response = wp_remote_get('https://www.googleapis.com/drive/v3/files?'.http_build_query([
                'q' => implode(' and ', $parts),
                'orderBy' => 'createdTime desc',
                'pageSize' => 15,
                'fields' => 'files(id,name,createdTime)',
                'supportsAllDrives' => 'true',
                'includeItemsFromAllDrives' => 'true',
            ]), ['timeout'=>25, 'headers'=>['Authorization'=>'Bearer '.$token]]);
            if (is_wp_error($response) || (int)wp_remote_retrieve_response_code($response) >= 400) return '';
            $data = json_decode(wp_remote_retrieve_body($response), true);
            $best = '';
            $bestGap = PHP_INT_MAX;
            $start = strtotime((string)$session->session_date.' '.(string)$session->start_time);
            foreach ((array)($data['files'] ?? []) as $file) {
                $id = (string)($file['id'] ?? '');
                if ($id === '' || isset($used[$id])) continue;
                $created = strtotime((string)($file['createdTime'] ?? ''));
                if ($start && $created && ($created < $start - 3600 || $created > $start + 8 * 3600)) continue;
                $gap = $start && $created ? abs($created - $start) : 0;
                if ($gap < $bestGap) { $bestGap = $gap; $best = $id; }
            }
            return $best;
        }
}
