<?php
/**
 * UniCybers Academy LMS: REST API Subsystem.
 *
 * Provides REST API health endpoints and real-time attendance heartbeat logging.
 */

if (!defined('ABSPATH')) exit;

final class UC_LMS_Rest {
    private static $instance = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public static function init() {
        $inst = self::instance();
        add_action('rest_api_init', [$inst, 'rest_routes']);
    }

    private static function table($name) {
        global $wpdb;
        return $wpdb->prefix . 'uc_' . $name;
    }

    public function rest_routes() {
        $ver = defined('UC_Academy_LMS::VERSION') ? UC_Academy_LMS::VERSION : '2.8.75';
        register_rest_route('uc-lms/v1', '/health', [
            'methods'             => 'GET',
            'permission_callback' => '__return_true',
            'callback'            => function() use ($ver) {
                return ['ok' => true, 'version' => $ver];
            }
        ]);

        register_rest_route('uc-lms/v1', '/attendance/heartbeat', [
            'methods'             => 'POST',
            'permission_callback' => function() { return is_user_logged_in(); },
            'callback'            => [$this, 'attendance_heartbeat']
        ]);
    }

    public function attendance_heartbeat($request) {
        global $wpdb;
        $uid = get_current_user_id();
        $sid = absint($request->get_param('session_id'));
        if (!$sid) return new WP_Error('invalid_session', 'Session is required', ['status' => 400]);

        $sessions_t = self::table('sessions');
        $enrol_t    = self::table('enrolments');
        $attend_t   = self::table('attendance');

        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$sessions_t} WHERE id=%d AND hidden=0", $sid));
        if (!$s) return new WP_Error('not_found', 'Session not found', ['status' => 404]);

        $enrolled = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$enrol_t} WHERE batch_id=%d AND user_id=%d AND status='active'", $s->batch_id, $uid));
        if (!$enrolled) return new WP_Error('forbidden', 'You are not enrolled in this batch.', ['status' => 403]);

        $now = current_time('mysql');
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$attend_t} WHERE session_id=%d AND user_id=%d", $sid, $uid));
        if (!$existing) {
            $wpdb->insert($attend_t, [
                'session_id'   => $sid,
                'batch_id'     => $s->batch_id,
                'user_id'      => $uid,
                'joined_at'    => $now,
                'last_seen_at' => $now,
                'minutes'      => 0,
                'status'       => 'present',
                'source'       => 'heartbeat'
            ]);
        } else {
            $joined = strtotime($existing->joined_at);
            $minutes = $joined ? max(0, (int)floor((time() - $joined) / 60)) : ((int)$existing->minutes);
            $wpdb->update($attend_t, [
                'last_seen_at' => $now,
                'minutes'      => $minutes,
                'status'       => $existing->status === 'absent' ? 'present' : $existing->status,
                'source'       => 'heartbeat'
            ], ['id' => $existing->id]);
        }

        return [
            'ok'         => true,
            'session_id' => $sid,
            'minutes'    => (int)$wpdb->get_var($wpdb->prepare("SELECT minutes FROM {$attend_t} WHERE session_id=%d AND user_id=%d", $sid, $uid))
        ];
    }
}
