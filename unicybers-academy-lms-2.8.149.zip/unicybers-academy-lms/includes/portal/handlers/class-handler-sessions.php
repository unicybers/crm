<?php
/**
 * UniCybers Academy LMS: Class Session & Meeting Handlers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Handler_Sessions {

    public static function fill_class_zoom($portal, &$join_url, &$passcode, &$zoom_id, $title, $date, $start, $end, $tz, $platform, $batch_id = 0, &$start_url = ''){
        if ($platform !== 'zoom') return '';
        if ($join_url) return 'kept';
        if (!class_exists('UC_Academy_LMS')) return 'missing';
        $m = UC_Academy_LMS::instance()->portal_class_zoom([
            'title'=>$title, 'session_date'=>$date, 'start_time'=>$start, 'end_time'=>$end,
            'timezone'=>$tz, 'zoom_meeting_id'=>$zoom_id, 'alternative_hosts'=>$portal->zoom_alt_hosts($batch_id),
        ]);
        if (is_wp_error($m)) return $m->get_error_code()==='zoom_config' ? 'missing' : 'Zoom did not return a link: '.$m->get_error_message();
        if (!empty($m['join_url'])) $join_url = esc_url_raw($m['join_url']);
        if ($passcode === '' && !empty($m['passcode'])) $passcode = sanitize_text_field($m['passcode']);
        if (!empty($m['zoom_meeting_id'])) $zoom_id = (string)$m['zoom_meeting_id'];
        if (!empty($m['start_url'])) $start_url = esc_url_raw($m['start_url']);
        $note = !empty($m['hosts_note']) ? $m['hosts_note'] : '';
        return $join_url ? 'ready'.$note : 'Zoom did not return a join link.';
    }

    public static function class_saved_flash($portal, $base, $zoom_note, $join_url, $platform){
        if ($platform !== 'zoom' || $zoom_note === '' || $zoom_note === 'kept') return $base;
        if (strpos((string)$zoom_note, 'ready') === 0 && $join_url) return $base.' Zoom room is on training@unicybers.com. Start class opens it as host — students join without being admitted. Cloud recording starts with the room.'.substr($zoom_note, 5);
        if ($zoom_note === 'missing') return $base.' Zoom is not connected, so no meeting link was created.';
        return $base.' '.$zoom_note;
    }

    public static function ensure_room_link($portal, &$join_url, $platform, $title, $date, $start, $end, $tz, &$meta = null){
        $meta = is_array($meta) ? $meta : [];
        if ($join_url || !in_array($platform, ['google_meet','teams','zoho'], true)) return '';
        if (!class_exists('UC_Academy_LMS')) return 'Meeting links cannot be created until the workspace account is connected.';
        $made = UC_Academy_LMS::instance()->portal_create_room($platform, $title, $date, $start, $end, $tz);
        if (is_wp_error($made)) return $made->get_error_message();
        if (is_array($made)) {
            $join_url = (string)($made['join_url'] ?? '');
            $meta = $made;
            if (!empty($made['passcode'])) $meta['passcode'] = sanitize_text_field($made['passcode']);
            return $join_url ? (string)($made['record_note'] ?? '') : 'No meeting link was returned.';
        }
        if (is_string($made) && $made !== '') { $join_url = $made; return ''; }
        return 'No meeting link was returned.';
    }

    public static function apply_meet_meta($portal, &$data, $meta){
        if (!is_array($meta)) return;
        if (!empty($meta['calendar_event_id'])) $data['calendar_event_id'] = sanitize_text_field($meta['calendar_event_id']);
        if (!empty($meta['meet_space_name'])) $data['meet_space_name'] = sanitize_text_field($meta['meet_space_name']);
        if (!empty($meta['meet_code'])) $data['meet_code'] = sanitize_text_field($meta['meet_code']);
        if (!empty($meta['provider_meeting_id'])) $data['provider_meeting_id'] = sanitize_text_field((string)$meta['provider_meeting_id']);
        if (!empty($meta['provider_data'])) $data['provider_data'] = wp_json_encode($meta['provider_data']);
        if (!empty($meta['passcode'])) $data['passcode'] = sanitize_text_field($meta['passcode']);
    }

    public static function meet_save_tail($portal, $platform, $join_url, $room_note){
            if ($platform !== 'google_meet' || !$join_url) return $room_note ? ' '.$room_note : '';
            if ($room_note) return ' '.$room_note;
            return ' Recording starts when the class starts. Sync recordings adds the Drive file after Google finishes it.';
        }

    public static function session_save($portal){
        $portal->guard('uc_portal_session_save',['super_admin','coordinator','trainer']);
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        $do = sanitize_key($_POST['do'] ?? 'save');
        $existing = $id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d", $id)) : null;
        $batch_id = $existing ? (int)$existing->batch_id : absint($_POST['batch_id'] ?? 0);
        if (!in_array($batch_id, $portal->batch_ids(), true)) wp_die('That batch is not yours to schedule.',403);
        if ($do === 'delete') {
            if (!$portal->ops()) wp_die('Only Super Admin or a Coordinator can delete a class.',403);
            $scope = sanitize_key($_POST['edit_scope'] ?? 'single');
            $group = ($existing && !empty($existing->recurring_group)) ? (string)$existing->recurring_group : '';
            $ids_to = [$id];
            if ($group && in_array($scope, ['future','series'], true)) {
                $sql = "SELECT id FROM {$portal->t('sessions')} WHERE recurring_group=%s AND batch_id=%d";
                $params = [$group, (int)$existing->batch_id];
                if ($scope === 'future') { $sql .= ' AND session_date >= %s'; $params[] = $existing->session_date; }
                $found = $wpdb->get_col($wpdb->prepare($sql, ...$params));
                if ($found) $ids_to = array_map('intval', $found);
            }
            foreach ($ids_to as $sid) {
                $wpdb->delete($portal->t('attendance'), ['session_id'=>$sid]);
                $ok = $wpdb->delete($portal->t('sessions'), ['id'=>$sid]);
                if ($ok === false) $portal->db_fail('classes');
            }
            $n = count($ids_to);
            $portal->log_audit('class',$id,'delete','Deleted '.$n.' class'.($n===1?'':'es'));
            $portal->set_flash($n===1 ? 'Class deleted.' : $n.' classes deleted.');
            $portal->back('classes');
        }

        $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        $date = $portal->ymd($_POST['session_date'] ?? '');
        $start = sanitize_text_field($_POST['start_time'] ?? '');
        if ($date === null) { $portal->set_flash('Choose a real class date.','warn'); $portal->back('classes'); }
        if (!$title || !$date || !$start) { $portal->set_flash('Enter a title, date and start time.','warn'); $portal->back('classes'); }

        $platform = sanitize_key($_POST['platform'] ?? 'zoom');
        if (!in_array($platform, ['zoom','google_meet','teams','meet','zoho','zoho_meeting','offline'], true)) $platform = 'zoom';
        if ($platform === 'meet') $platform = 'google_meet';
        if ($platform === 'zoho_meeting') $platform = 'zoho';
        $raw = trim((string)wp_unslash($_POST['join_url'] ?? ''));
        $join_url = $raw === '' ? '' : esc_url_raw($raw);
        if ($raw !== '' && !$join_url) $join_url = esc_url_raw('https://'.$raw);
        $batch = $wpdb->get_row($wpdb->prepare("SELECT zoom_join_url,end_date,timezone FROM {$portal->t('batches')} WHERE id=%d", $batch_id));
        // Batch-level Zoom rooms remain supported; other providers get a unique room per class.
        if (!$join_url && $platform === 'zoom' && $batch && $batch->zoom_join_url) $join_url = $batch->zoom_join_url;
        $tz = $portal->valid_tz(sanitize_text_field($_POST['timezone'] ?? '') ?: ($batch->timezone ?? 'Asia/Kolkata'));
        if ($tz) $wpdb->update($portal->t('batches'), ['timezone'=>$tz], ['id'=>$batch_id]);
        $end_time = sanitize_text_field($_POST['end_time'] ?? '');
        $passcode = sanitize_text_field(wp_unslash($_POST['passcode'] ?? ''));

        $repeat = array_values(array_unique(array_intersect(array_map('sanitize_text_field',(array)($_POST['repeat_days'] ?? [])), ['1','2','3','4','5','6','7'])));
        $until = sanitize_text_field($_POST['repeat_until'] ?? '') ?: (string)($batch->end_date ?? '');
        $extra_dates = [];
        foreach (preg_split('/[\s,;]+/', (string)wp_unslash($_POST['extra_dates'] ?? '')) as $raw_day) {
            $raw_day = trim($raw_day);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw_day) && $raw_day !== $date) $extra_dates[$raw_day] = $raw_day;
        }
        $extra_dates = array_values($extra_dates);
        $new_group = (!$id && (($repeat && $until && $until > $date) || $extra_dates)) ? wp_generate_uuid4() : '';
        $data = [
            'batch_id'=>$batch_id, 'title'=>$title, 'session_date'=>$date, 'start_time'=>$start,
            'end_time'=>$end_time ?: null, 'platform'=>$platform, 'join_url'=>$join_url,
            'passcode'=>$passcode, 'status'=>sanitize_key($_POST['status'] ?? 'scheduled'),
            'updated_at'=>current_time('mysql'),
        ];
        if ($new_group) {
            $data['recurring_group'] = $new_group;
            $data['recurring_days'] = implode(',', $repeat);
            $data['recurring_until'] = $until;
        }
        if (isset($_POST['recording_url']) && $_POST['recording_url'] !== '') {
            $ru = esc_url_raw(wp_unslash($_POST['recording_url']));
            $data['recording_url'] = $ru;
            if ($ru && $portal->embed($ru) !== '') $data['recording_status'] = 'available';
        }
        if ($portal->role()==='trainer') $data['trainer_user_id'] = get_current_user_id();

        $zoom_id = ($existing && !empty($existing->zoom_meeting_id)) ? (string)$existing->zoom_meeting_id : '';
        $start_url = ($existing && !empty($existing->zoom_start_url)) ? (string)$existing->zoom_start_url : '';
        $meta = [];
        $room_note = '';
        if (!$id && $platform !== 'offline') {
            if ($platform === 'zoom') {
                $room_note = $portal->fill_class_zoom($join_url, $passcode, $zoom_id, $title, $date, $start, $end_time, $tz, $platform, $batch_id, $start_url);
            } else {
                $room_note = $portal->ensure_room_link($join_url, $platform, $title, $date, $start, $end_time, $tz, $meta);
            }
        }
        $data['join_url'] = $join_url;
        if ($zoom_id) $data['zoom_meeting_id'] = $zoom_id;
        if ($start_url) $data['zoom_start_url'] = $start_url;
        if ($meta) $portal->apply_meet_meta($data, $meta);

        if ($id && $existing) {
            $scope = sanitize_key($_POST['edit_scope'] ?? 'single');
            $group = !empty($existing->recurring_group) ? (string)$existing->recurring_group : '';
            $targets = [$existing];
            if ($group && in_array($scope, ['future','series'], true)) {
                $sql = "SELECT * FROM {$portal->t('sessions')} WHERE recurring_group=%s AND batch_id=%d";
                $params = [$group, $batch_id];
                if ($scope === 'future') { $sql .= ' AND session_date >= %s'; $params[] = $existing->session_date; }
                $sql .= ' ORDER BY session_date ASC,id ASC';
                $targets = $wpdb->get_results($wpdb->prepare($sql, ...$params));
            } elseif ($group && $scope === 'single') {
                $data['recurring_group'] = null;
                $data['recurring_days'] = null;
                $data['recurring_until'] = null;
            }
            $date_shift = 0;
            if ($group && $scope !== 'single' && $date !== $existing->session_date) {
                $date_shift = (int)round((strtotime($date)-strtotime($existing->session_date))/DAY_IN_SECONDS);
            }
            $target_ids = array_values(array_filter(array_map(function($target){ return (int)$target->id; }, (array)$targets)));
            $target_id_sql = $target_ids ? implode(',', $target_ids) : (string)$id;
            $user_changed_link = ($raw !== '' && $raw !== (string)$existing->join_url);
            $updated = 0; $provider_errors = []; $conflicts = [];
            foreach ((array)$targets as $target) {
                $row = $data;
                $target_date = $target->session_date;
                if ($date_shift) $target_date = date('Y-m-d', strtotime(($date_shift > 0 ? '+' : '').$date_shift.' days', strtotime($target_date)));
                $row['session_date'] = $target_date;
                // Exclude every row in this edit operation. Otherwise shifting a whole series
                // collides with the original dates of sessions that are moving in the same update.
                $conflict_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$portal->t('sessions')} WHERE batch_id=%d AND session_date=%s AND start_time=%s AND id NOT IN ({$target_id_sql}) LIMIT 1", $batch_id, $target_date, $start));
                if ($conflict_id) { $conflicts[] = $target_date.' at '.substr((string)$start,0,5); continue; }
                $schedule_changed = ($target_date !== $target->session_date || substr((string)$target->start_time,0,5) !== substr($start,0,5) || substr((string)($target->end_time ?? ''),0,5) !== substr($end_time,0,5) || (string)$target->platform !== $platform || (string)$target->title !== $title || empty($target->join_url));
                if (!$user_changed_link) {
                    $row['join_url'] = (string)$target->join_url;
                    $row['passcode'] = (string)$target->passcode;
                    foreach (['zoom_meeting_id','zoom_start_url','calendar_event_id','meet_space_name','meet_code','provider_meeting_id','provider_data'] as $field) {
                        if (isset($target->$field) && $target->$field !== '') $row[$field] = $target->$field;
                    }
                }
                if ((string)$target->platform !== $platform) {
                    foreach (['zoom_meeting_id','zoom_start_url','calendar_event_id','meet_space_name','meet_code','provider_meeting_id','provider_data'] as $field) $row[$field] = null;
                }
                if ($schedule_changed && !$user_changed_link) {
                    $row_meta = [];
                    if ($platform === 'zoom') {
                        // Updating an existing class ID also updates its Zoom date/time. If it is a shared batch room, keep that link.
                        if (!empty($target->zoom_meeting_id)) {
                            $row_zoom=''; $row_pass=(string)$target->passcode; $row_zoom_id=(string)$target->zoom_meeting_id; $row_start=(string)$target->zoom_start_url;
                            $note = $portal->fill_class_zoom($row_zoom,$row_pass,$row_zoom_id,$title,$target_date,$start,$end_time,$tz,$platform,$batch_id,$row_start);
                            if ($row_zoom) { $row['join_url']=$row_zoom; $row['passcode']=$row_pass; $row['zoom_meeting_id']=$row_zoom_id; $row['zoom_start_url']=$row_start; }
                            elseif ($note && $note !== 'missing') $provider_errors[]='Class '.$target_date.': '.$note;
                        } elseif ($batch && !empty($batch->zoom_join_url) && strpos((string)$target->join_url, (string)$batch->zoom_join_url) === 0) {
                            $row['join_url'] = (string)$batch->zoom_join_url;
                        } else {
                            $row['join_url']=''; $row_pass=''; $row_zoom_id=''; $row_start='';
                            $note = $portal->fill_class_zoom($row['join_url'],$row_pass,$row_zoom_id,$title,$target_date,$start,$end_time,$tz,$platform,$batch_id,$row_start);
                            if ($row['join_url']) { $row['passcode']=$row_pass; $row['zoom_meeting_id']=$row_zoom_id; $row['zoom_start_url']=$row_start; }
                            elseif ($note && $note !== 'missing') $provider_errors[]='Class '.$target_date.': '.$note;
                        }
                    } elseif ($platform === 'google_meet' && $target->platform === 'google_meet' && !empty($target->calendar_event_id)) {
                        $made = UC_LMS_Meeting_Google::google_update_meet_event($target->calendar_event_id,$title,$target_date,$start,$end_time,$tz);
                        if (!is_wp_error($made) && !empty($made['join_url'])) { $row['join_url']=$made['join_url']; $portal->apply_meet_meta($row,$made); }
                        else { $row['join_url']=''; $note=$portal->ensure_room_link($row['join_url'],$platform,$title,$target_date,$start,$end_time,$tz,$row_meta); if(!$row['join_url'] && $note)$provider_errors[]='Class '.$target_date.': '.$note; }
                    } elseif ($platform === 'teams' && $target->platform === 'teams' && !empty($target->calendar_event_id)) {
                        $made = UC_LMS_Meeting_Teams::teams_update_meeting($target->calendar_event_id,(string)$target->join_url,$title,$target_date,$start,$end_time,$tz);
                        if (!is_wp_error($made) && !empty($made['join_url'])) { $row['join_url']=$made['join_url']; $portal->apply_meet_meta($row,$made); }
                        else { $row['join_url']=''; $note=$portal->ensure_room_link($row['join_url'],$platform,$title,$target_date,$start,$end_time,$tz,$row_meta); if(!$row['join_url'] && $note)$provider_errors[]='Class '.$target_date.': '.$note; }
                    } elseif ($platform === 'zoho' && $target->platform === 'zoho' && !empty($target->provider_meeting_id)) {
                        $made = UC_LMS_Meeting_Zoho::update_meeting($target->provider_meeting_id,$title,$target_date,$start,$end_time,$tz);
                        if (!is_wp_error($made) && !empty($made['join_url'])) { $row['join_url']=$made['join_url']; $portal->apply_meet_meta($row,$made); }
                        else { $row['join_url']=''; $note=$portal->ensure_room_link($row['join_url'],$platform,$title,$target_date,$start,$end_time,$tz,$row_meta); if(!$row['join_url'] && $note)$provider_errors[]='Class '.$target_date.': '.$note; }
                    } else {
                        // Provider changes use a fresh per-class meeting URL.
                        $row['join_url']=''; $row['passcode']=''; $row['provider_meeting_id']=''; $row['provider_data']=null;
                        $note = $portal->ensure_room_link($row['join_url'],$platform,$title,$target_date,$start,$end_time,$tz,$row_meta);
                        if ($row['join_url']) $portal->apply_meet_meta($row,$row_meta);
                        elseif ($note) $provider_errors[]='Class '.$target_date.': '.$note;
                    }
                }
                if ($user_changed_link) {
                    $row['join_url'] = $join_url;
                    foreach (['zoom_meeting_id','zoom_start_url','calendar_event_id','meet_space_name','meet_code','provider_meeting_id','provider_data'] as $field) $row[$field] = null;
                }
                if ($target->id === $id && $group && $scope === 'single') {
                    $row['recurring_group'] = null; $row['recurring_days'] = null; $row['recurring_until'] = null;
                }
                $ok = $wpdb->update($portal->t('sessions'), $row, ['id'=>(int)$target->id]);
                if ($ok !== false) $updated++;
            }
            if ($updated === 0 && !$conflicts) $portal->db_fail('classes');
            if ($updated > 0) $portal->log_audit('class',$id,'update','Updated '.$updated.' class session(s) '.$title);
            $msg = $updated === 1 ? 'Class updated.' : ($updated > 1 ? $updated.' classes in the recurring schedule updated.' : 'No sessions were updated.');
            if ($conflicts) $msg .= ' Skipped schedule conflicts: '.implode(', ', array_slice($conflicts,0,4)).'. Choose another date or time.';
            if ($scope === 'single' && $group) $msg .= ' This class is now independent from the series.';
            if ($provider_errors) $msg .= ' Some meeting links need attention: '.implode(' ', array_slice($provider_errors,0,2));
            $portal->set_flash($msg, $provider_errors ? 'warn' : 'ok');
        } else {
            $data['hidden'] = 0;
            $data['created_at'] = current_time('mysql');
            $ok = $portal->insert_row('sessions', $data);
            if (!$ok) $portal->db_fail('classes');
            $n = 1;
            $portal->log_audit('class',(int)$wpdb->insert_id,'create','Scheduled '.$title.' on '.$date.' '.$start);
            if ($new_group) {
                $map = ['0'=>'1','1'=>'2','2'=>'3','3'=>'4','4'=>'5','5'=>'6','6'=>'7'];
                $cursor = strtotime($date.' +1 day');
                $stop = strtotime($until);
                $safety = 0;
                while ($cursor && $cursor <= $stop && $safety < 370) {
                    $safety++;
                    $ucd = $map[date('w',$cursor)] ?? '';
                    if (in_array($ucd, $repeat, true)) {
                        $row = $data;
                        $row['session_date'] = date('Y-m-d', $cursor);
                        $row['created_at'] = current_time('mysql');
                        $row['updated_at'] = current_time('mysql');
                        $row['join_url'] = '';
                        $row['passcode'] = '';
                        unset($row['zoom_meeting_id'], $row['zoom_start_url'], $row['calendar_event_id'], $row['meet_space_name'], $row['meet_code'], $row['provider_meeting_id'], $row['provider_data']);
                        $row_meta = [];
                        if ($platform === 'zoom') {
                            // Preserve a batch-level shared Zoom room; otherwise create one per occurrence.
                            if ($batch && !empty($batch->zoom_join_url)) $row['join_url'] = esc_url_raw($batch->zoom_join_url);
                            else {
                                $rurl=''; $rpass=''; $rid=''; $rstart='';
                                $note = $portal->fill_class_zoom($rurl,$rpass,$rid,$title,$row['session_date'],$start,$end_time,$tz,$platform,$batch_id,$rstart);
                                if ($rurl) { $row['join_url']=$rurl; $row['passcode']=$rpass; if($rid)$row['zoom_meeting_id']=$rid; if($rstart)$row['zoom_start_url']=$rstart; }
                            }
                        } else {
                            $rurl='';
                            $note = $portal->ensure_room_link($rurl,$platform,$title,$row['session_date'],$start,$end_time,$tz,$row_meta);
                            if ($rurl) { $row['join_url']=$rurl; $portal->apply_meet_meta($row,$row_meta); }
                        }
                        if ($portal->insert_row('sessions', $row)) $n++;
                    }
                    $cursor = strtotime('+1 day', $cursor);
                }
                foreach ($extra_dates as $extra_day) {
                    if ($extra_day <= $date) continue;
                    $row = $data;
                    $row['session_date'] = $extra_day;
                    $row['created_at'] = current_time('mysql');
                    $row['updated_at'] = current_time('mysql');
                    $row['join_url'] = '';
                    $row['passcode'] = '';
                    unset($row['zoom_meeting_id'], $row['zoom_start_url'], $row['calendar_event_id'], $row['meet_space_name'], $row['meet_code'], $row['provider_meeting_id'], $row['provider_data']);
                    $row_meta = [];
                    if ($platform === 'zoom') {
                        if ($batch && !empty($batch->zoom_join_url)) $row['join_url'] = esc_url_raw($batch->zoom_join_url);
                        else {
                            $rurl=''; $rpass=''; $rid=''; $rstart='';
                            $portal->fill_class_zoom($rurl,$rpass,$rid,$title,$row['session_date'],$start,$end_time,$tz,$platform,$batch_id,$rstart);
                            if ($rurl) { $row['join_url']=$rurl; $row['passcode']=$rpass; if($rid)$row['zoom_meeting_id']=$rid; if($rstart)$row['zoom_start_url']=$rstart; }
                        }
                    } else {
                        $rurl='';
                        $portal->ensure_room_link($rurl,$platform,$title,$row['session_date'],$start,$end_time,$tz,$row_meta);
                        if ($rurl) { $row['join_url']=$rurl; $portal->apply_meet_meta($row,$row_meta); }
                    }
                    if ($portal->insert_row('sessions', $row)) $n++;
                }
            }
            $base = $n === 1 ? 'Class scheduled.' : $n.' classes scheduled.'.($until ? ' Repeat through '.$until.'.' : '');
            if ($platform !== 'zoom' && !$join_url) $base .= $room_note ? ' '.$room_note : ' The meeting provider did not return a link; use Generate link after connecting the provider.';
            $portal->set_flash($base, ($platform !== 'zoom' && !$join_url) ? 'warn' : 'ok');
        }
        $portal->back('classes');
    }

    public static function generate_link($portal){
            $portal->guard('uc_portal_generate_link', ['super_admin','coordinator','trainer']);
            global $wpdb;
            $id = absint($_POST['session_id'] ?? 0);
            $s = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.timezone FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.id=%d", $id));
            if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) wp_die('That class is not yours.', 403);
            if (!empty($s->join_url)) { $portal->set_flash('This class already has a meeting link.'); $portal->back('classes'); }
            $platform = strtolower((string)($s->platform ?: ''));
            if ($platform === 'meet' || $platform === 'google meet') $platform = 'google_meet';
            if (in_array($platform, ['microsoft_teams','ms_teams'], true)) $platform = 'teams';
            $join = '';
            $meta = [];
            $note = $portal->ensure_room_link($join, $platform, $s->title, $s->session_date, substr((string)$s->start_time, 0, 5), $s->end_time ? substr((string)$s->end_time, 0, 5) : '', $portal->valid_tz((string)($s->timezone ?: 'Asia/Kolkata')), $meta);
            if ($join) {
                $row = ['join_url'=>$join, 'updated_at'=>current_time('mysql')];
                $portal->apply_meet_meta($row, $meta);
                $ok = $portal->update_row('sessions', $row, ['id'=>$id]);
                if ($ok === false) $portal->db_fail('classes');
                $portal->log_audit('class', $id, 'link', 'Generated meeting link');
                $portal->set_flash('Meeting link created.'.($note ? ' '.$note : ($platform === 'google_meet' ? ' Recording starts when the class starts. Sync recordings adds the Drive file after Google finishes it.' : '')));
            } else {
                $portal->set_flash($note ?: 'Link was not created.', 'warn');
            }
            $portal->back('classes');
        }

    public static function meet_notes($portal){
            $portal->guard('uc_portal_meet_notes',['super_admin','coordinator','trainer']);
            $id = absint($_POST['session_id'] ?? 0);
            global $wpdb;
            $row = $id ? $wpdb->get_row($wpdb->prepare("SELECT id, batch_id FROM {$portal->t('sessions')} WHERE id=%d AND hidden=0", $id)) : null;
            if (!$row || !in_array((int)$row->batch_id, $portal->batch_ids(), true)) {
                $portal->set_flash('That class is not in your batches.', 'warn');
                wp_safe_redirect(home_url('/lms-class/'.$id.'/'));
                exit;
            }
            $n = 0;
            $err = '';
            if (class_exists('UC_Academy_LMS') && $id) {
                $got = UC_Academy_LMS::instance()->portal_sync_meet_notes($id);
                if (is_wp_error($got)) $err = $got->get_error_message();
                else $n = (int)$got;
            }
            if ($err !== '') $portal->set_flash($err, 'warn');
            elseif ($n > 0) $portal->set_flash('Google Meet notes are in the summary. Publish them when students should see them.', 'ok');
            else $portal->set_flash('No Meet notes doc was found for this class. In the Meet call, turn on Take notes for me, then sync again after Google saves the Doc.', 'warn');
            wp_safe_redirect(home_url('/lms-class/'.$id.'/'));
            exit;
        }

    public static function attendance_toggle($portal){
        $portal->guard('uc_portal_attendance_toggle',['super_admin','coordinator','trainer']);
        global $wpdb;
        $sid = absint($_POST['session_id'] ?? 0); $uid = absint($_POST['user_id'] ?? 0); $batch = absint($_POST['batch'] ?? 0);
        if (!in_array($batch, $portal->batch_ids(), true)) wp_die('That batch is not yours.',403);
        $s = $wpdb->get_row($wpdb->prepare("SELECT id,batch_id FROM {$portal->t('sessions')} WHERE id=%d", $sid));
        if (!$s || (int)$s->batch_id !== $batch) wp_die('That class is not in this batch.',403);
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('attendance')} WHERE session_id=%d AND user_id=%d", $sid, $uid));
        if ($existing) $wpdb->update($portal->t('attendance'), ['status'=>$existing->status==='present'?'absent':'present','source'=>'manual'], ['id'=>$existing->id]);
        else $wpdb->insert($portal->t('attendance'), ['session_id'=>$sid,'batch_id'=>$batch,'user_id'=>$uid,'status'=>'present','minutes'=>0,'source'=>'manual','joined_at'=>current_time('mysql'),'last_seen_at'=>current_time('mysql')]);
        $view = sanitize_key($_POST['view'] ?? '');
        $args = ['batch'=>$batch];
        if ($view) $args['view'] = $view;
        if ($view === 'class') $args['session'] = $sid;
        $portal->back('reports', $args);
    }

    public static function att_csv($portal){
        if (!is_user_logged_in() || !$portal->staff()) wp_die('Not allowed',403);
        check_admin_referer('uc_portal_att_csv');
        $b = absint($_GET['batch'] ?? 0); if (!in_array($b,$portal->batch_ids(),true)) wp_die('Not your batch',403);
        list($sess,$roster,$map) = $portal->att_data($b);
        $q = function($v){ $v=(string)$v; if ($v!=='' && strpos('=+-@',$v[0])!==false) $v="'".$v; return '"'.str_replace('"','""',$v).'"'; };
        header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="attendance-batch-'.$b.'.csv"');
        $h = ['Student','Email']; foreach ($sess as $s) $h[] = $s->session_date.' '.$s->title; $h[]='Present'; $h[]='Percent';
        echo implode(',',array_map($q,$h))."\n";
        foreach ($roster as $st) { $row=[$st->display_name,$st->user_email]; $p=0; foreach ($sess as $s){ $a=$map[$st->ID][$s->id]??null; $ok=$a&&$a->status==='present'; if($ok)$p++; $row[]=($ok?'Present':'Absent').' ('.($a?(int)$a->minutes:0).'m)'; } $row[]=$p; $row[]=$sess?round($p*100/count($sess)).'%':'0%'; echo implode(',',array_map($q,$row))."\n"; }
        exit;
    }

}
