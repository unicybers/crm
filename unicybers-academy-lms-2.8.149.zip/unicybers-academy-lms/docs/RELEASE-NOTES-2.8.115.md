# UniCybers Academy LMS 2.8.115

## Sidebar logo correction

- Uses only the configured original master logo URL: `https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp`.
- Displays the complete original horizontal image at its natural 2:1 aspect ratio, scaled to 112 × 56 CSS pixels within the 132 pixel sidebar rail.
- Removes the previous square crop and oversized image positioning.
- Replaces the old tagline visually with `ACADEMY` in UniCybers orange.
- The `ACADEMY` line is positioned to match the width of the `UNICYBERS` wordmark in the original image.
- No database migration or data changes.

## Validation

PHP and JavaScript syntax checks and ZIP integrity checks are required before deployment. Live visual verification is still required after installation and cache purge.
