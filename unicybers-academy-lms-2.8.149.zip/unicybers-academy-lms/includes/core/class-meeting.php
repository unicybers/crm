<?php
/**
 * UniCybers Academy LMS: Multi-Platform Meeting Manager & Facade.
 *
 * Coordinates Zoom, Google Meet, and Microsoft Teams providers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Meeting {
    public static function instance() {
        static $i = null;
        if (!$i) $i = new self();
        return $i;
    }

    public function can_manage() {
        return current_user_can('manage_options') || current_user_can('uc_coordinator');
    }

    public function table($name) {
        global $wpdb;
        return $wpdb->prefix . 'uc_' . $name;
    }

    public function now() {
        return current_time('mysql');
    }

    public function redirect($url, $msg = '', $err = false) {
        if ($msg !== '') {
            $this->notice($msg, $err);
        }
        wp_safe_redirect($url);
        exit;
    }

    public function notice($msg, $err = false) {
        $key = $err ? 'uc_meet_error' : 'uc_meet_notice';
        set_transient($key . '_' . get_current_user_id(), $msg, 60);
    }

    public function ensure_meet_session_columns() {
        global $wpdb;
        $ts = $this->table('sessions');
        $cols = $wpdb->get_col("DESCRIBE `$ts`", 0);
        if (!in_array('calendar_event_id', $cols, true)) $wpdb->query("ALTER TABLE `$ts` ADD calendar_event_id varchar(190) NULL AFTER room_link");
        if (!in_array('meet_space_name', $cols, true)) $wpdb->query("ALTER TABLE `$ts` ADD meet_space_name varchar(190) NULL AFTER calendar_event_id");
        if (!in_array('meet_code', $cols, true)) $wpdb->query("ALTER TABLE `$ts` ADD meet_code varchar(40) NULL AFTER meet_space_name");
        if (!in_array('recording_notes', $cols, true)) $wpdb->query("ALTER TABLE `$ts` ADD recording_notes text NULL AFTER recording_url");
    }

    public function normalize_host($email) {
        return strtolower(trim((string)$email));
    }

    public function portal_create_room($platform, $title, $date, $start, $end, $tz) {
        // New providers register a small callable through this filter; no framework or eager provider loading required.
        $providers = apply_filters('uc_lms_meeting_provider_registry', [
            'zoom'        => ['UC_LMS_Meeting', 'zoom_create_meeting_provider'],
            'google_meet' => ['UC_LMS_Meeting_Google', 'google_create_meet'],
            'teams'       => ['UC_LMS_Meeting_Teams', 'teams_create_meeting'],
            'zoho'        => ['UC_LMS_Meeting_Zoho', 'create_meeting'],
        ]);
        if (!isset($providers[$platform])) return new WP_Error('meeting_provider', 'This meeting provider is not configured.');
        $handler = $providers[$platform];
        if (is_callable($handler)) return call_user_func($handler, $title, $date, $start, $end, $tz);
        if (is_array($handler) && count($handler) === 2 && class_exists($handler[0]) && is_callable($handler)) return call_user_func($handler, $title, $date, $start, $end, $tz);
        return new WP_Error('meeting_provider', 'The configured meeting provider is unavailable.');
    }


    public static function zoom_create_meeting_provider($title, $date, $start, $end, $tz) {
        if (!class_exists('UC_LMS_Zoom')) return new WP_Error('zoom_missing', 'The existing Zoom integration is unavailable.');
        return UC_LMS_Zoom::portal_class_zoom([
            'title' => $title,
            'session_date' => $date,
            'start_time' => $start,
            'end_time' => $end,
            'timezone' => $tz,
            'zoom_meeting_id' => '',
        ]);
    }

    public function zoom_token() { return UC_LMS_Zoom::token(); }
    public function zoom_request($method, $path, $body = null) { return UC_LMS_Zoom::request($method, $path, $body); }
    public function zoom_classroom_settings($title, $start, $dur, $tz, $hosts = []) { return UC_LMS_Zoom::classroom_settings($title, $start, $dur, $tz, $hosts); }
    public function zoom_update_meeting($meeting_id, $data) { return UC_LMS_Zoom::update_batch_meeting($meeting_id, $data); }
    public function zoom_create_meeting($data) { return UC_LMS_Zoom::create_batch_meeting($data); }

    public function session_tz_name($s) { return UC_LMS_Zoom::session_tz_name($s); }
    public function session_labels($s) { return UC_LMS_Zoom::session_labels($s); }
    public function session_start_ts($s) { return UC_LMS_Zoom::session_start_ts($s); }
    public function recording_matches($r, $s) { return UC_LMS_Zoom::recording_matches($r, $s); }
    public function store_session_recording($session, $rec, $source = 'zoom') { return UC_LMS_Zoom::store_session_recording($session, $rec, $source); }

    // Google Provider Delegations
    public function google_connect() { UC_LMS_Meeting_Google::google_connect(); }
    public function google_oauth() { UC_LMS_Meeting_Google::google_oauth(); }
    public function google_access_token() { return UC_LMS_Meeting_Google::google_access_token(); }
    public function portal_google_token() { return UC_LMS_Meeting_Google::portal_google_token(); }
    public function google_create_meet($title, $date, $start, $end, $tz) { return UC_LMS_Meeting_Google::google_create_meet($title, $date, $start, $end, $tz); }
    public function meet_code_from_url($url) { return UC_LMS_Meeting_Google::meet_code_from_url($url); }
    public function meet_set_auto_record($token, $space_name) { return UC_LMS_Meeting_Google::meet_set_auto_record($token, $space_name); }
    public function meet_link_from_event($event) { return UC_LMS_Meeting_Google::meet_link_from_event($event); }
    public function google_calendar_call($token, $path, $method = 'GET', $body = null) { return UC_LMS_Meeting_Google::google_calendar_call($token, $path, $method, $body); }
    public function meet_arm_upcoming($hours = 3) { return UC_LMS_Meeting_Google::meet_arm_upcoming($hours); }
    public function keep_google_secret($posted) { UC_LMS_Meeting_Google::keep_google_secret($posted); }

    // Drive Provider Delegations
    public function portal_sync_meet_folder() { $used = []; return UC_LMS_Meeting_Drive::portal_sync_meet_folder($used); }
    public function portal_sync_meet_notes() { return UC_LMS_Meeting_Drive_Notes::portal_sync_meet_notes(); }
    public function drive_folder_docs($token, $folder_id, $q = '') { return UC_LMS_Meeting_Drive_Notes::drive_folder_docs($token, $folder_id, $q); }
    public function drive_search_note_docs($token, $title = '', $day = '') { return UC_LMS_Meeting_Drive_Notes::drive_search_note_docs($token, $title, $day); }
    public function drive_export_text($token, $file_id) { return UC_LMS_Meeting_Drive_Notes::drive_export_text($token, $file_id); }
    public function match_meet_note_to_session($doc, $sessions) { return UC_LMS_Meeting_Drive_Notes::match_meet_note_to_session($doc, $sessions); }
    public function save_meet_note($session, $doc, $text) { return UC_LMS_Meeting_Drive_Notes::save_meet_note($session, $doc, $text); }
    public function drive_folder_videos($token, $folder_id) { return UC_LMS_Meeting_Drive::drive_folder_videos($token, $folder_id); }
    public function match_meet_file_to_session($file, $sessions) { return UC_LMS_Meeting_Drive::match_meet_file_to_session($file, $sessions); }
    public function meet_file_day($file) { return UC_LMS_Meeting_Drive::meet_file_day($file); }
    public function meet_name_tokens($s) { return UC_LMS_Meeting_Drive::meet_name_tokens($s); }
    public function meet_token_overlap($a, $b) { return UC_LMS_Meeting_Drive::meet_token_overlap($a, $b); }
    public function meet_code_from_session($s) { return UC_LMS_Meeting_Drive::meet_code_from_session($s); }
    public function portal_sync_meet_recording($s, $file_id = '') { return UC_LMS_Meeting_Drive::portal_sync_meet_recording($s, $file_id); }
    public function meet_recording_from_api($token, $s) { return UC_LMS_Meeting_Drive::meet_recording_from_api($token, $s); }
    public function drive_id_from_meet_destination($dest) { return UC_LMS_Meeting_Drive::drive_id_from_meet_destination($dest); }
    public function meet_recording_from_drive($token, $s) { return UC_LMS_Meeting_Drive::meet_recording_from_drive($token, $s); }

    // Teams Provider Delegations
    public function teams_create_meeting($title, $date, $start, $end, $tz) { return UC_LMS_Meeting_Teams::teams_create_meeting($title, $date, $start, $end, $tz); }
    public function teams_update_meeting($meeting_id, $join_url, $title, $date, $start, $end, $tz) { return UC_LMS_Meeting_Teams::teams_update_meeting($meeting_id, $join_url, $title, $date, $start, $end, $tz); }
    public function google_update_meet_event($event_id, $title, $date, $start, $end, $tz) { return UC_LMS_Meeting_Google::google_update_meet_event($event_id, $title, $date, $start, $end, $tz); }
    public function zoho_create_meeting($title, $date, $start, $end, $tz) { return UC_LMS_Meeting_Zoho::create_meeting($title, $date, $start, $end, $tz); }
    public function zoho_sync_recordings() { return UC_LMS_Meeting_Zoho::sync_recordings(); }
    public function keep_ms_secret($posted) { UC_LMS_Meeting_Teams::keep_ms_secret($posted); }
}
