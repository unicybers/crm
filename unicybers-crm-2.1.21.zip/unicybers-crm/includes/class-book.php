<?php
if (!defined('ABSPATH')) exit;

/**
 * One JSON document per logical CRM module in the WordPress database.
 * The legacy row layout is retained internally for backward compatibility
 * while the frontend and business workflows move to native CRM terminology.
 */
class UC_CRM_Sheet {
    public $name;
    public $headers = array();
    public $rows = array();
    public $dirty = false;

    public function __construct($name, $headers, $rows) {
        $this->name = $name;
        $this->headers = array_values($headers);
        $this->rows = array();
        foreach ($rows as $row) {
            $this->rows[] = $this->pad(is_array($row) ? array_values($row) : array());
        }
    }

    public function last_row() {
        if (!$this->headers && !$this->rows) return 0;
        return 1 + count($this->rows);
    }

    public function last_col() {
        return count($this->headers);
    }

    public function pad($row) {
        $n = count($this->headers);
        $row = array_values($row);
        if (count($row) < $n) $row = array_pad($row, $n, '');
        if (count($row) > $n) $row = array_slice($row, 0, $n);
        return $row;
    }

    public function values() {
        $out = array($this->headers);
        foreach ($this->rows as $row) $out[] = $this->pad($row);
        return $out;
    }

    public function get($row, $col) {
        $row = (int) $row;
        $col = (int) $col;
        if ($row < 1 || $col < 1) return '';
        if ($row === 1) return isset($this->headers[$col - 1]) ? $this->headers[$col - 1] : '';
        $i = $row - 2;
        if (!isset($this->rows[$i])) return '';
        return isset($this->rows[$i][$col - 1]) ? $this->rows[$i][$col - 1] : '';
    }

    public function set($row, $col, $value) {
        $row = (int) $row;
        $col = (int) $col;
        if ($row < 1 || $col < 1) return;
        $this->ensure_col($col);
        if ($row === 1) {
            $this->headers[$col - 1] = $value;
            $this->dirty = true;
            return;
        }
        $i = $row - 2;
        while (count($this->rows) <= $i) $this->rows[] = $this->pad(array());
        $this->rows[$i][$col - 1] = $value;
        $this->dirty = true;
    }

    public function set_row($row, $values) {
        $row = (int) $row;
        $this->ensure_col(max(count($this->headers), count($values)));
        $values = $this->pad(array_values($values));
        if ($row === 1) {
            $this->headers = $values;
            $this->dirty = true;
            return;
        }
        $i = $row - 2;
        while (count($this->rows) <= $i) $this->rows[] = $this->pad(array());
        $this->rows[$i] = $values;
        $this->dirty = true;
    }

    public function append($values) {
        if (!$this->headers && $values) {
            $this->headers = array();
        }
        $width = max(count($this->headers), count($values));
        $this->ensure_col($width);
        $this->rows[] = $this->pad(array_values($values));
        $this->dirty = true;
        return $this->last_row();
    }

    public function delete_row($row) {
        $row = (int) $row;
        if ($row < 2) return;
        $i = $row - 2;
        if (!isset($this->rows[$i])) return;
        array_splice($this->rows, $i, 1);
        $this->dirty = true;
    }

    public function ensure_col($col) {
        $col = (int) $col;
        while (count($this->headers) < $col) $this->headers[] = '';
        foreach ($this->rows as $i => $row) $this->rows[$i] = $this->pad($row);
    }

    public function add_headers($names) {
        if (!$names) return;
        $start = count($this->headers) + 1;
        $this->ensure_col(count($this->headers) + count($names));
        $c = $start;
        foreach ($names as $name) {
            $this->headers[$c - 1] = $name;
            $c++;
        }
        $this->dirty = true;
    }
}

class UC_CRM_Book {
    private $table;
    private $cache = array();

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'uc_crm_sheet';
    }

    public static function activate() {
        global $wpdb;
        $table = $wpdb->prefix . 'uc_crm_sheet';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            name varchar(191) NOT NULL,
            body longtext NOT NULL,
            updated datetime NOT NULL,
            PRIMARY KEY (name)
        ) $charset;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function sheet($name) {
        $name = (string) $name;
        if (!isset($this->cache[$name])) $this->cache[$name] = $this->load($name);
        return $this->cache[$name];
    }

    public function has($name) {
        $sh = $this->sheet($name);
        return $sh->last_col() > 0 || $sh->last_row() > 0;
    }

    public function names() {
        global $wpdb;
        $rows = $wpdb->get_col("SELECT name FROM {$this->table} ORDER BY name");
        return $rows ? $rows : array();
    }

    private function load($name) {
        global $wpdb;
        $body = $wpdb->get_var($wpdb->prepare("SELECT body FROM {$this->table} WHERE name = %s", $name));
        if (!$body) return new UC_CRM_Sheet($name, array(), array());
        $data = json_decode($body, true);
        if (!is_array($data)) return new UC_CRM_Sheet($name, array(), array());
        return new UC_CRM_Sheet($name, isset($data['headers']) ? $data['headers'] : array(), isset($data['rows']) ? $data['rows'] : array());
    }

    public function flush() {
        global $wpdb;
        foreach ($this->cache as $name => $sheet) {
            if (!$sheet->dirty) continue;
            $body = wp_json_encode(array(
                'headers' => array_values($sheet->headers),
                'rows' => array_values($sheet->rows),
            ), JSON_UNESCAPED_UNICODE);
            $wpdb->replace($this->table, array(
                'name' => $name,
                'body' => $body,
                'updated' => current_time('mysql'),
            ), array('%s', '%s', '%s'));
            $sheet->dirty = false;
        }
    }

    public function replace_all($sheets) {
        global $wpdb;
        $wpdb->query("DELETE FROM {$this->table}");
        $this->cache = array();
        foreach ($sheets as $name => $sheet) {
            $headers = isset($sheet['headers']) ? $sheet['headers'] : array();
            $rows = isset($sheet['rows']) ? $sheet['rows'] : array();
            $obj = new UC_CRM_Sheet($name, $headers, $rows);
            $obj->dirty = true;
            $this->cache[$name] = $obj;
        }
        $this->flush();
    }

    public function counts() {
        $out = array();
        foreach ($this->names() as $name) {
            $sh = $this->sheet($name);
            $out[$name] = count($sh->rows);
        }
        ksort($out);
        return $out;
    }
}
