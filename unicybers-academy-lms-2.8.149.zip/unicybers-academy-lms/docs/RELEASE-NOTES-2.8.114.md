# UniCybers Academy LMS 2.8.114

## Sidebar brand sizing correction

- Replaced the oversized centered logo block with the compact horizontal sidebar lockup.
- Uses the exact supplied source URL: `https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp`.
- Displays the globe portion of that source image as a 36px emblem. The source file is not altered.
- Places `UNICYBERS` on the first line and `ACADEMY` on the second line, beside the emblem.
- Retains the established wordmark typography: white first line, orange `#FF6B1A` second line, equal text-block width.
- Keeps white-label tenant branding unchanged.
- No database schema or records are modified by this release.
