<?php
/**
 * Sample academy shown to the five client-preview seats.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Preview {
    public static function render($portal, $page){
        return self::bar($portal).self::page($portal, $page);
    }

    private static function bar($portal){
        $role = $portal->role();
        $labels = [
            'student' => 'Student',
            'trainer' => 'Trainer',
            'coordinator' => 'Coordinator',
            'hr' => 'Placement HR',
            'super_admin' => 'Super Admin',
        ];
        $o = '<form class="preview-switch" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $o .= '<input type="hidden" name="action" value="uc_portal_preview_role">'.wp_nonce_field('uc_portal_preview_role','_wpnonce',true,false);
        $o .= '<strong>View as</strong><select name="preview_role" aria-label="View as" onchange="this.form.submit()">';
        foreach ($labels as $id => $label) {
            $o .= '<option value="'.esc_attr($id).'"'.selected($role, $id, false).'>'.$portal->e($label).'</option>';
        }
        $o .= '</select><span class="hint">Sample only. This login cannot change UniCybers records.</span></form>';
        return $o;
    }

    private static function page($portal, $page){
        $note = '<p class="hint">Sample academy. These names, classes and scores are not UniCybers records.</p>';
        $role = $portal->role();
        if ($page === 'settings') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>Settings</h3></div></div><p>A live Super Admin saves Google, Zoom, roles and the academy brand here. This preview does not open those controls.</p></section>';
        }
        if ($page === 'people') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>People</h3></div></div><div class="req"><div><strong>Asha Rao</strong><small>Student · Sample batch · Active</small></div></div><div class="req"><div><strong>Ravi Menon</strong><small>Trainer · Sample batch</small></div></div></section>';
        }
        if ($page === 'batches') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>SOC Analyst · March</h3></div>'.$portal->pill('Active','ok').'</div><p>One sample batch. 24 learners. The live batch list is not loaded.</p></section>';
        }
        if ($page === 'announcements' || $page === 'messages') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>'.($page==='messages'?'Messages':'Announcements').'</h3></div></div><p>A sample note to the batch. Nothing here is sent.</p></section>';
        }
        if ($page === 'courses') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>SOC Analyst</h3></div>'.$portal->pill('Active','ok').'</div><p>A 12-week live batch. Labs, attendance and placement sit on this one course.</p></section>';
        }
        if ($page === 'classes') {
            return $note.'<div class="crows"><article class="crow"><div class="crow-top"><strong>Alert triage</strong>'.$portal->pill('Meet','info').'</div><p>Tomorrow, 7:00 PM. Sample room.</p></article><article class="crow"><div class="crow-top"><strong>SIEM lab</strong>'.$portal->pill('Finished','mut').'</div><p>Last Tuesday. Attendance recorded.</p></article></div>';
        }
        if ($page === 'practice') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>Mocks</h3></div></div><div class="req"><div><strong>SOC fundamentals</strong><small>Mock · 18 of 24 submitted</small></div>'.$portal->pill('Open','ok').'</div></section>';
        }
        if ($page === 'materials') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>This batch</h3></div></div><div class="req"><div><strong>SIEM lab notes</strong><small>PDF · Sample batch</small></div>'.$portal->pill('Available','ok').'</div><div class="req"><div><strong>Alert triage recording</strong><small>Meet · Sample</small></div>'.$portal->pill('Available','ok').'</div></section>';
        }
        if ($page === 'placement') {
            return $note.'<div class="kpis">'.$portal->kpi('Career IDs','24','Sample candidates','placement','orange').$portal->kpi('Ready','11','Pack complete','people','green').$portal->kpi('Placed','4','This batch','reports','violet').'</div><section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>A candidate</h3></div></div><p><strong>Asha Rao</strong> · UC-CR-1008 · Sample batch · Pack complete · Ready for a role.</p></section>';
        }
        if ($page === 'reports') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>Attendance</h3></div></div><p>Sample batch is at 86%. Unmarked stays unmarked. Absent is only a mark a trainer set.</p></section>';
        }
        if ($page === 'profile') {
            return $note.'<section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE</span><h3>Preview seat</h3></div></div><p>This login is one of five preview seats. Profile fields here are not a real student pack.</p></section>';
        }
        $seen = [
            'student' => 'You are seeing the student home: courses, classes, materials, practice and attendance.',
            'trainer' => 'You are seeing the trainer home: batches, classes, materials and reports. People and Settings stay off this menu.',
            'coordinator' => 'You are seeing the coordinator home: people, reports and the batch, without Settings.',
            'hr' => 'You are seeing Placement HR: the desk only, with a sample candidate.',
            'super_admin' => 'You are seeing the Super Admin menu, including Settings. The controls behind it stay with UniCybers.',
        ];
        $line = $seen[$role] ?? $seen['student'];
        return $note.'<div class="kpis">'.$portal->kpi('Next class','Tomorrow','Alert triage','classes','orange').$portal->kpi('Attendance','86%','Sample batch','reports','green').$portal->kpi('Ready','11','Placement pack','placement','blue').'</div><section class="panel"><div class="ph"><div><span class="eyebrow">SAMPLE BATCH</span><h3>SOC Analyst · March</h3></div></div><p>'.$portal->e($line).'</p></section>';
    }
}
