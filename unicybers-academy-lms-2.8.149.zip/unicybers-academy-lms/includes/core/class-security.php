<?php
/**
 * UniCybers Academy LMS: Account Security & Device Limits.
 *
 * Handles sign-in lockout, device binding limits, account disabling,
 * forced password updates, and public access requests.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Security {
    const COOKIE = 'uc_dev';
    const FAIL_MAX = 8;          // failed attempts
    const FAIL_WINDOW = 900;     // within 15 minutes
    const LOCK_SECONDS = 600;    // locks the email for 10 minutes
    const DEFAULT_LIMIT = 3;
    const OVERRIDE_LIMIT = 5;
    const MAIL_FROM = 'academy@unicybers.com';
    const MAIL_FROM_NAME = 'UniCybers Academy';
    const MAIL_CC = 'academy@unicybers.com';

    private static $inst;
    public static function instance() { return self::$inst ?: (self::$inst = new self()); }

    private function __construct() {
        add_filter('authenticate', [$this, 'check_lock'], 5, 3);
        add_filter('wp_authenticate_user', [$this, 'check_disabled'], 10, 2);
        add_filter('wp_authenticate_user', [$this, 'check_demo_gate'], 11, 2);
        add_filter('authenticate', [$this, 'check_device'], 99, 3);
        add_action('wp_login_failed', [$this, 'note_fail']);
        add_action('wp_login', [$this, 'on_login'], 10, 2);
        add_action('admin_post_nopriv_uc_access_request', [$this, 'access_request']);
        add_action('admin_post_uc_access_request', [$this, 'access_request']);
        add_filter('wp_mail_from', [$this, 'mail_from'], 9999);
        add_filter('wp_mail_from_name', [$this, 'mail_from_name'], 9999);
        add_action('phpmailer_init', [$this, 'phpmailer_init'], 9999);
        add_action('wp_mail_failed', [$this, 'mail_failed']);
    }

    public function mail_from($from) { return self::MAIL_FROM; }
    public function mail_from_name($name) { return self::MAIL_FROM_NAME; }
    public function phpmailer_init($phpmailer) {
        $phpmailer->From = self::MAIL_FROM;
        $phpmailer->FromName = self::MAIL_FROM_NAME;
        $phpmailer->Sender = self::MAIL_FROM;
        if (method_exists($phpmailer, 'ClearReplyTos')) $phpmailer->ClearReplyTos();
        if (method_exists($phpmailer, 'addReplyTo')) $phpmailer->addReplyTo(self::MAIL_FROM, self::MAIL_FROM_NAME);
    }
    public function mail_failed($error) {
        if (is_wp_error($error)) update_option('uc_last_mail_error', $error->get_error_message(), false);
    }
    public static function last_mail_error() {
        return (string) get_option('uc_last_mail_error', '');
    }
    public static function mail_headers($html = false, $extra_cc = []) {
        $headers = [
            'From: ' . self::MAIL_FROM_NAME . ' <' . self::MAIL_FROM . '>',
            'Reply-To: ' . self::MAIL_FROM,
        ];
        $cc = array_unique(array_filter((array)$extra_cc, 'is_email'));
        if ($cc) $headers[] = 'Cc: ' . implode(', ', $cc);
        $headers[] = $html ? 'Content-Type: text/html; charset=UTF-8' : 'Content-Type: text/plain; charset=UTF-8';
        return $headers;
    }
    public static function send_mail($to, $subject, $body, $html = false, $extra_cc = []) {
        $tos = array_filter(array_map('trim', (array)$to));
        $cc = array_values(array_filter((array)$extra_cc, 'is_email'));
        $academy_in_to = false;
        foreach ($tos as $addr) if (strcasecmp($addr, self::MAIL_CC) === 0) $academy_in_to = true;
        if (!$academy_in_to) array_unshift($cc, self::MAIL_CC);
        delete_option('uc_last_mail_error');
        return (bool) wp_mail($tos, $subject, $body, self::mail_headers($html, $cc));
    }

    private function t($n) { return UC_LMS_Database::table($n); }

    private function lock_key($email) { return 'uc_lock_' . md5(strtolower(trim((string)$email))); }
    private function fail_key($email) { return 'uc_fail_' . md5(strtolower(trim((string)$email))); }

    private function login_email($username) {
        $username = trim((string)$username);
        if (is_email($username)) return $username;
        $u = get_user_by('login', $username);
        return $u ? $u->user_email : $username;
    }

    public function check_lock($user, $username, $password) {
        if (!$username) return $user;
        if (get_transient($this->lock_key($this->login_email($username)))) {
            return new WP_Error('uc_locked', 'Too many attempts. Try again in about ten minutes.');
        }
        return $user;
    }

    public function note_fail($username) {
        $email = $this->login_email($username);
        $n = (int)get_transient($this->fail_key($email)) + 1;
        set_transient($this->fail_key($email), $n, self::FAIL_WINDOW);
        if ($n >= self::FAIL_MAX) set_transient($this->lock_key($email), 1, self::LOCK_SECONDS);
    }

    public function check_disabled($user, $password) {
        if ($user instanceof WP_User && get_user_meta($user->ID, 'uc_disabled', true)) {
            return new WP_Error('uc_disabled', 'This account is disabled. Contact support.');
        }
        if ($user instanceof WP_User && get_user_meta($user->ID, 'uc_archived', true)) {
            return new WP_Error('uc_archived', 'This account is archived. Ask the academy to restore it.');
        }
        return $user;
    }

    public function check_demo_gate($user, $password) {
        if (!$user instanceof WP_User) return $user;
        if (self::is_shared_demo($user)) {
            return new WP_Error('uc_demo_retired', 'Those shared demo seats are retired. Use the public demo link.');
        }
        if (self::is_demo($user) && self::demo_closed()) {
            return new WP_Error('uc_demo_closed', 'Demo access is closed.');
        }
        return $user;
    }

    public static function is_shared_demo($user) {
        $email = strtolower((string)($user->user_email ?? ''));
        return (bool)preg_match('/^demo\d{2}@unicybers\.com$/', $email);
    }

    public static function demo_closed() {
        if (get_option('uc_demo_open') !== '1') return true;
        $until = (int)get_option('uc_demo_until', 0);
        if (!$until || current_time('timestamp') >= $until) {
            update_option('uc_demo_open', '0', false);
            return true;
        }
        return false;
    }

    public static function is_demo($user) {
        if (self::is_shared_demo($user)) return true;
        return $user instanceof WP_User && get_user_meta($user->ID, 'uc_demo_guest', true) === '1';
    }

    public static function device_limit($uid) {
        return ((int)get_user_meta($uid, 'uc_device_limit', true) === self::OVERRIDE_LIMIT) ? self::OVERRIDE_LIMIT : self::DEFAULT_LIMIT;
    }

    /**
     * Fast batch lookup for user accounts at their device limit.
     * Replaces N+1 query loop on dashboard.
     */
    public static function accounts_at_device_limit_count() {
        global $wpdb;
        $t = UC_LMS_Database::table('devices');
        if (!UC_LMS_Database::has_table('devices')) return 0;

        $overrides = $wpdb->get_col("SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='uc_device_limit' AND meta_value='5'");
        $in_overrides = $overrides ? implode(',', array_map('intval', $overrides)) : '0';

        return (int)$wpdb->get_var("
            SELECT COUNT(*) FROM (
                SELECT user_id, COUNT(*) as cnt 
                FROM {$t} 
                GROUP BY user_id 
                HAVING (user_id IN ({$in_overrides}) AND cnt >= 5) 
                    OR (user_id NOT IN ({$in_overrides}) AND cnt >= 3)
            ) as over_limit
        ");
    }

    public static function device_id() {
        $id = isset($_COOKIE[self::COOKIE]) ? preg_replace('/[^a-z0-9]/', '', strtolower((string)$_COOKIE[self::COOKIE])) : '';
        if (strlen($id) < 16) {
            $id = strtolower(wp_generate_password(24, false, false));
            if (!headers_sent()) {
                setcookie(self::COOKIE, $id, [
                    'expires'  => time() + 5 * YEAR_IN_SECONDS,
                    'path'     => '/',
                    'secure'   => is_ssl(),
                    'httponly' => true,
                    'samesite' => 'Lax'
                ]);
            }
            $_COOKIE[self::COOKIE] = $id;
        }
        return $id;
    }

    private static function device_label() {
        $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
        $os = 'Browser';
        foreach (['Android'=>'Android phone','iPhone'=>'iPhone','iPad'=>'iPad','Windows'=>'Windows computer','Macintosh'=>'Mac','Linux'=>'Linux computer'] as $k=>$v) {
            if (stripos($ua, $k) !== false) { $os = $v; break; }
        }
        $br = '';
        foreach (['Edg/'=>'Edge','OPR/'=>'Opera','Chrome/'=>'Chrome','Firefox/'=>'Firefox','Safari/'=>'Safari'] as $k=>$v) {
            if (strpos($ua, $k) !== false) { $br = $v; break; }
        }
        return trim($os . ($br ? ' · ' . $br : ''));
    }

    public function check_device($user, $username, $password) {
        if (!($user instanceof WP_User)) return $user;
        if (user_can($user, 'manage_options') || self::is_demo($user)) return $user;
        global $wpdb;
        $t = $this->t('devices');
        if (!UC_LMS_Database::has_table('devices')) return $user;
        $dev = self::device_id();
        $now = current_time('mysql');
        $row = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$t} WHERE user_id=%d AND device_id=%s", $user->ID, $dev));
        if ($row) {
            $wpdb->update($t, ['last_seen' => $now, 'label' => self::device_label()], ['id' => $row->id]);
            return $user;
        }
        $count = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE user_id=%d", $user->ID));
        $limit = self::device_limit($user->ID);
        if ($count >= $limit) {
            return new WP_Error('uc_devices', sprintf('You have already signed in on %d devices. Use "Access request" to ask the Academy to reset them.', $limit));
        }
        $wpdb->insert($t, ['user_id' => $user->ID, 'device_id' => $dev, 'label' => self::device_label(), 'first_seen' => $now, 'last_seen' => $now]);
        return $user;
    }

    public function on_login($login, $user) {
        if ($user instanceof WP_User) {
            update_user_meta($user->ID, 'uc_last_login', current_time('mysql'));
        }
    }

    public function access_request() {
        check_admin_referer('uc_access_request', 'uc_ar_nonce');
        $email = sanitize_email((string)($_POST['ar_email'] ?? ''));
        $reason = sanitize_text_field((string)($_POST['ar_reason'] ?? ''));
        $detail = sanitize_textarea_field((string)($_POST['ar_detail'] ?? ''));
        $back = wp_get_referer() ?: home_url('/login/');
        if (!is_email($email)) {
            wp_safe_redirect(add_query_arg('uc_help', 'email', $back));
            exit;
        }
        $key = 'uc_ar_' . md5(strtolower($email));
        if (!get_transient($key)) {
            global $wpdb;
            $u = get_user_by('email', $email);
            if ($u) {
                $wpdb->insert($this->t('access_requests'), [
                    'user_id'   => (int)$u->ID,
                    'email'     => $email,
                    'reason'    => substr($reason ?: 'Access request', 0, 120),
                    'detail'    => substr($detail, 0, 400),
                    'device'    => substr(self::device_label(), 0, 120),
                    'raised_at' => current_time('mysql'),
                    'status'    => 'open'
                ]);
            }
            set_transient($key, 1, 10 * MINUTE_IN_SECONDS);
        }
        wp_safe_redirect(add_query_arg('uc_help', 'sent', $back));
        exit;
    }

    public function one_time_upgrade() {
        if (get_option('uc_devices_reset_230')) return;
        global $wpdb;
        $t = $this->t('devices');
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) {
            $wpdb->query("DELETE FROM {$t}");
        }
        update_option('uc_devices_reset_230', current_time('mysql'), false);
    }

    /* Readable one time password, no look alike characters. */
    public static function temp_password() {
        $a = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; $n = '23456789'; $o = 'UC';
        for ($i=0;$i<4;$i++) $o .= $a[random_int(0, strlen($a)-1)];
        for ($i=0;$i<4;$i++) $o .= $n[random_int(0, strlen($n)-1)];
        return $o;
    }

    public static function send_credentials($user, $password, $note = '') {
        $url = home_url('/login/');
        $name = $user->display_name ?: $user->user_email;
        $note_html = $note ? '<p style="margin:0 0 14px;color:#566C8C">' . esc_html($note) . '</p>' : '';
        $html = '<div style="font-family:Arial,sans-serif;background:#F2F5FA;padding:24px">
          <div style="max-width:560px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;border:1px solid #E1E8F2">
            <div style="background:#0C1B36;color:#fff;padding:20px 24px"><div style="font:800 18px Arial">UniCybers Academy</div><div style="color:#FF8A3D;font:700 11px/1.4 Arial;letter-spacing:.14em;margin-top:6px">LMS SIGN IN</div></div>
            <div style="padding:24px">
              <p style="margin:0 0 12px">Hello ' . esc_html($name) . ',</p>
              <p style="margin:0 0 14px">Your academy login is ready. Use these details at the student sign-in page:</p>
              <p style="margin:0 0 8px"><strong>Sign in:</strong> <a href="' . esc_url($url) . '">' . esc_html($url) . '</a></p>
              <p style="margin:0 0 8px"><strong>Email:</strong> ' . esc_html($user->user_email) . '</p>
              <p style="margin:0 0 16px"><strong>Temporary password:</strong> ' . esc_html($password) . '</p>
              ' . $note_html . '
              <p style="margin:0 0 18px"><a href="' . esc_url($url) . '" style="display:inline-block;background:#FF6B1A;color:#1A0B02;font-weight:800;padding:12px 18px;border-radius:10px;text-decoration:none">Open LMS</a></p>
              <p style="margin:0;color:#566C8C;font-size:13px">You will be asked to choose your own password the first time you sign in.</p>
            </div>
          </div>
        </div>';
        return self::send_mail($user->user_email, 'UniCybers Academy · Your LMS sign in details', $html, true);
    }
}
