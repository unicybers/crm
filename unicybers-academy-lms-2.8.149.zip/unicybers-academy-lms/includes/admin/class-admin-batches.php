<?php
/**
 * UniCybers Academy LMS: Admin Batches & Sessions Management.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Admin_Batches extends UC_LMS_Admin_Base {
    public static function instance() {
        static $i = null;
        if (!$i) $i = new self();
        return $i;
    }

    public function day_labels() {
        return ['1'=>'Sunday','2'=>'Monday','3'=>'Tuesday','4'=>'Wednesday','5'=>'Thursday','6'=>'Friday','7'=>'Saturday'];
    }

    private function batch_form($batch = null) {
        global $wpdb;
        $courses = $wpdb->get_results("SELECT id, name FROM {$this->table('courses')} WHERE status='active' ORDER BY name ASC");
        $trainers = $this->trainer_users();
        $days = array_filter(explode(',', (string)($batch->recurrence_days ?? '')));
        $labels = $this->day_labels();
        echo '<div class="uc-panel"><h2>' . ($batch ? 'Edit Batch' : 'Add New Batch') . '</h2>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field($batch ? 'uc_update_batch_' . $batch->id : 'uc_save_batch');
        echo '<input type="hidden" name="action" value="' . ($batch ? 'uc_update_batch' : 'uc_save_batch') . '">';
        if ($batch) echo '<input type="hidden" name="id" value="' . absint($batch->id) . '">';
        echo '<table class="form-table"><tr><th>Course</th><td><select name="course_id" ' . ($batch ? 'disabled' : 'required') . '><option value="">Select course</option>';
        foreach ($courses as $c) echo '<option value="' . absint($c->id) . '" ' . selected($batch->course_id ?? 0, $c->id, false) . '>' . esc_html($c->name) . '</option>';
        echo '</select>' . ($batch ? '<input type="hidden" name="course_id" value="' . absint($batch->course_id) . '">' : '') . '</td></tr>';
        echo '<tr><th>Batch name</th><td><input class="regular-text" name="name" required value="' . esc_attr($batch->name ?? '') . '"></td></tr>';
        echo '<tr><th>Trainer</th><td><select name="trainer_user_id"><option value="">Not assigned</option>';
        foreach ($trainers as $u) echo '<option value="' . absint($u->ID) . '" ' . selected($batch->trainer_user_id ?? 0, $u->ID, false) . '>' . esc_html($u->display_name . ' | ' . $u->user_email) . '</option>';
        echo '</select></td></tr>';
        echo '<tr><th>Batch dates</th><td><input type="date" name="start_date" required value="' . esc_attr($batch->start_date ?? '') . '"> to <input type="date" name="end_date" required value="' . esc_attr($batch->end_date ?? '') . '"></td></tr>';
        echo '<tr><th>Status</th><td><select name="status">';
        foreach (['draft', 'active', 'completed', 'cancelled'] as $s) echo '<option value="' . $s . '" ' . selected($batch->status ?? 'active', $s, false) . '>' . ucfirst($s) . '</option>';
        echo '</select></td></tr>';
        echo '<tr><th>Meeting provider</th><td><select name="default_meeting_provider"><option value="zoom" ' . selected($batch->default_meeting_provider ?? 'zoom', 'zoom', false) . '>Zoom</option><option value="google_meet" ' . selected($batch->default_meeting_provider ?? '', 'google_meet', false) . '>Google Meet</option><option value="teams" ' . selected($batch->default_meeting_provider ?? '', 'teams', false) . '>Microsoft Teams</option><option value="zoho" ' . selected($batch->default_meeting_provider ?? '', 'zoho', false) . '>Zoho Meeting</option></select></td></tr>';
        echo '<tr><th>Mode</th><td><select name="mode"><option value="online" ' . selected($batch->mode ?? 'online', 'online', false) . '>Online</option><option value="offline" ' . selected($batch->mode ?? '', 'offline', false) . '>Offline</option><option value="hybrid" ' . selected($batch->mode ?? '', 'hybrid', false) . '>Hybrid</option></select></td></tr>';
        echo '<tr><th>Timezone</th><td><input class="regular-text" name="timezone" required value="' . esc_attr($batch->timezone ?? get_option('uc_default_timezone', 'Asia/Kolkata')) . '"></td></tr>';
        echo '<tr><th>Class days</th><td><div class="uc-weekday-picker">';
        foreach ($labels as $k => $v) echo '<label class="uc-day-chip"><input type="checkbox" name="recurrence_days[]" value="' . $k . '" ' . checked(in_array((string)$k, $days, true), true, false) . '><span>' . esc_html(substr($v,0,3)) . '</span><small>' . esc_html($v) . '</small></label>';
        echo '</div></td></tr>';
        echo '<tr><th>Class time</th><td><input type="time" name="class_start_time" value="' . esc_attr($batch && $batch->class_start_time ? substr($batch->class_start_time, 0, 5) : '') . '"></td></tr>';
        echo '<tr><th>Duration</th><td><input type="number" min="15" max="480" name="class_duration" value="' . esc_attr($batch->class_duration ?? 60) . '"> minutes</td></tr>';
        echo '<tr><th>Class title</th><td><input class="regular-text" name="class_title" value="' . esc_attr($batch->class_title ?? 'Live Class') . '"></td></tr>';
        echo '<tr><th>Capacity</th><td><input type="number" min="0" name="capacity" value="' . esc_attr($batch->capacity ?? '') . '"></td></tr>';
        echo '<tr><th>Notes</th><td><textarea class="large-text" name="notes" rows="3">' . esc_textarea($batch->notes ?? '') . '</textarea></td></tr>';
        echo '</table>';
        submit_button($batch ? 'Save Batch' : 'Create Batch and Schedule');
        echo '</form></div>';
    }

    public function batches_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $edit = absint($_GET['edit'] ?? 0);
        echo '<div class="wrap uc-batch-screen"><style>.uc-weekday-picker{display:grid;grid-template-columns:repeat(7,minmax(72px,1fr));gap:8px;max-width:680px}.uc-day-chip{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;min-height:58px;padding:8px 4px;border:1px solid #cbd5e1;border-radius:11px;background:#fff;cursor:pointer;color:#334155}.uc-day-chip input{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer}.uc-day-chip span{font-weight:800;font-size:13px}.uc-day-chip small{font-size:10px;color:#64748b}.uc-day-chip:has(input:checked){background:#fff0e6;border-color:#ff6b1a;box-shadow:0 0 0 1px #ff6b1a;color:#9a3412}.uc-day-chip:focus-within{outline:2px solid #ff6b1a;outline-offset:2px}@media(max-width:780px){.uc-weekday-picker{grid-template-columns:repeat(4,minmax(70px,1fr))}}</style><h1>' . ($edit ? 'Edit Batch' : 'Batches') . '</h1>';
        $this->render_notice();
        $batch = $edit ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('batches')} WHERE id=%d", $edit)) : null;
        if ($edit && !$batch) {
            echo '<div class="notice notice-error"><p>Batch not found.</p></div></div>';
            return;
        }
        $this->batch_form($batch);
        $rows = $wpdb->get_results("SELECT b.*, c.name course_name, u.display_name trainer_name FROM {$this->table('batches')} b LEFT JOIN {$this->table('courses')} c ON c.id=b.course_id LEFT JOIN {$wpdb->users} u ON u.ID=b.trainer_user_id ORDER BY b.id DESC");
        echo '<h2>Existing Batches</h2><table class="widefat striped"><thead><tr><th>Batch</th><th>Course</th><th>Trainer</th><th>Dates</th><th>Schedule</th><th>Classes</th><th>Students</th><th>Meeting provider</th><th>Meeting links</th><th>Action</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $cnt = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table('sessions')} WHERE batch_id=%d", $r->id));
            $students = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table('enrolments')} WHERE batch_id=%d AND status='active'", $r->id));
            $labels = $this->day_labels();
            $d = [];
            foreach (array_filter(explode(',', (string)$r->recurrence_days)) as $x) if (isset($labels[$x])) $d[] = $labels[$x];
            $sch = $d ? implode(', ', $d) . ($r->class_start_time ? ' at ' . substr($r->class_start_time, 0, 5) : '') : 'Not configured';
            $provider_names = ['zoom'=>'Zoom','google_meet'=>'Google Meet','teams'=>'Microsoft Teams','zoho'=>'Zoho Meeting'];
            $provider = $r->mode === 'offline' ? 'Classroom' : ($provider_names[$r->default_meeting_provider ?: 'zoom'] ?? 'Zoom');
            $linked_count = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table('sessions')} WHERE batch_id=%d AND join_url<>''", $r->id));
            $meeting_status = $linked_count > 0 ? '<span class="uc-ok">'.$linked_count.' linked</span>' : '<span class="uc-warn">No links yet</span>';
            $e = $this->url('uc-batches', ['edit' => $r->id]);
            $del = wp_nonce_url(admin_url('admin-post.php?action=uc_delete_batch&id=' . $r->id), 'uc_delete_batch_' . $r->id);
            echo '<tr><td>' . esc_html($r->name) . '</td><td>' . esc_html($r->course_name) . '</td><td>' . esc_html($r->trainer_name ?: 'Not assigned') . '</td><td>' . esc_html($r->start_date . ' to ' . $r->end_date) . '</td><td>' . esc_html($sch) . '</td><td>' . $cnt . '</td><td>' . $students . '</td><td>' . esc_html($provider) . '</td><td>' . $meeting_status . '</td><td><a href="' . esc_url($e) . '">Edit</a> <a href="' . esc_url($del) . '" onclick="return confirm(\'Delete batch and its generated sessions?\')">Delete</a></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    private function batch_payload($post, $existing = null) {
        $days = array_values(array_intersect(array_map('sanitize_text_field', (array)($post['recurrence_days'] ?? [])), array_keys($this->day_labels())));
        sort($days, SORT_NUMERIC);
        $start = sanitize_text_field($post['start_date'] ?? ($existing->start_date ?? ''));
        $end = sanitize_text_field($post['end_date'] ?? ($existing->end_date ?? ''));
        if (!$start || !$end || $start > $end) wp_die('Invalid batch dates.');
        return [
            'course_id'        => absint($post['course_id'] ?? ($existing->course_id ?? 0)),
            'name'             => sanitize_text_field($post['name'] ?? ''),
            'trainer_user_id'  => absint($post['trainer_user_id'] ?? 0) ?: null,
            'start_date'       => $start,
            'end_date'         => $end,
            'status'           => sanitize_key($post['status'] ?? 'active'),
            'mode'             => sanitize_key($post['mode'] ?? 'online'),
            'default_meeting_provider' => in_array(sanitize_key($post['default_meeting_provider'] ?? 'zoom'), ['zoom','google_meet','teams','zoho'], true) ? sanitize_key($post['default_meeting_provider']) : 'zoom',
            'timezone'         => sanitize_text_field($post['timezone'] ?? get_option('uc_default_timezone', 'Asia/Kolkata')),
            'recurrence_days'  => implode(',', $days),
            'class_start_time' => sanitize_text_field($post['class_start_time'] ?? '') ?: null,
            'class_duration'   => max(15, min(480, absint($post['class_duration'] ?? 60))),
            'class_title'      => sanitize_text_field($post['class_title'] ?? 'Live Class') ?: 'Live Class',
            'capacity'         => absint($post['capacity'] ?? 0) ?: null,
            'notes'            => wp_kses_post($post['notes'] ?? ''),
            'updated_at'       => $this->now()
        ];
    }

    public function save_batch() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_batch')) wp_die('Not allowed');
        global $wpdb;
        $p = $this->batch_payload($_POST);
        if (!$p['course_id'] || !$p['name']) wp_die('Course and batch name are required.');
        $duplicate = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table('batches')} WHERE name=%s AND course_id=%d", $p['name'], $p['course_id']));
        if ($duplicate) $this->redirect('uc-batches', $this->notice('error', 'A batch with the same name already exists for this course. Open the existing batch instead of creating another one.'));
        $p['created_at'] = $this->now();
        $p['zoom_status'] = 'not_configured';
        $wpdb->insert($this->table('batches'), $p);
        $id = (int)$wpdb->insert_id;
        $this->sync_batch_schedule($id);
        $zoom = (($p['mode'] ?? 'online') !== 'offline' && ($p['default_meeting_provider'] ?? 'zoom') === 'zoom' && class_exists('UC_LMS_Zoom')) ? UC_LMS_Zoom::provision_batch_zoom($id) : ['status'=>'not_configured','message'=>'Zoom is not the selected provider.'];
        $sessions = $this->generate_sessions($id);
        $this->audit('batch', $id, 'create', null, $p, 'Created batch with ' . $sessions . ' generated sessions. Zoom status: ' . ($zoom['status'] ?? ''));
        $selected_provider = $p['mode'] === 'offline' ? 'offline' : (string)($p['default_meeting_provider'] ?? 'zoom');
        $message = 'Batch saved successfully. ' . $sessions . ' classes generated. ';
        if ($selected_provider === 'offline') $message .= 'Classroom sessions do not need meeting links.';
        elseif ($selected_provider !== 'zoom') $message .= ucfirst(str_replace('_',' ',$selected_provider)).' selected. Meeting links are generated for each new session when the provider is connected.';
        elseif (($zoom['status'] ?? '') === 'ready') $message .= 'Zoom meeting created and connected.';
        elseif (($zoom['status'] ?? '') === 'not_configured') $message .= 'Zoom credentials are not configured yet. Timetable is saved.';
        else $message .= 'Zoom needs attention: ' . ($zoom['message'] ?? '');
        $this->redirect('uc-batches', ['edit' => $id] + $this->notice(($zoom['status'] ?? '') === 'error' ? 'error' : 'success', $message));
    }

    public function update_batch() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_POST['id'] ?? 0);
        check_admin_referer('uc_update_batch_' . $id);
        global $wpdb;
        $old = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('batches')} WHERE id=%d", $id));
        if (!$old) wp_die('Batch not found.');
        $p = $this->batch_payload($_POST, $old);
        if (!$p['name']) wp_die('Batch name is required.');
        $duplicate = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table('batches')} WHERE name=%s AND course_id=%d AND id<>%d", $p['name'], (int)$old->course_id, $id));
        if ($duplicate) $this->redirect('uc-batches', ['edit' => $id] + $this->notice('error', 'Another batch with this name already exists in this course.'));
        $wpdb->update($this->table('batches'), $p, ['id' => $id]);
        $this->sync_batch_schedule($id);
        $schedule_changed = ($old->start_date !== $p['start_date'] || $old->end_date !== $p['end_date'] || $old->recurrence_days !== $p['recurrence_days'] || $old->class_start_time !== $p['class_start_time'] || (int)$old->class_duration !== (int)$p['class_duration'] || (int)$old->trainer_user_id !== (int)$p['trainer_user_id']);
        $zoom = (($p['mode'] ?? 'online') !== 'offline' && ($p['default_meeting_provider'] ?? 'zoom') === 'zoom' && class_exists('UC_LMS_Zoom')) ? UC_LMS_Zoom::provision_batch_zoom($id) : ['status'=>'not_configured','message'=>'Zoom is not the selected provider.'];
        if ($schedule_changed) {
            $this->generate_sessions($id);
            $this->refresh_session_links($id);
        }
        $this->audit('batch', $id, 'update', $old, $p, 'Updated batch. Zoom status: ' . ($zoom['status'] ?? ''));
        $selected_provider = $p['mode'] === 'offline' ? 'offline' : (string)($p['default_meeting_provider'] ?? 'zoom');
        $message = 'Batch saved successfully. ';
        if ($selected_provider === 'offline') $message .= 'Classroom sessions do not need meeting links.';
        elseif ($selected_provider !== 'zoom') $message .= ucfirst(str_replace('_',' ',$selected_provider)).' selected. Newly generated sessions use this provider.';
        elseif (($zoom['status'] ?? '') === 'ready') $message .= 'Zoom is connected and class links are ready.';
        elseif (($zoom['status'] ?? '') === 'not_configured') $message .= 'Zoom is not configured yet. Your timetable remains saved.';
        else $message .= 'Zoom needs attention: ' . ($zoom['message'] ?? '');
        $this->redirect('uc-batches', ['edit' => $id] + $this->notice(($zoom['status'] ?? '') === 'error' ? 'error' : 'success', $message));
    }

    public function sync_batch_schedule($id) {
        global $wpdb;
        $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('batches')} WHERE id=%d", $id));
        if (!$b) return;
        $wpdb->delete($this->table('batch_schedule'), ['batch_id' => $id], ['%d']);
        $days = array_filter(explode(',', (string)$b->recurrence_days));
        foreach ($days as $day) {
            $end = $b->class_start_time ? date('H:i:s', strtotime($b->class_start_time) + ((int)$b->class_duration * 60)) : null;
            $wpdb->insert($this->table('batch_schedule'), [
                'batch_id'            => $id,
                'day_of_week'         => (int)$day,
                'session_type'        => 'live',
                'facilitator_user_id' => $b->trainer_user_id,
                'start_time'          => $b->class_start_time ?: '00:00:00',
                'end_time'            => $end,
                'platform'            => ($b->mode === 'offline' ? 'offline' : ($b->default_meeting_provider ?: 'zoom')),
                'active'              => 1,
                'created_at'          => $this->now(),
                'updated_at'          => $this->now()
            ]);
        }
    }

    public function generate_sessions($batch_id) {
        global $wpdb;
        $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('batches')} WHERE id=%d", $batch_id));
        if (!$b || !$b->start_date || !$b->end_date || !$b->class_start_time) return 0;
        $days = array_filter(explode(',', (string)$b->recurrence_days));
        if (!$days) return 0;
        try {
            $tz = new DateTimeZone($b->timezone ?: get_option('uc_default_timezone', 'Asia/Kolkata'));
        } catch (Exception $e) {
            return 0;
        }
        $d = new DateTime($b->start_date . ' 00:00:00', $tz);
        $end = new DateTime($b->end_date . ' 23:59:59', $tz);
        $n = 0;
        while ($d <= $end) {
            $dow = (int)$d->format('w') + 1;
            if (in_array((string)$dow, $days, true)) {
                $date = $d->format('Y-m-d');
                $start = $b->class_start_time;
                $endtime = date('H:i:s', strtotime($start) + ((int)$b->class_duration * 60));
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table('sessions')} WHERE batch_id=%d AND session_date=%s AND start_time=%s", $batch_id, $date, $start));
                if (!$exists) {
                    $wpdb->insert($this->table('sessions'), [
                        'batch_id'        => $batch_id,
                        'title'           => $b->class_title ?: 'Live Class',
                        'session_date'    => $date,
                        'start_time'      => $start,
                        'end_time'        => $endtime,
                        'platform'        => $b->mode === 'offline' ? 'offline' : ($b->default_meeting_provider ?: 'zoom'),
                        'status'          => 'scheduled',
                        'trainer_user_id' => $b->trainer_user_id,
                        'zoom_meeting_id' => $b->zoom_meeting_id,
                        'join_url'        => $b->zoom_join_url,
                        'created_at'      => $this->now(),
                        'updated_at'      => $this->now()
                    ]);
                    $new_session_id = (int)$wpdb->insert_id;
                    if ($new_session_id && $b->mode !== 'offline' && in_array((string)($b->default_meeting_provider ?: 'zoom'), ['google_meet','teams','zoho'], true)) {
                        $provider = (string)$b->default_meeting_provider;
                        $created = UC_LMS_Meeting::instance()->portal_create_room($provider, $b->class_title ?: 'Live Class', $date, $start, $endtime, $b->timezone ?: 'Asia/Kolkata');
                        if (!is_wp_error($created) && is_array($created) && !empty($created['join_url'])) {
                            $session_meta = ['join_url'=>esc_url_raw($created['join_url'])];
                            if (!empty($created['calendar_event_id'])) $session_meta['calendar_event_id'] = sanitize_text_field($created['calendar_event_id']);
                            if (!empty($created['provider_meeting_id'])) $session_meta['provider_meeting_id'] = sanitize_text_field($created['provider_meeting_id']);
                            if (!empty($created['provider_data'])) $session_meta['provider_data'] = wp_json_encode($created['provider_data']);
                            if (!empty($created['meet_space_name'])) $session_meta['meet_space_name'] = sanitize_text_field($created['meet_space_name']);
                            if (!empty($created['meet_code'])) $session_meta['meet_code'] = sanitize_text_field($created['meet_code']);
                            if (!empty($created['passcode'])) $session_meta['passcode'] = sanitize_text_field($created['passcode']);
                            $wpdb->update($this->table('sessions'), $session_meta, ['id'=>$new_session_id]);
                        }
                    }
                    $n++;
                }
            }
            $d->modify('+1 day');
        }
        return $n;
    }

    public function refresh_session_links($batch_id) {
        global $wpdb;
        $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('batches')} WHERE id=%d", $batch_id));
        if (!$b) return;
        if (($b->default_meeting_provider ?: 'zoom') === 'zoom') {
            $wpdb->query($wpdb->prepare("UPDATE {$this->table('sessions')} SET trainer_user_id=%s, zoom_meeting_id=%s, join_url=%s, updated_at=%s WHERE batch_id=%d", $b->trainer_user_id ?: null, $b->zoom_meeting_id ?: null, $b->zoom_join_url ?: null, $this->now(), $batch_id));
        } else {
            $wpdb->update($this->table('sessions'), ['trainer_user_id'=>$b->trainer_user_id ?: null, 'updated_at'=>$this->now()], ['batch_id'=>$batch_id]);
        }
    }

    public function delete_batch() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_GET['id'] ?? 0);
        check_admin_referer('uc_delete_batch_' . $id);
        global $wpdb;
        $wpdb->delete($this->table('attendance'), ['batch_id' => $id]);
        $wpdb->delete($this->table('sessions'), ['batch_id' => $id]);
        $wpdb->delete($this->table('batch_schedule'), ['batch_id' => $id]);
        $wpdb->delete($this->table('enrolments'), ['batch_id' => $id]);
        $wpdb->delete($this->table('materials'), ['batch_id' => $id]);
        $wpdb->delete($this->table('batches'), ['id' => $id]);
        $this->audit('batch', $id, 'delete');
        $this->redirect('uc-batches', $this->notice('success', 'Batch deleted.'));
    }

    public function generate_schedule_action() {
        if (!$this->can_manage() || !check_admin_referer('uc_generate_schedule')) wp_die('Not allowed');
        $id = absint($_POST['batch_id'] ?? 0);
        $n = $this->generate_sessions($id);
        $this->redirect('uc-batches', ['edit' => $id] + $this->notice('success', $n . ' new sessions generated.'));
    }

    public function sessions_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $batch_filter = absint($_GET['batch_id'] ?? 0);
        $batches = $wpdb->get_results("SELECT id, name FROM {$this->table('batches')} ORDER BY name ASC");
        echo '<div class="wrap"><h1>Live Classes</h1>';
        $this->render_notice();
        $where = $batch_filter ? $wpdb->prepare("WHERE s.batch_id=%d", $batch_filter) : '';
        $rows = $wpdb->get_results("SELECT s.*, b.name batch_name, u.display_name trainer_name FROM {$this->table('sessions')} s LEFT JOIN {$this->table('batches')} b ON b.id=s.batch_id LEFT JOIN {$wpdb->users} u ON u.ID=s.trainer_user_id {$where} ORDER BY s.session_date DESC, s.start_time DESC LIMIT 100");
        echo '<div class="uc-panel"><form method="get" action="' . esc_url(admin_url('admin.php')) . '"><input type="hidden" name="page" value="uc-sessions"><select name="batch_id"><option value="">All batches</option>';
        foreach ($batches as $b) echo '<option value="' . absint($b->id) . '" ' . selected($batch_filter, $b->id, false) . '>' . esc_html($b->name) . '</option>';
        echo '</select> ';
        submit_button('Filter', 'secondary', 'submit', false);
        echo '</form></div>';
        echo '<table class="widefat striped"><thead><tr><th>Batch</th><th>Title</th><th>Date</th><th>Time</th><th>Trainer</th><th>Platform</th><th>Join Link</th><th>Recording</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $join = $r->join_url ? '<a href="' . esc_url($r->join_url) . '" target="_blank">Join</a>' : 'None';
            $rec = $r->recording_url ? '<a href="' . esc_url($r->recording_url) . '" target="_blank">Watch</a>' : 'None';
            echo '<tr><td>' . esc_html($r->batch_name) . '</td><td>' . esc_html($r->title) . '</td><td>' . esc_html($r->session_date) . '</td><td>' . esc_html(substr((string)$r->start_time, 0, 5) . ' - ' . substr((string)$r->end_time, 0, 5)) . '</td><td>' . esc_html($r->trainer_name ?: 'None') . '</td><td>' . esc_html($r->platform) . '</td><td>' . $join . '</td><td>' . $rec . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function save_session() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_session')) wp_die('Not allowed');
        global $wpdb;
        $batch_id = absint($_POST['batch_id'] ?? 0);
        $title = sanitize_text_field($_POST['title'] ?? 'Live Class');
        $date = sanitize_text_field($_POST['session_date'] ?? '');
        $start = sanitize_text_field($_POST['start_time'] ?? '');
        $end = sanitize_text_field($_POST['end_time'] ?? '');
        if (!$batch_id || !$date || !$start) wp_die('Batch, date and start time are required.');
        $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('batches')} WHERE id=%d", $batch_id));
        if (!$b) wp_die('Batch not found.');
        $platform = $b->mode === 'offline' ? 'offline' : (string)($b->default_meeting_provider ?: 'zoom');
        $row = ['batch_id'=>$batch_id,'title'=>$title,'session_date'=>$date,'start_time'=>$start,'end_time'=>$end ?: null,'platform'=>$platform,'status'=>'scheduled','created_at'=>$this->now(),'updated_at'=>$this->now()];
        if ($platform === 'zoom' && !empty($b->zoom_join_url)) $row['join_url'] = $b->zoom_join_url;
        elseif ($platform === 'zoom' && class_exists('UC_LMS_Zoom')) {
            $made = UC_LMS_Zoom::portal_class_zoom(['title'=>$title,'session_date'=>$date,'start_time'=>$start,'end_time'=>$end,'timezone'=>$b->timezone ?: 'Asia/Kolkata','zoom_meeting_id'=>'']);
            if (!is_wp_error($made) && !empty($made['join_url'])) { $row['join_url']=esc_url_raw($made['join_url']); $row['zoom_meeting_id']=sanitize_text_field((string)($made['zoom_meeting_id'] ?? '')); $row['zoom_start_url']=esc_url_raw((string)($made['start_url'] ?? '')); $row['passcode']=sanitize_text_field((string)($made['passcode'] ?? '')); }
        } elseif (in_array($platform, ['google_meet','teams','zoho'], true) && class_exists('UC_LMS_Meeting')) {
            $made = UC_LMS_Meeting::instance()->portal_create_room($platform,$title,$date,$start,$end,$b->timezone ?: 'Asia/Kolkata');
            if (!is_wp_error($made) && is_array($made) && !empty($made['join_url'])) { $row['join_url']=esc_url_raw($made['join_url']); foreach (['calendar_event_id','meet_space_name','meet_code','provider_meeting_id'] as $key) if (!empty($made[$key])) $row[$key]=sanitize_text_field((string)$made[$key]); if (!empty($made['provider_data'])) $row['provider_data']=wp_json_encode($made['provider_data']); if (!empty($made['passcode'])) $row['passcode']=sanitize_text_field($made['passcode']); }
        }
        $wpdb->insert($this->table('sessions'), $row);
        $this->redirect('uc-sessions', $this->notice('success', 'Class created using '.$platform.' provider.'.(empty($row['join_url']) && $platform !== 'offline' ? ' Meeting link needs provider configuration.' : '')));
    }

    public function update_session() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_POST['id'] ?? 0);
        check_admin_referer('uc_update_session_' . $id);
        global $wpdb;
        $wpdb->update($this->table('sessions'), [
            'title'        => sanitize_text_field($_POST['title'] ?? 'Live Class'),
            'session_date' => sanitize_text_field($_POST['session_date'] ?? ''),
            'start_time'   => sanitize_text_field($_POST['start_time'] ?? ''),
            'end_time'     => sanitize_text_field($_POST['end_time'] ?? ''),
            'updated_at'   => $this->now()
        ], ['id' => $id]);
        $this->redirect('uc-sessions', $this->notice('success', 'Class updated.'));
    }

    public function delete_session() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_GET['id'] ?? 0);
        check_admin_referer('uc_delete_session_' . $id);
        global $wpdb;
        $wpdb->delete($this->table('sessions'), ['id' => $id]);
        $this->redirect('uc-sessions', $this->notice('success', 'Class deleted.'));
    }
}
