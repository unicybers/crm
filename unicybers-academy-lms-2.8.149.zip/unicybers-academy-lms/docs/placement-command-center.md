# Placement Desk as a one-stop career tool

How UniCybers uses the existing Career Proxy (Apps Script) with this LMS. RapidAPI, Claude and Jooble keys stay in Google Apps Script Script Properties. They are never stored in WordPress, Next.js or the browser.

## Rotate leaked keys first

The RapidAPI key, AI keys and shared token were pasted into a chat and a screenshot. Treat them as public. In RapidAPI, Anthropic, OpenAI, Jooble and Apps Script: **create new keys, update Script Properties, delete the old ones.** Do not paste keys into the LMS.

## Who owns what

```
Student / Coordinator
        │  LMS session (Career ID, CV, courses, apply/join)
        ▼
WordPress  /wp-json/uc-career/v1/route
        │  injects SHARED_TOKEN, overwrites email from the WP user
        ▼
Apps Script Career Proxy  (/exec)
        │  JSearch + Jooble + job intelligence + eligibility + gaps + ranking
        ▼
Google Sheets  (job DB, evidence, eligibility, feed)
```

| Layer | Owns | Does not own |
| --- | --- | --- |
| LMS / Placement Desk | Identity, Career ID, CV files, applications, join tracking, client/referral Job DNA | RapidAPI keys, Claude keys, raw board dumps |
| Career Proxy | Discover, de-dupe, REVIEW vs ACCEPT, requirement extract, eligibility, skill/CV gaps, readiness, ranking, student feed | LMS login, Zoom, batches |
| Coordinator | Accept REVIEW jobs as Job DNA, client mandates, referrals, verify CVs | Letting AI set eligible / not eligible |
| Super Admin (Rafi) | /exec URL + shared token on WP, nightly pull | Putting board keys in the plugin |

## The pipeline (finest one-stop tool)

1. **Search** — nightly `syncJobs` for India cyber (SOC analyst, cybersecurity analyst, information security). RapidAPI JSearch + optional Jooble.
2. **Intelligence** — drop nationals-only, stale, country mismatch, keyword stuffing. Borderline jobs go to Claude as RELEVANT / NOT_RELEVANT / REVIEW. Uncertain jobs stay REVIEW.
3. **Job DNA** — coordinator accepts a REVIEW listing, or types a **client mandate** / **referral** directly. Those skip the board filter.
4. **Evidence** — LMS profile, verified CVs, labs/assessments. Self-reported skills stay CONDITIONAL.
5. **Match** — present / partial / missing including SIEM aliases. Mandatory gap = NOT_ELIGIBLE. AI may explain, never decide.
6. **Student feed** — Recommended / Action needed / Not yet, with missing skills, certs, what to do.
7. **Apply → interview → offer → joined** — already on Placement Desk. Join is an application status, not a job-board apply click.

## What to do next (order)

1. Rotate keys. Put only the new ones in Apps Script Script Properties.
2. Deploy Career Proxy as a Web app (Execute as Me, Anyone). Keep the `/exec` URL.
3. On WordPress Placement Desk (Rafi): paste `/exec` URL + SHARED_TOKEN. Click **Pull jobs (India cyber)**.
4. Coordinator opens REVIEW rows, saves accepted ones as Job DNA.
5. Student opens Placement Desk → Jobs & match. Feed uses Career ID email from the LMS session.
6. Later: `upsertStudentEvidence` from verified LMS labs so SIEM from a lab counts as VERIFIED.

## What this slice ships

- WP REST `uc-career/v1/route`, `/dashboard`, `/sync` (token never in the browser).
- Super Admin connection form (URL + token only).
- Preview mock feed so Placement Desk works without Apps Script.
- Job DNA source: Academy desk / Client mandate / Referral / Job board (accepted).
- Student ranked openings: eligibility, missing skills, certs, next action.

## What stays in Apps Script (do not rewrite into PHP)

Requirement extraction, eligibility engine, skill/CV gaps, preparation, readiness, matching, ranking, opportunity feed. The LMS calls them. It does not duplicate ten Google Sheets.

## What we will not do

- Store RapidAPI or Claude keys in WordPress.
- Auto-publish board jobs to students.
- Let a model mark a candidate eligible.
- Build an employer or college portal in this plugin.
- Embed WhatsApp as the application tracker.
