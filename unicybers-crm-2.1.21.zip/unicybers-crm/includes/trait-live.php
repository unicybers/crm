<?php
if (!defined('ABSPATH')) exit;

trait UC_CRM_Live {
    private function zone_name() {
        $z = $this->setting('timezone', 'Asia/Kolkata');
        try {
            new DateTimeZone($z);
            return $z;
        } catch (Exception $e) {
            return 'Asia/Kolkata';
        }
    }

    private function brand() {
        $name = trim((string) $this->setting('account_name', ''));
        return $name !== '' ? $name : 'CRM';
    }

    private function tax_parts($subtotal) {
        $mode = $this->setting('tax_mode', 'gst18');
        if ($mode === 'vat14') return array('rate' => 0.14, 'label' => 'VAT 14%', 'amount' => round($subtotal * 0.14, 2));
        if ($mode === 'none') return array('rate' => 0, 'label' => 'Tax', 'amount' => 0);
        return array('rate' => 0.18, 'label' => 'GST 18%', 'amount' => round($subtotal * 0.18, 2));
    }

    private function report_recipients() {
        $settings = function_exists('uc_crm_settings_get') ? uc_crm_settings_get() : array();
        $raw = isset($settings['report_recipients']) ? $settings['report_recipients'] : $this->setting('report_email', '');
        return function_exists('uc_crm_normalize_email_list') ? uc_crm_normalize_email_list($raw) : array_filter(array_map('trim', explode(',', (string) $raw)));
    }

    private function report_cc($extra = array()) {
        $cc = array();
        $legacy_report = strtolower(trim((string) $this->setting('report_email', '')));
        if ($legacy_report !== '' && is_email($legacy_report)) $cc[] = $legacy_report;
        foreach ($extra as $email) {
            $email = strtolower(trim((string) $email));
            if ($email !== '' && !in_array($email, $cc, true)) $cc[] = $email;
        }
        return $cc;
    }

    private function phone_key($phone) {
        $d = preg_replace('/\D+/', '', (string) $phone);
        if (strlen($d) > 10) $d = substr($d, -10);
        return $d;
    }

    private function matching_leads($phone, $email, $exceptId) {
        $ctx = $this->leads();
        $phoneKey = $this->phone_key($phone);
        $email = strtolower(trim((string) $email));
        $exceptId = (string) $exceptId;
        $out = array();
        foreach ($ctx['sh']->rows as $row) {
            $id = trim($this->cell($row, $ctx['map'], 'id'));
            if ($id === '' || $id === $exceptId) continue;
            if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($row, $ctx['map'], 'archived'))) continue;
            $samePhone = $phoneKey !== '' && $this->phone_key($this->cell($row, $ctx['map'], 'phone')) === $phoneKey;
            $sameEmail = $email !== '' && strtolower(trim($this->cell($row, $ctx['map'], 'email'))) === $email;
            if (!$samePhone && !$sameEmail) continue;
            $out[] = array(
                'id' => $id,
                'name' => $this->cell($row, $ctx['map'], 'name'),
                'owner' => $this->cell($row, $ctx['map'], 'owner'),
            );
            if (count($out) >= 5) break;
        }
        return $out;
    }

    private function reject_duplicate($d, $exceptId) {
        if (!empty($d['allowDuplicate'])) return;
        $phone = isset($d['phone']) ? $d['phone'] : '';
        $email = isset($d['email']) ? $d['email'] : '';
        $hits = $this->matching_leads($phone, $email, $exceptId);
        if (!$hits) return;
        $bits = array();
        foreach ($hits as $hit) $bits[] = ($hit['name'] !== '' ? $hit['name'] : 'Unnamed') . ' (' . $hit['id'] . ')';
        throw new Exception('DUPLICATE ' . implode(', ', $bits));
    }

    public function api_updateCollege($token, $rowNum, $d) {
        $this->auth($token);
        $d = is_array($d) ? $d : array();
        $ctx = $this->colleges();
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $ctx['sh']->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $row = $ctx['sh']->pad($ctx['sh']->rows[$rowNum - 2]);
        $map = $ctx['map'];
        foreach (array('name','city','state','type','university','tpoName','tpoPhone','tpoAltPhone','tpoEmail','status','coordinator','website','address','notes') as $field) {
            if (array_key_exists($field, $d)) $this->put_mapped($row, $map, $field, $d[$field]);
        }
        $this->put_mapped($row, $map, 'modified', $this->now());
        if (isset($map['id']) && trim((string) $row[$map['id']]) === '') $row[$map['id']] = 'COL' . $this->now('YmdHis');
        $ctx['sh']->set_row($rowNum, $row);
        $this->log_audit('UPDATE_COLLEGE', 'row ' . $rowNum, isset($d['name']) ? $d['name'] : '', '');
        return true;
    }

    public function api_updateVisitStatus($token, $rowNum, $status) {
        $this->auth($token);
        $sh = $this->book->sheet('VISIT_PLAN');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $sh->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $idx = $this->idx_map($sh->headers)['idx'];
        if (!isset($idx['status'])) throw new Exception('VISIT_PLAN has no Status column.');
        $sh->set($rowNum, $idx['status'] + 1, $status !== '' ? $status : 'Completed');
        $this->log_audit('VISIT_STATUS', 'row ' . $rowNum, (string) $status, '');
        return true;
    }

    public function api_uiTeam($token) {
        $this->auth($token);
        $sh = $this->book->sheet('USERS');
        $out = array();
        foreach ($sh->rows as $r) {
            $email = trim((string) (isset($r[0]) ? $r[0] : ''));
            $name = trim((string) (isset($r[2]) ? $r[2] : ''));
            $active = strtoupper((string) (isset($r[5]) ? $r[5] : '')) !== 'FALSE';
            if ($email === '' || !$active) continue;
            $out[] = array('name' => $name !== '' ? $name : $email, 'email' => $email);
        }
        return $out;
    }

    public function api_uiTaskAdd($token, $t) {
        $u = $this->auth($token);
        if ($this->is_trainer($u)) throw new Exception('NOT_PERMITTED_FOR_TRAINER');
        $t = is_array($t) ? $t : array();
        $title = trim((string) (isset($t['title']) ? $t['title'] : ''));
        $due = trim((string) (isset($t['due']) ? $t['due'] : ''));
        if ($title === '') throw new Exception('TITLE_REQUIRED');
        if ($due === '') throw new Exception('DUE_DATE_REQUIRED');
        $sh = $this->task_sheet();
        $team = $this->api_uiTeam($token);
        $requested = isset($t['assignees']) && is_array($t['assignees']) ? $t['assignees'] : preg_split('/[,;]+/', (string) (isset($t['email']) ? $t['email'] : ''));
        $allowed = array();
        foreach ($team as $member) $allowed[strtolower(trim($member['email']))] = $member;
        $selected = array();
        foreach ($requested as $email) {
            $key = strtolower(trim((string) $email));
            if ($key !== '' && isset($allowed[$key])) $selected[$key] = $allowed[$key];
        }
        if (!$selected) throw new Exception('ASSIGNEE_REQUIRED');
        $assignee_names = array(); $assignee_emails = array();
        foreach ($selected as $member) { $assignee_names[] = $member['name']; $assignee_emails[] = $member['email']; }
        $assignee_names_text = implode(', ', $assignee_names);
        $assignee_emails_text = implode(',', $assignee_emails);
        $idx = $this->idx_map($sh->headers)['idx'];
        $n = 0;
        if (isset($idx['taskid'])) {
            foreach ($sh->rows as $r) {
                $s = (string) (isset($r[$idx['taskid']]) ? $r[$idx['taskid']] : '');
                $p = strpos($s, '-');
                if ($p !== false) {
                    $v = (int) substr($s, $p + 1);
                    if ($v > $n) $n = $v;
                }
            }
        }
        $id = 'TSK-' . str_pad((string) ($n + 1), 3, '0', STR_PAD_LEFT);
        $meet = trim((string) (isset($t['meetLink']) ? $t['meetLink'] : ''));
        $row = array_fill(0, count($sh->headers), '');
        $put = function ($k, $v) use (&$row, $idx) {
            if (isset($idx[$k])) { $row[$idx[$k]] = $v; return; }
            $aliases = array('created' => array('createdat'), 'details' => array('description'),
                'meetlink' => array('meetinglink'), 'assignedto' => array('assigned','assignee'),
                'assignedemail' => array('assigneeemail','email'));
            if (isset($aliases[$k])) foreach ($aliases[$k] as $alias) if (isset($idx[$alias])) { $row[$idx[$alias]] = $v; return; }
        };
        $put('taskid', $id);
        $put('created', $this->now());
        $put('title', $title);
        $put('details', isset($t['details']) ? $t['details'] : '');
        $put('assignedto', $assignee_names_text);
        $put('assignedemail', $assignee_emails_text);
        $put('duedate', $due);
        $put('priority', isset($t['priority']) && $t['priority'] !== '' ? $t['priority'] : 'Medium');
        $put('status', 'Open');
        $put('meetlink', $meet);
        $put('createdby', $u['name'] ? $u['name'] : $u['email']);
        $sh->append($row);
        $body = "Task: $title"
            . (!empty($t['details']) ? "\n\n" . $t['details'] : '')
            . "\n\nDue: $due\nAssigned by: " . ($u['name'] ? $u['name'] : $u['email'])
            . ($meet !== '' ? "\nMeeting: $meet" : '');
        $to = $assignee_emails_text;
        if ($to !== '') {
            $this->mail($to, 'CRM task: ' . $title, $body, array('cc' => implode(',', $this->report_cc())));
        }
        $this->telegram("*New task* $id\n$title\nFor: " . $assignee_names_text . "\nDue: $due");
        $this->log_audit('TASK_CREATED', $id, $title, $u['email']);
        return array('ok' => true, 'id' => $id, 'meet' => $meet);
    }

    public function api_getLeadTimeline($token, $id) {
        $this->auth($token);
        $found = $this->find_lead_row($id);
        if (!$found) return array();
        $name = strtolower(trim($this->cell($found['row'], $found['ctx']['map'], 'name')));
        $org = strtolower(trim($this->cell($found['row'], $found['ctx']['map'], 'org')));
        $items = array();
        $push = function ($at, $kind, $text) use (&$items) {
            $items[] = array('at' => (string) $at, 'kind' => (string) $kind, 'text' => (string) $text);
        };
        $act = $this->book->sheet('ACTIVITIES');
        if ($act->headers) {
            $idx = $this->idx_map($act->headers)['idx'];
            foreach ($act->rows as $r) {
                $lead = isset($idx['leadid']) ? strtolower(trim((string) $r[$idx['leadid']])) : '';
                $orgCell = isset($idx['organization']) ? strtolower(trim((string) $r[$idx['organization']])) : '';
                if ($lead !== strtolower((string) $id) && !($org !== '' && $orgCell === $org)) continue;
                $type = isset($idx['type']) ? $r[$idx['type']] : 'Activity';
                $sum = isset($idx['summary']) ? $r[$idx['summary']] : '';
                $when = isset($idx['date']) ? $r[$idx['date']] : '';
                $push($when, $type, $sum);
            }
        }
        $visits = $this->book->sheet('VISIT_PLAN');
        if ($visits->headers && $org !== '') {
            $idx = $this->idx_map($visits->headers)['idx'];
            $nameCol = isset($idx['collegename']) ? 'collegename' : (isset($idx['college']) ? 'college' : null);
            foreach ($visits->rows as $r) {
                if (!$nameCol) break;
                $college = strtolower(trim((string) (isset($r[$idx[$nameCol]]) ? $r[$idx[$nameCol]] : '')));
                if ($college === '' || $college !== $org) continue;
                $when = isset($idx['date']) ? $r[$idx['date']] : '';
                $purpose = isset($idx['purpose']) ? $r[$idx['purpose']] : '';
                $status = isset($idx['status']) ? $r[$idx['status']] : '';
                $push($when, 'Visit', trim($purpose . ' ' . $status));
            }
        }
        $quotes = $this->book->sheet('QUOTATIONS');
        if ($quotes->headers && $org !== '') {
            $idx = $this->idx_map($quotes->headers)['idx'];
            foreach ($quotes->rows as $r) {
                $qOrg = isset($idx['organization']) ? strtolower(trim((string) $r[$idx['organization']])) : '';
                if ($qOrg === '' || $qOrg !== $org) continue;
                $when = isset($idx['date']) ? $r[$idx['date']] : '';
                $qid = isset($idx['quotationid']) ? $r[$idx['quotationid']] : 'Quotation';
                $push($when, 'Quotation', $qid);
            }
        }
        $audit = $this->book->sheet('AUDIT_TRAIL');
        if ($audit->headers) {
            $idx = $this->idx_map($audit->headers)['idx'];
            $refCol = isset($idx['recordid']) ? $idx['recordid'] : null;
            foreach ($audit->rows as $r) {
                if ($refCol === null) break;
                if (trim((string) $r[$refCol]) !== (string) $id) continue;
                $when = isset($idx['timestamp']) ? $r[$idx['timestamp']] : '';
                $action = isset($idx['action']) ? $r[$idx['action']] : '';
                $detail = isset($idx['fieldchanged']) ? $r[$idx['fieldchanged']] : (isset($idx['details']) ? $r[$idx['details']] : '');
                $push($when, 'Audit', trim($action . ' ' . $detail));
            }
        }
        usort($items, function ($a, $b) { return strcmp((string) $b['at'], (string) $a['at']); });
        return array_slice($items, 0, 40);
    }

    public function api_logWhatsApp($token, $id, $note) {
        $u = $this->auth($token);
        $found = $this->find_lead_row($id);
        if (!$found) throw new Exception('Lead not found: ' . $id);
        $note = trim((string) $note);
        if ($note === '') throw new Exception('Write what you sent before logging it.');
        $sh = $this->book->sheet('ACTIVITIES');
        if (!$sh->headers) {
            $sh->add_headers(array('Activity ID','Date','Type','Lead ID','Contact ID','Organization','Done By','Summary','Outcome','Next Action','Next Action Date','Duration (min)','Recorded By'));
        }
        $idx = $this->idx_map($sh->headers)['idx'];
        $row = array_fill(0, count($sh->headers), '');
        $put = function ($k, $v) use (&$row, $idx) { if (isset($idx[$k])) $row[$idx[$k]] = $v; };
        $put('activityid', 'ACT-' . $this->now('YmdHis'));
        $put('date', $this->now());
        $put('type', 'WhatsApp');
        $put('leadid', $id);
        $put('organization', $this->cell($found['row'], $found['ctx']['map'], 'org'));
        $put('doneby', $u['name'] ? $u['name'] : $u['email']);
        $put('summary', $note);
        $put('recordedby', $u['email'] ? $u['email'] : $u['name']);
        $sh->append($row);
        $map = $found['ctx']['map'];
        $lead = $found['row'];
        if (isset($map['lastContact'])) $lead[$map['lastContact']] = $this->now('Y-m-d');
        if (isset($map['modified'])) $lead[$map['modified']] = $this->now();
        $found['ctx']['sh']->set_row($found['rowNum'], $lead);
        $this->log_audit('WHATSAPP_LOGGED', $id, $note, $u['email']);
        return array('ok' => true);
    }

    public function api_getInstitutionFile($token, $name) {
        $this->auth($token);
        $name = strtolower(trim((string) $name));
        if ($name === '') return array('leads' => array(), 'visits' => array());
        $leads = array();
        $ctx = $this->leads();
        foreach ($ctx['sh']->rows as $row) {
            $org = strtolower(trim($this->cell($row, $ctx['map'], 'org')));
            if ($org === '' || $org !== $name) continue;
            $id = trim($this->cell($row, $ctx['map'], 'id'));
            if ($id === '') continue;
            $leads[] = array(
                'id' => $id,
                'name' => $this->cell($row, $ctx['map'], 'name'),
                'status' => $this->cell($row, $ctx['map'], 'status'),
                'owner' => $this->cell($row, $ctx['map'], 'owner'),
            );
            if (count($leads) >= 12) break;
        }
        $visits = array();
        $sh = $this->book->sheet('VISIT_PLAN');
        if ($sh->headers) {
            $idx = $this->idx_map($sh->headers)['idx'];
            $col = isset($idx['collegename']) ? $idx['collegename'] : (isset($idx['college']) ? $idx['college'] : null);
            foreach ($sh->rows as $r) {
                if ($col === null) break;
                if (strtolower(trim((string) (isset($r[$col]) ? $r[$col] : ''))) !== $name) continue;
                $visits[] = array(
                    'date' => isset($idx['date']) ? $r[$idx['date']] : '',
                    'purpose' => isset($idx['purpose']) ? $r[$idx['purpose']] : '',
                    'status' => isset($idx['status']) ? $r[$idx['status']] : '',
                );
                if (count($visits) >= 8) break;
            }
        }
        return array('leads' => $leads, 'visits' => $visits);
    }

    private function renewal_watch() {
        $sh = $this->book->sheet('RENEWALS');
        if (!$sh->headers) return array();
        $idx = $this->idx_map($sh->headers)['idx'];
        $dateCol = null;
        foreach (array('renewalduedate', 'contractend', 'duedate') as $k) {
            if (isset($idx[$k])) { $dateCol = $idx[$k]; break; }
        }
        if ($dateCol === null) return array();
        $today = $this->now('Y-m-d');
        $limit = $this->date_shift($today, 30);
        $out = array();
        foreach ($sh->rows as $r) {
            $due = substr(trim((string) (isset($r[$dateCol]) ? $r[$dateCol] : '')), 0, 10);
            if ($due === '' || $due > $limit) continue;
            $status = isset($idx['status']) ? strtolower(trim((string) $r[$idx['status']])) : '';
            if (in_array($status, array('renewed', 'lost', 'cancelled'), true)) continue;
            $org = isset($idx['organization']) ? $r[$idx['organization']] : '';
            $out[] = array('name' => (string) $org, 'due' => $due, 'status' => $due < $today ? 'Overdue' : 'Due');
        }
        usort($out, function ($a, $b) { return strcmp($a['due'], $b['due']); });
        return array_slice($out, 0, 8);
    }

    private function handoff_watch() {
        $sh = $this->book->sheet('ACADEMY_HANDOFF');
        if (!$sh->headers) return array();
        $idx = $this->idx_map($sh->headers)['idx'];
        $out = array();
        foreach ($sh->rows as $r) {
            $status = isset($idx['status']) ? (string) $r[$idx['status']] : '';
            if (strcasecmp($status, 'Queued') !== 0 && strcasecmp($status, 'Failed') !== 0) continue;
            $out[] = array(
                'id' => isset($idx['leadid']) ? $r[$idx['leadid']] : '',
                'name' => isset($idx['name']) ? $r[$idx['name']] : '',
                'status' => $status,
            );
        }
        return array_slice(array_reverse($out), 0, 8);
    }

    private function queue_academy_handoff($id, $row, $map) {
        $status = strtolower(trim($this->cell($row, $map, 'status')));
        if ($status !== 'won') return;
        $div = strtolower($this->cell($row, $map, 'division'));
        if (strpos($div, 'sales') !== false || strpos($div, 'service') !== false) return;
        $sh = $this->book->sheet('ACADEMY_HANDOFF');
        if (!$sh->headers) {
            $sh->add_headers(array('Handoff ID','Lead ID','Name','Email','Phone','Organization','Course','Owner','Status','Created','LMS Response'));
        }
        $idx = $this->idx_map($sh->headers)['idx'];
        foreach ($sh->rows as $existing) {
            $lead = isset($idx['leadid']) ? (string) $existing[$idx['leadid']] : '';
            $st = isset($idx['status']) ? strtolower((string) $existing[$idx['status']]) : '';
            if ($lead === (string) $id && in_array($st, array('queued', 'pushed'), true)) return;
        }
        $rec = array_fill(0, count($sh->headers), '');
        $put = function ($k, $v) use (&$rec, $idx) { if (isset($idx[$k])) $rec[$idx[$k]] = $v; };
        $put('handoffid', 'HO-' . $this->now('YmdHis'));
        $put('leadid', $id);
        $put('name', $this->cell($row, $map, 'name'));
        $put('email', $this->cell($row, $map, 'email'));
        $put('phone', $this->cell($row, $map, 'phone'));
        $put('organization', $this->cell($row, $map, 'org'));
        $put('course', $this->cell($row, $map, 'course'));
        $put('owner', $this->cell($row, $map, 'owner'));
        $put('status', 'Queued');
        $put('created', $this->now());
        $response = 'Waiting for the Academy address in CRM settings.';
        $url = $this->setting('lms_url', '');
        $secret = $this->setting('lms_secret', '');
        if ($url !== '' && $secret !== '') {
            $res = wp_remote_post($url, array(
                'timeout' => 12,
                'headers' => array('Content-Type' => 'application/json', 'X-UC-CRM-Secret' => $secret),
                'body' => wp_json_encode(array(
                    'account_id' => $this->setting('account_id', ''),
                    'lead_id' => $id,
                    'name' => $this->cell($row, $map, 'name'),
                    'email' => $this->cell($row, $map, 'email'),
                    'phone' => $this->cell($row, $map, 'phone'),
                    'organization' => $this->cell($row, $map, 'org'),
                    'course' => $this->cell($row, $map, 'course'),
                )),
            ));
            if (is_wp_error($res)) {
                $put('status', 'Failed');
                $response = $res->get_error_message();
            } else {
                $code = (int) wp_remote_retrieve_response_code($res);
                $put('status', ($code >= 200 && $code < 300) ? 'Pushed' : 'Failed');
                $response = 'HTTP ' . $code;
            }
        }
        $put('lmsresponse', $response);
        $sh->append($rec);
        $this->log_audit('ACADEMY_HANDOFF', $id, $this->cell($row, $map, 'name'), $response);
    }

    public function capture_public($d) {
        $d = is_array($d) ? $d : array();
        $name = trim((string) (isset($d['name']) ? $d['name'] : ''));
        $phone = trim((string) (isset($d['phone']) ? $d['phone'] : ''));
        $email = trim((string) (isset($d['email']) ? $d['email'] : ''));
        if ($name === '' || ($phone === '' && $email === '')) throw new Exception('Name and a phone or email are required.');
        $owner = $this->setting('default_owner', '');
        $id = $this->insert_lead(array('email' => 'website', 'name' => 'Website', 'role' => 'system', 'division' => 'All'), array(
            'name' => $name,
            'phone' => $phone,
            'email' => $email,
            'org' => isset($d['org']) ? $d['org'] : '',
            'college' => isset($d['org']) ? $d['org'] : '',
            'source' => isset($d['source']) && $d['source'] !== '' ? $d['source'] : 'Website',
            'notes' => isset($d['notes']) ? $d['notes'] : '',
            'owner' => $owner,
            'status' => 'New',
            'division' => isset($d['division']) ? $d['division'] : 'Academy',
            'category' => isset($d['category']) ? $d['category'] : 'Candidate',
            'allowDuplicate' => !empty($d['allowDuplicate']),
        ));
        return $id;
    }

    public function job_digest() {
        $ctx = $this->leads();
        $today = $this->now('Y-m-d');
        $follow = 0;
        $over = 0;
        $hot = 0;
        $lines = array();
        foreach ($ctx['sh']->rows as $row) {
            $id = trim($this->cell($row, $ctx['map'], 'id'));
            if ($id === '') continue;
            if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($row, $ctx['map'], 'archived'))) continue;
            $st = $this->cell($row, $ctx['map'], 'status');
            $fp = substr(trim($this->cell($row, $ctx['map'], 'followup')), 0, 10);
            if ($st === 'Negotiation') $hot++;
            if ($fp === $today) {
                $follow++;
                if (count($lines) < 5) $lines[] = '• ' . $this->cell($row, $ctx['map'], 'name');
            } elseif ($fp !== '' && $fp < $today && $st !== 'Won' && $st !== 'Lost') {
                $over++;
            }
        }
        $msg = "*CRM daily digest*\n" . $this->now('d M Y') . "\n\nFollow-ups today: $follow\n" . implode("\n", $lines) . "\n\nIn negotiation: $hot\nOverdue: $over";
        $this->telegram($msg);
        foreach ($this->report_recipients() as $to) {
            $this->mail($to, $this->brand() . ' CRM daily digest', str_replace('*', '', $msg), array('report' => true));
        }
    }

    public function job_visit_reminders() {
        $sh = $this->book->sheet('VISIT_PLAN');
        if (!$sh->headers) return;
        $idx = $this->idx_map($sh->headers)['idx'];
        if (!isset($idx['date'])) return;
        $today = $this->now('Y-m-d');
        $by = array();
        foreach ($sh->rows as $r) {
            $date = substr(trim((string) (isset($r[$idx['date']]) ? $r[$idx['date']] : '')), 0, 10);
            if ($date !== $today) continue;
            $status = isset($idx['status']) ? strtolower((string) $r[$idx['status']]) : '';
            if (in_array($status, array('completed', 'cancelled'), true)) continue;
            $who = isset($idx['coordinator']) ? trim((string) $r[$idx['coordinator']]) : '';
            $college = isset($idx['collegename']) ? $r[$idx['collegename']] : '';
            if ($who === '') continue;
            if (!isset($by[$who])) $by[$who] = array();
            $by[$who][] = $college !== '' ? $college : 'Visit';
        }
        foreach ($by as $who => $names) {
            $email = $this->resolve_email($who);
            if ($email === '') continue;
            $this->mail($email, 'Visits today', "Hello $who,\n\nVisits on the plan for today:\n- " . implode("\n- ", $names) . "\n\n" . $this->brand() . " CRM");
        }
    }

    public function job_weekly() {
        $ctx = $this->leads();
        $by = array();
        foreach ($ctx['sh']->rows as $row) {
            $id = trim($this->cell($row, $ctx['map'], 'id'));
            if ($id === '') continue;
            if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($row, $ctx['map'], 'archived'))) continue;
            $owner = trim($this->cell($row, $ctx['map'], 'owner'));
            if ($owner === '') $owner = 'Unassigned';
            if (!isset($by[$owner])) $by[$owner] = array('open' => 0, 'won' => 0, 'over' => 0);
            $st = $this->cell($row, $ctx['map'], 'status');
            $fp = substr(trim($this->cell($row, $ctx['map'], 'followup')), 0, 10);
            if ($st === 'Won') $by[$owner]['won']++;
            elseif ($st !== 'Lost') $by[$owner]['open']++;
            if ($fp !== '' && $fp < $this->now('Y-m-d') && $st !== 'Won' && $st !== 'Lost') $by[$owner]['over']++;
        }
        $cc = implode(',', $this->report_recipients());
        foreach ($by as $owner => $n) {
            if ($owner === 'Unassigned') continue;
            $email = $this->resolve_email($owner);
            if ($email === '') continue;
            $body = "Hello $owner,\n\nThis week in the CRM:\nOpen leads: {$n['open']}\nWon: {$n['won']}\nOverdue follow-ups: {$n['over']}\n\n" . $this->brand() . " CRM";
            $this->mail($email, $this->brand() . ' CRM weekly report', $body, array('cc' => $cc, 'report' => true));
        }
    }

    public function job_monthly() {
        $recipients = $this->report_recipients();
        if (!$recipients) return false;
        $ctx = $this->leads();
        $now = new DateTime('now', $this->tz($this->zone_name()));
        $monthStart = (clone $now)->modify('first day of this month')->setTime(0, 0, 0);
        $previousStart = (clone $monthStart)->modify('-1 month');
        $start = $previousStart->format('Y-m-d');
        $end = $monthStart->format('Y-m-d');
        $added = 0;
        $open = 0;
        $won = 0;
        $overdue = 0;
        $today = $now->format('Y-m-d');
        foreach ($ctx['sh']->rows as $row) {
            $id = trim($this->cell($row, $ctx['map'], 'id'));
            if ($id === '') continue;
            if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($row, $ctx['map'], 'archived'))) continue;
            $status = $this->cell($row, $ctx['map'], 'status');
            $created = substr(trim($this->cell($row, $ctx['map'], 'date')), 0, 10);
            if ($created >= $start && $created < $end) $added++;
            if ($status === 'Won') $won++;
            elseif ($status !== 'Lost') {
                $open++;
                $followup = substr(trim($this->cell($row, $ctx['map'], 'followup')), 0, 10);
                if ($followup !== '' && $followup < $today) $overdue++;
            }
        }
        $periodEnd = (clone $monthStart)->modify('-1 day')->format('d M Y');
        $periodStart = $previousStart->format('d M Y');
        $body = "Hello,\n\nMonthly CRM report for $periodStart – $periodEnd\n\n"
            . "New leads added during the month: $added\n"
            . "Open leads now: $open\nWon leads now: $won\nOverdue follow-ups now: $overdue\n\n"
            . $this->brand() . " CRM";
        $sent = true;
        foreach ($recipients as $email) {
            if (!$this->mail($email, $this->brand() . ' CRM monthly report', $body, array('report' => true))) $sent = false;
        }
        return $sent;
    }
}
