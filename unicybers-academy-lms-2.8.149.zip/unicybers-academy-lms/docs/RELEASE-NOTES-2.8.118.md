# UniCybers Academy LMS 2.8.118

## Sidebar logo

- Globe sits on the left, with no border and no crop of the oval lockup.
- UNICYBERS is above ACADEMY. Both lines use normal letter spacing and the same width.
- Built on the lightweight 2.8.117 plugin. No schema or data changes.
