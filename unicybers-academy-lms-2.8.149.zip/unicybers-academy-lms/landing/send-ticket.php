<?php
declare(strict_types=1);
session_start();

function clean(string $value, int $max): string {
    $value = trim(str_replace(["\r", "\n"], ' ', $value));
    if (function_exists('mb_substr')) return mb_substr($value, 0, $max);
    return substr($value, 0, $max);
}

function fail(string $message): void {
    render('Ticket not sent', '<p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><p><a class="btn" href="support.html">Back to the form</a></p>', false);
    exit;
}

function render(string $title, string $body, bool $ok): void {
    $banner = $ok ? 'ack' : 'safe';
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</title><link rel="stylesheet" href="site.css"></head><body>';
    echo '<header><div class="wrap bar"><a class="brand" href="index.html"><img src="assets/unicybers-logo.png" alt="UniCybers"><span><b>ACADEMY LMS</b><small>SUPPORT DESK</small></span></a><nav><a href="index.html">Product</a><a href="support.html">Support</a></nav></div></header>';
    echo '<main><section><div class="wrap"><div class="' . $banner . '"><p class="kicker">Support desk</p><h2>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h2>' . $body . '</div></div></section></main></body></html>';
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Location: support.html');
    exit;
}
if (trim((string)($_POST['company_fax'] ?? '')) !== '') {
    render('Ticket received', '<p>If this was a real ticket, check the inbox you typed.</p>', true);
    exit;
}
if (!empty($_SESSION['uc_ticket_at']) && time() - (int)$_SESSION['uc_ticket_at'] < 45) {
    fail('Please wait a minute before sending another ticket.');
}
if (($_POST['consent'] ?? '') !== 'yes') fail('Confirm that the ticket has no password or card number.');

$name = clean((string)($_POST['name'] ?? ''), 120);
$email = clean((string)($_POST['email'] ?? ''), 160);
$academy = clean((string)($_POST['academy'] ?? ''), 160);
$site = clean((string)($_POST['site'] ?? ''), 200);
$plan = clean((string)($_POST['plan'] ?? ''), 80);
$about = clean((string)($_POST['about'] ?? ''), 80);
$subject = clean((string)($_POST['subject'] ?? ''), 160);
$happened = trim((string)($_POST['happened'] ?? ''));
$expected = trim((string)($_POST['expected'] ?? ''));

if ($name === '' || $academy === '' || $subject === '') fail('Name, academy, and subject are required.');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Enter an email we can reply to.');
if (strlen($happened) < 20 || strlen($happened) > 4000) fail('Describe what happened in a sentence or two.');
if (strlen($expected) > 2000) fail('The expected result is too long.');

$attach = null;
if (!empty($_FILES['shot']['name'])) {
    $err = (int)($_FILES['shot']['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($err !== UPLOAD_ERR_OK) fail('The screenshot did not upload. You can send the ticket without it.');
    if ((int)$_FILES['shot']['size'] > 5 * 1024 * 1024) fail('Screenshot must be under 5 MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file((string)$_FILES['shot']['tmp_name']);
    $map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!isset($map[$mime])) fail('Screenshot must be a PNG, JPG, WEBP, or GIF.');
    $attach = [
        'path' => (string)$_FILES['shot']['tmp_name'],
        'name' => 'screenshot.' . $map[$mime],
        'mime' => $mime,
    ];
}

$id = 'UC-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
$shotLine = $attach ? 'Yes, one image is attached to the support copy.' : 'No';
$text = "Ticket: $id\nName: $name\nEmail: $email\nAcademy: $academy\nSite: " . ($site !== '' ? $site : '-') . "\nPlan: $plan\nAbout: $about\nSubject: $subject\n\nWhat happened:\n$happened\n\nWhat they expected:\n" . ($expected !== '' ? $expected : '-') . "\n\nScreenshot: $shotLine\n";

function mail_ticket(string $to, string $cc, string $reply, string $subject, string $text, ?array $attach): bool {
    $to = str_replace(["\r", "\n"], '', $to);
    $cc = str_replace(["\r", "\n"], '', $cc);
    $reply = str_replace(["\r", "\n"], '', $reply);
    $subject = str_replace(["\r", "\n"], '', $subject);
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "From: UniCybers Academy <support@unicybers.com>\r\n";
    if ($reply !== '') $headers .= "Reply-To: $reply\r\n";
    if ($cc !== '') $headers .= "Cc: $cc\r\n";
    if ($attach) {
        $boundary = 'uc' . bin2hex(random_bytes(8));
        $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";
        $file = chunk_split(base64_encode((string)file_get_contents($attach['path'])));
        $body = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n$text\r\n";
        $body .= "--$boundary\r\nContent-Type: {$attach['mime']}; name=\"{$attach['name']}\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=\"{$attach['name']}\"\r\n\r\n$file\r\n--$boundary--";
    } else {
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $body = $text;
    }
    return @mail($to, $subject, $body, $headers);
}

$dir = __DIR__ . '/tickets';
if (!is_dir($dir)) @mkdir($dir, 0700, true);
@file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
@file_put_contents($dir . '/' . $id . '.txt', $text);

$staffOk = mail_ticket('support@unicybers.com', 'rafi@unicybers.com', $email, "[$id] $subject", $text, $attach);
$userText = "Hello $name,\n\nWe received your UniCybers Academy support ticket.\n\nTicket number: $id\nSubject: $subject\n\nKeep this number. If you write again, put it in the subject. We reply to this email address.\n\nThe support copy went to support@unicybers.com, with a copy to rafi@unicybers.com.\n\n— UniCybers Academy\n";
$userOk = mail_ticket($email, '', 'support@unicybers.com', "We received $id", $userText, null);
$_SESSION['uc_ticket_at'] = time();

$safeId = htmlspecialchars($id, ENT_QUOTES, 'UTF-8');
$safeEmail = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
if ($staffOk) {
    $extra = $userOk
        ? '<p>A copy of this acknowledgement was sent to <strong>' . $safeEmail . '</strong>.</p>'
        : '<p>The support team has the ticket. The copy to your inbox could not be sent from this server. Keep the number below.</p>';
    render('Ticket ' . $id . ' is in', '<p>This page is your acknowledgement. The note is with support@unicybers.com, and rafi@unicybers.com is copied.</p>' . $extra . '<p>Your number is <strong>' . $safeId . '</strong>. We reply to the email you gave.</p><p><a class="btn" href="support.html">Raise another ticket</a></p>', true);
} else {
    render('Ticket saved, email did not leave the server', '<p>Your number is <strong>' . $safeId . '</strong>. This host did not hand the message to mail. Please send the same note yourself to support@unicybers.com and put rafi@unicybers.com on copy. Use ' . $safeId . ' in the subject.</p><p><a class="btn primary" href="mailto:support@unicybers.com?cc=rafi@unicybers.com&subject=' . rawurlencode('[' . $id . '] ' . $subject) . '">Open the email</a></p>', false);
}
