=== UniCybers Academy LMS ===
Contributors: unicybers
Tags: lms, education, courses, zoom, attendance, training, student-portal
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.8.149
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Consolidated training operations LMS for courses, batches, recurring live classes, Zoom, Google Meet, Microsoft Teams, Zoho Meeting, Google Drive materials synchronization, attendance, recordings, protected viewers, announcements, reports and white-label academies.

== Description ==

UniCybers Academy LMS is an enterprise-grade training operations system built specifically for technical institutes and cybersecurity training providers.

### Features
* **Google Drive Materials Sync**: Incremental folder/file sync for batch/category folders; stores Drive IDs and links rather than copying source files.
* **Meeting Providers**: Existing Zoom workflow, Google Meet, Microsoft Teams and Zoho Meeting connectors, with an extension registry for future providers.
* **Recurring Class Management**: Edit one session, one session and future occurrences, or the entire series.
* **Protected Content Viewer**: Batch-gated views, repeated student watermarks and best-effort download/copy deterrence. Screen capture cannot be guaranteed against.
* **Finance Excluded**: Finance modules are separate from the LMS core.
* **Lightning-Fast Student & Trainer Portal**: High-speed command rail interface with live countdowns, course progress, and quick action triage.
* **Modular Architecture**: Zero-overhead on-demand autoloader with domain modules for Dashboard, Classroom, Courses, Batches, Classes, Practice, Materials, People, Placement Desk, and Reports.
* **Multi-Platform Live Meetings**: Integrated support for Zoom, Google Meet (via Google Calendar OAuth), and Microsoft Teams.
* **Practice & Assessment Desk**: Interactive cybersecurity lab assignments and mock exams (SOC, CEH, Networking) with automated question templates and triage.
* **Google Drive In-App Streaming**: Protected streaming of recorded class videos and automated Google Drive transcript/notes syncing.
* **Multi-Tenant Custom Domains**: Point client/franchise domain CNAME directly to WordPress for automated white-label academy loading.
* **Student Report Cards**: Comprehensive individual report cards with progress notes and attendance metrics.
* **Device Limits & Account Security**: Multi-device binding with automated lockout protection and access request triage.

== Installation ==

1. Upload the `unicybers-academy-lms` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Access the LMS student portal at `/student-login/` or `/dashboard/`.
4. Existing Zoom credentials are retained. View or test the connection in **UniCybers LMS → Settings → Materials & Meeting Integrations → Existing Zoom connection**.

== Frequently Asked Questions ==

= Where do students sign in? =
Students and trainers log in via `/student-login/` which automatically presents their customized dashboard based on their role (`uc_student`, `uc_trainer`, `uc_coordinator`, or administrator).

= Is it compatible with caching plugins? =
Yes. The plugin automatically emits standard no-cache headers for private authenticated portal pages while allowing static assets to be cached by LiteSpeed, Cloudflare, WP Rocket, and W3 Total Cache.

== Changelog ==

= 2.8.147 =
* Sign-in scene images are visible in light and dark, and the form has more room without a page scroll.
* Privacy and Terms open the Legal page. The landing page is wider. Prices stay off until prices.js sets show to true.
* The tour person is named Rida.
* No database schema changes.

= 2.8.131 =
* The sign-in screen fits in the window. The page itself no longer scrolls.
* No database schema changes.

= 2.8.130 =
* The domain root opens the landing page edge to edge.
* Learners sign in at /login. Older /student-login/ and /lms-login/ addresses still open the same screen.
* Scrollbars are hidden on the academy and the login screen. The page still scrolls.
* No database schema changes.

= 2.8.129 =
* The public landing page is included in the plugin and served at /academy-landing/. No folder is created in the site root.
* No database schema changes.

= 2.8.128 =
* The site root is the WordPress homepage again. The login screen is no longer served at `/`.
* Sign-in stays at `/student-login/`. The older `/lms-login/` address still opens the same screen.
* A homepage that still contains the login shortcode is left for WordPress and Elementor to render.
* No database schema changes.

= 2.8.115 =
* Reduced the UniCybers globe emblem to a compact 36px mark.
* Restored the horizontal sidebar lockup with UNICYBERS above ACADEMY beside the emblem.
* Kept the exact supplied 7-Copy.webp source URL; no alternate or generated logo is used.
* Retained existing typography, white first line, orange second line and equal text-block width.


= 2.8.100 =
* Added Google Meet (via Google Calendar OAuth) and Microsoft Teams live meeting integration.
* Added Practice & Assessment module for assignments, question paper presets (SOC, CEH, Net), and mock triage.
* Added Google Drive embedded video player for in-app recording streaming.
* Added Student Report Cards view in the Reports module.
* Added Multi-tenant custom domain mapping (`portal_domain`) with automatic white-label host detection.
* Added test account isolation toggle to keep test students out of operational KPIs and reports.
* Standardized default tax to 18% GST with auto-tax label switching.
* Expanded Zoom AI Companion summary fetching to a 90-day window.
* UI polish: Transparent navy rail brand logo, updated hero styling, and aligned placement table controls.

= 2.8.75 =
* Decomposed monolith into modular domain folders (`includes/core/`, `includes/admin/`, `includes/portal/modules/`).
* Implemented zero-overhead PSR-style autoloader with O(1) class map.
* Eliminated runtime DDL/introspection queries on standard HTTP requests.
* Replaced N+1 user meta queries with single grouped queries.
* Converted graphic assets to next-gen WebP format (82.5% network reduction).
* Minified core portal stylesheets and scripts (`portal.min.css`, `portal.min.js`).

= 2.8.113 =
* Corrected UniCybers logo using the exact supplied 7-Copy.webp URL.
* Replaced the embedded legacy tagline visually with orange ACADEMY.
* Matched ACADEMY line width to the embedded UNICYBERS wordmark.
* Removed the previous emblem crop plus duplicated text treatment.

= 2.8.111 =
* Corrected the UniCybers logo lockup to show UNICYBERS over orange ACADEMY.
* Uses the provided master logo image as the cropped globe emblem without the old tagline.
* Restored the existing Zoom Server-to-Server credential fields and Test Zoom Connection control in Settings.
* Reused existing Zoom credentials, meetings, schedules and recording workflows.

= 2.8.117 =
* Sidebar brand is a horizontal row: original supplied globe logo on the left, UNICYBERS and ACADEMY on the right.
* ACADEMY is orange and dynamically scaled to the exact visible width of UNICYBERS.
* Uses only the configured master logo URL. No replacement or generated logo asset is used.
* No database schema changes.

= 2.8.117 =
* Corrects the master-logo crop for the actual square 7-Copy.webp source image.
* Keeps the logo mark on the left and UNICYBERS / ACADEMY on the right with exactly matched visible word widths.
* No database changes.
