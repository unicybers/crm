<?php
/**
 * UniCybers Academy LMS Intelligence Ingestion Engine.
 *
 * Handles fetching, parsing, and ingesting Zoom/Meet recordings, transcripts,
 * timelines, meeting summaries, participant engagement, and polls.
 */
if (!defined('ABSPATH')) exit;

class UC_LMS_Intelligence_Ingest {
    private static function t($name) {
        return UC_LMS_Database::table($name);
    }
    private static function api($endpoint, $token) {
        return UC_LMS_Intelligence_Sync::api($endpoint, $token);
    }

    public static function scheduled_seconds($session) {
        return UC_LMS_Intelligence_Sync::scheduled_seconds($session);
    }

    public static function soft(WP_Error $e) {
        return UC_LMS_Intelligence_Sync::soft($e);
    }

public static function uuid_path($uuid) {
        $lms = UC_Academy_LMS::instance();
        if (method_exists($lms, 'portal_zoom_uuid_path')) return $lms->portal_zoom_uuid_path($uuid);
        return str_replace(['/', '+'], ['%2F', '%2B'], $uuid);
    }

public static function pull_files($session, $enc, &$row) {
        global $wpdb;
        $sid = (int) $session->id;
        $data = self::api('GET', '/meetings/'.$enc.'/recordings?include_fields=download_access_token&ttl=86400');
        if (is_wp_error($data)) {
            if (($row['transcript_state'] ?? '') !== 'available') $row['transcript_state'] = self::soft($data);
            if (($row['chapters_state'] ?? '') !== 'available') $row['chapters_state'] = self::soft($data);
            if (empty($row['last_error'])) $row['last_error'] = $data->get_error_message();
            return;
        }
        $got_tr = false;
        $got_ch = false;
        foreach ((array)($data['recording_files'] ?? []) as $f) {
            $type = strtoupper((string)($f['file_type'] ?? ''));
            $url = (string)($f['download_url'] ?? '');
            $tok = (string)($data['download_access_token'] ?? '');
            if ($tok && $url) $url .= (strpos($url, '?') === false ? '?' : '&').'access_token='.rawurlencode($tok);
            if ($type === 'TRANSCRIPT' && $url) {
                $got_tr = self::ingest_vtt($sid, $url);
            }
            if (in_array($type, ['TIMELINE', 'CC'], true) && $url && !$got_ch) {
                $got_ch = self::ingest_timeline($sid, $url);
            }
        }
        if ($got_tr) $row['transcript_state'] = 'available';
        elseif (($row['transcript_state'] ?? '') !== 'available') $row['transcript_state'] = 'unavailable';
        if ($got_ch) $row['chapters_state'] = 'available';
        elseif (($row['chapters_state'] ?? '') !== 'available') $row['chapters_state'] = 'unavailable';
    }

public static function ingest_vtt($sid, $url) {
        global $wpdb;
        $body = self::fetch_text($url);
        if ($body === '') return false;
        $wpdb->delete(self::t('intel_cues'), ['session_id' => $sid, 'kind' => 'transcript']);
        $lines = preg_split("/\r\n|\n|\r/", $body);
        $t = 0;
        $buf = '';
        $n = 0;
        foreach ($lines as $line) {
            if (preg_match('/^(\d{2}):(\d{2}):(\d{2})[\.,]/', $line, $m)) {
                if ($buf !== '') {
                    $wpdb->insert(self::t('intel_cues'), [
                        'session_id' => $sid,
                        'kind' => 'transcript',
                        't_seconds' => $t,
                        'heading' => null,
                        'body' => wp_strip_all_tags($buf),
                    ]);
                    $n++;
                    $buf = '';
                }
                $t = ((int)$m[1]) * 3600 + ((int)$m[2]) * 60 + (int)$m[3];
                continue;
            }
            if (preg_match('/^\d+$/', trim($line)) || stripos($line, 'WEBVTT') === 0 || trim($line) === '') continue;
            $buf .= ($buf ? ' ' : '').trim($line);
        }
        if ($buf !== '') {
            $wpdb->insert(self::t('intel_cues'), [
                'session_id' => $sid,
                'kind' => 'transcript',
                't_seconds' => $t,
                'body' => wp_strip_all_tags($buf),
            ]);
            $n++;
        }
        return $n > 0;
    }

public static function ingest_timeline($sid, $url) {
        global $wpdb;
        $raw = self::fetch_text($url);
        if ($raw === '') return false;
        $json = json_decode($raw, true);
        $items = [];
        if (is_array($json)) {
            foreach (['timeline', 'chapters', 'items'] as $k) {
                if (!empty($json[$k]) && is_array($json[$k])) $items = $json[$k];
            }
            if (!$items && isset($json[0])) $items = $json;
        }
        if (!$items) return false;
        $wpdb->delete(self::t('intel_cues'), ['session_id' => $sid, 'kind' => 'chapter']);
        $n = 0;
        foreach ($items as $it) {
            if (!is_array($it)) continue;
            $sec = isset($it['start_time']) ? (int)$it['start_time'] : (int)($it['ts'] ?? $it['offset'] ?? 0);
            $label = (string)($it['text'] ?? $it['title'] ?? $it['label'] ?? '');
            if ($label === '') continue;
            $wpdb->insert(self::t('intel_cues'), [
                'session_id' => $sid,
                'kind' => 'chapter',
                't_seconds' => max(0, $sec),
                'heading' => sanitize_text_field($label),
                'body' => null,
            ]);
            $n++;
        }
        return $n > 0;
    }

public static function fetch_text($url) {
        $r = wp_remote_get($url, ['timeout' => 40, 'redirection' => 5]);
        if (is_wp_error($r) || wp_remote_retrieve_response_code($r) >= 400) return '';
        return (string) wp_remote_retrieve_body($r);
    }

public static function parse_summary_payload($data) {
        $recap = trim((string)($data['summary_content'] ?? $data['summary_overview'] ?? $data['summary'] ?? ''));
        if ($recap === '' && !empty($data['edited_summary']) && is_array($data['edited_summary'])) {
            $recap = trim((string)($data['edited_summary']['summary_overview'] ?? $data['edited_summary']['summary'] ?? ''));
        }
        $topics = $data['summary_details'] ?? [];
        if (!$topics && !empty($data['edited_summary']['summary_details'])) $topics = $data['edited_summary']['summary_details'];
        if (!$topics && !empty($data['edited_summary']['topics'])) $topics = $data['edited_summary']['topics'];
        $steps = $data['next_steps'] ?? $data['edited_summary']['next_steps'] ?? [];
        $topic_out = [];
        foreach ((array)$topics as $t) {
            if (is_string($t)) {
                $t = trim($t);
                if ($t !== '') $topic_out[] = $t;
                continue;
            }
            if (!is_array($t)) continue;
            $label = trim((string)($t['label'] ?? $t['title'] ?? $t['topic'] ?? ''));
            $body = trim((string)($t['summary'] ?? $t['content'] ?? $t['text'] ?? ''));
            if ($label && $body) $topic_out[] = $label.': '.$body;
            elseif ($label) $topic_out[] = $label;
            elseif ($body) $topic_out[] = $body;
        }
        $step_out = [];
        foreach ((array)$steps as $s) {
            if (is_string($s)) {
                $s = trim($s);
                if ($s !== '') $step_out[] = $s;
                continue;
            }
            if (!is_array($s)) continue;
            $s = trim((string)($s['text'] ?? $s['content'] ?? $s['next_step'] ?? $s['item'] ?? ''));
            if ($s !== '') $step_out[] = $s;
        }
        if ($recap === '' && $topic_out) $recap = implode("\n", array_slice($topic_out, 0, 8));
        return [$recap, $topic_out, $step_out];
    }

public static function pull_summary($session, $enc, &$row) {
        global $wpdb;
        $sid = (int) $session->id;
        $data = self::api('GET', '/meetings/'.$enc.'/meeting_summary');
        if (is_wp_error($data)) {
            if (($row['summary_state'] ?? '') !== 'available') $row['summary_state'] = self::soft($data);
            if (($row['tasks_state'] ?? '') !== 'available') $row['tasks_state'] = $row['summary_state'] ?? 'unavailable';
            if (empty($row['last_error'])) $row['last_error'] = $data->get_error_message();
            return;
        }
        list($recap, $topics, $steps) = self::parse_summary_payload($data);
        if ($recap === '' && !$topics && !$steps) {
            if (($row['summary_state'] ?? '') !== 'available') $row['summary_state'] = 'unavailable';
            if (($row['tasks_state'] ?? '') !== 'available') $row['tasks_state'] = 'unavailable';
            return;
        }
        $t_summaries = self::t('intel_summaries');
        $was = (int) $wpdb->get_var($wpdb->prepare("SELECT published FROM {$t_summaries} WHERE session_id=%d", $sid));
        $wpdb->replace(self::t('intel_summaries'), [
            'session_id' => $sid,
            'recap' => wp_kses_post($recap),
            'topics' => wp_json_encode($topics),
            'next_steps' => wp_json_encode($steps),
            'published' => $was ? 1 : 0,
            'updated_at' => current_time('mysql'),
        ]);
        $t_tasks = self::t('intel_tasks');
        foreach ($steps as $i => $step) {
            $ref = 'ns-'.$i;
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t_tasks} WHERE session_id=%d AND zoom_ref=%s", $sid, $ref));
            if ($exists) continue;
            $wpdb->insert(self::t('intel_tasks'), [
                'session_id' => $sid,
                'title' => sanitize_text_field(wp_strip_all_tags($step)),
                'body' => '',
                'status' => 'draft',
                'zoom_ref' => $ref,
            ]);
        }
        $row['summary_state'] = 'available';
        $row['tasks_state'] = $steps ? 'available' : (($row['tasks_state'] ?? '') ?: 'unavailable');
        $row['last_error'] = null;
    }

public static function pull_participants($session, $enc, &$row) {
        global $wpdb;
        $sid = (int) $session->id;
        $data = self::api('GET', '/report/meetings/'.$enc.'/participants?page_size=300');
        if (is_wp_error($data) || empty($data['participants'])) {
            $alt = self::api('GET', '/past_meetings/'.$enc.'/participants?page_size=300');
            if (!is_wp_error($alt) && !empty($alt['participants'])) $data = $alt;
        }
        if (is_wp_error($data)) {
            if (($row['participants_state'] ?? '') !== 'available') $row['participants_state'] = self::soft($data);
            if (($row['attendance_state'] ?? '') !== 'available') $row['attendance_state'] = $row['participants_state'];
            if (empty($row['last_error'])) $row['last_error'] = $data->get_error_message();
            return;
        }
        $people = (array)($data['participants'] ?? []);
        if (!$people) {
            $row['participants_state'] = 'unavailable';
            $row['attendance_state'] = 'unavailable';
            return;
        }
        $sched = self::scheduled_seconds($session);
        $present_pct = max(1, (int) get_option('uc_attend_present_pct', 90));
        $partial_pct = max(0, (int) get_option('uc_attend_partial_pct', 50));
        foreach ($people as $p) {
            $email = sanitize_email((string)($p['user_email'] ?? $p['email'] ?? ''));
            $zid = sanitize_text_field((string)($p['id'] ?? $p['user_id'] ?? md5(($p['name'] ?? '').$email)));
            $dur = (int)($p['duration'] ?? 0);
            $pct = $sched > 0 ? min(100, round(100 * $dur / $sched, 1)) : 0;
            $status = 'absent';
            if ($pct >= $present_pct) $status = 'present';
            elseif ($pct >= $partial_pct) $status = 'partial';
            $uid = $email ? (int) $wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->users} WHERE user_email=%s", $email)) : 0;
            $join = !empty($p['join_time']) ? gmdate('Y-m-d H:i:s', strtotime($p['join_time'])) : null;
            $leave = !empty($p['leave_time']) ? gmdate('Y-m-d H:i:s', strtotime($p['leave_time'])) : null;
            $t_parts = self::t('intel_participants');
            $wpdb->query($wpdb->prepare(
                "INSERT INTO {$t_parts}
                (session_id,user_id,zoom_user_id,display_name,email,join_time,leave_time,duration_seconds,attendance_status)
                VALUES (%d,%d,%s,%s,%s,%s,%s,%d,%s)
                ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), display_name=VALUES(display_name), email=VALUES(email),
                join_time=VALUES(join_time), leave_time=VALUES(leave_time), duration_seconds=VALUES(duration_seconds), attendance_status=VALUES(attendance_status)",
                $sid,
                $uid,
                $zid,
                sanitize_text_field((string)($p['name'] ?? 'Participant')),
                $email ?: null,
                $join,
                $leave,
                max(0, $dur),
                $status
            ));
            if ($uid && $session->batch_id) {
                $t_attend = self::t('attendance');
                $wpdb->query($wpdb->prepare(
                    "INSERT INTO {$t_attend} (session_id,batch_id,user_id,joined_at,last_seen_at,minutes,status,source)
                     VALUES (%d,%d,%d,%s,%s,%d,%s,'zoom')
                     ON DUPLICATE KEY UPDATE minutes=VALUES(minutes), status=VALUES(status), source='zoom', last_seen_at=VALUES(last_seen_at)",
                    $sid,
                    (int)$session->batch_id,
                    $uid,
                    $join,
                    $leave,
                    (int) round($dur / 60),
                    $status
                ));
            }
        }
        $row['participants_state'] = 'available';
        $row['attendance_state'] = 'available';
    }

public static function pull_polls($session, $enc, &$row) {
        global $wpdb;
        $sid = (int) $session->id;
        $data = self::api('GET', '/report/meetings/'.$enc.'/polls');
        if (is_wp_error($data)) {
            $row['polls_state'] = self::soft($data);
            return;
        }
        $agg = [];
        foreach ((array)($data['questions'] ?? []) as $person) {
            foreach ((array)($person['question_details'] ?? []) as $q) {
                $label = trim((string)($q['question'] ?? 'Poll'));
                $pid = sanitize_text_field((string)($q['polling_id'] ?? md5($label)));
                if (!isset($agg[$pid])) $agg[$pid] = ['question' => $label, 'answers' => [], 'n' => 0];
                $ans = trim((string)($q['answer'] ?? $q['answer_details'] ?? ''));
                if ($ans === '') continue;
                $agg[$pid]['n']++;
                $agg[$pid]['answers'][$ans] = ($agg[$pid]['answers'][$ans] ?? 0) + 1;
            }
        }
        if (!$agg) {
            foreach ((array)($data['polls'] ?? []) as $q) {
                $pid = sanitize_text_field((string)($q['id'] ?? md5((string)($q['question'] ?? ''))));
                $agg[$pid] = ['question' => (string)($q['question'] ?? 'Poll'), 'answers' => [], 'n' => 0, 'raw' => $q];
            }
        }
        if (!$agg) {
            $row['polls_state'] = 'unavailable';
            return;
        }
        $t_polls = self::t('intel_polls');
        foreach ($agg as $pid => $q) {
            $n = max(1, (int)$q['n']);
            $opts = [];
            foreach ($q['answers'] as $label => $count) {
                $opts[] = ['label' => $label, 'count' => $count, 'pct' => round(100 * $count / $n)];
            }
            usort($opts, function ($a, $b) { return $b['count'] <=> $a['count']; });
            $pub = (int) $wpdb->get_var($wpdb->prepare("SELECT published FROM {$t_polls} WHERE session_id=%d AND zoom_poll_id=%s", $sid, $pid));
            $wpdb->query($wpdb->prepare(
                "INSERT INTO {$t_polls} (session_id, zoom_poll_id, question, options_json, published)
                 VALUES (%d,%s,%s,%s,%d)
                 ON DUPLICATE KEY UPDATE question=VALUES(question), options_json=VALUES(options_json)",
                $sid,
                $pid,
                sanitize_text_field($q['question']),
                wp_json_encode(['participants' => (int)$q['n'], 'options' => $opts]),
                $pub
            ));
        }
        $row['polls_state'] = 'available';
    }
}
