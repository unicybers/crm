<?php
/**
 * UniCybers Academy LMS: Materials & Recordings Module.
 *
 * Manages the consolidated media catalog (course materials, slide decks,
 * documents, and cloud video recordings).
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Materials {
    public static function render($portal) {
        global $wpdb;
        $ids = UC_LMS_Portal_Context::batch_ids();
        $tb  = UC_LMS_Database::table('batches');
        $tm  = UC_LMS_Database::table('materials');
        $ts  = UC_LMS_Database::table('sessions');

        $batches = $ids ? $wpdb->get_results("SELECT id, name FROM `$tb` WHERE id IN (" . UC_LMS_Portal_Context::in_ids($ids) . ") ORDER BY name") : [];
        $sel = absint($_GET['batch'] ?? 0);
        if ($sel && !in_array($sel, $ids, true)) $sel = 0;
        $scope = $sel ? (string)$sel : UC_LMS_Portal_Context::in_ids($ids);

        $vis  = UC_LMS_Portal_Context::staff() ? '' : ' AND m.visible=1 AND IFNULL(m.student_locked,0)=0';
        $mats = $ids ? $wpdb->get_results("SELECT m.*, b.name batch_name FROM `$tm` m JOIN `$tb` b ON b.id=m.batch_id WHERE m.batch_id IN ({$scope}){$vis} ORDER BY b.name ASC, m.id DESC LIMIT 400") : [];

        $ist   = UC_LMS_Portal_Context::now_in_tz();
        $today = esc_sql($ist->format('Y-m-d'));
        $from  = esc_sql((clone $ist)->modify('-90 days')->format('Y-m-d'));

        $recs = $ids ? $wpdb->get_results("SELECT s.id, s.batch_id, s.title, s.session_date, s.start_time, s.end_time, s.platform, s.status, s.recording_url, s.recording_status, s.recording_duration, s.recording_notes, b.name batch_name FROM `$ts` s JOIN `$tb` b ON b.id=s.batch_id WHERE s.batch_id IN ({$scope}) AND s.hidden=0 AND LOWER(IFNULL(s.status,''))<>'cancelled' AND LOWER(IFNULL(s.recording_status,''))<>'discarded' AND s.session_date<='{$today}' AND s.session_date>='{$from}' AND " . $portal->class_finished_sql('s') . " AND (IFNULL(s.recording_url,'')<>'' OR IFNULL(s.recording_duration,0)>0 OR LOWER(IFNULL(s.recording_status,'')) IN ('available','processing')) ORDER BY b.name ASC, s.session_date DESC, s.start_time DESC LIMIT 200") : [];

        if ($recs && !UC_LMS_Portal_Context::staff()) {
            $recs = array_values(array_filter($recs, function($r) use ($portal) {
                return $portal->recording_playable_fast($r);
            }));
        }

        $del_nonce = UC_LMS_Portal_Context::ops() ? wp_create_nonce('uc_portal_material_delete') : '';

        $batch_nav = '';
        if ($batches) {
            $batch_nav = '<label class="lib-batch"><select aria-label="Batches" onchange="if(this.value)location.href=this.value">';
            $batch_nav .= '<option value="' . esc_url($portal->url('materials')) . '"' . (!$sel ? ' selected' : '') . '>All Batches</option>';
            foreach ($batches as $b) {
                $href = esc_url(add_query_arg('batch', (int)$b->id, $portal->url('materials')));
                $batch_nav .= '<option value="' . $href . '"' . ($sel === (int)$b->id ? ' selected' : '') . '>' . esc_html($b->name) . '</option>';
            }
            $batch_nav .= '</select></label>';
        }

        if (!$batches) {
            $o = $portal->empty_state('No batches yet', 'Documents and class videos appear here once a batch is running.', 'materials');
        } else {
            $o = $portal->library_desk($mats, $recs, $del_nonce, $batch_nav);
        }

        if (UC_LMS_Portal_Context::staff()) {
            $o .= $portal->material_modal_tpl($batches) . $portal->recording_modal_tpl();
        }

        return $o;
    }
}
