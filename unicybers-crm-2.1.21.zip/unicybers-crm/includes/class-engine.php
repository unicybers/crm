<?php
if (!defined('ABSPATH')) exit;

class UC_CRM_Engine {
    use UC_CRM_Live;

    const AUTH_SALT = 'UniCybers-2026-CHANGE-THIS-TO-A-LONG-RANDOM-STRING';
    const HASH_ITERS = 3000;
    const SESSION_HOURS = 24;

    private $book;
    private $actor = null;

    private static $lead_aliases = array(
        'id' => array('leadid','id'),
        'date' => array('leaddate','dateadded','date','createddate'),
        'name' => array('leadname','collegestudentname','studentname','name'),
        'org' => array('organisation','organization','collegeorg','collegename','college','company'),
        'phone' => array('phone','mobile','phonenumber','contactnumber'),
        'email' => array('email','emailaddress','mail'),
        'whatsapp' => array('whatsapp','whatsappnumber','wa'),
        'source' => array('leadsource','source'),
        'division' => array('division'),
        'businessUnit' => array('businessunit','businessdivision','businessunitname'),
        'category' => array('category','servicetype','leadtype','type'),
        'owner' => array('leadowner','ownercoordinator','owner','coordinator'),
        'assignedTo' => array('assignedto','assigned','assignedperson'),
        'altPhone' => array('alternatephone','altphone','alternatecontact','alternatenumber','phone2','secondaryphone'),
        'priority' => array('priority'),
        'status' => array('status','currentstatus'),
        'firstContact' => array('firstcontactdate','firstcontact'),
        'lastContact' => array('lastcontacted','lastcontactdate','lastcontact'),
        'followup' => array('nextfollowupdate','followupdate','nextfollowup','followup'),
        'followupAction' => array('nextfollowupaction','followupaction','actionneeded','remarksactionneeded'),
        'notes' => array('notes','discussionsummary','remarks','remark'),
        'archived' => array('archived','archive'),
        'createdBy' => array('createdby'),
        'modified' => array('modifieddate','lastmodified','modified'),
        'stage' => array('stage','currentstage'),
        'program' => array('programdepartment','program','department'),
        'students' => array('noofstudents','numberofstudents','students','batchsize'),
        'meetingDate' => array('meetingdate'),
        'expectedStart' => array('expectedstartdate','expectedstart','startdate'),
        'outcome' => array('outcome','finaloutcome'),
        'revenue' => array('revenue','proposalvalue','dealvalue','amount'),
        'batchstage' => array('batchstage','batch'),
        'trainer' => array('trainer','assignedtrainer','faculty'),
        'mode' => array('mode','deliverymode','onlineoffline'),
        'course' => array('course','coursename'),
        'amountreceived' => array('amountreceived','received','amountpaid'),
        'paymentstatus' => array('paymentstatus','payment'),
        'deliverystatus' => array('deliverystatus','delivery'),
        'deliverydate' => array('deliverydate'),
        'escalationnote' => array('escalationnote','needsyou'),
        'academyvalue' => array('academyvalue'),
        'labsvalue' => array('labsvalue'),
        'solutionsvalue' => array('solutionsvalue'),
        'servicesvalue' => array('servicesvalue'),
        'closed' => array('closuredate','closeddate'),
        'location' => array('city','location'),
        'service' => array('service'),
    );

    private static $col_aliases = array(
        'id' => array('collegeid','id'),
        'name' => array('collegename','name','institution'),
        'city' => array('city'),
        'state' => array('state','country'),
        'type' => array('type'),
        'university' => array('affiliateduniversity','university','affiliation'),
        'principalName' => array('principalname'),
        'principalPhone' => array('principalphone'),
        'tpoName' => array('tponame','contactperson','contact'),
        'tpoPhone' => array('tpophone','phone','contactnumber','mobile'),
        'tpoAltPhone' => array('tpoaltphone','alternatephone','altphone','phone2'),
        'tpoEmail' => array('tpoemail','email'),
        'hodName' => array('hodname'),
        'hodDept' => array('hoddepartment','hoddept'),
        'hodPhone' => array('hodphone'),
        'address' => array('address'),
        'website' => array('website'),
        'rating' => array('rating'),
        'status' => array('status'),
        'coordinator' => array('assignedcoordinator','coordinator'),
        'lastVisit' => array('lastvisitdate','lastvisit'),
        'nextVisit' => array('nextvisitdate','nextvisit'),
        'notes' => array('notes'),
        'archived' => array('archived','archive'),
        'modified' => array('modifieddate','lastmodified','modified'),
    );

    private static $business_units = array('academy'=>'Academy','sales'=>'Sales','services'=>'Services');
    private static $sales = array('Cybersecurity Sales' => 1);
    private static $service_business = array('Cybersecurity Services' => 1);
    private static $followup_required = array('Contacted','Follow-up Due','Meeting Scheduled','Proposal Shared','Negotiation');
    private static $streams = array('Academy','Labs','Solutions','Services');
    private static $confidential = array('ranjan');
    private static $trainer_allowed = array(
        'getLeads','getStats','uiTrainerSummaryOwn','uiTrainerView','changePassword','logout',
        'whoami','uiTabs','uiTasks','uiTaskUpdate','uiAlerts','uiAlertRead'
    );
    private static $tabs = array(
        array('key'=>'DASHBOARD','label'=>'Dashboard','group'=>'Main','kind'=>'dashboard'),
        array('key'=>'LEADS','label'=>'Leads','group'=>'Main'),
        array('key'=>'PIPELINE','label'=>'Pipeline','group'=>'Main','kind'=>'pipeline','src'=>'LEADS'),
        array('key'=>'COMPANIES','label'=>'Accounts','group'=>'Main'),
        array('key'=>'CONTACTS','label'=>'Contacts','group'=>'Main'),
        array('key'=>'CYBER_OPPORTUNITIES','label'=>'Opportunities','group'=>'Main'),
        array('key'=>'QUOTATIONS','label'=>'Quotations','group'=>'Main'),
        array('key'=>'ACTIVITIES','label'=>'Activities','group'=>'Main'),
        array('key'=>'TASKS','label'=>'Tasks','group'=>'Main'),
        array('key'=>'MEETINGS','label'=>'Calendar','group'=>'Main'),
        array('key'=>'COLLEGES','label'=>'Institutions','group'=>'Operations'),
        array('key'=>'VISIT_PLAN','label'=>'Visits','group'=>'Operations'),
        array('key'=>'VISIT_REPORTS','label'=>'Visit Reports','group'=>'Operations'),
        array('key'=>'FOLLOW_UPS','label'=>'Follow Ups','group'=>'Operations'),
        array('key'=>'PROPOSALS','label'=>'Proposals','group'=>'Operations'),
        array('key'=>'STUDENTS','label'=>'Students','group'=>'Operations'),
        array('key'=>'BATCHES','label'=>'Batches','group'=>'Operations'),
        array('key'=>'WORKSHOPS','label'=>'Workshops','group'=>'Operations'),
        array('key'=>'INTERNSHIPS','label'=>'Internships','group'=>'Operations'),
        array('key'=>'PROJECTS','label'=>'Projects','group'=>'Operations'),
        array('key'=>'CYBER_PRODUCTS','label'=>'Products','group'=>'Operations'),
        array('key'=>'RENEWALS','label'=>'Renewals','group'=>'Operations'),
        array('key'=>'COORDINATOR_LOG','label'=>'Coordinator Log','group'=>'Operations','readOnly'=>true),
        array('key'=>'TRAINER_LOG','label'=>'Trainer Log','group'=>'Operations','readOnly'=>true),
        array('key'=>'PERFORMANCE','label'=>'Performance','group'=>'System','kind'=>'performance'),
        array('key'=>'USERS','label'=>'User Management','group'=>'System','kind'=>'users'),
        array('key'=>'AUDIT_TRAIL','label'=>'Audit Trail','group'=>'System','readOnly'=>true),
        array('key'=>'ARCHIVE','label'=>'Archive','group'=>'System','readOnly'=>true),
        array('key'=>'ACADEMY_HANDOFF','label'=>'Academy Handoff','group'=>'Operations','readOnly'=>true),
    );

    public function __construct(UC_CRM_Book $book) {
        $this->book = $book;
    }

    public function call($fn, $args) {
        $fn = (string) $fn;
        $args = is_array($args) ? array_values($args) : array();
        if (!method_exists($this, 'api_' . $fn)) {
            throw new Exception('Unknown CRM action: ' . $fn);
        }
        if ($fn !== 'login' && $fn !== 'requestPasswordReset') {
            $token = isset($args[0]) ? (string) $args[0] : '';
            $user = $this->auth($token);
            $this->assert_endpoint_access($user, $fn, $args);
            if ($this->is_trainer($user) && !in_array($fn, self::$trainer_allowed, true)) {
                throw new Exception('NOT_PERMITTED_FOR_TRAINER');
            }
        }
        $method = new ReflectionMethod($this, 'api_' . $fn);
        $args = array_slice($args, 0, $method->getNumberOfParameters());
        return $method->invokeArgs($this, $args);
    }

    /* ---------- time, text, auth ---------- */

    private function tz($name) {
        return new DateTimeZone($name);
    }

    private function now($format = 'Y-m-d H:i:s', $zone = '') {
        if ($zone === '') $zone = $this->zone_name();
        $dt = new DateTime('now', $this->tz($zone));
        return $dt->format($format);
    }

    private function norm($s) {
        return strtolower(preg_replace('/[^a-z0-9]/i', '', (string) $s));
    }

    private function header_map($headers, $aliases) {
        $norm = array();
        foreach ($headers as $i => $h) $norm[$this->norm($h)] = $i;
        $map = array();
        foreach ($aliases as $field => $list) {
            foreach ($list as $alias) {
                if (isset($norm[$alias])) { $map[$field] = $norm[$alias]; break; }
            }
        }
        return $map;
    }

    private function idx_map($headers) {
        $idx = array();
        foreach ($headers as $i => $h) {
            $k = $this->norm($h);
            if ($k !== '' && !isset($idx[$k])) $idx[$k] = $i;
        }
        return array('headers' => $headers, 'idx' => $idx);
    }

    private function cell($row, $map, $field) {
        if (!isset($map[$field])) return '';
        $c = isset($row[$map[$field]]) ? $row[$map[$field]] : '';
        if ($c === null) return '';
        return is_string($c) ? $c : (string) $c;
    }

    private function archived_flag($v) {
        $a = strtolower(trim((string) $v));
        if ($a === '') return false;
        return !in_array($a, array('no','false','0','n'), true);
    }

    private function lead_division($service) {
        $value = trim((string) $service);
        $key = strtolower($value);
        if (isset(self::$business_units[$key])) return self::$business_units[$key];
        if (isset(self::$sales[$value])) return 'Sales';
        if (isset(self::$service_business[$value])) return 'Services';
        return 'Academy';
    }

    private function user_division($value) {
        $value = trim((string) $value);
        if (strcasecmp($value, 'All') === 0 || strcasecmp($value, 'Operations') === 0) return 'All';
        if (strcasecmp($value, 'Training') === 0) return 'Academy';
        foreach (self::$business_units as $unit) if (strcasecmp($value, $unit) === 0) return $unit;
        return '';
    }

    private function division_for_sheet($sheet) {
        $key = strtoupper(trim((string) $sheet));
        $units = array(
            'COLLEGES'=>'Academy','VISIT_PLAN'=>'Academy','VISIT_REPORTS'=>'Academy','FOLLOW_UPS'=>'Academy',
            'STUDENTS'=>'Academy','BATCHES'=>'Academy','WORKSHOPS'=>'Academy','INTERNSHIPS'=>'Academy',
            'ACADEMY_HANDOFF'=>'Academy','TRAINER_LOG'=>'Academy',
            'COMPANIES'=>'Sales','CONTACTS'=>'Sales','CYBER_OPPORTUNITIES'=>'Sales','CYBER_PRODUCTS'=>'Sales',
            'QUOTATIONS'=>'Sales','PROPOSALS'=>'Sales','RENEWALS'=>'Sales',
            'PROJECTS'=>'Services',
            'LEADS'=>'Shared','ACTIVITIES'=>'Shared','TASKS'=>'Shared','MEETINGS'=>'Shared',
            'PIPELINE'=>'Shared','PERFORMANCE'=>'Shared','USERS'=>'Shared','AUDIT_TRAIL'=>'Shared',
            'ARCHIVE'=>'Shared','COORDINATOR_LOG'=>'Shared'
        );
        return isset($units[$key]) ? $units[$key] : '';
    }

    private function assert_sheet_access($u, $sheet) {
        if (!$u || $u['division'] === 'All') return;
        $unit = $this->lead_division($u['division']);
        $area = $this->division_for_sheet($sheet);
        if ($area === '' || ($area !== 'Shared' && $area !== $unit)) throw new Exception('DIVISION_ACCESS_DENIED');
    }

    private function assert_endpoint_access($u, $fn, $args) {
        if (!$u || $u['division'] === 'All') return;
        $unit = $this->lead_division($u['division']);
        $name = (string) $fn;
        $arg = function($i) use ($args) { return isset($args[$i]) ? $args[$i] : null; };
        $sheets = array(
            'uiGrid','uiGridSchema','uiGridAdd','uiArchive','uiNotInterested','uiDeleteRow','uiNudge'
        );
        if (in_array($name, $sheets, true)) {
            $sheet = (string) $arg(1);
            $this->assert_sheet_access($u, $sheet);
            if (strtoupper($sheet) === 'LEADS' && in_array($name, array('uiGridAdd','uiArchive','uiNotInterested','uiDeleteRow','uiNudge'), true)) {
                throw new Exception('Use the dedicated lead actions for LEADS.');
            }
            if (strtoupper($sheet) === 'LEADS' && in_array($name, array('uiArchive','uiNotInterested','uiDeleteRow','uiNudge'), true)) {
                $ctx = $this->leads(); $rowNum = (int) $arg(2);
                if ($rowNum < 2 || $rowNum > $ctx['sh']->last_row()) throw new Exception('Invalid row reference.');
                $this->assert_lead_access($u, $ctx['sh']->rows[$rowNum - 2], $ctx['map']);
            }
        }
        $academy = array('getColleges','addCollege','updateCollege','deleteCollege','restoreCollege','syncCollegesFromLeads',
            'getVisits','addVisit','updateVisit','completeVisit','archiveVisit','restoreVisit','updateVisitStatus','nudgeVisit','getInstitutionFile');
        if (in_array($name, $academy, true) && $unit !== 'Academy') throw new Exception('DIVISION_ACCESS_DENIED');
        $sales = array('getQuotationHistory','archiveQuote','restoreQuote','sendQuotationFromWeb');
        if (in_array($name, $sales, true) && $unit !== 'Sales') throw new Exception('DIVISION_ACCESS_DENIED');
        $leadActions = array('updateLead','deleteLead','archiveLead','restoreLead','nudgeLead','uiEscalate','uiSetLeadValues',
            'uiDraftFollowup','uiSendFollowup','getLeadTimeline','logWhatsApp');
        if (in_array($name, $leadActions, true)) {
            $found = $this->find_lead_row($arg(1));
            if (!$found) throw new Exception('Lead not found');
            $this->assert_lead_access($u, $found['row'], $found['ctx']['map']);
        }
        if (in_array($name, array('bulkArchiveLeads','bulkSetFollowup'), true)) {
            foreach ((array) $arg(1) as $id) {
                $found = $this->find_lead_row($id);
                if (!$found) throw new Exception('Lead not found');
                $this->assert_lead_access($u, $found['row'], $found['ctx']['map']);
            }
        }
        if ($name === 'uiReport') {
            $kind = strtolower((string) $arg(1));
            $salesReports = array('quotations','proposals','renewals');
            $academyReports = array('colleges','visits','academy','trainer');
            if (in_array($kind, $salesReports, true) && $unit !== 'Sales') throw new Exception('DIVISION_ACCESS_DENIED');
            if (in_array($kind, $academyReports, true) && $unit !== 'Academy') throw new Exception('DIVISION_ACCESS_DENIED');
        }
    }

    private function lead_business_unit($row, $map) {
        $unit = trim($this->cell($row, $map, 'businessUnit'));
        if ($unit !== '') return $this->lead_division($unit);
        $legacy = trim($this->cell($row, $map, 'division'));
        if ($legacy === '') $legacy = trim($this->cell($row, $map, 'category'));
        if ($legacy === '') $legacy = trim($this->cell($row, $map, 'service'));
        return $this->lead_division($legacy);
    }

    private function assert_lead_access($u, $row, $map) {
        if (!$u || $u['division'] === 'All') return;
        $ownerUnit = $this->lead_business_unit($row, $map);
        if ($ownerUnit !== $this->lead_division($u['division'])) throw new Exception('DIVISION_ACCESS_DENIED');
    }

    private function ensure_business_unit_column(&$ctx) {
        if (isset($ctx['map']['businessUnit'])) return;
        $ctx['sh']->add_headers(array('Business Unit'));
        $ctx['map'] = $this->header_map($ctx['sh']->headers, self::$lead_aliases);
        $ctx['headers'] = $ctx['sh']->headers;
    }

    private function settings() {
        $s = get_option('uc_crm_settings', array());
        return is_array($s) ? $s : array();
    }

    private function setting($key, $default = '') {
        $s = $this->settings();
        return isset($s[$key]) && $s[$key] !== '' ? $s[$key] : $default;
    }

    private function sha256($s) {
        return hash('sha256', (string) $s);
    }

    private function hash_v2($pw, $salt, $iters) {
        $h = $this->sha256($pw . $salt . self::AUTH_SALT);
        for ($i = 1; $i < $iters; $i++) $h = $this->sha256($h . $salt);
        return $h;
    }

    private function hash_store($pw) {
        $salt = bin2hex(random_bytes(16));
        return 'v2$' . self::HASH_ITERS . '$' . $salt . '$' . $this->hash_v2($pw, $salt, self::HASH_ITERS);
    }

    private function verify_stored($pw, $stored) {
        $stored = (string) $stored;
        if (strpos($stored, 'v2$') === 0) {
            $p = explode('$', $stored);
            $iters = isset($p[1]) ? (int) $p[1] : self::HASH_ITERS;
            $salt = isset($p[2]) ? $p[2] : '';
            $hash = isset($p[3]) ? $p[3] : '';
            $ok = hash_equals($hash, $this->hash_v2($pw, $salt, $iters));
            return array('ok' => $ok, 'migrate' => false);
        }
        $legacy = $this->sha256($pw . self::AUTH_SALT);
        $ok = strlen($legacy) === strlen($stored) && hash_equals($stored, $legacy);
        return array('ok' => $ok, 'migrate' => true);
    }

    private function cache_get($key) {
        $v = get_transient('uc_crm_' . md5($key));
        return $v === false ? null : $v;
    }

    private function cache_set($key, $val, $seconds) {
        set_transient('uc_crm_' . md5($key), $val, (int) $seconds);
    }

    private function cache_del($key) {
        delete_transient('uc_crm_' . md5($key));
    }

    private function auth($token) {
        $token = trim((string) $token);
        if ($token === '') throw new Exception('SESSION_EXPIRED');
        $rec = get_transient('uc_crm_sess_' . $token);
        if (!is_array($rec) || empty($rec['email'])) throw new Exception('SESSION_EXPIRED');
        set_transient('uc_crm_sess_' . $token, $rec, self::SESSION_HOURS * HOUR_IN_SECONDS);
        $this->actor = array(
            'email' => $rec['email'],
            'role' => isset($rec['role']) ? $rec['role'] : 'coordinator',
            'division' => $this->user_division(isset($rec['division']) ? $rec['division'] : 'All') ?: 'All',
            'name' => isset($rec['name']) ? $rec['name'] : $rec['email'],
        );
        return $this->actor;
    }

    private function is_trainer($u) {
        return strtolower((string) $u['role']) === 'trainer';
    }

    private function is_admin($u) {
        $r = strtolower((string) $u['role']);
        return $r === 'admin' || $r === 'superadmin' || $r === 'super admin';
    }

    private function require_admin($token) {
        $u = $this->auth($token);
        $r = strtolower((string) $u['role']);
        if (!in_array($r, array('admin','superadmin','super admin','manager'), true)) {
            throw new Exception('ADMIN_ONLY');
        }
        return $u;
    }

    private function require_super($token) {
        $u = $this->auth($token);
        if (strtolower((string) $u['role']) !== 'superadmin') throw new Exception('Only a Super Admin can do this.');
        return $u;
    }

    private function can_see_trainer($u, $trainer) {
        $n = strtolower(trim((string) $trainer));
        if ($n === '' || !in_array($n, self::$confidential, true)) return true;
        $role = strtolower((string) $u['role']);
        if (in_array($role, array('admin','superadmin','super admin','coordinator'), true)) return true;
        return strtolower(trim((string) $u['name'])) === $n;
    }

    /* ---------- leads ---------- */

    private function leads() {
        $sh = $this->book->sheet('LEADS');
        if (!$sh->headers) throw new Exception('LEADS sheet not found');
        return array('sh' => $sh, 'map' => $this->header_map($sh->headers, self::$lead_aliases), 'headers' => $sh->headers);
    }

    private function lead_to_arr($row, $map) {
        $div = $this->cell($row, $map, 'division');
        if ($div === '') $div = $this->lead_division($this->cell($row, $map, 'category') !== '' ? $this->cell($row, $map, 'category') : $this->cell($row, $map, 'service'));
        $g = function ($f) use ($row, $map) { return $this->cell($row, $map, $f); };
        return array(
            $g('id'), $g('date'), $g('name'), $g('email'), $g('phone'), $g('category'),
            $g('org'), $g('owner'), $g('status'), $g('priority'), $g('source'), $g('service'),
            $g('location'), $g('followup'), $g('closed'), $g('revenue'), $g('notes'),
            $g('whatsapp'), $div, $g('category'), $g('firstContact'), $g('lastContact'),
            $g('followupAction'), $g('createdBy'), $g('modified'), $g('archived'),
            $g('program'), $g('students'), $g('stage'), $g('meetingDate'), $g('expectedStart'),
            $g('outcome'), $g('assignedTo'), $g('altPhone'), $g('escalationnote'),
            $g('academyvalue'), $g('labsvalue'), $g('solutionsvalue'), $g('servicesvalue'),
            $g('amountreceived'), $g('paymentstatus'), $g('deliverystatus'), $g('deliverydate'),
            $g('batchstage'), $g('mode'), $g('course'), $g('trainer')
            , $this->lead_business_unit($row, $map)
        );
    }

    private function scope_leads($rows, $u) {
        $role = strtolower((string) $u['role']);
        if ($role === 'trainer') {
            $me = strtolower(trim((string) $u['name']));
            if ($me === '') return array();
            return array_values(array_filter($rows, function ($r) use ($me) {
                return strtolower(trim((string) (isset($r[46]) ? $r[46] : ''))) === $me;
            }));
        }
        if (!$u || $u['division'] === 'All') {
            $out = ($role === 'agent')
                ? array_values(array_filter($rows, function ($r) use ($u) {
                    return strtolower((string) $r[7]) === strtolower((string) $u['name']);
                }))
                : $rows;
        } else {
            $out = array();
            foreach ($rows as $r) {
                $dv = isset($r[47]) && trim((string) $r[47]) !== '' ? $this->lead_division($r[47]) : $this->lead_division((isset($r[18]) && $r[18] !== '') ? $r[18] : (isset($r[5]) ? $r[5] : ''));
                if ($dv !== $u['division']) continue;
                if ($role === 'agent' && strtolower((string) $r[7]) !== strtolower((string) $u['name'])) continue;
                $out[] = $r;
            }
        }
        $self = $this;
        return array_values(array_filter($out, function ($r) use ($u, $self) {
            return $self->can_see_trainer($u, isset($r[46]) ? $r[46] : '');
        }));
    }

    private function active_lead_rows($u) {
        $ctx = $this->leads();
        $idCol = isset($ctx['map']['id']) ? $ctx['map']['id'] : 0;
        $arc = isset($ctx['map']['archived']) ? $ctx['map']['archived'] : null;
        $mapped = array();
        foreach ($ctx['sh']->rows as $row) {
            if (!isset($row[$idCol]) || trim((string) $row[$idCol]) === '') continue;
            if ($arc !== null && $this->archived_flag(isset($row[$arc]) ? $row[$arc] : '')) continue;
            $mapped[] = $this->lead_to_arr($row, $ctx['map']);
        }
        return $this->scope_leads($mapped, $u);
    }

    private function find_lead_row($id) {
        $ctx = $this->leads();
        $idCol = isset($ctx['map']['id']) ? $ctx['map']['id'] : 0;
        foreach ($ctx['sh']->rows as $i => $row) {
            if (trim((string) (isset($row[$idCol]) ? $row[$idCol] : '')) === trim((string) $id)) {
                return array('ctx' => $ctx, 'index' => $i, 'rowNum' => $i + 2, 'row' => $row);
            }
        }
        return null;
    }

    private function put_mapped(&$row, $map, $field, $val) {
        if (!isset($map[$field])) return;
        $row[$map[$field]] = $val;
    }

    private function require_followup($status, $followup, $existing) {
        if (!$status) return;
        if (!in_array((string) $status, self::$followup_required, true)) return;
        $have = ($followup !== null && trim((string) $followup) !== '') ? trim((string) $followup) : trim((string) $existing);
        if ($have === '') throw new Exception('FOLLOWUP_REQUIRED');
    }

    private function next_lead_id($ctx) {
        $idCol = isset($ctx['map']['id']) ? $ctx['map']['id'] : 0;
        $max = 0;
        foreach ($ctx['sh']->rows as $row) {
            if (preg_match('/^LD-(\d+)$/', (string) (isset($row[$idCol]) ? $row[$idCol] : ''), $m)) {
                $n = (int) $m[1];
                if ($n > $max) $max = $n;
            }
        }
        return 'LD-' . str_pad((string) ($max + 1), 4, '0', STR_PAD_LEFT);
    }

    public function api_login($email, $pw) {
        $email = strtolower(trim((string) $email));
        $from = strtolower(trim((string) $this->setting('legacy_email_from', '')));
        $to = strtolower(trim((string) $this->setting('legacy_email_to', '')));
        if ($from !== '' && $to !== '' && substr($email, -strlen($from)) === $from) {
            $email = substr($email, 0, -strlen($from)) . $to;
        }
        $bad = array('ok' => false, 'msg' => 'Invalid email or password.');
        if ($email === '') return $bad;
        if ($this->cache_get('lock_' . $email)) return array('ok' => false, 'msg' => 'Too many attempts. Try again in a few minutes.');
        $sh = $this->book->sheet('USERS');
        if (!$sh->headers) return array('ok' => false, 'msg' => 'USERS sheet missing');
        foreach ($sh->rows as $i => $r) {
            if (strtolower(trim((string) (isset($r[0]) ? $r[0] : ''))) !== $email) continue;
            if (strtoupper((string) (isset($r[5]) ? $r[5] : '')) === 'FALSE') return array('ok' => false, 'msg' => 'Account disabled');
            $v = $this->verify_stored($pw, isset($r[1]) ? $r[1] : '');
            if ($v['ok']) {
                if ($v['migrate']) $sh->set($i + 2, 2, $this->hash_store($pw));
                $this->cache_del('fail_' . $email);
                $this->cache_del('lock_' . $email);
                $name = (isset($r[2]) && $r[2] !== '') ? $r[2] : $email;
                $role = (isset($r[3]) && $r[3] !== '') ? $r[3] : 'coordinator';
                $division = $this->user_division((isset($r[4]) && $r[4] !== '') ? $r[4] : 'All') ?: 'All';
                $must = strtoupper(trim((string) (isset($r[6]) ? $r[6] : ''))) === 'TRUE';
                $wpUserId = $this->sync_wp_account($email, (string) $pw, $name, true);
                if ($wpUserId) {
                    wp_set_current_user($wpUserId);
                    wp_set_auth_cookie($wpUserId, true, is_ssl());
                }
                $token = wp_generate_uuid4();
                set_transient('uc_crm_sess_' . $token, array(
                    'email' => $email, 'role' => $role, 'division' => $division, 'name' => $name,
                ), self::SESSION_HOURS * HOUR_IN_SECONDS);
                $this->actor = array('email' => $email, 'name' => $name, 'role' => $role, 'division' => $division);
                $this->log_audit('LOGIN', $email, 'web login', '');
                return array('ok' => true, 'token' => $token, 'name' => $name, 'role' => $role, 'division' => $division, 'mustChange' => $must);
            }
            $this->note_fail($email);
            return $bad;
        }
        $this->note_fail($email);
        return $bad;
    }

    public function api_requestPasswordReset($email) {
        $neutral = array('ok' => true, 'msg' => 'If that email is registered, a temporary password is on its way.');
        $email = strtolower(trim((string) $email));
        if ($email === '') return $neutral;
        $tries = (int) $this->cache_get('reset_' . $email);
        if ($tries >= 3) return $neutral;
        $this->cache_set('reset_' . $email, $tries + 1, 900);
        $sh = $this->book->sheet('USERS');
        $row = 0;
        foreach ($sh->rows as $i => $r) {
            if (strtolower(trim((string) (isset($r[0]) ? $r[0] : ''))) !== $email) continue;
            if (strtoupper((string) (isset($r[5]) ? $r[5] : '')) === 'FALSE') return $neutral;
            $row = $i + 2;
            break;
        }
        if (!$row) return $neutral;
        if ($this->setting('from_email', '') === '') {
            return array('ok' => false, 'msg' => 'Password email is not set up yet. In WordPress, open UniCybers CRM and set a new password for this email.');
        }
        $temp = 'UC-' . substr(bin2hex(random_bytes(4)), 0, 8);
        $sent = $this->mail($email, 'UniCybers CRM password reset',
            'A temporary password was requested for your UniCybers CRM account.<br><br>Temporary password: <b>' . esc_html($temp) . '</b><br><br>Sign in with it. You will be asked to choose a new password.',
            array('html' => true));
        if (!$sent) {
            return array('ok' => false, 'msg' => 'The reset email could not be sent. Set a new password from the WordPress CRM screen.');
        }
        $sh->set($row, 2, $this->hash_store($temp));
        $sh->set($row, 7, 'TRUE');
        $this->sync_wp_account($email, $temp, '', true);
        $this->log_audit('PASSWORD_RESET_REQUEST', $email, 'self-service', '');
        return $neutral;
    }

    public function set_user_password($email, $pw) {
        $email = strtolower(trim((string) $email));
        $pw = (string) $pw;
        if ($email === '' || strlen($pw) < 8) return 'Use the account email and a password of at least 8 characters.';
        $sh = $this->book->sheet('USERS');
        foreach ($sh->rows as $i => $r) {
            if (strtolower(trim((string) (isset($r[0]) ? $r[0] : ''))) !== $email) continue;
            $sh->set($i + 2, 2, $this->hash_store($pw));
            $sh->set($i + 2, 6, 'TRUE');
            $sh->set($i + 2, 7, 'FALSE');
            $this->sync_wp_account($email, $pw, '', true);
            $this->cache_del('fail_' . $email);
            $this->cache_del('lock_' . $email);
            $this->log_audit('PASSWORD_SET', $email, 'wordpress admin', '');
            return '';
        }
        return 'No CRM user uses that email.';
    }

    private function note_fail($email) {
        $n = (int) $this->cache_get('fail_' . $email) + 1;
        $this->cache_set('fail_' . $email, $n, 900);
        if ($n >= 6) $this->cache_set('lock_' . $email, 1, 600);
    }

    public function api_whoami($token) { return $this->auth($token); }

    public function api_logout($token) {
        $token = trim((string) $token);
        if ($token !== '') delete_transient('uc_crm_sess_' . $token);
        if (is_user_logged_in()) wp_logout();
        return true;
    }

    public function api_changePassword($token, $current, $newPw) {
        $u = $this->auth($token);
        $newPw = (string) $newPw;
        if (strlen($newPw) < 8) return array('ok' => false, 'msg' => 'New password must be at least 8 characters.');
        $sh = $this->book->sheet('USERS');
        $found = null;
        foreach ($sh->rows as $i => $r) {
            if (strtolower(trim((string) $r[0])) === strtolower($u['email'])) { $found = array($i, $r); break; }
        }
        if (!$found) return array('ok' => false, 'msg' => 'User not found.');
        $must = strtoupper(trim((string) (isset($found[1][6]) ? $found[1][6] : ''))) === 'TRUE';
        if (!$must) {
            $v = $this->verify_stored((string) $current, isset($found[1][1]) ? $found[1][1] : '');
            if (!$v['ok']) return array('ok' => false, 'msg' => 'Current password is incorrect.');
        }
        $sh->set($found[0] + 2, 2, $this->hash_store($newPw));
        $sh->ensure_col(7);
        $sh->set($found[0] + 2, 7, 'FALSE');
        $this->sync_wp_account($u['email'], $newPw, '', true);
        $this->log_audit('PASSWORD_CHANGE', $u['email'], 'self', '');
        return array('ok' => true, 'msg' => 'Password updated.');
    }

    public function api_getStats($token) {
        $u = $this->auth($token);
        $today = $this->now('Y-m-d');
        $stats = array('total'=>0,'won'=>0,'hot'=>0,'revenue'=>0,'pipelineValue'=>0,'batchTotal'=>0,'batchReady'=>0,'batchInterested'=>0,'visits'=>0,'colleges'=>0,'overdue'=>array(),'today'=>array(),'revenueList'=>array(),'recent'=>array(),'noFollowup'=>array(),'sources'=>array(),'owners'=>array(),'statusCounts'=>array(),'revenueMonths'=>array());
        $rows = $this->active_lead_rows($u);
        $stats['total'] = count($rows);
        foreach ($rows as $r) {
            $st = $r[8];
            $fp = $r[13] ? explode(' ', (string) $r[13])[0] : '';
            if ($st === 'Won') {
                $stats['won']++;
                $stats['revenue'] += (float) $r[15];
                if ($r[15]) $stats['revenueList'][] = array('name' => $r[2], 'revenue' => $r[15]);
            }
            if ($st === 'Negotiation') $stats['hot']++;
            if (in_array($st, array('New','Contacted','Follow-up Due','Meeting Scheduled','Proposal Shared','Negotiation','On Hold'), true)) {
                $stats['pipelineValue'] += (float) $r[15];
            }
            $cat = strtolower((string) (isset($r[5]) ? $r[5] : ''));
            $stage = strtolower(trim((string) (isset($r[43]) ? $r[43] : '')));
            if (strpos($cat, 'student') !== false || strpos($cat, 'candidate') !== false || $stage !== '') {
                $stats['batchTotal']++;
                if ($stage === 'confirmed' || $stage === 'enrolled') $stats['batchReady']++;
                if ($stage === 'interested') $stats['batchInterested']++;
            }
            if ($fp && $fp < $today && $st !== 'Won' && $st !== 'Lost') $stats['overdue'][] = array('name'=>$r[2],'followup'=>$fp,'owner'=>$r[7]);
            if ($fp === $today) $stats['today'][] = array('name'=>$r[2],'owner'=>$r[7],'status'=>$st);
            if ($fp === '' && $st !== 'Won' && $st !== 'Lost') $stats['noFollowup'][] = array('name'=>$r[2],'owner'=>$r[7],'status'=>$st);
            $src = trim((string) $r[10]) !== '' ? (string) $r[10] : 'Unknown';
            if (!isset($stats['sources'][$src])) $stats['sources'][$src] = 0;
            $stats['sources'][$src]++;
            $owner = trim((string) $r[7]);
            if ($owner !== '') {
                if (!isset($stats['owners'][$owner])) $stats['owners'][$owner] = array('total' => 0, 'won' => 0);
                $stats['owners'][$owner]['total']++;
                if ($st === 'Won') $stats['owners'][$owner]['won']++;
            }
            if (!isset($stats['statusCounts'][$st])) $stats['statusCounts'][$st] = 0;
            $stats['statusCounts'][$st]++;
            if ($st === 'Won') {
                $when = $r[14] ? explode(' ', (string) $r[14])[0] : ($r[1] ? explode(' ', (string) $r[1])[0] : '');
                if ($when) {
                    $mk = substr($when, 0, 7);
                    if (!isset($stats['revenueMonths'][$mk])) $stats['revenueMonths'][$mk] = 0;
                    $stats['revenueMonths'][$mk] += (float) $r[15];
                }
            }
        }
        $stats['noFollowupCount'] = count($stats['noFollowup']);
        $stats['noFollowup'] = array_slice($stats['noFollowup'], 0, 8);
        $stats['renewals'] = $this->renewal_watch();
        $stats['handoffs'] = $this->handoff_watch();
        $recent = array_slice($rows, -5);
        $recent = array_reverse($recent);
        foreach ($recent as $r) $stats['recent'][] = array('name'=>$r[2],'status'=>$r[8]);
        usort($stats['overdue'], function ($a, $b) { return strcmp($a['followup'], $b['followup']); });
        if ($u['division'] === 'Academy') {
            $stats['visits'] = max(0, count($this->book->sheet('VISIT_PLAN')->rows));
            $stats['colleges'] = max(0, count($this->book->sheet('COLLEGES')->rows));
        }
        return $stats;
    }

    private function lead_creator_display_names($rows) {
        $directory = array();
        $users = $this->book->sheet('USERS');
        if ($users && is_array($users->rows)) {
            foreach ($users->rows as $user_row) {
                $email = strtolower(trim((string) (isset($user_row[0]) ? $user_row[0] : '')));
                $name = trim((string) (isset($user_row[2]) ? $user_row[2] : ''));
                if ($email !== '' && $name !== '') $directory[$email] = $name;
            }
        }
        foreach ($rows as &$lead) {
            if (!isset($lead[23])) continue;
            $creator = trim((string) $lead[23]);
            if ($creator === '' || strpos($creator, '@') === false) continue;
            $email = strtolower($creator);
            if (isset($directory[$email])) {
                $lead[23] = $directory[$email];
                continue;
            }
            if ($email === 'info@unicybers.com') {
                $lead[23] = 'UniCybers';
                continue;
            }
            if ($email === 'coordinator@unicybers.com') {
                $lead[23] = 'Coordinator';
                continue;
            }
            $local = strstr($creator, '@', true);
            $local = preg_replace('/[._-]+/', ' ', (string) $local);
            $lead[23] = ucwords(trim($local)) !== '' ? ucwords(trim($local)) : $creator;
        }
        unset($lead);
        return $rows;
    }

    public function api_getLeads($token, $query = null) {
        $rows = $this->lead_creator_display_names($this->active_lead_rows($this->auth($token)));
        if (!is_array($query)) return $rows;
        $per = isset($query['per']) ? (int) $query['per'] : 60;
        if ($per < 1) return $rows;
        $per = max(20, min(80, $per));
        $page = max(1, (int) (isset($query['page']) ? $query['page'] : 1));
        $q = strtolower(trim((string) (isset($query['q']) ? $query['q'] : '')));
        $st = (string) (isset($query['status']) ? $query['status'] : '');
        $ow = strtolower((string) (isset($query['owner']) ? $query['owner'] : ''));
        $ty = strtolower((string) (isset($query['type']) ? $query['type'] : ''));
        $filtered = array();
        foreach ($rows as $r) {
            if ($st !== '' && (string) $r[8] !== $st) continue;
            if ($ow !== '' && strtolower((string) $r[7]) !== $ow) continue;
            if ($ty !== '' && strtolower((string) $r[5]) !== $ty) continue;
            if ($q !== '') {
                $hay = strtolower((string) $r[2] . ' ' . (string) $r[3] . ' ' . (string) $r[4] . ' ' . (string) $r[6] . ' ' . (string) (isset($r[26]) ? $r[26] : ''));
                if (strpos($hay, $q) === false) continue;
            }
            $filtered[] = $r;
        }
        $total = count($filtered);
        return array(
            'rows' => array_values(array_slice($filtered, ($page - 1) * $per, $per)),
            'total' => $total,
            'page' => $page,
            'per' => $per,
        );
    }

    public function api_addLead($token, $d) {
        return $this->insert_lead($this->auth($token), is_array($d) ? $d : array());
    }

    private function insert_lead($u, $d) {
        $d = is_array($d) ? $d : array();
        $unit = isset($d['businessUnit']) ? $this->lead_division($d['businessUnit']) : '';
        if ($u && $u['division'] !== 'All') $unit = $this->lead_division($u['division']);
        if ($unit === '') $unit = $this->lead_division(isset($d['division']) ? $d['division'] : (isset($d['category']) ? $d['category'] : (isset($d['service']) ? $d['service'] : '')));
        $d['businessUnit'] = $unit;
        $this->reject_duplicate($d, '');
        $ctx = $this->leads();
        $this->ensure_business_unit_column($ctx);
        $map = $ctx['map'];
        $id = $this->next_lead_id($ctx);
        $row = array_fill(0, max(count($ctx['headers']), 1), '');
        $this->put_mapped($row, $map, 'id', $id);
        $this->put_mapped($row, $map, 'date', $this->now('Y-m-d'));
        $this->put_mapped($row, $map, 'name', isset($d['name']) ? $d['name'] : '');
        $this->put_mapped($row, $map, 'org', isset($d['org']) ? $d['org'] : (isset($d['college']) ? $d['college'] : ''));
        $this->put_mapped($row, $map, 'phone', isset($d['phone']) ? $d['phone'] : '');
        $this->put_mapped($row, $map, 'email', isset($d['email']) ? $d['email'] : '');
        $this->put_mapped($row, $map, 'whatsapp', isset($d['whatsapp']) ? $d['whatsapp'] : '');
        $this->put_mapped($row, $map, 'source', isset($d['source']) ? $d['source'] : '');
        $div = isset($d['division']) && $d['division'] !== '' ? $d['division'] : $this->lead_division(isset($d['category']) ? $d['category'] : (isset($d['service']) ? $d['service'] : ''));
        $this->put_mapped($row, $map, 'division', $div);
        $this->put_mapped($row, $map, 'businessUnit', $unit);
        $cat = isset($d['category']) ? $d['category'] : (isset($d['type']) ? $d['type'] : (isset($d['service']) ? $d['service'] : ''));
        $this->put_mapped($row, $map, 'category', $cat);
        $this->put_mapped($row, $map, 'owner', isset($d['owner']) ? $d['owner'] : '');
        $this->put_mapped($row, $map, 'assignedTo', isset($d['assignedTo']) ? $d['assignedTo'] : '');
        $this->put_mapped($row, $map, 'altPhone', isset($d['altPhone']) ? $d['altPhone'] : '');
        $this->put_mapped($row, $map, 'priority', isset($d['priority']) ? $d['priority'] : 'Medium');
        $this->put_mapped($row, $map, 'status', isset($d['status']) ? $d['status'] : 'New Lead');
        foreach (array('firstContact','lastContact','followup','followupAction','notes','program','students','stage','meetingDate','expectedStart','outcome','revenue','location','service','closed') as $f) {
            if (isset($d[$f])) $this->put_mapped($row, $map, $f, $d[$f]);
        }
        $this->put_mapped($row, $map, 'createdBy', $u['email'] ? $u['email'] : $u['name']);
        $this->put_mapped($row, $map, 'modified', $this->now());
        $ctx['sh']->append($row);
        $this->log_audit('ADD_LEAD', $id, isset($d['name']) ? $d['name'] : '', '');
        $this->telegram('New Lead: ' . (isset($d['name']) ? $d['name'] : '-') . '  Phone: ' . (isset($d['phone']) ? $d['phone'] : '-') . '  Owner: ' . (isset($d['owner']) ? $d['owner'] : '-'));
        return $id;
    }

    public function api_updateLead($token, $id, $d) {
        $u = $this->auth($token);
        $d = is_array($d) ? $d : array();
        $this->reject_duplicate($d, $id);
        $found = $this->find_lead_row($id);
        if (!$found) throw new Exception('Lead not found: ' . $id);
        $this->assert_lead_access($u, $found['row'], $found['ctx']['map']);
        $ctx = $found['ctx'];
        $this->ensure_business_unit_column($ctx);
        $map = $ctx['map'];
        $row = $ctx['sh']->pad($found['row']);
        if ($u['division'] !== 'All') $d['businessUnit'] = $this->lead_division($u['division']);
        $set = function ($field, $key) use (&$row, $map, $d) {
            if (array_key_exists($key, $d)) $this->put_mapped($row, $map, $field, $d[$key]);
        };
        $set('name','name');
        if (array_key_exists('org', $d)) $this->put_mapped($row, $map, 'org', $d['org']);
        elseif (array_key_exists('college', $d)) $this->put_mapped($row, $map, 'org', $d['college']);
        foreach (array('phone','email','whatsapp','source','division','businessUnit','owner','assignedTo','altPhone','priority','firstContact','lastContact','followup','followupAction','notes','revenue','location','service','program','students','stage','meetingDate','expectedStart','outcome','closed') as $f) $set($f, $f);
        if (array_key_exists('category', $d)) $this->put_mapped($row, $map, 'category', $d['category']);
        elseif (array_key_exists('type', $d)) $this->put_mapped($row, $map, 'category', $d['type']);
        if (array_key_exists('status', $d)) {
            $existing = isset($map['followup']) ? (isset($row[$map['followup']]) ? $row[$map['followup']] : '') : '';
            $this->require_followup($d['status'], isset($d['followup']) ? $d['followup'] : null, $existing);
            $this->put_mapped($row, $map, 'status', $d['status']);
        }
        $extra = array(
            'batchstage' => array('Batch Stage', 'batchStage'),
            'mode' => array('Mode', 'mode'),
            'course' => array('Course', 'course'),
            'trainer' => array('Trainer', 'trainer'),
        );
        foreach ($extra as $field => $spec) {
            if (!array_key_exists($spec[1], $d)) continue;
            if (!isset($map[$field])) {
                $ctx['sh']->add_headers(array($spec[0]));
                $map = $this->header_map($ctx['sh']->headers, self::$lead_aliases);
                $row = array_pad($row, count($ctx['sh']->headers), '');
            }
            $this->put_mapped($row, $map, $field, $d[$spec[1]]);
        }
        $this->put_mapped($row, $map, 'modified', $this->now());
        $ctx['sh']->set_row($found['rowNum'], $row);
        $this->queue_academy_handoff($id, $row, $map);
        $this->log_audit('UPDATE_LEAD', $id, isset($d['name']) ? $d['name'] : '', '');
        return true;
    }

    public function api_deleteLead($token, $id) {
        $u = $this->auth($token);
        if (strtolower($u['role']) !== 'admin' && strtolower($u['role']) !== 'superadmin') throw new Exception('Only an admin can permanently delete. Use Archive instead.');
        $found = $this->find_lead_row($id);
        if (!$found) throw new Exception('Lead not found: ' . $id);
        $name = $this->cell($found['row'], $found['ctx']['map'], 'name');
        $found['ctx']['sh']->delete_row($found['rowNum']);
        $this->log_audit('DELETE_LEAD', $id, $name, '');
        return true;
    }

    public function api_archiveLead($token, $id, $reason = '') {
        $this->auth($token);
        $found = $this->find_lead_row($id);
        if (!$found) throw new Exception('Lead not found: ' . $id);
        $map = $found['ctx']['map'];
        if (!isset($map['archived'])) throw new Exception('No "Archived" column in LEADS sheet.');
        $row = $found['row'];
        $row[$map['archived']] = $reason ? $reason : 'Not interested';
        if (isset($map['modified'])) $row[$map['modified']] = $this->now();
        $found['ctx']['sh']->set_row($found['rowNum'], $row);
        $this->log_audit('ARCHIVE_LEAD', $id, $this->cell($found['row'], $map, 'name'), $reason);
        return true;
    }

    public function api_restoreLead($token, $id) {
        $u = $this->auth($token);
        $found = $this->find_lead_row($id);
        if (!$found) throw new Exception('Lead not found: ' . $id);
        $map = $found['ctx']['map'];
        if (!isset($map['archived'])) throw new Exception('Lead not found: ' . $id);
        $row = $found['row'];
        $row[$map['archived']] = '';
        if (isset($map['modified'])) $row[$map['modified']] = $this->now();
        $found['ctx']['sh']->set_row($found['rowNum'], $row);
        $this->log_audit('RESTORE_LEAD', $id, $this->cell($found['row'], $map, 'name'), $u['email']);
        return true;
    }

    public function api_getArchived($token) {
        $u = $this->auth($token);
        $ctx = $this->leads();
        if (!isset($ctx['map']['archived'])) return array();
        $idCol = isset($ctx['map']['id']) ? $ctx['map']['id'] : 0;
        $out = array();
        foreach ($ctx['sh']->rows as $row) {
            if (!isset($row[$idCol]) || trim((string) $row[$idCol]) === '') continue;
            if (!$this->archived_flag(isset($row[$ctx['map']['archived']]) ? $row[$ctx['map']['archived']] : '')) continue;
            $out[] = $this->lead_to_arr($row, $ctx['map']);
        }
        return $this->scope_leads($out, $u);
    }

    public function api_bulkArchiveLeads($token, $ids) {
        $this->auth($token);
        if (!is_array($ids) || !$ids) return 0;
        $ctx = $this->leads();
        if (!isset($ctx['map']['archived'])) throw new Exception('No "Archived" column in LEADS sheet.');
        $want = array();
        foreach ($ids as $id) $want[(string) $id] = true;
        $idCol = isset($ctx['map']['id']) ? $ctx['map']['id'] : 0;
        $n = 0;
        foreach ($ctx['sh']->rows as $i => $row) {
            $id = (string) (isset($row[$idCol]) ? $row[$idCol] : '');
            if (!isset($want[$id])) continue;
            $row[$ctx['map']['archived']] = 'Duplicate / bulk archive';
            if (isset($ctx['map']['modified'])) $row[$ctx['map']['modified']] = $this->now();
            $ctx['sh']->set_row($i + 2, $row);
            $this->log_audit('ARCHIVE_LEAD', $id, isset($row[$ctx['map']['name']]) ? $row[$ctx['map']['name']] : '', 'bulk');
            $n++;
        }
        return $n;
    }

    public function api_bulkSetFollowup($token, $ids, $date) {
        $this->auth($token);
        $ctx = $this->leads();
        if (!isset($ctx['map']['followup'])) throw new Exception('No follow-up date column found in the sheet');
        if (!is_array($ids)) $ids = array();
        $idCol = isset($ctx['map']['id']) ? $ctx['map']['id'] : 0;
        $n = 0;
        foreach ($ctx['sh']->rows as $i => $row) {
            if (!in_array((string) (isset($row[$idCol]) ? $row[$idCol] : ''), array_map('strval', $ids), true)) continue;
            $row[$ctx['map']['followup']] = $date;
            $ctx['sh']->set_row($i + 2, $row);
            $n++;
        }
        $this->log_audit('BULK_FOLLOWUP', implode(',', $ids), $date, $n . ' rows updated');
        return $n;
    }

    public function api_nudgeLead($token, $id, $note = '') {
        $u = $this->auth($token);
        $found = $this->find_lead_row($id);
        if (!$found) throw new Exception('Lead not found: ' . $id);
        $get = function ($f) use ($found) { return trim($this->cell($found['row'], $found['ctx']['map'], $f)); };
        $target = $get('assignedTo') !== '' ? $get('assignedTo') : $get('owner');
        if ($target === '') throw new Exception('This lead has no Assigned To or Owner to notify.');
        $key = 'nudge_' . $id . '_' . ($u['email'] ? $u['email'] : $u['name']);
        if ($this->cache_get($key)) throw new Exception('You already nudged this lead recently. Try again in 30 minutes.');
        $email = $this->resolve_email($target);
        if ($email === '') throw new Exception('No active user named "' . $target . '" in USERS, so there is no email to notify.');
        $nm = $get('name') !== '' ? $get('name') : $id;
        $body = "Hi $target,\n\n" . ($u['name'] ? $u['name'] : $u['email']) . " is requesting an update on this lead.\n\nLead: $nm"
            . ($get('org') ? "\nOrganisation: " . $get('org') : '')
            . "\nStatus: " . ($get('status') !== '' ? $get('status') : '-')
            . "\nNext follow-up: " . ($get('followup') !== '' ? $get('followup') : '-')
            . ($note ? "\n\nMessage: $note" : '')
            . "\n\nPlease update it in the CRM.\n\nUniCybers CRM";
        $this->mail($email, '[UniCybers CRM] Update requested: ' . $nm . ' (' . $id . ')', $body);
        $this->cache_set($key, 1, 1800);
        $this->log_audit('NUDGE', $id, $nm, $target);
        return array('ok' => true, 'to' => $target);
    }

    public function api_uiEscalate($token, $leadId, $note = '', $clear = false) {
        $u = $this->auth($token);
        $found = $this->find_lead_row($leadId);
        if (!$found) throw new Exception('LEAD_NOT_FOUND');
        $sh = $found['ctx']['sh'];
        $m = $this->ensure_headers($sh, array(
            'escalationnote' => 'Escalation Note',
            'escalatedby' => 'Escalated By',
            'escalatedon' => 'Escalated On',
        ));
        $row = $sh->pad($found['row']);
        $txt = $clear ? '' : substr((string) $note, 0, 500);
        $row[$m['escalationnote']] = $txt;
        $row[$m['escalatedby']] = $clear ? '' : ($u['name'] ? $u['name'] : $u['email']);
        $row[$m['escalatedon']] = $clear ? '' : $this->now();
        $sh->set_row($found['rowNum'], $row);
        $this->log_audit($clear ? 'ESCALATION_CLEARED' : 'ESCALATED', $leadId, $txt, $u['email']);
        if (!$clear) {
            $this->telegram("*Needs you*\n$leadId\nFrom: " . ($u['name'] ? $u['name'] : $u['email']) . "\n$txt");
            $report = $this->setting('report_email', '');
            if ($report !== '') $this->mail($report, $this->brand() . ' CRM: ' . ($u['name'] ? $u['name'] : $u['email']) . ' needs you on ' . $leadId, $txt);
        }
        return array('ok' => true);
    }

    public function api_uiSetLeadValues($token, $leadId, $vals) {
        $u = $this->auth($token);
        $vals = is_array($vals) ? $vals : array();
        $found = $this->find_lead_row($leadId);
        if (!$found) throw new Exception('LEAD_NOT_FOUND');
        $sh = $found['ctx']['sh'];
        $need = array();
        $idx = $this->idx_map($sh->headers)['idx'];
        foreach (self::$streams as $s) if (!isset($idx[$this->norm($s . ' Value')])) $need[] = $s . ' Value';
        foreach (array('Amount Received','Payment Status','Delivery Status','Delivery Date') as $h) {
            if (!isset($idx[$this->norm($h)])) $need[] = $h;
        }
        if ($need) { $sh->add_headers($need); $idx = $this->idx_map($sh->headers)['idx']; }
        $row = $sh->pad($found['row']);
        $total = 0;
        foreach (self::$streams as $s) {
            $key = strtolower($s);
            $n = isset($vals[$key]) ? (float) $vals[$key] : 0;
            if ($n < 0) $n = 0;
            $total += $n;
            $col = $this->norm($s . ' Value');
            if (isset($idx[$col])) $row[$idx[$col]] = $n ? $n : '';
        }
        $put = function ($key, $val) use (&$row, $idx) {
            $k = $this->norm($key);
            if (isset($idx[$k]) && $val !== null) $row[$idx[$k]] = $val;
        };
        if (array_key_exists('received', $vals)) $put('amountreceived', $vals['received'] !== '' ? (float) $vals['received'] : '');
        if (array_key_exists('payment', $vals)) $put('paymentstatus', $vals['payment']);
        if (array_key_exists('delivery', $vals)) $put('deliverystatus', $vals['delivery']);
        if (array_key_exists('deliverydate', $vals)) $put('deliverydate', $vals['deliverydate']);
        $map = $this->header_map($sh->headers, self::$lead_aliases);
        if (!isset($map['revenue'])) {
            $sh->add_headers(array('Proposal Value'));
            $map = $this->header_map($sh->headers, self::$lead_aliases);
            $row = array_pad($row, count($sh->headers), '');
        }
        $row[$map['revenue']] = $total ? $total : '';
        $sh->set_row($found['rowNum'], $row);
        $this->log_audit('LEAD_VALUE_SET', $leadId, (string) $total, $u['email']);
        return array('ok' => true, 'total' => $total);
    }

    public function api_uiDraftFollowup($token, $leadId) {
        $u = $this->auth($token);
        $found = $this->find_lead_row($leadId);
        if (!$found) throw new Exception('LEAD_NOT_FOUND');
        $g = function ($f) use ($found) { return $this->cell($found['row'], $found['ctx']['map'], $f); };
        $to = $g('email');
        if ($to === '') throw new Exception('NO_EMAIL_ON_LEAD');
        $facts = "Contact name: " . ($g('name') !== '' ? $g('name') : 'not recorded') . "\n"
            . "Institution: " . ($g('org') !== '' ? $g('org') : 'not recorded') . "\n"
            . "What we discussed (coordinator notes): " . ($g('notes') !== '' ? $g('notes') : 'nothing recorded') . "\n"
            . "Current status: " . ($g('status') !== '' ? $g('status') : 'not recorded') . "\n"
            . "Last contacted: " . ($g('lastContact') !== '' ? $g('lastContact') : 'not recorded') . "\n"
            . "Our contact person: " . ($u['name'] ? $u['name'] : $u['email']) . ", UniCybers";
        $prompt = "Write a short follow-up email from a UniCybers coordinator to a college contact.\n\n"
            . "Return exactly:\nSUBJECT: <subject>\nBODY:\n<the email>\n\nFACTS:\n" . $facts;
        $res = $this->api_aiRequest($token, array('prompt' => $prompt, 'action' => 'followup'));
        $text = isset($res['text']) ? (string) $res['text'] : '';
        $subject = '';
        $body = '';
        $si = strpos($text, 'SUBJECT:');
        $bi = strpos($text, 'BODY:');
        if ($si !== false && $bi !== false && $bi > $si) {
            $subject = trim(substr($text, $si + 8, $bi - ($si + 8)));
            $body = trim(substr($text, $bi + 5));
        } else {
            $subject = 'Following up, ' . ($g('org') !== '' ? $g('org') : 'UniCybers');
            $body = trim($text);
        }
        $this->log_audit('AI_FOLLOWUP_DRAFTED', $leadId, $subject, $u['email']);
        return array('to'=>$to,'subject'=>$subject,'body'=>$body,'contact'=>$g('name'),'org'=>$g('org'));
    }

    public function api_uiSendFollowup($token, $leadId, $subject, $body) {
        $u = $this->auth($token);
        $subject = trim((string) $subject);
        $body = trim((string) $body);
        if ($subject === '') throw new Exception('SUBJECT_REQUIRED');
        if ($body === '') throw new Exception('BODY_REQUIRED');
        $found = $this->find_lead_row($leadId);
        if (!$found) throw new Exception('LEAD_NOT_FOUND');
        $to = $this->cell($found['row'], $found['ctx']['map'], 'email');
        if ($to === '') throw new Exception('NO_EMAIL_ON_LEAD');
        $cc = $this->report_cc(array($u['email']));
        $sig = "\n\n" . ($u['name'] ? $u['name'] : $u['email']) . "\n" . $this->brand();
        $phone = $this->setting('public_phone', '');
        if ($phone !== '') $sig .= "\n" . $phone;
        $this->mail($to, $subject, $body . $sig, array('cc' => implode(',', $cc), 'reply_to' => $u['email']));
        $map = $found['ctx']['map'];
        $row = $found['row'];
        $today = $this->now('Y-m-d');
        if (isset($map['lastContact'])) $row[$map['lastContact']] = $today;
        if (isset($map['modified'])) $row[$map['modified']] = $this->now();
        if (isset($map['notes'])) {
            $prev = isset($row[$map['notes']]) ? (string) $row[$map['notes']] : '';
            $entry = '[' . $today . ' ' . ($u['name'] ? $u['name'] : $u['email']) . '] Follow-up email sent: ' . $subject;
            $row[$map['notes']] = $prev ? $entry . "\n" . $prev : $entry;
        }
        $found['ctx']['sh']->set_row($found['rowNum'], $row);
        $this->log_audit('FOLLOWUP_EMAIL_SENT', $leadId, $subject, $u['email']);
        return array('ok' => true, 'to' => $to, 'cc' => $cc);
    }

    /* ---------- colleges ---------- */

    private function colleges() {
        $sh = $this->book->sheet('COLLEGES');
        if (!$sh->headers) {
            $sh->add_headers(array('College ID','College Name','City','State','Type','Affiliated University','Principal Name','Principal Phone','TPO Name','TPO Phone','TPO Email','HOD Name','HOD Department','HOD Phone','Address','Website','Rating','Status','Assigned Coordinator','Last Visit Date','Next Visit Date','Notes','Archived'));
        }
        return array('sh' => $sh, 'map' => $this->header_map($sh->headers, self::$col_aliases));
    }

    private function col_to_arr($row, $map, $rowNum) {
        $c = function ($f) use ($row, $map) { return $this->cell($row, $map, $f); };
        return array(
            $c('id'),$c('name'),$c('city'),$c('state'),$c('type'),$c('university'),
            $c('principalName'),$c('principalPhone'),$c('tpoName'),$c('tpoPhone'),$c('tpoEmail'),
            $c('hodName'),$c('hodDept'),$c('hodPhone'),$c('address'),$c('website'),$c('rating'),
            $c('status'),$c('coordinator'),$c('lastVisit'),$c('nextVisit'),$c('notes'),$c('archived'),
            $rowNum, $c('tpoAltPhone'), $c('modified')
        );
    }

    public function api_getColleges($token, $mode = '') {
        $u = $this->auth($token);
        if ($u['division'] === 'Sales') return array();
        $ctx = $this->colleges();
        $want = ($mode === 'archived');
        $out = array();
        foreach ($ctx['sh']->rows as $i => $row) {
            $arr = $this->col_to_arr($row, $ctx['map'], $i + 2);
            $isArc = strtoupper(trim((string) $arr[22])) === 'TRUE';
            if ($want !== $isArc) continue;
            if (trim((string) $arr[1]) !== '' || trim((string) $arr[2]) !== '' || trim((string) $arr[9]) !== '') $out[] = $arr;
        }
        return $out;
    }

    public function api_addCollege($token, $d) {
        $this->auth($token);
        $d = is_array($d) ? $d : array();
        $ctx = $this->colleges();
        $id = 'COL' . $this->now('YmdHis');
        $row = array_fill(0, count($ctx['sh']->headers), '');
        $put = function ($f, $v) use (&$row, $ctx) { $this->put_mapped($row, $ctx['map'], $f, $v); };
        $put('id', $id);
        $put('name', isset($d['name']) ? $d['name'] : '');
        $put('city', isset($d['city']) ? $d['city'] : '');
        $put('state', isset($d['state']) ? $d['state'] : (isset($d['country']) ? $d['country'] : ''));
        $put('type', isset($d['type']) ? $d['type'] : '');
        $put('university', isset($d['university']) ? $d['university'] : '');
        $put('tpoName', isset($d['tpoName']) ? $d['tpoName'] : (isset($d['contact']) ? $d['contact'] : ''));
        $put('tpoPhone', isset($d['tpoPhone']) ? $d['tpoPhone'] : (isset($d['phone']) ? $d['phone'] : ''));
        $put('tpoAltPhone', isset($d['tpoAltPhone']) ? $d['tpoAltPhone'] : '');
        $put('tpoEmail', isset($d['tpoEmail']) ? $d['tpoEmail'] : (isset($d['email']) ? $d['email'] : ''));
        $put('status', isset($d['status']) ? $d['status'] : 'In Discussion');
        $put('coordinator', isset($d['coordinator']) ? $d['coordinator'] : '');
        $put('website', isset($d['website']) ? $d['website'] : '');
        $put('address', isset($d['address']) ? $d['address'] : '');
        $put('notes', isset($d['notes']) ? $d['notes'] : '');
        $put('modified', $this->now());
        $ctx['sh']->append($row);
        $this->log_audit('ADD_COLLEGE', $id, isset($d['name']) ? $d['name'] : '', '');
        return $id;
    }

    public function api_deleteCollege($token, $rowNum) {
        $this->auth($token);
        $ctx = $this->colleges();
        if (!isset($ctx['map']['archived'])) throw new Exception('No "Archived" column in COLLEGES sheet. Add one to enable archiving.');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $ctx['sh']->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $ctx['sh']->set($rowNum, $ctx['map']['archived'] + 1, 'TRUE');
        $this->log_audit('ARCHIVE_COLLEGE', 'row ' . $rowNum, (string) $ctx['sh']->get($rowNum, isset($ctx['map']['name']) ? $ctx['map']['name'] + 1 : 2), '');
        return true;
    }

    public function api_restoreCollege($token, $rowNum) {
        $this->auth($token);
        $ctx = $this->colleges();
        if (!isset($ctx['map']['archived'])) throw new Exception('No "Archived" column in COLLEGES sheet.');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $ctx['sh']->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $ctx['sh']->set($rowNum, $ctx['map']['archived'] + 1, '');
        $this->log_audit('RESTORE_COLLEGE', 'row ' . $rowNum, '', '');
        return true;
    }

    public function api_syncCollegesFromLeads($token) {
        $this->auth($token);
        $ctx = $this->colleges();
        $existing = array();
        $nameIdx = isset($ctx['map']['name']) ? $ctx['map']['name'] : null;
        foreach ($ctx['sh']->rows as $row) {
            $nm = $nameIdx !== null ? strtolower(trim(preg_replace('/\s+/', ' ', (string) (isset($row[$nameIdx]) ? $row[$nameIdx] : '')))) : '';
            if ($nm !== '') $existing[$nm] = true;
        }
        $lctx = $this->leads();
        $added = 0;
        foreach ($lctx['sh']->rows as $i => $L) {
            $g = function ($f) use ($L, $lctx) {
                if (!isset($lctx['map'][$f])) return '';
                return trim((string) (isset($L[$lctx['map'][$f]]) ? $L[$lctx['map'][$f]] : ''));
            };
            $org = $g('org');
            if ($org === '') continue;
            $cat = strtolower($g('category'));
            if ($cat !== '' && strpos($cat, 'college') === false) continue;
            $key = strtolower(trim(preg_replace('/\s+/', ' ', $org)));
            if ($key === '' || isset($existing[$key])) continue;
            $existing[$key] = true;
            $row = array_fill(0, count($ctx['sh']->headers), '');
            $this->put_mapped($row, $ctx['map'], 'id', 'COL' . $this->now('YmdHis') . '-' . ($i + 2));
            $this->put_mapped($row, $ctx['map'], 'name', $org);
            $this->put_mapped($row, $ctx['map'], 'city', $g('location'));
            $this->put_mapped($row, $ctx['map'], 'tpoName', $g('name'));
            $this->put_mapped($row, $ctx['map'], 'tpoPhone', $g('phone'));
            $this->put_mapped($row, $ctx['map'], 'tpoEmail', $g('email'));
            $this->put_mapped($row, $ctx['map'], 'coordinator', $g('owner'));
            $this->put_mapped($row, $ctx['map'], 'status', 'In Discussion');
            $this->put_mapped($row, $ctx['map'], 'notes', 'Auto-synced from Leads');
            $ctx['sh']->append($row);
            $added++;
        }
        $this->log_audit('SYNC_COLLEGES', (string) $added, 'from leads', '');
        return array('added' => $added);
    }

    /* ---------- visits: stored by the real headers, shown in the UI order ---------- */

    private function visit_view($row, $rowNum, $idx) {
        $g = function ($keys) use ($row, $idx) {
            foreach ((array) $keys as $k) if (isset($idx[$k])) return isset($row[$idx[$k]]) ? $row[$idx[$k]] : '';
            return '';
        };
        $id = trim((string) (isset($row[0]) ? $row[0] : ''));
        if (!preg_match('/^VIS-/i', $id)) {
            $status = isset($row[4]) ? $row[4] : '';
            if (is_bool($status) || strtoupper(trim((string) $status)) === 'TRUE' || strtoupper(trim((string) $status)) === 'FALSE') $status = 'Planned';
            return array(
                isset($row[0]) ? $row[0] : '',
                isset($row[1]) ? $row[1] : '',
                isset($row[2]) ? $row[2] : '',
                isset($row[3]) ? $row[3] : '',
                $status,
                isset($row[5]) ? $row[5] : '',
                isset($row[6]) ? $row[6] : '',
                isset($row[7]) ? $row[7] : '',
                $rowNum,
                isset($row[9]) ? $row[9] : '',
            );
        }
        return array(
            $g(array('collegename','college')),
            $g('date'),
            $g(array('coordinator','assignedto')),
            $g('purpose'),
            $g('status'),
            $g(array('contactperson','contact')),
            $g(array('notes','postvisitnotes')),
            $g(array('createdby')),
            $rowNum,
            $g('outcome'),
        );
    }

    public function api_getVisits($token, $mode = '') {
        $u = $this->auth($token);
        if ($u['division'] === 'Sales') return array();
        $sh = $this->book->sheet('VISIT_PLAN');
        if (!$sh->headers) return array();
        $idx = $this->idx_map($sh->headers)['idx'];
        $want = ($mode === 'archived');
        $out = array();
        foreach ($sh->rows as $i => $row) {
            $view = $this->visit_view($row, $i + 2, $idx);
            if (trim((string) $view[0]) === '' && trim((string) (isset($row[0]) ? $row[0] : '')) === '') continue;
            $arch = isset($idx['archived']) ? strtoupper(trim((string) (isset($row[$idx['archived']]) ? $row[$idx['archived']] : ''))) : '';
            $isArc = ($arch === 'TRUE');
            if ($want !== $isArc) continue;
            $out[] = $view;
        }
        return array_reverse($out);
    }

    private function visit_put($sh, $rowNum, $d, $createdBy) {
        $idx = $this->idx_map($sh->headers)['idx'];
        $pairs = array(
            'collegename' => isset($d['college']) ? $d['college'] : '',
            'date' => isset($d['date']) ? $d['date'] : '',
            'coordinator' => isset($d['coordinator']) ? $d['coordinator'] : '',
            'purpose' => isset($d['purpose']) ? $d['purpose'] : '',
            'status' => isset($d['status']) ? $d['status'] : 'Planned',
            'contactperson' => isset($d['contact']) ? $d['contact'] : '',
            'notes' => isset($d['notes']) ? $d['notes'] : '',
        );
        if ($createdBy !== null) $pairs['createdby'] = $createdBy;
        if ($rowNum === null) {
            $row = array_fill(0, count($sh->headers), '');
            if (isset($idx['visitid']) && trim((string) $row[$idx['visitid']]) === '') {
                $row[$idx['visitid']] = 'VIS-' . $this->now('YmdHis');
            }
        } else {
            $row = $sh->pad($sh->rows[$rowNum - 2]);
        }
        foreach ($pairs as $key => $val) {
            if (!isset($idx[$key]) && $key === 'createdby' && $createdBy !== null) {
                $sh->add_headers(array('Created By'));
                $idx = $this->idx_map($sh->headers)['idx'];
                $row = array_pad($row, count($sh->headers), '');
            }
            if (isset($idx[$key])) $row[$idx[$key]] = $val;
        }
        if ($rowNum === null) $sh->append($row);
        else $sh->set_row($rowNum, $row);
    }

    public function api_addVisit($token, $d) {
        $u = $this->auth($token);
        $d = is_array($d) ? $d : array();
        $sh = $this->book->sheet('VISIT_PLAN');
        if (!$sh->headers) throw new Exception('VISIT_PLAN sheet not found');
        $this->visit_put($sh, null, $d, $u['name'] ? $u['name'] : $u['email']);
        $this->stamp_college_visit(isset($d['college']) ? $d['college'] : '', isset($d['date']) ? $d['date'] : '');
        $this->log_audit('ADD_VISIT', isset($d['college']) ? $d['college'] : '', isset($d['date']) ? $d['date'] : '', isset($d['purpose']) ? $d['purpose'] : '');
        return true;
    }

    public function api_updateVisit($token, $rowNum, $d) {
        $this->auth($token);
        $d = is_array($d) ? $d : array();
        $sh = $this->book->sheet('VISIT_PLAN');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $sh->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $this->visit_put($sh, $rowNum, $d, null);
        $this->log_audit('UPDATE_VISIT', 'row ' . $rowNum, isset($d['college']) ? $d['college'] : '', '');
        return true;
    }

    public function api_completeVisit($token, $rowNum, $d) {
        $this->auth($token);
        $d = is_array($d) ? $d : array();
        if (trim((string) (isset($d['outcome']) ? $d['outcome'] : '')) === '') throw new Exception('Outcome is required to complete a visit.');
        $sh = $this->book->sheet('VISIT_PLAN');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $sh->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $idx = $this->idx_map($sh->headers)['idx'];
        $row = $sh->pad($sh->rows[$rowNum - 2]);
        if (isset($idx['status'])) $row[$idx['status']] = 'Completed';
        if (isset($idx['outcome'])) $row[$idx['outcome']] = $d['outcome'];
        if (isset($idx['followupdate']) && isset($d['nextFollowup'])) $row[$idx['followupdate']] = $d['nextFollowup'];
        $noteKey = isset($idx['postvisitnotes']) ? 'postvisitnotes' : (isset($idx['notes']) ? 'notes' : null);
        if ($noteKey && !empty($d['notes'])) {
            $old = (string) $row[$idx[$noteKey]];
            $row[$idx[$noteKey]] = $old ? $old . ' | Post-visit: ' . $d['notes'] : 'Post-visit: ' . $d['notes'];
        }
        if (isset($idx['actualvisitdate'])) $row[$idx['actualvisitdate']] = $this->now('Y-m-d H:i:s');
        $sh->set_row($rowNum, $row);
        $college = isset($idx['collegename']) ? (string) $row[$idx['collegename']] : '';
        $date = isset($idx['date']) ? (string) $row[$idx['date']] : '';
        $this->stamp_college_visit($college, $date);
        $updated = 0;
        if (!empty($d['nextFollowup']) && $college !== '') {
            $lctx = $this->leads();
            if (isset($lctx['map']['org']) && isset($lctx['map']['followup'])) {
                foreach ($lctx['sh']->rows as $i => $lr) {
                    $org = strtolower(trim((string) (isset($lr[$lctx['map']['org']]) ? $lr[$lctx['map']['org']] : '')));
                    $arc = isset($lctx['map']['archived']) ? (string) (isset($lr[$lctx['map']['archived']]) ? $lr[$lctx['map']['archived']] : '') : '';
                    if ($org === '' || $this->archived_flag($arc)) continue;
                    if ($org !== strtolower(trim($college))) continue;
                    $lr[$lctx['map']['followup']] = $d['nextFollowup'];
                    if (isset($lctx['map']['followupAction']) && !empty($d['nextAction'])) $lr[$lctx['map']['followupAction']] = $d['nextAction'];
                    if (isset($lctx['map']['modified'])) $lr[$lctx['map']['modified']] = $this->now();
                    $lctx['sh']->set_row($i + 2, $lr);
                    $updated++;
                }
            }
        }
        $this->log_audit('COMPLETE_VISIT', 'row ' . $rowNum, $college, $d['outcome']);
        return array('ok' => true, 'leadsUpdated' => $updated);
    }

    public function api_archiveVisit($token, $rowNum) {
        $this->auth($token);
        $sh = $this->book->sheet('VISIT_PLAN');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $sh->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $idx = $this->idx_map($sh->headers)['idx'];
        if (!isset($idx['archived'])) {
            $sh->add_headers(array('Archived'));
            $idx = $this->idx_map($sh->headers)['idx'];
        }
        $sh->set($rowNum, $idx['archived'] + 1, 'TRUE');
        $this->log_audit('ARCHIVE_VISIT', 'row ' . $rowNum, '', '');
        return true;
    }

    public function api_restoreVisit($token, $rowNum) {
        $this->auth($token);
        $sh = $this->book->sheet('VISIT_PLAN');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $sh->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $idx = $this->idx_map($sh->headers)['idx'];
        if (isset($idx['archived'])) $sh->set($rowNum, $idx['archived'] + 1, '');
        $this->log_audit('RESTORE_VISIT', 'row ' . $rowNum, '', '');
        return true;
    }

    public function api_nudgeVisit($token, $rowNum, $note = '') {
        $u = $this->auth($token);
        $sh = $this->book->sheet('VISIT_PLAN');
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $sh->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $key = 'nudge_visit_' . $rowNum . '_' . $u['email'];
        if ($this->cache_get($key)) throw new Exception('You already nudged this recently. Try again in 30 minutes.');
        $idx = $this->idx_map($sh->headers)['idx'];
        $row = $sh->rows[$rowNum - 2];
        $who = isset($idx['coordinator']) ? trim((string) $row[$idx['coordinator']]) : '';
        if ($who === '') throw new Exception('This visit has no coordinator to notify.');
        $email = $this->resolve_email($who);
        if ($email === '') throw new Exception('No active user named "' . $who . '" in USERS, so there is no email to notify.');
        $college = isset($idx['collegename']) ? $row[$idx['collegename']] : '';
        $this->mail($email, '[UniCybers CRM] Visit update requested: ' . $college, "Hi $who,\n\n" . $u['name'] . " is requesting an update.\n\n$college\n" . ($note ? "\n$note\n" : '') . "\nUniCybers CRM");
        $this->create_alert($email, 'nudge', 'Visit update: ' . $college, (string) $rowNum);
        $this->cache_set($key, 1, 1800);
        $this->log_audit('NUDGE', 'visit ' . $rowNum, $college, $who);
        return array('ok' => true, 'to' => $who);
    }

    private function stamp_college_visit($college, $date) {
        if ($college === '' || $date === '') return;
        $ctx = $this->colleges();
        if (!isset($ctx['map']['name']) || !isset($ctx['map']['lastVisit'])) return;
        foreach ($ctx['sh']->rows as $i => $row) {
            $nm = isset($row[$ctx['map']['name']]) ? $row[$ctx['map']['name']] : '';
            if (strtolower(trim((string) $nm)) === strtolower(trim($college))) {
                $ctx['sh']->set($i + 2, $ctx['map']['lastVisit'] + 1, $date);
                break;
            }
        }
    }

    /* ---------- quotations ---------- */

    public function api_getQuotationHistory($token, $mode = '') {
        $u = $this->auth($token);
        $sh = $this->book->sheet('QUOTATIONS');
        if (!$sh->headers) return array();
        $idx = $this->idx_map($sh->headers)['idx'];
        $want = ($mode === 'archived');
        $out = array();
        foreach ($sh->rows as $i => $row) {
            if (trim((string) (isset($row[0]) ? $row[0] : '')) === '' && trim((string) (isset($idx['organization']) && isset($row[$idx['organization']]) ? $row[$idx['organization']] : '')) === '') continue;
            $arch = isset($idx['archived']) ? strtoupper(trim((string) $row[$idx['archived']])) : '';
            if ($want !== ($arch === 'TRUE')) continue;
            $g = function ($k) use ($row, $idx) { return isset($idx[$k]) && isset($row[$idx[$k]]) ? $row[$idx[$k]] : ''; };
            $cell3 = isset($row[3]) ? (string) $row[3] : '';
            $legacy = (strpos($cell3, '@') !== false);
            if ($legacy) {
                $status = isset($row[11]) ? $row[11] : 'Sent';
                if (is_bool($status) || strtoupper(trim((string) $status)) === 'TRUE' || trim((string) $status) === '') $status = 'Sent';
                $view = array(
                    isset($row[0]) ? $row[0] : '',
                    '',
                    isset($row[2]) ? $row[2] : '',
                    isset($row[3]) ? $row[3] : '',
                    isset($row[1]) ? $row[1] : '',
                    isset($row[7]) ? $row[7] : 0,
                    $status,
                    '',
                    '',
                    $arch === 'TRUE' ? 'TRUE' : '',
                    $i + 2,
                );
            } else {
            $status = $g('status');
            if (is_bool($status) || strtoupper(trim((string) $status)) === 'TRUE' || trim((string) $status) === '') $status = 'Sent';
            $total = $g('grandtotal');
            if ($total === '' || !is_numeric($total)) $total = $g('totalvalue');
            $view = array(
                $g('quotationid') !== '' ? $g('quotationid') : (isset($row[0]) ? $row[0] : ''),
                '',
                $g('organization'),
                '',
                $g('date'),
                is_numeric($total) ? $total : 0,
                $status,
                $g('approvedby'),
                '',
                $arch === 'TRUE' ? 'TRUE' : '',
                $i + 2,
            );
            }
            if ($u['division'] !== 'All') {
                $dv = $view[8] !== '' ? $view[8] : 'Academy';
                if ($dv !== $u['division']) continue;
            }
            $out[] = $view;
        }
        return array_reverse($out);
    }

    private function quote_row_num($sh, $key) {
        $idx = $this->idx_map($sh->headers)['idx'];
        $col = isset($idx['quotationid']) ? $idx['quotationid'] : 0;
        foreach ($sh->rows as $i => $row) {
            if (trim((string) (isset($row[$col]) ? $row[$col] : '')) === trim((string) $key)) return $i + 2;
        }
        $n = (int) $key;
        if ($n >= 2 && $n <= $sh->last_row()) return $n;
        return 0;
    }

    public function api_archiveQuote($token, $key) {
        $this->auth($token);
        $sh = $this->book->sheet('QUOTATIONS');
        $rowNum = $this->quote_row_num($sh, $key);
        if (!$rowNum) throw new Exception('Quotation not found. Refresh and try again.');
        $idx = $this->idx_map($sh->headers)['idx'];
        if (!isset($idx['archived'])) { $sh->add_headers(array('Archived')); $idx = $this->idx_map($sh->headers)['idx']; }
        $sh->set($rowNum, $idx['archived'] + 1, 'TRUE');
        $this->log_audit('ARCHIVE_QUOTE', (string) $key, '', '');
        return true;
    }

    public function api_restoreQuote($token, $key) {
        $this->auth($token);
        $sh = $this->book->sheet('QUOTATIONS');
        $rowNum = $this->quote_row_num($sh, $key);
        if (!$rowNum) throw new Exception('Quotation not found. Refresh and try again.');
        $idx = $this->idx_map($sh->headers)['idx'];
        if (isset($idx['archived'])) $sh->set($rowNum, $idx['archived'] + 1, '');
        $this->log_audit('RESTORE_QUOTE', (string) $key, '', '');
        return true;
    }

    public function api_sendQuotationFromWeb($token, $d) {
        $u = $this->auth($token);
        $d = is_array($d) ? $d : array();
        $sh = $this->book->sheet('QUOTATIONS');
        if (!$sh->headers) {
            $sh->add_headers(array('Quotation ID','Opportunity ID','Organization','Date','Products / Services','Total Value (₹)','Tax (₹)','Grand Total (₹)','Valid Until','Status','Approved By','Drive Link','Notes'));
        }
        $sub = 0;
        $lines = array();
        $sales = false;
        foreach ((isset($d['items']) && is_array($d['items'])) ? $d['items'] : array() as $item) {
            $qty = isset($item['qty']) ? (float) $item['qty'] : 1;
            $rate = isset($item['rate']) ? (float) $item['rate'] : 0;
            $sub += $qty * $rate;
            $label = (isset($item['service']) ? $item['service'] : '') . (!empty($item['category']) ? ' — ' . $item['category'] : '');
            $lines[] = $label . ' x ' . $qty . ' @ ' . $rate;
            if (isset(self::$sales[trim((string) (isset($item['service']) ? $item['service'] : ''))])) $sales = true;
        }
        $tax = $this->tax_parts($sub);
        $gst = $tax['amount'];
        $total = $sub + $gst;
        $quotNo = 'UCQ-' . $this->now('Ymd-Hi');
        $idx = $this->idx_map($sh->headers)['idx'];
        $row = array_fill(0, count($sh->headers), '');
        $put = function ($k, $v) use (&$row, $idx) { if (isset($idx[$k])) $row[$idx[$k]] = $v; };
        $put('quotationid', $quotNo);
        $put('organization', isset($d['org']) && $d['org'] !== '' ? $d['org'] : (isset($d['client']) ? $d['client'] : ''));
        $put('date', isset($d['date']) ? $d['date'] : $this->now('Y-m-d'));
        $put('productsservices', implode('; ', $lines));
        $put('totalvalue', $sub);
        $put('tax', round($gst, 2));
        $put('grandtotal', round($total, 2));
        $put('validuntil', isset($d['valid']) ? $d['valid'] : '');
        $put('status', 'Sent');
        $put('approvedby', $u['email']);
        $put('notes', isset($d['notes']) ? $d['notes'] : '');
        $sh->append($row);
        $html = '<p>Quotation <b>' . esc_html($quotNo) . '</b> for ' . esc_html(isset($d['client']) ? $d['client'] : '') . '</p>'
            . '<p>' . esc_html(implode('; ', $lines)) . '</p>'
            . '<p>Subtotal ' . esc_html((string) $sub) . '<br>' . esc_html($tax['label']) . ' ' . esc_html((string) round($gst, 2)) . '<br><b>Total ' . esc_html((string) round($total, 2)) . '</b></p>';
        if (!empty($d['email'])) {
            $this->mail($d['email'], 'Quotation ' . $quotNo . ' — ' . $this->brand(), $html, array('html' => true, 'cc' => implode(',', $this->report_cc())));
        }
        $this->link_quote($d, $sub, $quotNo);
        $this->log_audit('QUOTATION_SENT', $quotNo, isset($d['client']) ? $d['client'] : '', (string) $total);
        return $quotNo;
    }

    private function link_quote($d, $subtotal, $quotNo) {
        try {
            $ctx = $this->leads();
            $email = strtolower(trim((string) (isset($d['email']) ? $d['email'] : '')));
            $org = strtolower(trim((string) (isset($d['org']) ? $d['org'] : (isset($d['client']) ? $d['client'] : ''))));
            $hit = null;
            foreach ($ctx['sh']->rows as $i => $row) {
                if (isset($ctx['map']['archived']) && $this->archived_flag(isset($row[$ctx['map']['archived']]) ? $row[$ctx['map']['archived']] : '')) continue;
                $st = strtolower($this->cell($row, $ctx['map'], 'status'));
                if ($st === 'lost') continue;
                $e = strtolower($this->cell($row, $ctx['map'], 'email'));
                if ($email !== '' && $e === $email) { $hit = array($i, $row); break; }
            }
            if (!$hit && $org !== '') {
                foreach ($ctx['sh']->rows as $i => $row) {
                    if (isset($ctx['map']['archived']) && $this->archived_flag(isset($row[$ctx['map']['archived']]) ? $row[$ctx['map']['archived']] : '')) continue;
                    if (strtolower($this->cell($row, $ctx['map'], 'status')) === 'lost') continue;
                    if (strtolower($this->cell($row, $ctx['map'], 'org')) === $org) { $hit = array($i, $row); break; }
                }
            }
            if (!$hit) return;
            $row = $hit[1];
            $map = $ctx['map'];
            if (!isset($map['revenue'])) {
                $ctx['sh']->add_headers(array('Proposal Value'));
                $map = $this->header_map($ctx['sh']->headers, self::$lead_aliases);
                $row = array_pad($row, count($ctx['sh']->headers), '');
            }
            $row[$map['revenue']] = $subtotal;
            if (isset($map['status'])) {
                $cur = (string) $row[$map['status']];
                if (in_array($cur, array('New','Contacted','Follow-up Due','Meeting Scheduled',''), true)) $row[$map['status']] = 'Proposal Shared';
            }
            if (isset($map['modified'])) $row[$map['modified']] = $this->now();
            $ctx['sh']->set_row($hit[0] + 2, $row);
            $this->log_audit('QUOTE_LINKED_TO_LEAD', isset($map['id']) ? (string) $row[$map['id']] : '', $quotNo, (string) $subtotal);
        } catch (Exception $e) {}
    }

    /* ---------- generic grids, users, tasks, reports ---------- */

    public function api_uiTabs($token) {
        $u = $this->auth($token);
        $tabs = array();
        foreach (self::$tabs as $t) {
            $source = isset($t['src']) ? $t['src'] : $t['key'];
            if ($u['division'] !== 'All') {
                $area = $this->division_for_sheet($source);
                if ($area !== 'Shared' && $area !== $this->lead_division($u['division'])) continue;
            }
            $count = null;
            if (!isset($t['kind']) || $t['kind'] === 'pipeline') {
                if (strtoupper($source) === 'LEADS') $count = count($this->active_lead_rows($u));
                else {
                    $sh = $this->book->sheet($source);
                    if ($sh->headers || $sh->rows) $count = count($sh->rows);
                }
            }
            $tabs[] = array(
                'key' => $t['key'], 'label' => $t['label'], 'group' => $t['group'],
                'kind' => isset($t['kind']) ? $t['kind'] : 'grid',
                'readOnly' => !empty($t['readOnly']),
                'src' => $source,
                'count' => $count,
            );
        }
        return array('tabs' => $tabs);
    }

    public function api_uiGrid($token, $sheetName, $opts = array()) {
        $u = $this->auth($token);
        $this->assert_sheet_access($u, $sheetName);
        $opts = is_array($opts) ? $opts : array();
        $sh = $this->book->sheet($sheetName);
        if (!$sh->headers && !$sh->rows) return array('headers'=>array(),'rows'=>array(),'total'=>0,'missing'=>true);
        $headers = $sh->headers;
        $mask = array();
        foreach ($headers as $i => $h) if (preg_match('/pass|hash|secret|key/i', (string) $h)) $mask[] = $i;
        $arch = -1;
        foreach ($headers as $i => $h) if (strtolower((string) $h) === 'archived') { $arch = $i; break; }
        $show = !empty($opts['archived']);
        $search = strtolower((string) (isset($opts['search']) ? $opts['search'] : ''));
        $leadMap = strtoupper((string) $sheetName) === 'LEADS' ? $this->header_map($headers, self::$lead_aliases) : array();
        $out = array();
        foreach ($sh->rows as $r => $row) {
            if ($leadMap && $u['division'] !== 'All' && $this->lead_business_unit($row, $leadMap) !== $this->lead_division($u['division'])) continue;
            if ($arch > -1 && !$show) {
                $av = trim((string) (isset($row[$arch]) ? $row[$arch] : ''));
                if ($av !== '' && strtoupper($av) !== 'FALSE' && $av !== '0') continue;
            }
            $ser = array();
            foreach ($headers as $ci => $h) {
                if (in_array($ci, $mask, true)) { $ser[] = '••••'; continue; }
                $ser[] = isset($row[$ci]) && $row[$ci] !== null ? $row[$ci] : '';
            }
            if ($search !== '' && strpos(strtolower(implode(' ', $ser)), $search) === false) continue;
            $out[] = array('_row' => $r + 2, 'c' => $ser);
        }
        $page = max(1, (int) (isset($opts['page']) ? $opts['page'] : 1));
        $size = max(10, min(200, (int) (isset($opts['pageSize']) ? $opts['pageSize'] : 50)));
        $start = ($page - 1) * $size;
        return array('headers'=>$headers,'rows'=>array_slice($out, $start, $size),'total'=>count($out),'page'=>$page,'pageSize'=>$size,'archivedCol'=>$arch);
    }

    public function api_uiGridSchema($token, $sheetName) {
        $this->auth($token);
        $sh = $this->book->sheet($sheetName);
        if (!$sh->headers) return array('missing'=>true,'fields'=>array(),'readOnly'=>true);
        $auto = array('archived','timestamp','createdat','created','lastmodified','modifiedat','updatedat');
        $fields = array();
        foreach ($sh->headers as $h) {
            if ($h === '' || preg_match('/pass|hash|secret|key/i', $h)) continue;
            $k = $this->norm($h);
            if (in_array($k, $auto, true)) continue;
            $t = 'text';
            if (preg_match('/(?:^|[^a-z])(?:date|follow-?up|deadline|due|start|end)(?:[^a-z]|$)/i', $h)) $t = 'date';
            elseif (preg_match('/email/i', $h)) $t = 'email';
            elseif (preg_match('/phone|mobile|contact no/i', $h)) $t = 'tel';
            elseif (preg_match('/amount|value|revenue|fee|cost|price|count|qty|quantity|students/i', $h)) $t = 'number';
            elseif (preg_match('/notes|remarks|description|comment|address/i', $h)) $t = 'textarea';
            $fields[] = array('name'=>$h,'key'=>$k,'type'=>$t);
        }
        $ro = in_array($sheetName, array('USERS','AUDIT_TRAIL','COORDINATOR_LOG','TRAINER_LOG','ARCHIVE'), true);
        return array('missing'=>false,'readOnly'=>$ro,'label'=>$sheetName,'fields'=>$fields);
    }

    public function api_uiGridAdd($token, $sheetName, $rec) {
        $u = $this->auth($token);
        $rec = is_array($rec) ? $rec : array();
        if (in_array($sheetName, array('USERS','AUDIT_TRAIL','COORDINATOR_LOG','TRAINER_LOG','ARCHIVE'), true)) throw new Exception('READ_ONLY_TAB');
        $sh = $this->book->sheet($sheetName);
        if (!$sh->headers) throw new Exception('SHEET_NOT_FOUND');
        $row = array();
        $filled = 0;
        foreach ($sh->headers as $h) {
            $k = $this->norm($h);
            if (preg_match('/pass|hash|secret|key/i', (string) $h)) { $row[] = ''; continue; }
            if (isset($rec[$k]) && (string) $rec[$k] !== '') { $row[] = $rec[$k]; $filled++; }
            elseif ($k === 'archived') $row[] = 'FALSE';
            elseif (in_array($k, array('timestamp','createdat','created'), true)) $row[] = $this->now();
            elseif ($k === 'owner') $row[] = $u['name'] ? $u['name'] : $u['email'];
            elseif ($k === 'createdby' || $k === 'addedby') $row[] = $u['email'];
            else $row[] = '';
        }
        if (!$filled) throw new Exception('NOTHING_TO_SAVE');
        $newRow = $sh->append($row);
        $this->log_audit('ADD_' . $sheetName, (string) $newRow, isset($rec['name']) ? $rec['name'] : '', $u['email']);
        return array('ok' => true, 'row' => $newRow);
    }

    public function api_uiArchive($token, $sheetName, $rowNum, $reason = '') {
        $u = $this->auth($token);
        $sh = $this->book->sheet($sheetName);
        if (!$sh->headers) throw new Exception('Sheet not found');
        $idx = $this->idx_map($sh->headers)['idx'];
        if (!isset($idx['archived'])) { $sh->add_headers(array('Archived')); $idx = $this->idx_map($sh->headers)['idx']; }
        $sh->set((int) $rowNum, $idx['archived'] + 1, $reason ? $reason : 'Archived');
        $this->log_audit('ARCHIVE', $sheetName . '#' . $rowNum, $reason ? $reason : 'Archived', $u['email']);
        return array('ok' => true);
    }

    public function api_uiNotInterested($token, $sheetName, $rowNum, $reason = '') {
        return $this->api_uiArchive($token, $sheetName, $rowNum, 'Not interested' . ($reason ? ': ' . $reason : ''));
    }

    public function api_uiDeleteRow($token, $sheetName, $rowNum) {
        $u = $this->require_super($token);
        $sh = $this->book->sheet($sheetName);
        if (!$sh->headers && !$sh->rows) throw new Exception('Sheet not found');
        $sh->delete_row((int) $rowNum);
        $this->log_audit('DELETE_ROW', $sheetName . '#' . $rowNum, 'hard delete by Super Admin', $u['email']);
        return array('ok' => true);
    }

    public function api_uiNudge($token, $sheetName, $rowNum, $note = '') {
        if ($sheetName === 'LEADS') throw new Exception('Use nudgeLead for LEADS.');
        if ($sheetName === 'VISIT_PLAN') throw new Exception('Use nudgeVisit for VISIT_PLAN.');
        $u = $this->auth($token);
        $sh = $this->book->sheet($sheetName);
        $rowNum = (int) $rowNum;
        if ($rowNum < 2 || $rowNum > $sh->last_row()) throw new Exception('Invalid row reference. Reload and try again.');
        $key = 'nudge_' . $sheetName . '_' . $rowNum . '_' . $u['email'];
        if ($this->cache_get($key)) throw new Exception('You already nudged this recently. Try again in 30 minutes.');
        $idx = $this->idx_map($sh->headers)['idx'];
        $row = $sh->rows[$rowNum - 2];
        $owner = '';
        foreach (array('leadowner','assignedto','assignedcoordinator','accountmanager','coordinator','owner','preparedby') as $k) {
            if (isset($idx[$k]) && trim((string) $row[$idx[$k]]) !== '') { $owner = trim((string) $row[$idx[$k]]); break; }
        }
        if ($owner === '') throw new Exception('This record has no owner or assignee to notify.');
        $email = $this->resolve_email($owner);
        if ($email === '') throw new Exception('No active user named "' . $owner . '" in USERS, so there is no email to notify.');
        $this->mail($email, '[UniCybers CRM] Update requested', "Hi $owner,\n\n" . $u['name'] . " is requesting an update on $sheetName row $rowNum.\n\n$note\n\nUniCybers CRM");
        $this->create_alert($email, 'nudge', 'Update requested on ' . $sheetName, (string) $rowNum);
        $this->cache_set($key, 1, 1800);
        $this->log_audit('NUDGE', $sheetName . '#' . $rowNum, $owner, $u['email']);
        return array('ok'=>true,'owner'=>$owner,'emailed'=>true);
    }

    public function api_uiAlerts($token) {
        $u = $this->auth($token);
        $sh = $this->alerts();
        $out = array();
        foreach ($sh->rows as $r) {
            if (strtolower((string) (isset($r[1]) ? $r[1] : '')) !== strtolower($u['email'])) continue;
            if (strtoupper((string) (isset($r[6]) ? $r[6] : '')) === 'TRUE') continue;
            $out[] = array('id'=>$r[0],'type'=>isset($r[2])?$r[2]:'','text'=>isset($r[3])?$r[3]:'','ref'=>isset($r[4])?$r[4]:'','at'=>isset($r[5])?$r[5]:'');
        }
        $out = array_reverse($out);
        return array('alerts'=>$out,'count'=>count($out));
    }

    public function api_uiAlertRead($token, $id) {
        $u = $this->auth($token);
        $sh = $this->alerts();
        foreach ($sh->rows as $i => $r) {
            if ((string) $r[0] === (string) $id && strtolower((string) $r[1]) === strtolower($u['email'])) {
                $sh->set($i + 2, 7, 'TRUE');
                break;
            }
        }
        return array('ok' => true);
    }

    private function alerts() {
        $sh = $this->book->sheet('ALERTS');
        if (!$sh->headers) $sh->add_headers(array('AlertID','ToEmail','Type','Text','Ref','CreatedAt','Read'));
        return $sh;
    }

    private function create_alert($email, $type, $text, $ref) {
        $sh = $this->alerts();
        $sh->append(array('AL' . time() . wp_rand(10, 99), strtolower($email), $type, $text, $ref, $this->now(), 'FALSE'));
    }

    public function api_uiUsers($token) {
        $this->require_admin($token);
        $sh = $this->book->sheet('USERS');
        $out = array();
        foreach ($sh->rows as $i => $r) {
            if (trim((string) (isset($r[0]) ? $r[0] : '')) === '') continue;
            $wpUser = get_user_by('email', strtolower(trim((string) $r[0])));
            $out[] = array(
                'row' => $i + 2,
                'email' => $r[0],
                'name' => isset($r[2]) ? $r[2] : '',
                'role' => isset($r[3]) ? $r[3] : '',
                'division' => isset($r[4]) ? $r[4] : '',
                'active' => strtoupper((string) (isset($r[5]) ? $r[5] : '')) !== 'FALSE',
                'financeRole' => $wpUser ? (string) get_user_meta($wpUser->ID, 'ub_role', true) : '',
            );
        }
        return array('users' => $out);
    }

    public function api_uiUserSave($token, $rec) {
        $u = $this->require_admin($token);
        $rec = is_array($rec) ? $rec : array();
        $email = strtolower(trim((string) (isset($rec['email']) ? $rec['email'] : '')));
        $name = trim((string) (isset($rec['name']) ? $rec['name'] : ''));
        $role = strtolower(trim((string) (isset($rec['role']) ? $rec['role'] : 'coordinator')));
        $division = $this->user_division(isset($rec['division']) ? $rec['division'] : 'All');
        if ($division === '') throw new Exception('Choose All, Academy, Sales, or Services for the user division.');
        if (!preg_match('/^[^@\s]+@[^@\s]+\.[^@\s]+$/', $email)) throw new Exception('Valid email required');
        if ($name === '') throw new Exception('Name required');
        if (!in_array($role, array('superadmin','admin','manager','coordinator','trainer','agent','viewer'), true)) throw new Exception('Invalid role');
        if ($role === 'superadmin' && strtolower($u['role']) !== 'superadmin') throw new Exception('Only a Super Admin can grant the Super Admin role.');
        $sh = $this->book->sheet('USERS');
        $row = isset($rec['row']) ? (int) $rec['row'] : 0;
        if ($row < 2) {
            foreach ($sh->rows as $i => $r) if (strtolower((string) $r[0]) === $email) { $row = $i + 2; break; }
        }
        $pw = (string) (isset($rec['password']) ? $rec['password'] : '');
        $active = (isset($rec['active']) && $rec['active'] === false) ? 'FALSE' : 'TRUE';
        if ($row < 2) {
            if ($pw === '') throw new Exception('Password required for a new user');
            if (!$this->sync_wp_account($email, $pw, $name, $active === 'TRUE')) throw new Exception('Could not create or link the WordPress sign-in for this CRM user. Check that the email is not already used by another WordPress account.');
            $sh->append(array($email, $this->hash_store($pw), $name, $role, $division, $active, ''));
            $this->log_audit('USER_CREATE', $email, $name, $role);
            return array('ok'=>true,'created'=>true);
        }
        $oldEmail = strtolower(trim((string) $sh->get($row, 1)));
        $hash = $pw !== '' ? $this->hash_store($pw) : $sh->get($row, 2);
        $must = $sh->get($row, 7);
        if (!$this->sync_wp_account($oldEmail, $pw, $name, $active === 'TRUE', $email)) throw new Exception('Could not update the linked WordPress sign-in. Check that the new email is not already used by another WordPress account.');
        $sh->set_row($row, array($email, $hash, $name, $role, $division, $active, $must));
        $this->log_audit('USER_UPDATE', $email, $name, $role);
        return array('ok'=>true,'updated'=>true);
    }

    private function sync_wp_account($email, $password = '', $name = '', $active = true, $new_email = '') {
        $email = strtolower(trim((string) $email));
        $new_email = strtolower(trim((string) ($new_email !== '' ? $new_email : $email)));
        if (!is_email($new_email)) return 0;
        $user = $email !== '' ? get_user_by('email', $email) : false;
        if (!$user) $user = get_user_by('email', $new_email);
        $data = array('user_email' => $new_email);
        if (trim((string) $name) !== '') $data['display_name'] = trim((string) $name);
        if (!$user) {
            $login = sanitize_user((string) strtok($new_email, '@'), true);
            if ($login === '') $login = 'ucuser';
            if (username_exists($login)) $login .= '-' . strtolower(wp_generate_password(5, false, false));
            $data['user_login'] = $login;
            $data['user_pass'] = (string) $password !== '' ? (string) $password : wp_generate_password(40, true, true);
            $data['role'] = 'subscriber';
            $id = wp_insert_user($data);
            if (is_wp_error($id)) return 0;
            $user = get_user_by('id', $id);
        } else {
            $data['ID'] = (int) $user->ID;
            $id = wp_update_user($data);
            if (is_wp_error($id)) return 0;
            if ((string) $password !== '') {
                wp_set_password((string) $password, (int) $user->ID);
                if (is_user_logged_in() && get_current_user_id() === (int) $user->ID) {
                    wp_set_current_user((int) $user->ID);
                    wp_set_auth_cookie((int) $user->ID, true, is_ssl());
                }
            }
        }
        if (!$user) return 0;
        update_user_meta($user->ID, 'uc_crm_managed', 1);
        update_user_meta($user->ID, 'uc_crm_active', $active ? 1 : 0);
        return (int) $user->ID;
    }

    public function api_uiFinanceAccessSave($token, $email, $financeRole) {
        $actor = $this->require_admin($token);
        $email = strtolower(trim((string) $email));
        $financeRole = strtolower(trim((string) $financeRole));
        if (!in_array($financeRole, array('', 'none', 'coordinator', 'trainer', 'accountant', 'owner'), true)) throw new Exception('Choose a valid Finance role.');
        if ($financeRole === 'owner' && strtolower($actor['role']) !== 'superadmin') throw new Exception('Only a Super Admin can grant Finance owner access.');
        $sh = $this->book->sheet('USERS');
        $crmUser = null;
        foreach ($sh->rows as $r) {
            if (strtolower(trim((string) (isset($r[0]) ? $r[0] : ''))) === $email) { $crmUser = $r; break; }
        }
        if (!$crmUser) throw new Exception('This email is not a CRM team account.');
        if (strtoupper((string) (isset($crmUser[5]) ? $crmUser[5] : '')) === 'FALSE') throw new Exception('Enable this CRM user before granting Finance access.');
        $existingWpUser = get_user_by('email', $email);
        if ($existingWpUser && (string) get_user_meta($existingWpUser->ID, 'ub_role', true) === 'owner' && strtolower($actor['role']) !== 'superadmin') throw new Exception('Only a Super Admin can change Finance owner access.');
        $id = $this->sync_wp_account($email, '', isset($crmUser[2]) ? $crmUser[2] : '', true);
        if (!$id) throw new Exception('Could not link this CRM account to WordPress.');
        if ($financeRole === '' || $financeRole === 'none') {
            delete_user_meta($id, 'ub_role');
            delete_user_meta($id, 'ub_caps');
        } else {
            update_user_meta($id, 'ub_role', $financeRole);
            update_user_meta($id, 'ub_must_change', 0);
            if ($financeRole === 'accountant') {
                $savedCaps = get_user_meta($id, 'ub_caps', true);
                if (!is_array($savedCaps) || !$savedCaps) update_user_meta($id, 'ub_caps', array('sales'=>1,'finance'=>1,'expenses'=>1,'bank'=>1,'reports'=>1));
            }
            else delete_user_meta($id, 'ub_caps');
        }
        update_user_meta($id, 'uc_crm_managed', 1);
        update_user_meta($id, 'uc_crm_active', 1);
        $this->log_audit('FINANCE_ACCESS_UPDATE', $email, $financeRole === 'none' || $financeRole === '' ? 'removed Finance access' : 'Finance role ' . $financeRole, '');
        return array('ok'=>true,'role'=>$financeRole === 'none' ? '' : $financeRole);
    }

    public function api_uiUserDeleteTransfer($token, $row, $transferTo) {
        $u = $this->require_super($token);
        $sh = $this->book->sheet('USERS');
        $row = (int) $row;
        if ($row < 2 || $row > $sh->last_row()) throw new Exception('Invalid user');
        $fromEmail = strtolower((string) $sh->get($row, 1));
        $fromName = (string) $sh->get($row, 3);
        if ($fromEmail === strtolower($u['email'])) throw new Exception('You cannot delete yourself');
        $toEmail = strtolower(trim((string) $transferTo));
        if ($toEmail === '') throw new Exception('Choose a user to receive the data');
        $toName = '';
        $found = false;
        foreach ($sh->rows as $r) {
            if (strtolower((string) $r[0]) === $toEmail) { $toName = (string) $r[2]; $found = true; break; }
        }
        if (!$found) throw new Exception('Transfer target not found');
        $moved = $this->reassign($fromEmail, $fromName, $toName !== '' ? $toName : $toEmail);
        $wpUser = get_user_by('email', $fromEmail);
        if ($wpUser) {
            update_user_meta($wpUser->ID, 'uc_crm_managed', 1);
            update_user_meta($wpUser->ID, 'uc_crm_active', 0);
            delete_user_meta($wpUser->ID, 'ub_role');
            delete_user_meta($wpUser->ID, 'ub_caps');
        }
        $sh->delete_row($row);
        $this->log_audit('USER_DELETE_TRANSFER', $fromEmail, 'moved ' . $moved . ' records to ' . $toEmail, $u['email']);
        return array('ok'=>true,'moved'=>$moved,'to'=>$toEmail);
    }

    private function reassign($fromEmail, $fromName, $toName) {
        $plan = array(
            'LEADS' => array('leadowner','assignedto'),
            'COLLEGES' => array('assignedcoordinator'),
            'VISIT_PLAN' => array('coordinator'),
            'FOLLOW_UPS' => array('assignedto'),
            'CYBER_OPPORTUNITIES' => array('accountmanager'),
            'PROPOSALS' => array('preparedby'),
        );
        $changed = 0;
        foreach ($plan as $sheet => $cols) {
            $sh = $this->book->sheet($sheet);
            if (!$sh->headers) continue;
            $idx = $this->idx_map($sh->headers)['idx'];
            foreach ($sh->rows as $i => $row) {
                $dirty = false;
                foreach ($cols as $c) {
                    if (!isset($idx[$c])) continue;
                    $cur = strtolower(trim((string) $row[$idx[$c]]));
                    if ($cur === strtolower($fromEmail) || ($fromName !== '' && $cur === strtolower($fromName))) {
                        $row[$idx[$c]] = $toName;
                        $dirty = true;
                        $changed++;
                    }
                }
                if ($dirty) $sh->set_row($i + 2, $row);
            }
        }
        return $changed;
    }

    public function api_getPerformance($token) {
        $u = $this->auth($token);
        $leads = $this->active_lead_rows($u);
        $visits = $this->book->sheet('VISIT_PLAN');
        $vheaders = ($visits && is_array($visits->headers)) ? $visits->headers : array();
        $vrows = ($visits && is_array($visits->rows)) ? $visits->rows : array();
        $vidx = $this->idx_map($vheaders)['idx'];
        $names = array();
        if (strtolower($u['role']) === 'coordinator') $names = array($u['name']);
        else {
            foreach ($this->book->sheet('USERS')->rows as $r) {
                if (strtolower((string) (isset($r[3]) ? $r[3] : '')) === 'coordinator' && strtoupper((string) (isset($r[5]) ? $r[5] : '')) !== 'FALSE' && trim((string) $r[2]) !== '') {
                    $names[] = trim((string) $r[2]);
                }
            }
        }
        $weekStart = $this->now('Y-m-d', 'Africa/Gaborone');
        $dow = (int) $this->now('N', 'Africa/Gaborone');
        $weekStart = $this->date_shift($weekStart, -($dow - 1));
        $today = $this->now('Y-m-d', 'Africa/Gaborone');
        $seen = array();
        $unique = array();
        foreach ($names as $name) {
            $key = strtolower($name);
            if (isset($seen[$key])) continue;
            $seen[$key] = 1;
            $unique[] = $name;
        }
        $names = $unique;
        $members = array();
        foreach ($names as $name) {
            $mine = array();
            foreach ($leads as $r) if (strtolower((string) $r[7]) === strtolower($name)) $mine[] = $r;
            $m = array('name'=>$name,'role'=>'Coordinator','email'=>'','total'=>count($mine));
            foreach ($this->book->sheet('USERS')->rows as $r) {
                if (strtolower(trim((string) $r[2])) === strtolower($name)) { $m['email'] = (string) $r[0]; break; }
            }
            $countSt = function ($st) use ($mine) { $n = 0; foreach ($mine as $r) if ($r[8] === $st) $n++; return $n; };
            $m['contacted'] = $countSt('Contacted');
            $m['followup'] = $countSt('Follow-up Due');
            $m['hot'] = $countSt('Negotiation');
            $m['won'] = $countSt('Won');
            $m['lost'] = $countSt('Lost');
            $m['revenue'] = 0;
            foreach ($mine as $r) if ($r[8] === 'Won') $m['revenue'] += (float) $r[15];
            $m['visits'] = 0;
            $weekVisits = 0;
            foreach ($vrows as $v) {
                if (!is_array($v)) continue;
                $coord = isset($vidx['coordinator']) ? (string) $v[$vidx['coordinator']] : '';
                $st = isset($vidx['status']) ? (string) $v[$vidx['status']] : '';
                $dt = isset($vidx['date']) ? explode(' ', (string) $v[$vidx['date']])[0] : '';
                if (strtolower($coord) === strtolower($name) && $st === 'Completed') {
                    $m['visits']++;
                    if ($dt >= $weekStart) $weekVisits++;
                }
            }
            $weekNew = 0; $weekWon = 0; $weekRev = 0; $over = 0;
            foreach ($mine as $r) {
                $d = explode(' ', (string) $r[1])[0];
                if ($d >= $weekStart) $weekNew++;
                $closed = explode(' ', (string) $r[14])[0];
                if ($r[8] === 'Won' && $closed >= $weekStart) { $weekWon++; $weekRev += (float) $r[15]; }
                $fp = explode(' ', (string) $r[13])[0];
                if ($fp && $fp < $today && $r[8] !== 'Won' && $r[8] !== 'Lost') $over++;
            }
            $m['week'] = array('newLeads'=>$weekNew,'won'=>$weekWon,'revenue'=>$weekRev,'visits'=>$weekVisits,'followups'=>$m['followup'],'overdue'=>$over);
            $members[] = $m;
        }
        $conv = array();
        foreach ($leads as $r) if ($r[8] === 'Won') $conv[] = $r;
        return array('members'=>$members,'convLeads'=>$conv,'weekStart'=>$weekStart,'generatedAt'=>$this->now('d M Y H:i', 'Africa/Gaborone'));
    }

    public function api_uiTrainerSummaryOwn($token) {
        $u = $this->auth($token);
        $ctx = $this->leads();
        $out = array('delivered'=>0,'won'=>0,'agreed'=>0,'collected'=>0,'share'=>0,'rows'=>array());
        $me = strtolower(trim((string) $u['name']));
        if ($me === '' || !isset($ctx['map']['trainer'])) return $out;
        foreach ($ctx['sh']->rows as $row) {
            if (isset($ctx['map']['archived']) && $this->archived_flag(isset($row[$ctx['map']['archived']]) ? $row[$ctx['map']['archived']] : '')) continue;
            if (strtolower(trim($this->cell($row, $ctx['map'], 'trainer'))) !== $me) continue;
            $st = $this->cell($row, $ctx['map'], 'status');
            $val = (float) $this->cell($row, $ctx['map'], 'revenue');
            $got = (float) $this->cell($row, $ctx['map'], 'amountreceived');
            $dv = $this->cell($row, $ctx['map'], 'deliverystatus');
            if ($dv === 'Delivered') $out['delivered']++;
            if ($st === 'Won') { $out['won']++; $out['agreed'] += $val; }
            $out['collected'] += $got;
            $out['rows'][] = array(
                'lead' => $this->cell($row, $ctx['map'], 'name'),
                'org' => $this->cell($row, $ctx['map'], 'org'),
                'course' => $this->cell($row, $ctx['map'], 'course'),
                'mode' => $this->cell($row, $ctx['map'], 'mode'),
                'status' => $st, 'delivery' => $dv, 'agreed' => $val, 'collected' => $got, 'share' => (int) round($got / 2),
            );
        }
        $out['share'] = (int) round($out['collected'] / 2);
        return $out;
    }

    private function task_sheet() {
        $sh = $this->book->sheet('TASKS');
        if (!$sh->headers) {
            $sh->add_headers(array('Task ID','Created','Title','Details','Assigned To','Assigned Email','Due Date','Priority','Status','Meet Link','Created By','Completed On'));
        }
        $idx = $this->idx_map($sh->headers)['idx'];
        $missing = array();
        if (!isset($idx['assignedto']) && !isset($idx['assigned']) && !isset($idx['assignee'])) $missing[] = 'Assigned To';
        if (!isset($idx['assignedemail']) && !isset($idx['assigneeemail']) && !isset($idx['email'])) $missing[] = 'Assigned Email';
        if ($missing) $sh->add_headers($missing);
        return $sh;
    }

    private function task_col($idx, $keys) {
        foreach ($keys as $k) if (isset($idx[$k])) return $idx[$k];
        return null;
    }

    public function api_uiTasks($token) {
        $this->auth($token);
        $sh = $this->task_sheet();
        $idx = $this->idx_map($sh->headers)['idx'];
        $idc = $this->task_col($idx, array('taskid'));
        $out = array();
        foreach ($sh->rows as $row) {
            $id = $idc !== null ? trim((string) (isset($row[$idc]) ? $row[$idc] : '')) : '';
            if ($id === '') continue;
            $g = function ($keys) use ($row, $idx) {
                $c = $this->task_col($idx, $keys);
                return $c === null ? '' : (isset($row[$c]) ? $row[$c] : '');
            };
            $out[] = array(
                'id' => $id,
                'created' => $g(array('created','createdat')),
                'title' => (string) $g(array('title')),
                'details' => (string) $g(array('details','description')),
                'who' => (string) $g(array('assignedto','assigned','assignee')),
                'email' => (string) $g(array('assignedemail','assigneeemail','email')),
                'assignees' => array_values(array_filter(array_map('trim', preg_split('/[,;]+/', (string) $g(array('assignedemail','assigneeemail','email')))))),
                'due' => (string) $g(array('duedate')),
                'priority' => (string) ($g(array('priority')) !== '' ? $g(array('priority')) : 'Medium'),
                'status' => (string) ($g(array('status')) !== '' ? $g(array('status')) : 'Open'),
                'meet' => (string) $g(array('meetlink')),
                'by' => (string) $g(array('createdby')),
                'done' => (string) $g(array('completedon','completedat')),
            );
        }
        return $out;
    }

    public function api_uiTaskUpdate($token, $id, $status) {
        $u = $this->auth($token);
        $sh = $this->task_sheet();
        $idx = $this->idx_map($sh->headers)['idx'];
        $idc = $this->task_col($idx, array('taskid'));
        if ($idc === null) throw new Exception('TASK_NOT_FOUND');
        foreach ($sh->rows as $i => $row) {
            if (trim((string) (isset($row[$idc]) ? $row[$idc] : '')) !== trim((string) $id)) continue;
            $st = $this->task_col($idx, array('status'));
            if ($st !== null) $row[$st] = $status;
            if ($status === 'Done') {
                $done = $this->task_col($idx, array('completedon','completedat'));
                if ($done !== null) $row[$done] = $this->now('Y-m-d');
            }
            $sh->set_row($i + 2, $row);
            $this->log_audit('TASK_' . strtoupper((string) $status), $id, '', $u['email']);
            return array('ok' => true);
        }
        throw new Exception('TASK_NOT_FOUND');
    }

    public function api_uiReport($token, $kind, $opts = array()) {
        $u = $this->auth($token);
        $kind = strtolower(trim((string) $kind));
        $opts = is_array($opts) ? $opts : array();
        $admin_only = array('leads','pipeline','streams','trainer','audit','quotations','proposals','renewals','revenue','conversion','performance');
        if (in_array($kind, $admin_only, true) && !$this->is_admin($u)) {
            throw new Exception('ADMIN_ONLY_REPORT');
        }

        $stamp = $this->now('Y-m-d');
        $sheet_rows = function ($name) {
            $sh = $this->book->sheet($name);
            if (!$sh || !$sh->headers) return array(array('No records available'));
            $out = array($sh->headers);
            foreach ($sh->rows as $row) $out[] = $row;
            return $out;
        };
        $csv = function ($rows) {
            $lines = array();
            foreach ($rows as $r) {
                $cells = array();
                foreach ($r as $v) {
                    $s = (string) $v;
                    // Prevent spreadsheet formula execution when CSV files are opened.
                    if ($s !== '' && preg_match('/^[\s]*[=+\-@]/', $s)) $s = "'" . $s;
                    if (strpos($s, '"') !== false) $s = str_replace('"', '""', $s);
                    if (strpos($s, ',') !== false || strpos($s, "\n") !== false || strpos($s, '"') !== false) $s = '"' . $s . '"';
                    $cells[] = $s;
                }
                $lines[] = implode(',', $cells);
            }
            return "\xEF\xBB\xBF" . implode("\r\n", $lines);
        };
        $result = function ($name, $rows) use ($csv, $stamp) {
            return array('filename' => sanitize_file_name($name . '-' . $stamp . '.csv'), 'csv' => $csv($rows));
        };
        $raw_map = array(
            'leads' => 'LEADS',
            'colleges' => 'COLLEGES',
            'visits' => 'VISIT_PLAN',
            'audit' => 'AUDIT_TRAIL',
            'quotations' => 'QUOTATIONS',
            'tasks' => 'TASKS',
            'followups' => 'FOLLOW_UPS',
            'activities' => 'ACTIVITIES',
            'meetings' => 'MEETINGS',
            'proposals' => 'PROPOSALS',
            'renewals' => 'RENEWALS',
            'academy' => 'ACADEMY_HANDOFF'
        );
        if (isset($raw_map[$kind])) {
            return $result($kind, $sheet_rows($raw_map[$kind]));
        }

        if ($kind === 'source') {
            $stats = $this->api_getStats($token);
            $rows = array(array('Source', 'Lead Count'));
            foreach ((array) $stats['sources'] as $src => $n) $rows[] = array($src, $n);
            return $result('lead-sources', $rows);
        }

        if ($kind === 'pipeline') {
            $ctx = $this->leads();
            $by = array();
            foreach ($ctx['sh']->rows as $row) {
                if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($row, $ctx['map'], 'archived'))) continue;
                if (trim($this->cell($row, $ctx['map'], 'id')) === '') continue;
                $st = $this->cell($row, $ctx['map'], 'status');
                if ($st === '') $st = 'Unknown';
                if (!isset($by[$st])) $by[$st] = array(0, 0);
                $by[$st][0]++;
                $by[$st][1] += (float) $this->cell($row, $ctx['map'], 'revenue');
            }
            $rows = array(array('Status', 'Lead Count', 'Recorded Value'));
            foreach ($by as $st => $pair) $rows[] = array($st, $pair[0], round($pair[1], 2));
            return $result('pipeline-summary', $rows);
        }

        if ($kind === 'streams') {
            $ctx = $this->leads();
            $sh = $ctx['sh'];
            $headers = array_map('strtolower', (array) $sh->headers);
            $fields = array('Labs Value', 'Solutions Value', 'Services Value', 'Academy Value', 'Proposal Value');
            $rows = array(array('Business Stream', 'Recorded Value', 'Lead Records With Value'));
            foreach ($fields as $field) {
                $idx = array_search(strtolower($field), $headers, true);
                $sum = 0; $count = 0;
                if ($idx !== false) foreach ($sh->rows as $r) {
                    if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($r,$ctx['map'],'archived'))) continue;
                    $v = isset($r[$idx]) ? (float) $r[$idx] : 0;
                    if ($v != 0) { $sum += $v; $count++; }
                }
                $rows[] = array($field, round($sum, 2), $count);
            }
            return $result('revenue-by-stream', $rows);
        }

        if ($kind === 'trainer') {
            $ctx = $this->leads();
            $sh = $ctx['sh'];
            $headers = array_map('strtolower', (array) $sh->headers);
            $idx_trainer = array_search('trainer', $headers, true);
            $idx_course = array_search('course', $headers, true);
            $idx_delivery = array_search('delivery status', $headers, true);
            $idx_received = array_search('amount received', $headers, true);
            $groups = array();
            foreach ($sh->rows as $r) {
                if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($r,$ctx['map'],'archived'))) continue;
                $trainer = ($idx_trainer !== false && isset($r[$idx_trainer])) ? trim((string) $r[$idx_trainer]) : '';
                if ($trainer === '') continue;
                if (!isset($groups[$trainer])) $groups[$trainer] = array('records'=>0,'received'=>0,'delivered'=>0,'courses'=>array());
                $groups[$trainer]['records']++;
                if ($idx_received !== false && isset($r[$idx_received])) $groups[$trainer]['received'] += (float) $r[$idx_received];
                if ($idx_delivery !== false && isset($r[$idx_delivery]) && strtolower(trim((string) $r[$idx_delivery])) === 'delivered') $groups[$trainer]['delivered']++;
                if ($idx_course !== false && !empty($r[$idx_course])) $groups[$trainer]['courses'][(string) $r[$idx_course]] = 1;
            }
            $rows = array(array('Trainer','Assigned Records','Delivered Records','Amount Received','Courses'));
            foreach ($groups as $name => $g) $rows[] = array($name,$g['records'],$g['delivered'],round($g['received'],2),implode('; ',array_keys($g['courses'])));
            return $result('trainer-delivery', $rows);
        }

        if ($kind === 'overdue') {
            $ctx = $this->leads();
            $today = $this->now('Y-m-d');
            $rows = array(array('Lead ID','Lead Name','Organisation','Phone','Owner','Status','Follow-up Date','Days Overdue'));
            foreach ($ctx['sh']->rows as $r) {
                if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($r,$ctx['map'],'archived'))) continue;
                $id = $this->cell($r,$ctx['map'],'id');
                $date = substr(trim($this->cell($r,$ctx['map'],'followup')),0,10);
                $status = $this->cell($r,$ctx['map'],'status');
                if ($id === '' || $date === '' || $date >= $today || in_array(strtolower($status),array('won','lost','not interested'),true)) continue;
                $days = (int) floor((strtotime($today) - strtotime($date)) / 86400);
                $rows[] = array($id,$this->cell($r,$ctx['map'],'name'),$this->cell($r,$ctx['map'],'college'),$this->cell($r,$ctx['map'],'phone'),$this->cell($r,$ctx['map'],'owner'),$status,$date,$days);
            }
            return $result('overdue-followups', $rows);
        }

        if ($kind === 'conversion') {
            $ctx = $this->leads();
            $counts = array();
            foreach ($ctx['sh']->rows as $r) {
                if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($r,$ctx['map'],'archived'))) continue;
                if ($this->cell($r,$ctx['map'],'id') === '') continue;
                $status = $this->cell($r,$ctx['map'],'status');
                if ($status === '') $status = 'Unknown';
                if (!isset($counts[$status])) $counts[$status] = 0;
                $counts[$status]++;
            }
            $total = array_sum($counts);
            $rows = array(array('Status','Lead Count','Share Of Active Leads (%)'));
            foreach ($counts as $status => $count) $rows[] = array($status,$count,$total ? round(($count/$total)*100,2) : 0);
            return $result('lead-conversion', $rows);
        }

        if ($kind === 'revenue') {
            $ctx = $this->leads();
            $rows = array(array('Lead ID','Lead Name','Organisation','Owner','Status','Recorded Revenue','Amount Received','Payment Status'));
            foreach ($ctx['sh']->rows as $r) {
                if (isset($ctx['map']['archived']) && $this->archived_flag($this->cell($r,$ctx['map'],'archived'))) continue;
                if ($this->cell($r,$ctx['map'],'id') === '') continue;
                $rows[] = array($this->cell($r,$ctx['map'],'id'),$this->cell($r,$ctx['map'],'name'),$this->cell($r,$ctx['map'],'college'),$this->cell($r,$ctx['map'],'owner'),$this->cell($r,$ctx['map'],'status'),$this->cell($r,$ctx['map'],'revenue'),$this->cell($r,$ctx['map'],'amountreceived'),$this->cell($r,$ctx['map'],'paymentstatus'));
            }
            return $result('revenue-register', $rows);
        }

        if ($kind === 'performance') {
            $perf = $this->api_getPerformance($token);
            $rows = array(array('Coordinator','Email','Total Leads','Contacted','Follow-up Due','Negotiation','Won','Lost','Won Revenue','Completed Visits','Overdue Follow-ups'));
            foreach ((array) $perf['members'] as $m) $rows[] = array($m['name'],$m['email'],$m['total'],$m['contacted'],$m['followup'],$m['hot'],$m['won'],$m['lost'],$m['revenue'],$m['visits'],isset($m['week']['overdue'])?$m['week']['overdue']:0);
            return $result('coordinator-performance', $rows);
        }

        throw new Exception('UNKNOWN_REPORT');
    }

    public function api_aiRequest($token, $opts) {
        $u = $this->auth($token);
        $opts = is_array($opts) ? $opts : array();
        $prompt = trim((string) (isset($opts['prompt']) ? $opts['prompt'] : ''));
        if ($prompt === '') throw new Exception('PROMPT_REQUIRED');
        $provider = strtolower((string) $this->setting('ai_provider', 'claude'));
        $budget = (float) $this->setting('ai_budget', 5);
        $month = $this->now('Y-m');
        $usage = $this->book->sheet('AI_USAGE');
        $spent = 0;
        foreach ($usage->rows as $r) {
            $ts = isset($r[0]) ? substr((string) $r[0], 0, 7) : '';
            if ($ts === $month) $spent += (float) (isset($r[6]) ? $r[6] : 0);
        }
        if ($spent >= $budget) throw new Exception('AI_MONTHLY_BUDGET_REACHED');
        $system = 'You are UniCybers CRM Copilot. Be concise, factual and action-oriented. Do not invent CRM facts.';
        if ($provider === 'openai') {
            $key = $this->setting('openai_key', '');
            if ($key === '') throw new Exception('OPENAI_API_KEY_NOT_CONFIGURED');
            $model = $this->setting('openai_model', 'gpt-4o-mini');
            $res = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
                'timeout' => 40,
                'headers' => array('Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json'),
                'body' => wp_json_encode(array('model'=>$model,'messages'=>array(array('role'=>'system','content'=>$system),array('role'=>'user','content'=>$prompt)),'max_tokens'=>700)),
            ));
            if (is_wp_error($res)) throw new Exception($res->get_error_message());
            $jr = json_decode(wp_remote_retrieve_body($res), true);
            if (!empty($jr['error']['message'])) throw new Exception($jr['error']['message']);
            $text = isset($jr['choices'][0]['message']['content']) ? $jr['choices'][0]['message']['content'] : '';
            $in = isset($jr['usage']['prompt_tokens']) ? (int) $jr['usage']['prompt_tokens'] : 0;
            $out = isset($jr['usage']['completion_tokens']) ? (int) $jr['usage']['completion_tokens'] : 0;
            $cost = ((isset($jr['usage']['total_tokens']) ? (int) $jr['usage']['total_tokens'] : 0)) * 0.0000002;
        } else {
            $key = $this->setting('anthropic_key', '');
            if ($key === '') throw new Exception('ANTHROPIC_API_KEY_NOT_CONFIGURED');
            $model = $this->setting('anthropic_model', 'claude-haiku-4-5-20251001');
            $res = wp_remote_post('https://api.anthropic.com/v1/messages', array(
                'timeout' => 40,
                'headers' => array('x-api-key' => $key, 'anthropic-version' => '2023-06-01', 'Content-Type' => 'application/json'),
                'body' => wp_json_encode(array('model'=>$model,'max_tokens'=>700,'system'=>$system,'messages'=>array(array('role'=>'user','content'=>$prompt)))),
            ));
            if (is_wp_error($res)) throw new Exception($res->get_error_message());
            $aj = json_decode(wp_remote_retrieve_body($res), true);
            if (!empty($aj['error']['message'])) throw new Exception($aj['error']['message']);
            $text = isset($aj['content'][0]['text']) ? $aj['content'][0]['text'] : '';
            $in = isset($aj['usage']['input_tokens']) ? (int) $aj['usage']['input_tokens'] : 0;
            $out = isset($aj['usage']['output_tokens']) ? (int) $aj['usage']['output_tokens'] : 0;
            $cost = ($in * 0.000003) + ($out * 0.000015);
            $provider = 'claude';
        }
        if (!$usage->headers) $usage->add_headers(array('Timestamp','User','Provider','Action','Input Tokens','Output Tokens','Cost USD','Credits'));
        $usage->append(array($this->now(), $u['email'], $provider, isset($opts['action']) ? $opts['action'] : 'copilot', $in, $out, $cost, max(1, (int) ceil($cost * 1000))));
        $this->log_audit('AI_RUN', 'AI', $u['email'], $provider);
        return array('text'=>$text,'provider'=>$provider,'model'=>$model,'costUsd'=>$cost,'cost'=>$cost,'credits'=>max(1, (int) ceil($cost * 1000)));
    }

    /* ---------- support ---------- */

    private function ensure_headers($sh, $map) {
        $idx = $this->idx_map($sh->headers)['idx'];
        $need = array();
        foreach ($map as $key => $label) if (!isset($idx[$key])) $need[] = $label;
        if ($need) { $sh->add_headers($need); $idx = $this->idx_map($sh->headers)['idx']; }
        return $idx;
    }

    private function resolve_email($val) {
        $val = trim((string) $val);
        if ($val === '') return '';
        if (strpos($val, '@') !== false) return strtolower($val);
        $sh = $this->book->sheet('USERS');
        foreach ($sh->rows as $r) {
            if (strtolower(trim((string) (isset($r[2]) ? $r[2] : ''))) === strtolower($val) && strtolower((string) (isset($r[5]) ? $r[5] : '')) !== 'false') {
                return strtolower(trim((string) $r[0]));
            }
        }
        return '';
    }

    private function mail($to, $subject, $body, $opts = array()) {
        if (!$to) return false;
        $headers = array();
        $from = !empty($opts['report'])
            ? $this->setting('report_from_email', 'academy@unicybers.com')
            : $this->setting('from_email', '');
        if ($from !== '') $headers[] = 'From: ' . $this->brand() . ' <' . $from . '>';
        if (!empty($opts['cc'])) $headers[] = 'Cc: ' . $opts['cc'];
        if (!empty($opts['reply_to'])) $headers[] = 'Reply-To: ' . $opts['reply_to'];
        if (!empty($opts['html'])) $headers[] = 'Content-Type: text/html; charset=UTF-8';
        return wp_mail($to, $subject, $body, $headers);
    }

    private function telegram($msg) {
        $token = $this->setting('telegram_token', '');
        $chat = $this->setting('telegram_chat', '');
        if ($token === '' || $chat === '') return false;
        wp_remote_post('https://api.telegram.org/bot' . $token . '/sendMessage', array(
            'timeout' => 8,
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode(array('chat_id' => $chat, 'text' => (string) $msg, 'parse_mode' => 'Markdown')),
        ));
        return true;
    }

    private function log_audit($action, $ref, $detail, $extra) {
        try {
            $sh = $this->book->sheet('AUDIT_TRAIL');
            if (!$sh->headers) {
                $sh->add_headers(array('Audit ID','Timestamp','User','Module','Record ID','Action','Field Changed','Old Value','New Value','IP / Device'));
            }
            $idx = $this->idx_map($sh->headers)['idx'];
            $n = 0;
            if (isset($idx['auditid'])) {
                foreach ($sh->rows as $r) {
                    $s = (string) (isset($r[$idx['auditid']]) ? $r[$idx['auditid']] : '');
                    $p = strpos($s, '-');
                    if ($p !== false) { $num = (int) substr($s, $p + 1); if ($num > $n) $n = $num; }
                }
            }
            $row = array_fill(0, count($sh->headers), '');
            $put = function ($k, $v) use (&$row, $idx) { if (isset($idx[$k])) $row[$idx[$k]] = $v; };
            $who = $this->actor ? $this->actor['email'] : '';
            $put('auditid', 'AUD-' . str_pad((string) ($n + 1), 4, '0', STR_PAD_LEFT));
            $put('timestamp', $this->now());
            $put('user', $who);
            $put('module', $this->audit_module($action));
            $put('recordid', $ref);
            $put('action', $action);
            $put('details', $detail);
            if (!isset($idx['details'])) $put('fieldchanged', $detail);
            $put('newvalue', $extra);
            $put('ipdevice', isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '');
            $sh->append($row);
        } catch (Exception $e) {}
    }

    private function audit_module($action) {
        $a = strtoupper((string) $action);
        if (strpos($a, 'LEAD') !== false) return 'LEADS';
        if (strpos($a, 'COLLEGE') !== false) return 'COLLEGES';
        if (strpos($a, 'VISIT') !== false) return 'VISIT_PLAN';
        if (strpos($a, 'QUOT') !== false) return 'QUOTATIONS';
        if (strpos($a, 'USER') !== false) return 'USERS';
        if (strpos($a, 'LOGIN') !== false || strpos($a, 'PASSWORD') !== false) return 'AUTH';
        if (strpos($a, 'AI') === 0) return 'AI';
        return 'SYSTEM';
    }

    private function date_shift($ymd, $days) {
        $dt = DateTime::createFromFormat('Y-m-d', $ymd, $this->tz($this->zone_name()));
        if (!$dt) return $ymd;
        if ($days >= 0) $dt->modify('+' . $days . ' day');
        else $dt->modify($days . ' day');
        return $dt->format('Y-m-d');
    }
}
