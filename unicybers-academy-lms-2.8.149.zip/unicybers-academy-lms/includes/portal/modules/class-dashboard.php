<?php
/**
 * UniCybers Academy LMS: Dashboard Module.
 *
 * Renders the primary command dashboard with Hero greeting,
 * next class countdown, cached KPIs, action items, and live schedule.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Dashboard {
    public static function render($portal) {
        global $wpdb;
        $user = UC_LMS_Portal_Context::user();
        $name = UC_LMS_Portal_Context::user_name();
        $uid  = UC_LMS_Portal_Context::user_id();
        $role = UC_LMS_Portal_Context::role();
        $ids  = UC_LMS_Portal_Context::in_ids();

        if ($role === 'student' && class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo(wp_get_current_user())) {
            return self::demo_home($name, $portal);
        }

        $o = self::hero($name, $portal);

        if ($role === 'student') {
            // Transient cache for Student KPIs (300 seconds)
            $cache_key = 'uc_kpi_student_' . $uid;
            $kpi_data = get_transient($cache_key);
            if (!$kpi_data || !is_array($kpi_data)) {
                $tb = UC_LMS_Database::table('batches');
                $tm = UC_LMS_Database::table('materials');
                $ta = UC_LMS_Database::table('attendance');

                $courses  = (int)$wpdb->get_var("SELECT COUNT(DISTINCT b.course_id) FROM `$tb` b WHERE b.id IN ({$ids})");
                $upcoming = count($portal->sessions("s.session_date>=CURDATE() AND LOWER(s.status)<>'cancelled'", 's.session_date', 100));
                $mats     = (int)$wpdb->get_var("SELECT COUNT(*) FROM `$tm` WHERE batch_id IN ({$ids}) AND visible=1 AND IFNULL(student_locked,0)=0");
                $att      = UC_LMS_Database::has_table('attendance') ? $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) total, SUM(status='present') present FROM `$ta` WHERE user_id=%d", $uid)) : null;
                $pct      = ($att && $att->total) ? round($att->present * 100 / $att->total) . '%' : '0%';

                $kpi_data = [
                    'courses'  => $courses,
                    'upcoming' => $upcoming,
                    'mats'     => $mats,
                    'pct'      => $pct
                ];
                set_transient($cache_key, $kpi_data, 300);
            }

            $o .= '<div class="kpis">';
            $o .= self::kpi($portal, 'My Courses', $kpi_data['courses'], 'Enrolled Programmes', 'courses', 'blue', $portal->url('courses'));
            $o .= self::kpi($portal, 'Upcoming Classes', $kpi_data['upcoming'], 'Scheduled Sessions', 'classes', 'violet', $portal->url('classes'));
            $o .= self::kpi($portal, 'Materials', $kpi_data['mats'], 'Shared With Your Batch', 'materials', 'amber', $portal->url('materials'));
            $o .= self::kpi($portal, 'Attendance', $kpi_data['pct'], 'Classes Present', 'reports', 'indigo', $portal->url('reports'));
            $o .= '</div>';
            $o .= $portal->student_progress_panel($uid, $ids);
            $o .= '<div class="dash-grid">';
            $o .= '<section class="panel"><div class="ph"><div><span class="eyebrow">LIVE SCHEDULE</span><h3>Upcoming classes</h3></div><a class="link" href="' . esc_url($portal->url('classes')) . '">All classes →</a></div>' . $portal->class_rows($portal->upcoming_rows(16), false, true) . '</section>';
            $o .= '<section class="panel"><div class="ph"><div><span class="eyebrow">ACADEMY</span><h3>Latest announcements</h3></div><a class="link" href="' . esc_url($portal->url('announcements')) . '">All →</a></div>' . $portal->notice_rows(3) . '</section>';
            $o .= '</div>';
            $o .= UC_LMS_Module_Support::training_form($portal);
            return $o;
        }

        // Staff / Admin KPIs with transient cache (180 seconds)
        $cache_key = 'uc_kpi_staff_' . $uid;
        $kpi_data = get_transient($cache_key);
        if (!$kpi_data || !is_array($kpi_data)) {
            $te = UC_LMS_Database::table('enrolments');
            $tb = UC_LMS_Database::table('batches');

            $demo_sql = UC_LMS_Portal_Context::demo_sql();
            $students = (int)$wpdb->get_var("SELECT COUNT(DISTINCT e.user_id) FROM `$te` e JOIN {$wpdb->users} u ON u.ID=e.user_id WHERE e.status='active' AND e.batch_id IN ({$ids}) AND {$demo_sql}");
            $batches  = (int)$wpdb->get_var("SELECT COUNT(*) FROM `$tb` WHERE id IN ({$ids}) AND status='active'");
            $today    = count($portal->sessions("s.session_date=CURDATE() AND LOWER(s.status)<>'cancelled'", 's.start_time', 100));
            $recs     = $portal->playable_recording_count($ids);

            $kpi_data = [
                'students' => $students,
                'batches'  => $batches,
                'today'    => $today,
                'recs'     => $recs
            ];
            set_transient($cache_key, $kpi_data, 180);
        }

        $o .= '<div class="kpis">';
        $o .= self::kpi($portal, 'Active Students', $kpi_data['students'], 'Demo Seats Excluded', 'people', 'green', $portal->ops() ? $portal->url('people') : '');
        $o .= self::kpi($portal, 'Active Batches', $kpi_data['batches'], 'Currently Running', 'batches', 'teal', $portal->url('batches'));
        $o .= self::kpi($portal, 'Classes Today', $kpi_data['today'], 'Scheduled For Today', 'classes', 'violet', $portal->url('classes'));
        $o .= self::kpi($portal, 'Recordings', $kpi_data['recs'], 'Available To Learners', 'materials', 'amber', $portal->url('materials'));
        $o .= '</div>';
        if ($portal->ops()) $o .= UC_LMS_Module_Support::training_queue($portal);
        $o .= '<div class="dash-grid">';
        $o .= '<section class="panel"><div class="ph"><div><span class="eyebrow">LIVE SCHEDULE</span><h3>Today And Next Up</h3></div><a class="link" href="' . esc_url($portal->url('classes')) . '">All Classes →</a></div>' . $portal->class_rows($portal->upcoming_rows(16), false, true) . '</section>';
        $o .= '<section class="panel"><div class="ph"><div><span class="eyebrow">NEEDS ATTENTION</span><h3>Action Items</h3></div></div>' . $portal->attention() . '</section>';
        $o .= '</div>';

        return $o;
    }

    private static function demo_home($name, $portal) {
        $until = (int)get_option('uc_demo_until', 0);
        $left = $until ? 'Open until '.$portal->e(wp_date('g:i A', $until)).'.' : '';
        $o = '<section class="hero"><div><span class="eyebrow">'.self::greeting().'</span><h1>'.$portal->e($name).'</h1><p>This login is only for the live demo. '.$left.'</p></div></section>';
        return $o . self::demo_card($portal);
    }

    public static function demo_card($portal) {
        $meet = esc_url((string)get_option('uc_demo_meet_url'));
        $o = '<section class="panel"><div class="ph"><div><span class="eyebrow">DEMO SESSION</span><h3>Today\'s demo</h3></div></div>';
        $o .= '<p>Academy classes and announcements are not shown here.</p>';
        if ($meet) {
            $o .= '<p><a class="btn primary" target="_blank" rel="noopener" href="'.$meet.'">Open Google Meet</a></p>';
        } else {
            $o .= '<p>The trainer has not posted the Google Meet link yet. It appears here after they save it in Settings, under Demo access.</p>';
        }
        return $o.'</section>';
    }

    private static function greeting() {
        $h = (int)UC_LMS_Portal_Context::now_in_tz()->format('G');
        return $h < 12 ? 'Good morning' : ($h < 17 ? 'Good afternoon' : 'Good evening');
    }

    private static function hero($name, $portal) {
        list($s, $w) = $portal->next_session();
        $date = UC_LMS_Portal_Context::now_in_tz()->format('l, j F Y');
        $desk = esc_url(plugins_url('assets/hero-desk.webp', UC_LMS_FILE));
        $role = UC_LMS_Portal_Context::role();

        $h = '<div class="hero-row"><section class="hero" style="--hero-desk:url(\'' . esc_attr($desk) . '\')">' . $portal->hero_edge() . '<div class="hero-main"><span class="eyebrow on-dark">' . esc_html(strtoupper($date)) . '</span><h2>' . esc_html(self::greeting()) . ', ' . esc_html(strtok($name, ' ')) . '.</h2>';
        $h .= '<p>' . ($role === 'student' ? 'Your classes, materials and attendance.' : 'Here\'s what needs your attention today.') . '</p></div></section>';

        if ($s) {
            $h .= '<div class="next"><div class="next-top"><span class="next-ico">' . $portal->icon('classes') . '</span><span class="eyebrow">' . ($w['live'] ? '<i class="dot live"></i>LIVE NOW' : 'NEXT CLASS') . '</span><a class="next-go" href="' . esc_url($portal->url('classes')) . '" aria-label="Open classes">›</a></div>';
            $h .= '<strong>' . esc_html($s->title) . '</strong><small>' . esc_html($s->batch_name) . ' · ' . esc_html($portal->t12($s->start_time)) . ($s->end_time ? ' to ' . esc_html($portal->t12($s->end_time)) : '') . ' IST</small>';
            $h .= '<div class="cd" data-start="' . ($w['start'] * 1000) . '" data-end="' . ($w['end'] * 1000) . '"><span><b data-u="d">0</b>d</span><span><b data-u="h">00</b>h</span><span><b data-u="m">00</b>m</span><span><b data-u="s">00</b>s</span></div>';
            $h .= '<div class="next-act">' . $portal->join_button($s, $w) . '</div></div>';
        } else {
            $h .= '<div class="next idle"><div class="next-top"><span class="next-ico">' . $portal->icon('classes') . '</span><span class="eyebrow">NEXT CLASS</span></div><strong>Nothing scheduled</strong><small>The countdown appears here as soon as a class is added.</small></div>';
        }
        return $h . '</div>';
    }

    private static function kpi($portal, $label, $value, $sub, $icon, $tone = 'flat', $href = '') {
        $tag = $href ? 'a href="' . esc_url($href) . '"' : 'div';
        return '<' . $tag . ' class="kpi k-' . $tone . '"><span class="kpi-ico">' . $portal->icon($icon) . '</span><div><small>' . esc_html($label) . '</small><strong>' . esc_html($value) . '</strong><em>' . esc_html($sub) . '</em></div></' . ($href ? 'a' : 'div') . '>';
    }
}
