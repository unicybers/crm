<?php
/**
 * UniCybers Academy LMS: Database Migrations & Version Patches.
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('UC_LMS_Database_Migrations')) {
final class UC_LMS_Database_Migrations {

    public static function table($name) {
        return UC_LMS_Database::table($name);
    }

    public static function add_column_if_missing($table, $column, $definition) {
        global $wpdb;
        $full = self::table($table);
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $full));
        if ($exists !== $full) return;
        $column_exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$full` LIKE %s", $column));
        if (!$column_exists) {
            $wpdb->query("ALTER TABLE `$full` ADD `$column` $definition");
        }
    }

    public static function ensure_job_columns() {
        self::add_column_if_missing('jobs', 'track', "varchar(20) NOT NULL DEFAULT 'cyber'");
        self::add_column_if_missing('jobs', 'asks', 'text NULL');
    }

    public static function ensure_profile_columns() {
        foreach ([
            'headline' => 'varchar(255) NULL',
            'field_of_study' => 'varchar(255) NULL',
            'tools' => 'text NULL',
            'relevant_experience' => 'varchar(20) NULL',
            'current_ctc' => 'varchar(80) NULL',
            'willing_to_relocate' => 'varchar(40) NULL',
            'shift_preference' => 'varchar(80) NULL',
            'key_projects' => 'text NULL',
            'state' => 'varchar(100) NULL',
            'postal_code' => 'varchar(20) NULL',
            'nationality' => 'varchar(100) NULL',
        ] as $column => $definition) {
            self::add_column_if_missing('student_profiles', $column, $definition);
        }
    }

    public static function ensure_batch_group_columns() {
        self::add_column_if_missing('batches', 'whatsapp_url', 'text NULL');
        self::add_column_if_missing('batches', 'telegram_url', 'text NULL');
        self::add_column_if_missing('batches', 'discord_url', 'text NULL');
    }

    public static function ensure_ist_batch_timezones() {
        global $wpdb;
        $t = self::table('batches');
        $has = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
        if (!$has) return;
        $utc = ['UTC','GMT','GMT+0','GMT0','Etc/UTC','Etc/GMT','Etc/GMT+0','UTC+0','UTC+00','+00:00','+00','0','Z','ist','IST','India','Asia/Calcutta'];
        $in = implode(',', array_map(function($z) use ($wpdb){ return $wpdb->prepare('%s', $z); }, $utc));
        $wpdb->query("UPDATE {$t} SET timezone='Asia/Kolkata' WHERE timezone IS NULL OR timezone='' OR timezone IN ({$in})");
        $def = (string) get_option('uc_default_timezone', 'Asia/Kolkata');
        if ($def === '' || in_array($def, $utc, true)) {
            update_option('uc_default_timezone', 'Asia/Kolkata');
        }
    }

    public static function migrate_legacy_classes() {
        global $wpdb;
        $old = self::table('classes');
        $new = self::table('sessions');
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $old));
        if ($exists !== $old) return;
        $rows = $wpdb->get_results("SELECT * FROM `$old` ORDER BY id ASC");
        foreach ($rows as $r) {
            $already = $wpdb->get_var($wpdb->prepare("SELECT id FROM `$new` WHERE legacy_class_id=%d", $r->id));
            if ($already) continue;
            $wpdb->insert($new, [
                'batch_id' => (int)$r->batch_id,
                'title' => $r->title,
                'session_date' => $r->class_date,
                'start_time' => $r->start_time,
                'end_time' => $r->end_time,
                'platform' => 'zoom',
                'join_url' => $r->zoom_join_url,
                'status' => $r->status ?: 'scheduled',
                'recording_url' => $r->recording_url,
                'zoom_meeting_id' => $r->zoom_meeting_id,
                'legacy_class_id' => (int)$r->id,
                'created_at' => $r->created_at ?: current_time('mysql')
            ]);
        }
    }

    public static function migrate_com_emails() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT ID, user_email, user_login FROM {$wpdb->users} WHERE user_email LIKE '%@unicybers.online'");
        foreach ($rows as $row) {
            $com = preg_replace('/@unicybers\\.online$/i', '@unicybers.com', $row->user_email);
            if (!$com || strcasecmp($com, $row->user_email) === 0) continue;
            $taken = get_user_by('email', $com);
            if ($taken && (int)$taken->ID !== (int)$row->ID) continue;
            wp_update_user(['ID' => (int)$row->ID, 'user_email' => $com]);
            update_user_meta((int)$row->ID, 'uc_email_alias', strtolower($row->user_email));
        }
    }

    public static function clear_staff_password_wall_now() { self::clear_staff_password_wall(); }

    public static function clear_staff_password_wall() {
        $staff = [
            'rafi@unicybers.com','coordinator@unicybers.com','sofia@unicybers.com','noori@unicybers.com',
            'ranjan@unicybers.com','shoaib@unicybers.com',
        ];
        foreach ($staff as $email) {
            $u = get_user_by('email', $email);
            if ($u) delete_user_meta($u->ID, 'uc_must_change');
        }
    }

    public static function ensure_noori_coordinator() {
        $email = 'noori@unicybers.com';
        $u = get_user_by('email', $email);
        if (!$u) {
            $id = wp_insert_user([
                'user_login'   => 'noori',
                'user_email'   => $email,
                'user_pass'    => wp_generate_password(16, true, true),
                'display_name' => 'Noori',
                'role'         => 'uc_coordinator',
            ]);
            if (is_wp_error($id)) return;
            $u = get_user_by('id', $id);
            update_user_meta($id, 'uc_must_change', 1);
        }
        if ($u) {
            $u->set_role('uc_coordinator');
            delete_user_meta($u->ID, 'uc_disabled');
        }
    }

    public static function ensure_home_tenant() {
        self::seed_home_tenant();
    }

    public static function ensure_home_tenant_sidebar_brand() {
        global $wpdb;
        $table = self::table('tenants');
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($exists !== $table || get_option('uc_lms_brand_lockup_28111_done')) return;

        // Normalize only the home UniCybers tenant. White-label tenant rows are not touched.
        $new_logo = 'https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp';
        $wpdb->update($table, [
            'logo_url' => $new_logo,
            'name' => 'UniCybers',
            'product_label' => 'ACADEMY',
        ], ['is_home' => 1]);

        // Migrate only known old UniCybers defaults. Client-specific branding remains unchanged.
        if (get_option('uc_academy_name') === 'UniCybers Academy') update_option('uc_academy_name', 'UniCybers');
        if (get_option('uc_product_label') === 'ACADEMY LMS' || get_option('uc_product_label') === '') update_option('uc_product_label', 'ACADEMY');
        update_option('uc_logo_url', $new_logo);
        update_option('uc_lms_brand_lockup_28111_done', 1, false);
    }

    public static function seed_home_tenant() {
        global $wpdb;
        $table = self::table('tenants');
        $has = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ($has !== $table) return;
        $home = $wpdb->get_row("SELECT * FROM $table WHERE is_home=1 ORDER BY id ASC LIMIT 1");
        if ($home) {
            if (!get_option('uc_home_tenant_id')) update_option('uc_home_tenant_id', (int)$home->id, false);
            return;
        }
        $wpdb->insert($table, [
            'slug' => 'unicybers',
            'name' => 'UniCybers',
            'legal_name' => 'UniCybers Academy',
            'tagline' => 'Learn · Practice · Prove · Advance',
            'product_label' => 'ACADEMY',
            'logo_url' => plugins_url('assets/unicybers-emblem.svg', UC_LMS_FILE),
            'accent' => '#FF6B1A',
            'accent2' => '#FF8A3D',
            'support_email' => 'support@unicybers.com',
            'mail_from' => 'academy@unicybers.com',
            'website' => 'https://unicybers.com',
            'portal_domain' => '',
            'timezone' => 'Asia/Kolkata',
            'phone' => '+91 86880 22686',
            'status' => 'live',
            'is_home' => 1,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ]);
        update_option('uc_home_tenant_id', (int)$wpdb->insert_id, false);
    }

    public static function ensure_academy_super_admin() {
        $email = 'academy@unicybers.com';
        $u = get_user_by('email', $email);
        if (!$u) {
            $pw = class_exists('UC_LMS_Security') ? UC_LMS_Security::temp_password() : wp_generate_password(12, false, false);
            $id = wp_insert_user([
                'user_login' => 'academy',
                'user_email' => $email,
                'user_pass' => $pw,
                'display_name' => 'Academy',
                'role' => 'administrator',
            ]);
            if (is_wp_error($id)) return;
            $u = get_user_by('id', $id);
            if ($u && class_exists('UC_LMS_Security')) UC_LMS_Security::send_credentials($u, $pw, 'Your Super Admin account is ready.');
        }
        if ($u) {
            $u->set_role('administrator');
            delete_user_meta($u->ID, 'uc_disabled');
            delete_user_meta($u->ID, 'uc_archived');
            delete_user_meta($u->ID, 'uc_must_change');
        }
    }

    public static function ensure_meet_session_columns() {
        self::add_column_if_missing('sessions', 'calendar_event_id', 'varchar(255) NULL');
        self::add_column_if_missing('sessions', 'meet_space_name', 'varchar(255) NULL');
        self::add_column_if_missing('sessions', 'meet_code', 'varchar(100) NULL');
    }

    /** Add lightweight metadata fields for Drive imports and recurring/provider meetings. */
    public static function ensure_integrations_columns() {
        self::add_column_if_missing('materials', 'drive_file_id', 'varchar(255) NULL');
        self::add_column_if_missing('batches', 'default_meeting_provider', "varchar(30) NOT NULL DEFAULT 'zoom'");
        self::add_column_if_missing('materials', 'source', "varchar(20) NOT NULL DEFAULT 'manual'");
        self::add_column_if_missing('materials', 'mime_type', 'varchar(160) NULL');
        self::add_column_if_missing('materials', 'modified_time', 'datetime NULL');
        self::add_column_if_missing('materials', 'drive_path', 'text NULL');
        self::add_column_if_missing('sessions', 'recurring_group', 'varchar(64) NULL');
        self::add_column_if_missing('sessions', 'recurring_days', 'varchar(30) NULL');
        self::add_column_if_missing('sessions', 'recurring_until', 'date NULL');
        self::add_column_if_missing('sessions', 'provider_meeting_id', 'varchar(255) NULL');
        self::add_column_if_missing('sessions', 'provider_data', 'longtext NULL');
        global $wpdb;
        $materials = self::table('materials');
        $sessions = self::table('sessions');
        $idx1 = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM `{$materials}` WHERE Key_name=%s", 'drive_file_id'));
        if (!$idx1) $wpdb->query("ALTER TABLE `{$materials}` ADD KEY drive_file_id (drive_file_id)");
        $idx2 = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM `{$sessions}` WHERE Key_name=%s", 'recurring_group'));
        if (!$idx2) $wpdb->query("ALTER TABLE `{$sessions}` ADD KEY recurring_group (recurring_group,session_date)");
    }

    public static function ensure_portal_extras() {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $prev = $wpdb->suppress_errors(true);
        ob_start();
        $p = self::table('');
        dbDelta("CREATE TABLE {$p}practice (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint unsigned NOT NULL,
            kind varchar(20) NOT NULL DEFAULT 'assignment',
            title varchar(255) NOT NULL,
            body longtext NULL,
            due_at datetime NULL,
            starts_at datetime NULL,
            ends_at datetime NULL,
            url text NULL,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY batch_id (batch_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}practice_done (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            practice_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            completed_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY one_done (practice_id, user_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}opens (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NOT NULL,
            kind varchar(20) NOT NULL,
            ref_id bigint unsigned NOT NULL,
            opened_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_kind (user_id, kind, ref_id)
        ) $c;");
        $mat = self::table('materials');
        $col = $wpdb->get_results("SHOW COLUMNS FROM `{$mat}` LIKE 'student_locked'");
        if (!$col) $wpdb->query("ALTER TABLE `{$mat}` ADD student_locked tinyint(1) NOT NULL DEFAULT 0");
        $prac = self::table('practice');
        $done = self::table('practice_done');
        if (!$wpdb->get_results("SHOW COLUMNS FROM `{$prac}` LIKE 'paper'")) $wpdb->query("ALTER TABLE `{$prac}` ADD paper longtext NULL");
        if (!$wpdb->get_results("SHOW COLUMNS FROM `{$prac}` LIKE 'brief_url'")) $wpdb->query("ALTER TABLE `{$prac}` ADD brief_url text NULL");
        if (!$wpdb->get_results("SHOW COLUMNS FROM `{$done}` LIKE 'answers'")) $wpdb->query("ALTER TABLE `{$done}` ADD answers longtext NULL");
        if (!$wpdb->get_results("SHOW COLUMNS FROM `{$done}` LIKE 'file_url'")) $wpdb->query("ALTER TABLE `{$done}` ADD file_url text NULL");
        self::add_column_if_missing('tenants', 'portal_domain', "varchar(191) NULL");
        ob_end_clean();
        $wpdb->suppress_errors($prev);
    }

    public static function flag_internal_testers() {
        foreach (['sofia@unicybers.com', 'sofia@unicybers.online', 'mohammedrafi786@gmail.com'] as $email) {
            $u = get_user_by('email', $email);
            if ($u) update_user_meta($u->ID, 'uc_internal_test', 1);
        }
    }


    /**
     * One-time removal of legacy LMS finance data. Finance is now a separate product.
     * Only finance-owned tables/columns are removed; academic, user, attendance,
     * material, meeting, tenant branding and audit tables remain intact.
     */
    public static function remove_legacy_finance_data() {
        global $wpdb;
        if (get_option('uc_lms_finance_cleanup_done') === '1') return;
        $tables = ['invoices','student_payments','trainer_earnings','trainer_payments','expenses','invoice_adjustments'];
        $success = true;
        foreach ($tables as $name) {
            $table = self::table($name);
            $result = $wpdb->query("DROP TABLE IF EXISTS `{$table}`");
            if ($result === false) $success = false;
        }
        // Batch price and currency, plus tenant tax settings, belonged to the removed Finance module.
        $columns = [
            'batches' => ['price','currency'],
            'tenants' => ['tax_percent','tax_label'],
        ];
        foreach ($columns as $table_name => $fields) {
            $table = self::table($table_name);
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
            if ($exists !== $table) continue;
            foreach ($fields as $field) {
                $column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$table}` LIKE %s", $field));
                if ($column) {
                    $result = $wpdb->query("ALTER TABLE `{$table}` DROP COLUMN `{$field}`");
                    if ($result === false) $success = false;
                }
            }
        }
        // Remove the former student-fee fields from WordPress usermeta as well.
        // These keys were used only by the LMS Finance feature.
        $meta_keys = ['uc_total_fees', 'uc_fees_paid', 'uc_fees_pending', 'uc_currency'];
        foreach ($meta_keys as $meta_key) {
            $result = $wpdb->delete($wpdb->usermeta, ['meta_key' => $meta_key], ['%s']);
            if ($result === false) $success = false;
        }
        if ($success) {
            update_option('uc_lms_finance_cleanup_done', '1', false);
            delete_option('uc_default_currency');
            UC_LMS_Database::invalidate_table_cache();
        }
    }

}
}
