<?php
if (!defined('ABSPATH')) exit;
$app = isset($GLOBALS['uc_books_app']) ? $GLOBALS['uc_books_app'] : null;
if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
nocache_headers();
status_header(200);
?><!doctype html>
<html lang="en">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Books - UniCybers</title>
<script>try{var t=localStorage.getItem('uc_lms_theme')||'dark';document.documentElement.setAttribute('data-theme',t);document.addEventListener('DOMContentLoaded',function(){document.body.setAttribute('data-theme',t)})}catch(e){}</script>
<?php if ($app) echo $app->assets(); ?>
</head>
<body class="ub-books">
<?php
if ($app) echo $app->render_front();
else echo '<p>Books is not loaded.</p>';
?>
</body>
</html>
