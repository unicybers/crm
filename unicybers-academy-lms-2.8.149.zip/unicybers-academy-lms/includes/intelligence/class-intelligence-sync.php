<?php
/**
 * UniCybers Academy LMS: Intelligence Sync Engine (Zoom Artefacts & Transcripts).
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Intelligence_Sync {

    public static function api($method, $path, $body = null) {
        if (class_exists('UC_LMS_Zoom') && method_exists('UC_LMS_Zoom', 'request')) {
            return UC_LMS_Zoom::request($method, $path, $body);
        }
        $lms = UC_Academy_LMS::instance();
        if (method_exists($lms, 'portal_zoom_request')) return $lms->portal_zoom_request($method, $path, $body);
        return new WP_Error('zoom', 'Zoom client missing.');
    }

    public static function uuid($session) {
        $u = trim((string)($session->zoom_uuid ?? ''));
        if ($u !== '') return $u;
        return preg_replace('/\D+/', '', (string)($session->zoom_meeting_id ?? ''));
    }

    public static function session_start_ts($session) {
        $tz = 'Asia/Kolkata';
        try { $dtz = new DateTimeZone($tz); } catch (Exception $e) { $dtz = new DateTimeZone('UTC'); }
        $t = trim((string)($session->session_date ?? '').' '.(string)($session->start_time ?? '00:00:00'));
        try { return (new DateTime($t, $dtz))->getTimestamp(); } catch (Exception $e) { return 0; }
    }

    public static function account_summaries() {
        static $rows = null;
        static $err = null;
        if ($rows !== null) return [$rows, $err];
        $rows = [];
        $ranges = [
            [gmdate('Y-m-d', time() - 30 * 86400), gmdate('Y-m-d', time() + 86400)],
            [gmdate('Y-m-d', time() - 60 * 86400), gmdate('Y-m-d', time() - 30 * 86400)],
            [gmdate('Y-m-d', time() - 90 * 86400), gmdate('Y-m-d', time() - 60 * 86400)],
        ];
        foreach ($ranges as $range) {
            $token = '';
            $guard = 0;
            do {
                $q = '/meetings/meeting_summaries?page_size=50&from='.rawurlencode($range[0]).'&to='.rawurlencode($range[1]);
                if ($token !== '') $q .= '&next_page_token='.rawurlencode($token);
                $data = self::api('GET', $q);
                if (is_wp_error($data)) {
                    if (!$rows) $err = $data;
                    break;
                }
                foreach ((array)($data['summaries'] ?? []) as $s) $rows[] = $s;
                $token = (string)($data['next_page_token'] ?? '');
                $guard++;
            } while ($token !== '' && $guard < 8);
        }
        return [$rows, $err];
    }

    public static function match_account_summary($session) {
        list($list, $err) = self::account_summaries();
        $target = self::session_start_ts($session);
        if (!$target) return [null, $err];
        $mid = preg_replace('/\D+/', '', (string)($session->zoom_meeting_id ?? ''));
        $best = null;
        $best_score = -1;
        foreach ($list as $s) {
            if (!is_array($s)) continue;
            $start = (string)($s['meeting_start_time'] ?? $s['summary_start_time'] ?? $s['summary_created_time'] ?? '');
            $ts = $start ? strtotime($start) : 0;
            if (!$ts) continue;
            $diff = abs($ts - $target);
            if ($diff > 8 * 3600) continue;
            $sid = preg_replace('/\D+/', '', (string)($s['meeting_id'] ?? ''));
            $id_ok = $mid !== '' && $sid !== '' && $sid === $mid;
            $score = ($id_ok ? 800 : 0) + max(0, 400 - (int)($diff / 60));
            if ($score > $best_score) { $best = $s; $best_score = $score; }
        }
        return [$best, $err];
    }

    public static function instance_keys($session) {
        $keys = [];
        list($hit) = self::match_account_summary($session);
        if ($hit) {
            foreach (['meeting_uuid', 'uuid'] as $k) {
                $v = trim((string)($hit[$k] ?? ''));
                if ($v !== '' && !in_array($v, $keys, true)) $keys[] = $v;
            }
            $mid = preg_replace('/\D+/', '', (string)($hit['meeting_id'] ?? ''));
            if ($mid !== '' && !in_array($mid, $keys, true)) $keys[] = $mid;
        }
        foreach ([self::uuid($session)] as $v) {
            $v = trim((string)$v);
            if ($v !== '' && !in_array($v, $keys, true)) $keys[] = $v;
        }
        return $keys;
    }

    public static function sync_session($session) {
        if (!is_object($session) || empty($session->id)) return;
        try {
            $sid = (int) $session->id;
            $rec = 'unavailable';
            $st = strtolower((string)($session->recording_status ?? ''));
            $url = trim((string)($session->recording_url ?? ''));
            if ($st === 'available' || $url !== '') $rec = 'available';
            elseif ($st === 'processing') $rec = 'processing';
            $row = [
                'session_id' => $sid,
                'recording_state' => $rec,
                'last_sync' => current_time('mysql'),
                'last_error' => null,
            ];
            $keys = self::instance_keys($session);
            if (!$keys) {
                list(, $list_err) = self::account_summaries();
                $row['transcript_state'] = 'unavailable';
                $row['summary_state'] = 'unavailable';
                $row['participants_state'] = 'unavailable';
                $row['polls_state'] = 'unavailable';
                $row['chapters_state'] = 'unavailable';
                $row['attendance_state'] = 'unavailable';
                $row['tasks_state'] = 'unavailable';
                if (is_wp_error($list_err)) $row['last_error'] = $list_err->get_error_message();
                self::upsert_status($row);
                return;
            }
            foreach ($keys as $k) {
                $enc = self::uuid_path($k);
                if (($row['transcript_state'] ?? '') !== 'available') self::pull_files($session, $enc, $row);
                if (($row['summary_state'] ?? '') !== 'available') self::pull_summary($session, $enc, $row);
                if (($row['participants_state'] ?? '') !== 'available') self::pull_participants($session, $enc, $row);
                if (($row['polls_state'] ?? '') !== 'available') self::pull_polls($session, $enc, $row);
                if (($row['summary_state'] ?? '') === 'available' && ($row['participants_state'] ?? '') === 'available') break;
            }
            if (($row['summary_state'] ?? '') !== 'available') {
                $msg = (string)($row['last_error'] ?? '');
                if ($msg === '' || stripos($msg, 'Meeting does not exist') !== false || stripos($msg, 'not found') !== false) {
                    $row['last_error'] = 'Zoom has no AI summary for this class. Turn on AI Companion meeting summary for the host before the class, then Sync Zoom. A class that already finished without a summary cannot be filled in later.';
                }
            }
            self::upsert_status($row);
        } catch (Throwable $e) {
            error_log('UC LMS intelligence: '.$e->getMessage());
        }
    }



    public static function uuid_path($uuid) {
        return UC_LMS_Intelligence_Ingest::uuid_path($uuid);
    }

    public static function pull_files($session, $enc, &$row) {
        return UC_LMS_Intelligence_Ingest::pull_files($session, $enc, $row);
    }

    public static function pull_summary($session, $enc, &$row) {
        return UC_LMS_Intelligence_Ingest::pull_summary($session, $enc, $row);
    }

    public static function pull_participants($session, $enc, &$row) {
        return UC_LMS_Intelligence_Ingest::pull_participants($session, $enc, $row);
    }

    public static function pull_polls($session, $enc, &$row) {
        return UC_LMS_Intelligence_Ingest::pull_polls($session, $enc, $row);
    }

    public static function scheduled_seconds($session) {
        $start = strtotime($session->session_date.' '.$session->start_time);
        $end = !empty($session->end_time) ? strtotime($session->session_date.' '.$session->end_time) : $start + 7200;
        if ($end <= $start) $end = $start + 7200;
        return max(1, $end - $start);
    }

    public static function soft(WP_Error $e) {
        $m = strtolower($e->get_error_message());
        if (strpos($m, 'scope') !== false || strpos($m, 'permission') !== false || strpos($m, '404') !== false) return 'unavailable';
        return 'failed';
    }

    public static function upsert_status($row) {
        global $wpdb;
        $t_status = self::t('intel_status');
        $old = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t_status} WHERE session_id=%d", (int)$row['session_id']), ARRAY_A);
        $wpdb->replace(self::t('intel_status'), array_merge($old ?: [], $row));
    }

    public static function t($n) {
        global $wpdb;
        return $wpdb->prefix.'uc_'.$n;
    }
}
