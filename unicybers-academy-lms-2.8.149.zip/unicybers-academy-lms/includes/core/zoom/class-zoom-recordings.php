<?php
/**
 * UniCybers Academy LMS: Zoom Cloud Recordings Sync & Ingestion Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Zoom_Recordings {
    const LICENSE_EMAIL = 'training@unicybers.com';

    public static function uuid_path($uuid) {
        return UC_LMS_Zoom_Storage::uuid_path($uuid);
    }

    public static function sync_one_recording_safe($session) {
        $r = self::sync_one_recording($session);
        global $wpdb;
        $fresh = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . UC_LMS_Database::table('sessions') . " WHERE id=%d", (int)$session->id));
        do_action('uc_lms_session_recording_synced', $fresh ?: $session);
        return $r;
    }

    public static function sync_one_recording($session) {
        $data = self::zoom_recording_for_session($session);
        if (is_wp_error($data)) return $data;
        $duration = 0; $mp4 = false; $play = '';
        foreach ((array)($data['recording_files'] ?? []) as $f) {
            if (strtolower((string)($f['file_type'] ?? '')) === 'mp4') {
                $mp4 = true;
                if ($play === '' && !empty($f['play_url'])) $play = (string)$f['play_url'];
            }
            if (!empty($f['recording_start']) && !empty($f['recording_end'])) {
                $a = strtotime($f['recording_start']); $b = strtotime($f['recording_end']);
                if ($a && $b) $duration = max($duration, $b - $a);
            }
        }
        $url = !empty($data['share_url']) ? (string)$data['share_url'] : $play;
        if (!$mp4) {
            if ($url === '') return new WP_Error('recording', 'Zoom has this class but the MP4 is still processing.');
            self::store_session_recording($session, $data, $url, $duration, 'processing');
            return new WP_Error('processing', 'Zoom has this class but the MP4 is still processing.');
        }
        if ($url === '') return new WP_Error('recording', 'Zoom returned no share link for this class.');
        self::store_session_recording($session, $data, $url, $duration, 'available');
        return true;
    }

    public static function portal_sync_recordings_now() {
        global $wpdb;
        $ist = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $today = $ist->format('Y-m-d');
        $nowt = $ist->format('H:i:s');
        $from = (clone $ist)->modify('-14 days')->format('Y-m-d');
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . UC_LMS_Database::table('sessions') . " WHERE hidden=0 AND LOWER(IFNULL(status,''))<>'cancelled' AND LOWER(IFNULL(recording_status,''))<>'discarded' AND session_date BETWEEN %s AND %s AND (LOWER(IFNULL(status,'')) IN ('completed','finished') OR session_date < %s OR (session_date=%s AND IFNULL(end_time,'23:59:00') <= %s)) ORDER BY session_date DESC, start_time DESC LIMIT 80",
            $from, $today, $today, $today, $nowt
        ));
        $pulled = 0; $linked = 0; $processing = 0; $missed = 0; $errors = []; $intel = 0;
        if (function_exists('set_time_limit')) @set_time_limit(0);
        foreach ((array)$rows as $s) {
            $s = UC_LMS_Zoom_Meeting::portal_ensure_meeting_id($s);
            $path = UC_LMS_Zoom_Storage::cached_recording_path($s);
            if ($path && is_file($path) && filesize($path) > 50000) {
                $pulled++;
            } else {
                $r = self::sync_one_recording($s);
                if (is_wp_error($r)) {
                    if ($r->get_error_code() === 'processing') $processing++;
                    else {
                        $missed++;
                        if (count($errors) < 4) $errors[] = $r->get_error_message();
                    }
                } else {
                    $fresh = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . UC_LMS_Database::table('sessions') . " WHERE id=%d", (int)$s->id));
                    if ($fresh) $s = $fresh;
                    $file = self::portal_cache_recording($s);
                    if ($file) $pulled++;
                    else $linked++;
                }
            }
            do_action('uc_lms_session_recording_synced', $s);
            $intel++;
        }
        return ['pulled' => $pulled, 'linked' => $linked, 'processing' => $processing, 'missed' => $missed, 'intel' => $intel, 'errors' => $errors];
    }

    private static function recording_matches($rec, $target) {
        if (empty($rec['recording_files'])) return false;
        if (empty($rec['start_time'])) return false;
        $ts = strtotime((string)$rec['start_time']);
        return $ts && abs($ts - $target) <= 43200;
    }

    private static function zoom_topic_matches($topic, $session) {
        $hay = strtolower(preg_replace('/[^a-z0-9]+/i', ' ', (string)$topic));
        foreach (self::session_labels($session) as $n) {
            $n = strtolower(preg_replace('/[^a-z0-9]+/i', ' ', $n));
            if (strlen($n) < 4) continue;
            if ($hay !== '' && (strpos($hay, $n) !== false || strpos($n, $hay) !== false)) return true;
            foreach (preg_split('/\s+/', $n) as $p) {
                if (strlen($p) >= 5 && strpos($hay, $p) !== false) return true;
            }
        }
        return false;
    }

    private static function zoom_row_seconds($row) {
        $mins = (int)($row['duration'] ?? 0);
        if ($mins > 0) return $mins * 60;
        $sec = 0;
        foreach ((array)($row['recording_files'] ?? []) as $f) {
            if (strtolower((string)($f['file_type'] ?? '')) !== 'mp4') continue;
            if (!empty($f['recording_start']) && !empty($f['recording_end'])) {
                $a = strtotime((string)$f['recording_start']); $b = strtotime((string)$f['recording_end']);
                if ($a && $b) $sec = max($sec, $b - $a);
            }
        }
        return $sec;
    }

    public static function portal_cache_recording($session) {
        return UC_LMS_Zoom_Storage::portal_cache_recording($session);
    }

    public static function zoom_recording_usable($rec) {
        if (empty($rec['recording_files'])) return false;
        foreach ((array)$rec['recording_files'] as $f) {
            if (strtolower((string)($f['file_type'] ?? '')) === 'mp4' && strtolower((string)($f['status'] ?? 'completed')) === 'completed') return true;
        }
        return false;
    }

    public static function zoom_recording_for_session($session) {
        $q = '?include_fields=download_access_token&ttl=86400';
        $target = self::session_start_ts($session);
        if (!empty($session->zoom_uuid)) {
            $r = UC_LMS_Zoom_Client::request('GET', '/meetings/' . self::uuid_path($session->zoom_uuid) . '/recordings' . $q);
            if (!is_wp_error($r) && (self::zoom_recording_usable($r) || !empty($r['share_url']))) return $r;
        }
        $mid = trim((string)($session->zoom_meeting_id ?? ''));
        $best = null; $best_score = -1;
        $from = gmdate('Y-m-d', $target - 86400); $to = gmdate('Y-m-d', $target + 86400);
        foreach ([rawurlencode(self::LICENSE_EMAIL), 'me'] as $user) {
            $list = UC_LMS_Zoom_Client::request('GET', '/users/' . $user . '/recordings?from=' . $from . '&to=' . $to . '&page_size=100');
            if (is_wp_error($list)) continue;
            foreach ((array)($list['meetings'] ?? []) as $row) {
                if (empty($row['uuid']) || empty($row['start_time'])) continue;
                $diff = abs(strtotime((string)$row['start_time']) - $target);
                if ($diff > 43200) continue;
                $id_ok = $mid !== '' && (string)($row['id'] ?? '') === $mid;
                $topic_ok = self::zoom_topic_matches((string)($row['topic'] ?? ''), $session);
                if (!$id_ok && !$topic_ok && $diff > 10800) continue;
                $dur = self::zoom_row_seconds($row);
                if ($dur > 0 && $dur < 60) continue;
                $score = ($id_ok ? 1000 : 0) + ($topic_ok ? 200 : 0) + ($diff <= 10800 ? 150 : 0) + min(400, $dur) - ($diff / 30);
                if ($score > $best_score) { $best = $row; $best_score = $score; }
            }
            if ($best) break;
        }
        if (!$best && $mid !== '') {
            $inst = UC_LMS_Zoom_Client::request('GET', '/past_meetings/' . rawurlencode($mid) . '/instances');
            if (!is_wp_error($inst)) {
                foreach ((array)($inst['meetings'] ?? []) as $row) {
                    if (empty($row['uuid']) || empty($row['start_time'])) continue;
                    $diff = abs(strtotime((string)$row['start_time']) - $target);
                    if ($diff > 43200) continue;
                    $score = 1000 - ($diff / 30);
                    if ($score > $best_score) { $best = $row; $best_score = $score; }
                }
            }
        }
        if ($best) {
            $r = UC_LMS_Zoom_Client::request('GET', '/meetings/' . self::uuid_path($best['uuid']) . '/recordings' . $q);
            if (!is_wp_error($r) && (self::zoom_recording_usable($r) || !empty($r['share_url']))) return $r;
        }
        if ($mid !== '') {
            $r = UC_LMS_Zoom_Client::request('GET', '/meetings/' . rawurlencode($mid) . '/recordings' . $q);
            if (is_wp_error($r)) return $r;
            if (self::recording_matches($r, $target) && (self::zoom_recording_usable($r) || !empty($r['share_url']))) return $r;
        }
        return new WP_Error('recording', 'No Zoom recording matches this class date and time yet.');
    }

    private static function store_session_recording($session, $data, $url, $duration, $status) {
        $token = trim((string)($data['recording_play_passcode'] ?? ''));
        if ($url !== '' && stripos($url, 'zoom.us') !== false) {
            $url = rtrim(preg_replace('/([?&])pwd=[^&]*/', '$1', $url), '?&');
            if ($token !== '') $url .= (strpos($url, '?') === false ? '?' : '&') . 'pwd=' . rawurlencode($token);
        }
        $human = trim((string)($data['password'] ?? ''));
        global $wpdb;
        $now = current_time('mysql');
        $update = [
            'recording_url'      => esc_url_raw($url),
            'recording_status'   => sanitize_key($status),
            'recording_at'       => $now,
            'recording_duration' => (int)$duration,
            'updated_at'         => $now,
            'recording_passcode' => sanitize_text_field($human ?: $token)
        ];
        if (!empty($data['uuid'])) $update['zoom_uuid'] = sanitize_text_field((string)$data['uuid']);
        $ok = $wpdb->update(UC_LMS_Database::table('sessions'), $update, ['id' => $session->id]);
        if ($ok === false) {
            unset($update['recording_passcode']);
            $wpdb->update(UC_LMS_Database::table('sessions'), $update, ['id' => $session->id]);
        }
    }

    private static function session_tz_name($raw = '') {
        $tz = trim((string)$raw);
        $key = strtolower($tz);
        $utc = ['', 'utc', 'gmt', 'gmt+0', 'gmt0', 'etc/utc', 'etc/gmt', 'etc/gmt+0', 'utc+0', 'utc+00', '+00:00', '+00', '0', 'z'];
        if (in_array($key, $utc, true) || $key === 'ist' || $key === 'india' || $key === 'asia/calcutta') return 'Asia/Kolkata';
        try { new DateTimeZone($tz); return $tz; } catch (Exception $e) { return 'Asia/Kolkata'; }
    }

    private static function session_start_ts($session) {
        global $wpdb;
        $tz = $wpdb->get_var($wpdb->prepare("SELECT timezone FROM " . UC_LMS_Database::table('batches') . " WHERE id=%d", (int)$session->batch_id));
        $tz = self::session_tz_name($tz ?: get_option('uc_default_timezone', 'Asia/Kolkata'));
        try { $d = new DateTime($session->session_date . ' ' . $session->start_time, new DateTimeZone($tz)); return $d->getTimestamp(); }
        catch (Exception $e) { return (int)strtotime($session->session_date . ' ' . $session->start_time); }
    }

    private static function session_labels($session) {
        global $wpdb;
        $batch = (string)$wpdb->get_var($wpdb->prepare("SELECT name FROM " . UC_LMS_Database::table('batches') . " WHERE id=%d", (int)$session->batch_id));
        return array_values(array_filter([trim((string)($session->title ?? '')), trim($batch)]));
    }
}
