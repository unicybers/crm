# UniCybers Academy LMS 2.8.111 — Operations and Integration Setup

This is the consolidated operating guide for the 2.8.111 release.

## 1. Google Drive folder hierarchy

Use the existing shared folder as the configured root:

`https://drive.google.com/drive/u/0/folders/1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi`

Create one folder for each existing LMS batch. The batch folder name should match the LMS batch name (case and punctuation are normalized, but use the same name to keep it clear). Create the same category folders inside each batch:

```text
Google Meet  (configured Drive root)
├── EH SOC 1026
│   ├── Notes
│   ├── Slides
│   ├── Labs
│   ├── Assignments
│   ├── Recordings
│   ├── Links
│   └── Other
├── SOC R030926
│   ├── Notes
│   ├── Slides
│   ├── Labs
│   ├── Assignments
│   ├── Recordings
│   ├── Links
│   └── Other
└── Other batch names
    ├── Notes
    ├── Slides
    ├── Labs
    ├── Assignments
    ├── Recordings
    ├── Links
    └── Other
```

The LMS matches a batch folder against an existing LMS batch. Create the batch in the LMS first, then create the Drive folder with that batch's name. Category folders map as follows: Notes → notes; Slides → slides; Labs → labs; Assignments → assignments; Recordings → recordings; Links → links; Other → other.

Files are indexed by Google Drive file ID. The LMS stores the file name, type, modified time, Drive path and viewer link. It does not create a second copy in WordPress uploads. The first scan reads the configured hierarchy. Subsequent scans use the Google Drive Changes API cursor. Manual Sync Drive is available to staff with materials-management access; scheduled sync reuses the existing 10-minute cron job.

### Important: Google Meet recordings

Google Meet normally saves auto-recordings into the organizer's root-level `Meet Recordings` folder. Keep that folder at the root if you use the built-in Google Meet recording matcher. The Meet recording importer scans that dedicated folder and attaches matched recordings to their LMS class sessions. The batch-level `Recordings` folder remains useful for supplemental videos uploaded by trainers, but do not move the source Meet recording out of `Meet Recordings` unless you intend to manage it as a general batch material instead of a class-session recording.

### Important: Zoom recordings

Zoom recordings continue to sync directly through the existing Zoom integration. They do not need to be uploaded to Google Drive. Existing Zoom session and recording references are stored in the LMS database.

## 2. Google Drive sharing

Recommended configuration:

- Share the root folder with the Google Workspace account connected to LMS Settings. Viewer permission is enough to list and index files.
- Give that integration account the file/folder capabilities needed to change download restrictions if you enable the optional Drive restriction. The Drive API reports whether the account can change this setting; if it cannot, the LMS records that protection could not be applied.
- Share each batch folder with the matching Google Group as Viewer when students will use the native Google Drive preview. Example: `eh-soc-1026-students@yourdomain`.
- Do not use “Anyone with the link” for student materials.
- Student Google accounts must have view access to private Drive files for the native Drive preview to work. If you do not want students to have Drive access, use an authenticated storage/streaming service that can deliver content inside the LMS.

The Drive restriction option asks Google to restrict download, print and copy for readers/commenters where the file type, owner and permission capabilities allow it. It cannot stop screen filming or another camera.

## 3. Meeting-provider behavior

All classes inherit the batch's default meeting provider. A class may override that provider. Zoom keeps its existing batch-room behavior. Google Meet, Teams and Zoho create a provider meeting for each class session. For recurring sessions, the LMS creates or updates each occurrence according to the selected recurring-edit scope.

### Zoom

Keep the existing Zoom account connection. The existing integration creates/uses the Zoom room and synchronizes cloud recordings. Zoom cloud recording must be enabled for the host/account and the host/co-host must have recording permission. The Zoom webhook `recording.completed` can notify the application when a recording becomes available; the existing scheduled sync remains the fallback. Existing Zoom configuration and batch/class data are preserved by this release.

### Google Meet

In LMS Settings, save the Google OAuth Client ID and Secret, Calendar ID, then use Connect Google Workspace. Reconnect and approve the scopes requested by this release if the existing consent does not include Drive and Meet space settings.

The connector creates a Google Calendar event with a Meet conference link and requests auto-recording for the meeting space. Google Meet's API supports preconfiguring auto-recording through `meetings.space.settings`, but the organizer must have the relevant Workspace licence and recording privilege, and Workspace administrator policy must permit it. After the meeting, Google saves the recording in the organizer's Drive, usually in `Meet Recordings`; the LMS scans that folder and matches the file to the session.

### Microsoft Teams

In LMS Settings, configure the Microsoft Entra Tenant ID, Application Client ID, Client Secret and organizer UPN/ID. Grant the required Microsoft Graph application permissions and admin consent. Apply an application access policy to the organizer for online meeting and recording access. The Teams connector creates calendar-backed online meetings, then looks up meeting recordings through Graph and streams available recording content from Microsoft 365 through the authenticated LMS viewer without creating a second WordPress video copy.

Important: the LMS does not force Teams auto-recording on each new meeting. Teams automatic recording must be enabled through the organizer's Teams meeting policy/template or meeting options. For standard meetings, the organizer may still need to enable “Record and transcribe automatically” for that meeting, depending on the tenant policy and template. Teams recordings are stored in OneDrive for private meetings or SharePoint for channel meetings. External viewers may require explicit file sharing if playback is not provided through the Graph integration.

### Zoho Meeting

In LMS Settings, choose the correct Zoho data centre, enter the OAuth Client ID and Secret, Organization ID (zsoid) and Presenter User ID, save, then choose Connect Zoho Meeting. The OAuth connector requests meeting create/update and recording-read scopes.

Enable **Auto-record meetings** in the Zoho Meeting account's Recording Settings if you want all meetings recorded automatically. This is a provider account setting; the LMS creates meetings and retrieves uploaded recordings but does not override Zoho's global recording setting. The recording must reach `UPLOADED` before the LMS links it to the class.

## 4. Future meeting providers

The meeting manager exposes the `uc_lms_meeting_provider_registry` filter. A future provider can register a small callable for meeting creation without loading its implementation on every front-end request. Provider-specific OAuth, webhook and recording retrieval code should remain in a separate file under `includes/core/meetings/` and be loaded only when the provider is enabled or invoked.

## 5. Recording behavior summary

| Provider | Meeting link | Automatic recording | LMS recording sync |
|---|---|---|---|
| Zoom | Existing integration | Zoom host/account recording setting | Existing Zoom sync/webhook workflow |
| Google Meet | Google Calendar + Meet API | LMS requests auto-recording; Workspace licence/policy required | Google Drive `Meet Recordings` folder matching |
| Microsoft Teams | Microsoft Graph calendar event | Configure Teams meeting policy/template/options; not forced by LMS | Graph recording lookup and authenticated stream |
| Zoho Meeting | Zoho Meeting API | Enable Auto-record meetings in Zoho account settings | Zoho recording API after status is `UPLOADED` |

Provider policies, licence tiers, API scopes and recording-retention settings are controlled by the provider and may differ by client.

## 6. Content protection

The LMS applies server-side enrollment/batch checks to protected viewers, displays a repeated watermark containing the logged-in user's name/email and access time, suppresses common copy/context-menu actions, uses `controlslist="nodownload"` for HTML video, and pauses the viewer when the page loses focus or becomes hidden. Google Drive download/print/copy restrictions can also be requested where Drive permissions allow.

These safeguards deter casual copying and help identify leaks. They are not a guarantee against all screenshots, screen recording, external capture cards, browser modifications or filming with another device. No ordinary web LMS can guarantee that visible content cannot be captured.

## 7. Recurring class edits

When editing a class in a recurring series, choose:

- **This class only** — update the selected class and detach it from the series.
- **This and future classes** — update the selected class and later occurrences.
- **Entire series** — update all linked occurrences.

Date shifts move selected sessions by the same day offset. Time/title/provider changes apply to the selected scope. Conflicts are skipped and included in the result message. Always review provider meeting updates after changing a recurring schedule.

## 8. Finance removal and data safety

Finance screens and Finance-only handlers are not part of the LMS core. On the first upgrade where the Finance cleanup marker is absent, the migration drops legacy Finance tables (`invoices`, `student_payments`, `trainer_earnings`, `trainer_payments`, `expenses`, `invoice_adjustments`) and removes Finance-only student user metadata, batch price/currency fields and tenant tax fields. This is destructive and irreversible without a database backup. It does not target courses, batches, students, enrolments, classes, Zoom links/recordings, attendance, materials or device records.

The uninstall handler retains LMS records. Do not use uninstall as a way to clear or reset production data.

## 9. Scheduled sync on shared hosting

The LMS reuses the existing 10-minute recording sync event for Drive, Meet, Teams and Zoho checks. WordPress Cron is traffic-triggered, so low-traffic sites may run late. Configure a cPanel cron to invoke `https://lms.unicybers.com/wp-cron.php?doing_wp_cron` every 5 minutes. Do not disable the normal WP-Cron trigger unless the cPanel cron is confirmed working.


Branding correction 2.8.111: default UniCybers lockup is UNICYBERS over ACADEMY; existing Zoom settings are visible in LMS Settings.
