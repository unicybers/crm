<?php
/**
 * UniCybers Academy LMS: Core Database Schema & Roles Installer.
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('UC_LMS_Database_Schema')) {
final class UC_LMS_Database_Schema {

    public static function table($name) {
        return UC_LMS_Database::table($name);
    }

    public static function install_roles() {
        if (!get_role('uc_trainer')) add_role('uc_trainer', 'UniCybers Trainer', ['read' => true]);
        if (!get_role('uc_student')) add_role('uc_student', 'UniCybers Student', ['read' => true]);
        if (!get_role('uc_coordinator')) add_role('uc_coordinator', 'UniCybers Coordinator', ['read' => true]);
        if (!get_role('uc_hr')) add_role('uc_hr', 'UniCybers Placement HR', ['read' => true]);
    }

    public static function install_schema() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $sql = [];

        $sql[] = "CREATE TABLE " . self::table('courses') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            slug varchar(255) NOT NULL,
            description longtext NULL,
            category varchar(100) NULL,
            level varchar(50) NULL,
            duration varchar(100) NULL,
            mode varchar(30) NOT NULL DEFAULT 'live',
            status varchar(20) NOT NULL DEFAULT 'active',
            enrolment_open tinyint(1) NOT NULL DEFAULT 1,
            outline longtext NULL,
            created_at datetime NOT NULL,
            updated_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('batches') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            course_id bigint unsigned NOT NULL,
            name varchar(255) NOT NULL,
            mode varchar(30) NOT NULL DEFAULT 'online',
            trainer_user_id bigint unsigned NULL,
            coordinator_user_id bigint unsigned NULL,
            start_date date NULL,
            end_date date NULL,
            status varchar(30) NOT NULL DEFAULT 'active',
            group_type varchar(50) NULL,
            group_url text NULL,
            whatsapp_url text NULL,
            telegram_url text NULL,
            discord_url text NULL,
            drive_folder_id varchar(255) NULL,
            country varchar(100) NULL,
            location varchar(255) NULL,
            enrolment_open tinyint(1) NOT NULL DEFAULT 1,
            capacity int unsigned NULL,
            notes longtext NULL,
            grace_months int unsigned NULL,
            access_expiry date NULL,
            timezone varchar(80) NOT NULL DEFAULT 'Asia/Kolkata',
            recurrence_days varchar(50) NULL,
            class_start_time time NULL,
            class_duration int unsigned NULL,
            class_title varchar(255) NULL,
            zoom_meeting_id varchar(80) NULL,
            zoom_join_url text NULL,
            zoom_start_url text NULL,
            zoom_passcode varchar(100) NULL,
            zoom_status varchar(30) NOT NULL DEFAULT 'not_configured',
            zoom_error text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NULL,
            PRIMARY KEY  (id),
            KEY course_id (course_id),
            KEY trainer_user_id (trainer_user_id),
            KEY status (status)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('batch_schedule') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint unsigned NOT NULL,
            day_of_week tinyint unsigned NOT NULL,
            session_type varchar(50) NOT NULL DEFAULT 'live',
            facilitator_user_id bigint unsigned NULL,
            start_time time NOT NULL,
            end_time time NULL,
            platform varchar(50) NOT NULL DEFAULT 'zoom',
            active tinyint(1) NOT NULL DEFAULT 1,
            notes text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NULL,
            PRIMARY KEY  (id),
            KEY batch_day (batch_id, day_of_week)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('sessions') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint unsigned NOT NULL,
            title varchar(255) NOT NULL,
            session_date date NOT NULL,
            start_time time NOT NULL,
            end_time time NULL,
            platform varchar(50) NOT NULL DEFAULT 'zoom',
            join_url text NULL,
            passcode varchar(100) NULL,
            status varchar(30) NOT NULL DEFAULT 'scheduled',
            hidden tinyint(1) NOT NULL DEFAULT 0,
            session_type varchar(50) NOT NULL DEFAULT 'live',
            notes longtext NULL,
            recording_url text NULL,
            recording_status varchar(30) NULL,
            recording_duration int unsigned NULL,
            recording_at datetime NULL,
            calendar_event_id varchar(255) NULL,
            meet_space_name varchar(255) NULL,
            meet_code varchar(100) NULL,
            trainer_user_id bigint unsigned NULL,
            backup_trainer_user_id bigint unsigned NULL,
            zoom_meeting_id varchar(80) NULL,
            zoom_uuid text NULL,
            legacy_class_id bigint unsigned NULL,
            created_at datetime NOT NULL,
            updated_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_slot (batch_id, session_date, start_time),
            KEY batch_date (batch_id, session_date),
            KEY status_date (status, session_date)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('enrolments') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            status varchar(30) NOT NULL DEFAULT 'active',
            enrolled_at datetime NOT NULL,
            trial_ends_at datetime NULL,
            access_expires_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY batch_user (batch_id, user_id),
            KEY user_id (user_id),
            KEY batch_status (batch_id, status)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('attendance') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            session_id bigint unsigned NOT NULL,
            batch_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            joined_at datetime NULL,
            last_seen_at datetime NULL,
            minutes int unsigned NULL,
            status varchar(30) NOT NULL DEFAULT 'present',
            source varchar(30) NULL,
            device varchar(255) NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_user (session_id, user_id),
            KEY batch_id (batch_id),
            KEY user_status (user_id, status)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('materials') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint unsigned NOT NULL,
            title varchar(255) NOT NULL,
            type varchar(50) NULL,
            url text NOT NULL,
            added_by bigint unsigned NULL,
            visible tinyint(1) NOT NULL DEFAULT 1,
            student_locked tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY batch_visible (batch_id, visible)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('announcements') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            audience varchar(50) NOT NULL DEFAULT 'all',
            batch_id bigint unsigned NULL,
            title varchar(255) NOT NULL,
            body longtext NOT NULL,
            by_user_id bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY batch_id (batch_id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('messages') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            scope varchar(50) NOT NULL DEFAULT 'general',
            batch_id bigint unsigned NULL,
            from_user_id bigint unsigned NULL,
            body longtext NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY batch_id (batch_id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('student_profiles') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NOT NULL,
            phone varchar(50) NULL,
            country varchar(100) NULL,
            city varchar(100) NULL,
            highest_qualification varchar(255) NULL,
            institution varchar(255) NULL,
            graduation_year varchar(20) NULL,
            certifications text NULL,
            skills text NULL,
            employment_status varchar(100) NULL,
            employer varchar(255) NULL,
            experience_years decimal(5,2) NULL,
            preferred_role varchar(255) NULL,
            preferred_location varchar(255) NULL,
            work_preference varchar(100) NULL,
            availability varchar(100) NULL,
            registration_status varchar(50) NULL,
            placement_status varchar(50) NULL,
            whatsapp varchar(50) NULL,
            linkedin varchar(255) NULL,
            github varchar(255) NULL,
            portfolio varchar(255) NULL,
            current_job_title varchar(255) NULL,
            notice_period varchar(100) NULL,
            work_authorization varchar(255) NULL,
            languages text NULL,
            professional_summary longtext NULL,
            expected_salary decimal(12,2) NULL,
            expected_salary_currency varchar(10) NULL,
            share_with_employers tinyint(1) NOT NULL DEFAULT 0,
            placement_excluded tinyint(1) NOT NULL DEFAULT 0,
            updated_at datetime NOT NULL,
            updated_by bigint unsigned NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY user_id (user_id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('student_documents') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NOT NULL,
            document_type varchar(100) NOT NULL,
            file_name varchar(255) NULL,
            url text NULL,
            drive_file_id varchar(255) NULL,
            status varchar(30) NOT NULL DEFAULT 'pending',
            uploaded_by bigint unsigned NULL,
            verified_by bigint unsigned NULL,
            verified_at datetime NULL,
            reject_reason text NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('access_requests') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NULL,
            email varchar(255) NULL,
            reason varchar(255) NULL,
            detail text NULL,
            device varchar(255) NULL,
            raised_at datetime NOT NULL,
            status varchar(30) NOT NULL DEFAULT 'open',
            handled_by bigint unsigned NULL,
            handled_at datetime NULL,
            PRIMARY KEY  (id),
            KEY status (status)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('demo_leads') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            email varchar(255) NULL,
            phone varchar(50) NULL,
            seat varchar(100) NULL,
            started_at datetime NULL,
            device varchar(255) NULL,
            interest varchar(255) NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('tenants') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            slug varchar(80) NOT NULL,
            name varchar(191) NOT NULL,
            legal_name varchar(255) NULL,
            tagline varchar(255) NULL,
            product_label varchar(80) NULL,
            logo_url text NULL,
            accent varchar(20) NOT NULL DEFAULT '#FF6B1A',
            accent2 varchar(20) NOT NULL DEFAULT '#FF8A3D',
            support_email varchar(191) NULL,
            mail_from varchar(191) NULL,
            website varchar(255) NULL,
            portal_domain varchar(191) NULL,
            timezone varchar(80) NOT NULL DEFAULT 'Asia/Kolkata',
            phone varchar(50) NULL,
            status varchar(20) NOT NULL DEFAULT 'draft',
            is_home tinyint(1) NOT NULL DEFAULT 0,
            notes text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY status (status)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('audit') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            entity varchar(100) NOT NULL,
            entity_id bigint unsigned NULL,
            action varchar(100) NOT NULL,
            by_user_id bigint unsigned NULL,
            at_time datetime NOT NULL,
            before_json longtext NULL,
            after_json longtext NULL,
            detail text NULL,
            PRIMARY KEY  (id),
            KEY entity (entity, entity_id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('practice') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint unsigned NOT NULL,
            kind varchar(20) NOT NULL DEFAULT 'assignment',
            title varchar(255) NOT NULL,
            body longtext NULL,
            due_at datetime NULL,
            starts_at datetime NULL,
            ends_at datetime NULL,
            url text NULL,
            paper longtext NULL,
            brief_url text NULL,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY batch_id (batch_id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('practice_done') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            practice_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            completed_at datetime NOT NULL,
            answers longtext NULL,
            file_url text NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY one_done (practice_id, user_id)
        ) $c;";

        $sql[] = "CREATE TABLE " . self::table('opens') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NOT NULL,
            kind varchar(20) NOT NULL,
            ref_id bigint unsigned NOT NULL,
            opened_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_kind (user_id, kind, ref_id)
        ) $c;";

        foreach ($sql as $q) {
            dbDelta($q);
        }

        // Keep this table outside dbDelta(): dbDelta can attempt to re-add an
        // already-existing composite unique index on some MySQL/MariaDB setups.
        self::ensure_devices_table();
    }

    /**
     * Create the device table on fresh installs and add its unique key only
     * when the same unique index is not already present. Existing device rows
     * are never deleted or rewritten by this schema check.
     */
    public static function ensure_devices_table() {
        global $wpdb;

        $table = self::table('devices');
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));

        if ($found !== $table) {
            $charset = $wpdb->get_charset_collate();
            $wpdb->query("CREATE TABLE IF NOT EXISTS `{$table}` (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                user_id bigint unsigned NOT NULL,
                device_id varchar(255) NOT NULL,
                label varchar(255) NULL,
                first_seen datetime NULL,
                last_seen datetime NULL,
                PRIMARY KEY (id),
                UNIQUE KEY `user_device` (`user_id`, `device_id`),
                KEY `user_id` (`user_id`)
            ) {$charset}");
            return;
        }

        $rows = $wpdb->get_results("SHOW INDEX FROM `{$table}`");
        $indexes = [];
        foreach ((array) $rows as $row) {
            $name = (string) $row->Key_name;
            if (!isset($indexes[$name])) {
                $indexes[$name] = [
                    'non_unique' => (int) $row->Non_unique,
                    'columns' => [],
                ];
            }
            $indexes[$name]['columns'][(int) $row->Seq_in_index] = (string) $row->Column_name;
        }

        $expected = ['user_id', 'device_id'];
        foreach ($indexes as $name => $index) {
            ksort($index['columns']);
            if ($index['non_unique'] === 0 && array_values($index['columns']) === $expected) {
                return;
            }
            // Never attempt to create an index with a name already in use.
            if ($name === 'user_device') {
                return;
            }
        }

        // A unique index cannot be added while historical duplicate rows exist.
        // Leave those records intact and log the issue for administrator review.
        $duplicates = $wpdb->get_var("SELECT 1 FROM `{$table}` GROUP BY user_id, device_id HAVING COUNT(*) > 1 LIMIT 1");
        if ($duplicates) {
            error_log('UniCybers LMS: device unique index was not added because duplicate user/device rows already exist. Existing rows were preserved.');
            return;
        }

        $wpdb->query("ALTER TABLE `{$table}` ADD UNIQUE KEY `user_device` (`user_id`, `device_id`)");
        if (!empty($wpdb->last_error)) {
            error_log('UniCybers LMS: could not ensure device unique index: ' . $wpdb->last_error);
        }
    }

    public static function ensure_indexes() {
        global $wpdb;
        $sessions = self::table('sessions');
        $has_idx = $wpdb->get_var($wpdb->prepare("SHOW INDEX FROM `$sessions` WHERE Key_name = %s", 'idx_sess_perf'));
        if (!$has_idx) {
            $wpdb->query("ALTER TABLE `$sessions` ADD INDEX idx_sess_perf (batch_id, hidden, status, session_date)");
        }
    }
}
}
