<?php
/**
 * UniCybers Academy LMS: Multi-Tenant Desk Module.
 *
 * Provides Super Admin with tenant workspace management:
 * client academy branding (logos, accents, legal name and contact details),
 * user-to-tenant allocation, and live preview cookie switching.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Tenants {
    public static function render($portal) {
        global $wpdb;
        if (UC_LMS_Portal_Context::role() !== 'super_admin') {
            return $portal->empty_state('Not available', 'Only Super Admin creates a client academy and sets their logo and details.', 'tenants');
        }
        if (!UC_LMS_Database::has_table('tenants')) {
            if (class_exists('UC_Academy_LMS')) UC_Academy_LMS::instance()->maybe_upgrade();
            if (!UC_LMS_Database::has_table('tenants')) {
                return $portal->empty_state('Tenants table missing', 'Re-activate the plugin so the tenants table can be created.', 'tenants');
            }
        }
        $tb_tenants = UC_LMS_Database::table('tenants');
        $rows = $wpdb->get_results("SELECT * FROM `$tb_tenants` ORDER BY is_home DESC, name ASC");
        $edit_id = sanitize_text_field(wp_unslash($_GET['edit'] ?? ''));
        $editing = null;
        if ($edit_id === 'new') {
            $editing = (object)[
                'id' => 0, 'slug' => '', 'name' => '', 'legal_name' => '', 'tagline' => '',
                'product_label' => 'ACADEMY', 'logo_url' => '', 'accent' => '#FF6B1A', 'accent2' => '#FF8A3D',
                'support_email' => '', 'mail_from' => '', 'website' => '', 'portal_domain' => '', 'timezone' => 'Asia/Kolkata',
                'phone' => '', 'status' => 'draft',
                'is_home' => 0, 'notes' => ''
            ];
        } elseif ($edit_id) {
            $editing = $wpdb->get_row($wpdb->prepare("SELECT * FROM `$tb_tenants` WHERE id=%d", absint($edit_id)));
        }
        $preview = isset($_COOKIE['uc_preview_tenant']) ? absint($_COOKIE['uc_preview_tenant']) : 0;
        $o = '';
        if ($preview) {
            $p = $wpdb->get_row($wpdb->prepare("SELECT name FROM `$tb_tenants` WHERE id=%d", $preview));
            $o .= '<div class="panel" style="border-color:#F59E0B"><p>Previewing <strong>' . $portal->e($p->name ?? 'client') . '</strong>. Login and portal branding use this logo.</p>';
            $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_tenant_preview">' . wp_nonce_field('uc_portal_tenant_preview', '_wpnonce', true, false) . '<input type="hidden" name="id" value="0"><button class="btn ghost" type="submit">Stop preview</button></form></div>';
        }
        $o .= '<p class="hint">One WordPress, one plugin. Point the client hostname at this install, save it as LMS domain, and that academy’s logo, colours and tax load when someone opens that host. Do not copy the plugin.</p>';
        $o .= '<div class="tablewrap"><table><thead><tr><th>Academy</th><th>Slug</th><th>Mail from</th><th>Status</th><th></th></tr></thead><tbody>';
        if (!$rows) {
            $o .= '<tr><td colspan="5">' . $portal->empty_state('No academies yet', 'Add the home UniCybers tenant by re-activating, then add a client.', 'tenants') . '</td></tr>';
        }
        foreach ($rows as $r) {
            $o .= '<tr data-q="' . esc_attr(strtolower($r->name . ' ' . $r->slug . ' ' . $r->legal_name)) . '"><td><strong>' . $portal->e($r->name) . '</strong>' . ($r->is_home ? ' ' . $portal->pill('Home', 'info') : '') . '<div class="muted">' . $portal->e($r->legal_name) . '</div></td>';
            $o .= '<td class="mono-s">' . $portal->e($r->slug) . '</td><td>' . $portal->e($r->mail_from ?: '—') . '</td>';
            $o .= '<td>' . $portal->pill($r->status === 'live' ? 'Live' : 'Draft', $r->status === 'live' ? 'ok' : 'mut') . '</td><td>';
            $o .= '<a class="link" href="' . esc_url(add_query_arg('edit', (int)$r->id, $portal->url('tenants'))) . '">Edit logo &amp; details</a> · ';
            $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_tenant_preview">' . wp_nonce_field('uc_portal_tenant_preview', '_wpnonce', true, false) . '<input type="hidden" name="id" value="' . (int)$r->id . '"><button class="btn ghost sm" type="submit">Preview</button></form>';
            $o .= '</td></tr>';
        }
        $o .= '</tbody></table></div>';

        if ($editing) {
            $assigned = [];
            if ((int)$editing->id) {
                $users = get_users(['meta_key' => 'uc_tenant_id', 'meta_value' => (int)$editing->id, 'number' => 2000, 'fields' => ['ID']]);
                foreach ($users as $u) $assigned[(int)$u->ID] = true;
            }
            $people = get_users(['role__in' => ['uc_student', 'uc_trainer', 'uc_coordinator'], 'orderby' => 'display_name', 'number' => 2000]);
            $o .= '<section class="panel" style="margin-top:16px"><h3 class="fin-h">' . ((int)$editing->id ? 'Edit ' . $portal->e($editing->name) : 'New client academy') . '</h3>';
            $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="form tenant-form-wrap" enctype="multipart/form-data"><input type="hidden" name="action" value="uc_portal_tenant_save">' . wp_nonce_field('uc_portal_tenant_save', '_wpnonce', true, false);
            $o .= '<input type="hidden" name="id" value="' . (int)$editing->id . '">';
            $o .= '<div class="tenant-hero">';
            $o .= '<img src="' . esc_url($editing->logo_url ?: plugins_url('assets/unicybers-emblem.svg', UC_LMS_FILE)) . '" alt="" class="tenant-logo">';
            $o .= '<label class="tenant-logo-field">Logo — square PNG or SVG works best' . $portal->file_control('logo', 'image/png,image/svg+xml,image/jpeg,image/webp,.png,.svg,.jpg,.jpeg,.webp') . '</label></div>';
            $o .= '<div class="tenant-sec"><h4>Identity</h4><div class="tenant-form">';
            $o .= '<label>Academy name<input name="name" required value="' . $portal->e($editing->name) . '" placeholder="Client academy name"></label>';
            $o .= '<label>Legal name<input name="legal_name" value="' . $portal->e($editing->legal_name) . '" placeholder="Registered trading name"></label>';
            $o .= '<label>Slug<input name="slug" value="' . $portal->e($editing->slug) . '" ' . ($editing->is_home ? 'readonly' : '') . '></label>';
            $o .= '<label>Product line<input name="product_label" value="' . $portal->e($editing->product_label ?: 'ACADEMY') . '"></label>';
            $o .= '<label class="span-2">Tagline<input name="tagline" value="' . $portal->e($editing->tagline) . '" placeholder="Shown on login"></label>';
            $o .= '</div></div>';
            $o .= '<div class="tenant-sec"><h4>Brand colours</h4><div class="tenant-form">';
            $o .= '<label>Accent<span class="tenant-swatch"><input type="color" name="accent" value="' . esc_attr($editing->accent ?: '#FF6B1A') . '"><input name="accent_hex" value="' . esc_attr($editing->accent ?: '#FF6B1A') . '" readonly></span></label>';
            $o .= '<label>Accent 2<span class="tenant-swatch"><input type="color" name="accent2" value="' . esc_attr($editing->accent2 ?: '#FF8A3D') . '"><input name="accent2_hex" value="' . esc_attr($editing->accent2 ?: '#FF8A3D') . '" readonly></span></label>';
            $o .= '</div></div>';
            $o .= '<div class="tenant-sec"><h4>Contact</h4><div class="tenant-form">';
            $o .= '<label>Website<input name="website" value="' . $portal->e($editing->website) . '" placeholder="https://"></label>';
            $o .= '<label>LMS domain<input name="portal_domain" value="' . $portal->e($editing->portal_domain ?? '') . '" placeholder="lms.client.com — no https"></label>';
            $o .= '<label>Mail from<input type="email" name="mail_from" value="' . $portal->e($editing->mail_from ?: 'academy@unicybers.com') . '"></label>';
            $o .= '<label>Support email<input type="email" name="support_email" value="' . $portal->e($editing->support_email) . '"></label>';
            $o .= '<label>Phone / WhatsApp<input name="phone" value="' . $portal->e($editing->phone) . '"></label>';
            $o .= '</div></div>';
            $o .= '<div class="tenant-sec"><h4>Regional settings and status</h4><div class="tenant-form">';
            $o .= '<label>Timezone<select name="timezone">';
            foreach (['Asia/Kolkata' => 'India IST', 'Africa/Gaborone' => 'Botswana', 'Asia/Dubai' => 'UAE', 'Africa/Johannesburg' => 'South Africa', 'UTC' => 'UTC'] as $tz => $lab) {
                $o .= '<option value="' . esc_attr($tz) . '"' . selected($editing->timezone, $tz, false) . '>' . $lab . '</option>';
            }
            $o .= '</select></label>';
            $o .= '<label>Status<select name="status"><option value="draft"' . selected($editing->status, 'draft', false) . '>Draft</option><option value="live"' . selected($editing->status, 'live', false) . '>Live</option></select></label>';
            $o .= '<label class="span-2">Notes<textarea name="notes" rows="3" placeholder="Internal: contract, go-live">' . $portal->e($editing->notes) . '</textarea></label>';
            $o .= '</div></div>';
            if (!(int)$editing->is_home) {
                $o .= '<p class="hint">Assign people to this academy. Super Admin stays on the home tenant.</p><div class="tablewrap" style="max-height:220px;overflow:auto"><table><tbody>';
                foreach ($people as $u) {
                    $o .= '<tr><td><label class="check"><input type="checkbox" name="member_ids[]" value="' . (int)$u->ID . '"' . checked(!empty($assigned[(int)$u->ID]), true, false) . '> ' . $portal->e($u->display_name) . ' <span class="muted">' . $portal->e($u->user_email) . '</span></label></td></tr>';
                }
                $o .= '</tbody></table></div>';
            }
            $o .= '<div class="fin-act"><button class="btn primary" type="submit">Save details</button></div></form></section>';
        }
        return $o;
    }
}
