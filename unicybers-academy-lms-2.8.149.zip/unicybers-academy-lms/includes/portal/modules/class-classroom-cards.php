<?php
/**
 * UniCybers Academy LMS: Classroom Intelligence & Engagement Cards.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Classroom_Cards {

public static function cr_summary_card($portal, $pack, $staff, $s, $intel=null, $full=false) {
        $sum = $pack['summary'];
        $o = '<section class="cr-card cr-sum"><div class="cr-card-h"><h3>AI Class Summary</h3>';
        if ($staff && $sum) {
            $on = !empty($sum->published);
            $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form">'.wp_nonce_field('uc_portal_intel_publish','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_intel_publish"><input type="hidden" name="session_id" value="'.(int)$s->id.'"><input type="hidden" name="what" value="summary">';
            $o .= $on ? '<input type="hidden" name="on" value="0"><button class="btn ghost sm" type="submit">Hide from students</button>' : '<input type="hidden" name="on" value="1"><button class="btn primary sm" type="submit">Publish summary</button>';
            $o .= '</form>';
        }
        $o .= '</div>';
        if (!$sum || (!$staff && empty($sum->published))) {
            if ($staff) {
                $err = trim((string)($pack['status']->last_error ?? ''));
                $plat = $portal->platform_label($s);
                if ($plat === 'Classroom') $o .= '<p class="muted">This is a classroom session. Write the recap under Summary. There is no meeting summary to sync.</p>';
                elseif ($plat === 'Zoom') $o .= '<p class="muted">No Zoom AI summary for this class yet. Open the class that matches the Zoom Summaries date, then Sync recording.</p>';
                else $o .= '<p class="muted">No '.$portal->e($plat).' summary for this class yet. Sync the recording after class, or write the recap under Summary.</p>';
                if ($err) $o .= '<p class="muted">'.$portal->e($err).'</p>';
            } else {
                $o .= '<p class="muted">Your trainer has not published the summary yet.</p>';
            }
            return $o.'</section>';
        }
        $o .= '<div class="cr-mini" data-sum-tabs><button type="button" class="on" data-sum="overview">Overview</button><button type="button" data-sum="topics">Key Topics</button><button type="button" data-sum="commands">Commands</button><button type="button" data-sum="next">Next Steps</button></div>';
        $o .= '<div data-sum-panel="overview"><h4>Quick Recap</h4><p>'.nl2br($portal->e(wp_strip_all_tags($sum->recap))).'</p>';
        if ($pack['topics']) {
            $o .= '<h4>Key Takeaways</h4><ul class="cr-checks">';
            foreach ($pack['topics'] as $t) $o .= '<li>'.$portal->e(is_string($t)?$t:(string)($t['label']??'')).'</li>';
            $o .= '</ul>';
        }
        $o .= '</div>';
        $o .= '<div data-sum-panel="topics" hidden><ul class="cr-checks">';
        foreach ($pack['topics'] as $t) $o .= '<li>'.$portal->e(is_string($t)?$t:(string)($t['label']??'')).'</li>';
        $o .= '</ul></div>';
        $o .= '<div data-sum-panel="commands" hidden><p class="muted">Commands appear here when the meeting summary includes them, or after the trainer edits the summary.</p></div>';
        $o .= '<div data-sum-panel="next" hidden><ul class="cr-checks">';
        foreach ($pack['steps'] as $t) $o .= '<li>'.$portal->e(is_string($t)?$t:wp_strip_all_tags(wp_json_encode($t))).'</li>';
        $o .= '</ul></div>';
        return $o.'</section>';
    }

public static function cr_summary_full($portal, $pack, $staff, $s) {
        $o = $portal->cr_summary_card($pack, $staff, $s, null, true);
        if (!$staff) return $o;
        $sum = $pack['summary'];
        $topics = implode("\n", array_map(function($t){ return is_string($t)?$t:''; }, $pack['topics']));
        $steps = implode("\n", array_map(function($t){ return is_string($t)?$t:''; }, $pack['steps']));
        $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form cr-edit">'.wp_nonce_field('uc_portal_intel_summary','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_intel_summary"><input type="hidden" name="session_id" value="'.(int)$s->id.'">';
        $o .= '<label>Quick recap<textarea name="recap" rows="5">'.esc_textarea($sum->recap ?? '').'</textarea></label>';
        $o .= '<label>Key topics (one per line)<textarea name="topics" rows="4">'.esc_textarea($topics).'</textarea></label>';
        $o .= '<label>Next steps (one per line)<textarea name="steps" rows="4">'.esc_textarea($steps).'</textarea></label>';
        $o .= '<button class="btn primary sm" type="submit">Save summary</button></form>';
        return $o;
    }

public static function cr_tasks_card($portal, $pack, $staff, $s, $full=false) {
        $o = '<section class="cr-card cr-taskcard"><h3>Tasks &amp; Assignments</h3>';
        if (!$pack['tasks']) {
            $plat = $portal->platform_label($s);
            $o .= '<p class="muted">'.($staff?'No next steps yet for this '.$portal->e($plat).' class. Add them after the summary is ready.':'No assignments published for this class.').'</p></section>';
            return $o;
        }
        $o .= '<ul class="cr-tasks">';
        foreach ($pack['tasks'] as $t) {
            $o .= '<li><span class="cr-box"></span><span><strong>'.$portal->e($t->title).'</strong>';
            if ($staff) {
                $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="cr-task-form">'.wp_nonce_field('uc_portal_intel_task','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_intel_task"><input type="hidden" name="id" value="'.(int)$t->id.'"><input type="hidden" name="session_id" value="'.(int)$s->id.'">';
                $o .= '<input name="title" value="'.esc_attr($t->title).'">';
                $o .= '<select name="status"><option value="draft"'.selected($t->status,'draft',false).'>Draft</option><option value="published"'.selected($t->status,'published',false).'>Published</option></select>';
                $o .= '<button class="btn ghost sm" type="submit">Save</button></form>';
            }
            $o .= '</span></li>';
        }
        $o .= '</ul><a class="btn primary sm cr-lab" href="https://labs.unicybers.com" target="_blank" rel="noopener">Open Lab Environment →</a>';
        return $o.'</section>';
    }

public static function cr_polls_card($portal, $pack, $staff, $s, $full=false) {
        $o = '<section class="cr-card"><div class="cr-card-h"><h3>Polls &amp; Quiz</h3></div><div class="cr-pills"><span class="pill p-ok">Live Polls</span></div>';
        if (!$pack['polls']) {
            $plat = $portal->platform_label($s);
            $o .= '<p class="muted">'.($staff?($plat==='Zoom'?'No Zoom poll results yet.':'No poll results for this '.$portal->e($plat).' class.'):'Poll results are hidden until your trainer publishes them.').'</p></section>';
            return $o;
        }
        foreach ($pack['polls'] as $p) {
            $data = json_decode((string)$p->options_json, true) ?: [];
            $o .= '<article class="cr-poll"><strong>'.$portal->e($p->question).'</strong>';
            if (!empty($data['participants'])) $o .= '<small>Participants: '.(int)$data['participants'].'</small>';
            foreach ((array)($data['options'] ?? []) as $opt) {
                $o .= '<div class="cr-bar"><span>'.$portal->e((string)($opt['label']??'')).'</span><i style="width:'.(int)($opt['pct']??0).'%"></i><em>'.(int)($opt['pct']??0).'%</em></div>';
            }
            $o .= '</article>';
        }
        if ($staff) {
            $on = !empty($pack['polls'][0]->published);
            $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form">'.wp_nonce_field('uc_portal_intel_publish','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_intel_publish"><input type="hidden" name="session_id" value="'.(int)$s->id.'"><input type="hidden" name="what" value="polls">';
            $o .= $on ? '<input type="hidden" name="on" value="0"><button class="btn ghost sm" type="submit">Hide polls</button>' : '<input type="hidden" name="on" value="1"><button class="btn primary sm" type="submit">Publish poll results</button>';
            $o .= '</form>';
        }
        return $o.'</section>';
    }

public static function cr_transcript($portal, $pack, $intel, $compact=false) {
        $o = '<section class="cr-card"><h3>Transcript</h3>';
        if (!$pack['transcript']) return $o.'<p class="muted">Transcript is not available for this class yet.</p></section>';
        $o .= '<input class="cr-search" type="search" placeholder="Search transcript" data-cr-filter>';
        $o .= '<ol class="cr-tr'.($compact?' compact':'').'">';
        foreach ($pack['transcript'] as $line) {
            $t = $intel ? $intel->clock($line->t_seconds) : '';
            $o .= '<li data-q="'.esc_attr(strtolower((string)$line->body)).'"><button type="button" class="cr-seek" data-t="'.(int)$line->t_seconds.'">▶ '.$portal->e($t).'</button><span>'.$portal->e($line->body).'</span></li>';
        }
        $o .= '</ol>';
        if ($compact) $o .= '<span class="cr-link">View Full Transcript →</span>';
        return $o.'</section>';
    }

public static function cr_ring($portal, $pct) {
        $pct = max(0, min(100, (int)$pct));
        $r = 42; $c = 2 * M_PI * $r; $dash = ($pct / 100) * $c;
        return '<div class="cr-ring-wrap"><svg class="cr-ring" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="'.$r.'"></circle><circle cx="50" cy="50" r="'.$r.'" style="stroke-dasharray:'.$dash.' '.$c.'"></circle></svg><strong class="cr-ring-pct">'.$pct.'%</strong></div>';
    }

public static function cr_attendance($portal, $pack, $staff, $s, $intel) {
        $sched_min = max(1, (int)round($pack['sched'] / 60));
        $st = $pack['stats'];
        $rate = $st['total'] ? (int)round($st['present'] * 100 / $st['total']) : 0;
        $mine = $pack['mine'];
        $show = $staff ? $rate : ($mine && $pack['sched'] ? (int)min(100, round(100 * $mine->duration_seconds / $pack['sched'])) : 0);
        $o = '<section class="cr-card cr-att"><h3>Class Attendance</h3><div class="cr-att-row">'.$portal->cr_ring($show);
        $o .= '<ul><li>Total Students <b>'.(int)$st['total'].'</b></li><li class="ok">Present <b>'.(int)$st['present'].'</b></li><li class="warn">Late <b>'.(int)$st['partial'].'</b></li><li>Absent <b>'.(int)$st['absent'].'</b></li><li>Average Time <b>'.(int)$st['avg_min'].' mins</b></li></ul></div>';
        if (!$staff) {
            if (!$mine) $o .= '<p class="cr-mine">Your attendance for this class is not on file yet.</p>';
            else $o .= '<p class="cr-mine">You attended '.(int)round($mine->duration_seconds/60).' of '.$sched_min.' scheduled minutes · '.$portal->e(ucfirst($mine->attendance_status)).'</p>';
        }
        $o .= '<a class="cr-link" href="'.esc_url($portal->url('reports')).'">View Detailed Attendance →</a>';
        return $o.'</section>';
    }

public static function cr_participants($portal, $pack, $s, $staff=true) {
        if (empty($pack['participants'])) return '<section class="cr-card"><h3>Participants</h3><p class="muted">Participant list is not ready yet.</p></section>';
        $o = '<section class="cr-card"><div class="cr-card-h"><h3>Participants ('.count($pack['participants']).')</h3>';
        if ($staff) $o .= '<a class="btn ghost sm" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=uc_portal_intel_csv&session_id='.(int)$s->id),'uc_portal_intel_csv')).'">Download CSV</a>';
        $o .= '</div>';
        $o .= '<div class="tablewrap"><table><thead><tr><th>Name</th><th>Join</th><th>Leave</th><th>Duration</th><th>Status</th></tr></thead><tbody>';
        foreach ($pack['participants'] as $p) {
            $join = $p->join_time ? $portal->e(gmdate('H:i', strtotime($p->join_time.' UTC'))) : '–';
            $leave = $p->leave_time ? $portal->e(gmdate('H:i', strtotime($p->leave_time.' UTC'))) : '–';
            $st = ucfirst($p->attendance_status);
            $tone = $p->attendance_status === 'present' ? 'ok' : ($p->attendance_status === 'partial' ? 'warn' : 'mut');
            $o .= '<tr><td>'.$portal->e($p->display_name).'</td><td>'.$join.'</td><td>'.$leave.'</td><td>'.(int)round($p->duration_seconds/60).' min</td><td><span class="pill p-'.$tone.'">'.$portal->e($st).'</span></td></tr>';
        }
        return $o.'</tbody></table></div></section>';
    }

public static function cr_materials($portal, $batch_id, $sid) {
        global $wpdb;
        $vis = $portal->staff() ? '' : ' AND visible=1';
        $tied = [];
        $cols = $wpdb->get_col("SHOW COLUMNS FROM {$portal->t('materials')}", 0);
        if (in_array('session_id', $cols, true)) {
            $tied = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$portal->t('materials')} WHERE batch_id=%d AND session_id=%d{$vis} ORDER BY id DESC LIMIT 20", $batch_id, $sid));
        }
        $rows = [];
        foreach ($tied ?: [] as $m) {
            if ($portal->is_video_material($m)) continue;
            $rows[] = $m;
        }
        $lib = esc_url(add_query_arg('batch', (int)$batch_id, $portal->url('materials')));
        if (!$rows) {
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$portal->t('materials')} WHERE batch_id=%d{$vis} ORDER BY id DESC LIMIT 12", $batch_id));
            $rows = array_values(array_filter((array)$rows, function($m) use ($portal){ return !$portal->is_video_material($m); }));
        }
        $o = '<section class="cr-card"><div class="cr-card-h"><h3>Class Materials</h3><a class="cr-link" href="'.$lib.'" style="margin:0">This batch</a></div>';
        if (!$rows) {
            $o .= '<a class="btn ghost sm" href="'.$lib.'">Open this batch</a>';
            return $o.'</section>';
        }
        $o .= '<ul class="cr-mats">';
        foreach ($rows as $m) {
            $h = $portal->library_item_href($m);
            $kind = strtoupper(substr((string)$m->type, 0, 3)) ?: 'DOC';
            $o .= '<li><b>'.$portal->e($kind).'</b><span><strong>'.$portal->e($m->title).'</strong><small>'.$portal->e($m->type).'</small></span>';
            if ($h['href'] && ($portal->staff() || $portal->material_kind($m->url) !== 'zip')) {
                $blank = $h['blank'] ? ' target="_blank" rel="noopener"' : '';
                $o .= '<a class="btn ghost sm" href="'.esc_url($h['href']).'"'.$blank.'>'.$portal->e($h['label']).'</a>';
            }
            $o .= '</li>';
        }
        return $o.'</ul></section>';
    }

public static function cr_trainer_strip($portal, $pack, $st, $s) {
        $sum = $pack['summary'];
        $row = function ($label, $ok) {
            return '<li class="'.($ok?'':'off').'">'.$label.'</li>';
        };
        $o = '<section class="cr-card cr-trainer"><h3>Trainer View</h3><div class="cr-trainer-grid"><ul class="cr-checks">';
        $o .= $row('Recording Available', ($st->recording_state ?? '') === 'available' || $portal->recording_playable($s));
        $o .= $row('Transcript Available', !empty($pack['transcript']));
        $o .= $row('AI Summary Generated', !empty($sum));
        $o .= $row('Tasks Generated', !empty($pack['tasks']));
        $o .= $row('Poll Results Available', !empty($pack['polls']));
        $o .= $row('Attendance Processed', !empty($pack['stats']['total']));
        $o .= '</ul><div>';
        $o .= '<p class="muted">Summary (Draft)</p><p>'.($sum ? nl2br($portal->e(wp_strip_all_tags($sum->recap))) : 'Sync the recording after class, then publish.').'</p>';
        $o .= '<div class="cr-review-acts">';
        if ($sum) {
            $on = !empty($sum->published);
            $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form">'.wp_nonce_field('uc_portal_intel_publish','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_intel_publish"><input type="hidden" name="session_id" value="'.(int)$s->id.'"><input type="hidden" name="what" value="summary">';
            $o .= $on ? '<input type="hidden" name="on" value="0"><button class="btn ghost sm" type="submit">Edit</button>' : '<input type="hidden" name="on" value="1"><button class="btn primary sm" type="submit">Publish to Students</button>';
            $o .= '</form>';
        }
        $o .= '</div></div></div></section>';
        return $o;
    }
}
