<?php
/**
 * Plugin Name: UniCybers CRM
 * Description: UniCybers CRM for leads, institutions, visits, quotations and business operations.
 * Version: 2.1.21
 * Author: UniCybers
 * Requires at least: 6.4
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

define('UC_CRM_FILE', __FILE__);
define('UC_CRM_DIR', plugin_dir_path(__FILE__));
define('UC_CRM_VERSION', '2.1.21');

require_once UC_CRM_DIR . 'includes/class-book.php';
require_once UC_CRM_DIR . 'includes/class-import.php';
require_once UC_CRM_DIR . 'includes/trait-live.php';
require_once UC_CRM_DIR . 'includes/class-engine.php';

register_activation_hook(__FILE__, 'uc_crm_activate');
add_action('rest_api_init', 'uc_crm_routes');
add_action('wp_ajax_uc_crm_rpc', 'uc_crm_ajax_rpc');
add_action('wp_ajax_nopriv_uc_crm_rpc', 'uc_crm_ajax_rpc');
add_action('init', 'uc_crm_schedule');
add_action('uc_crm_hourly', 'uc_crm_hourly_jobs');
add_shortcode('unicybers_crm_capture', 'uc_crm_capture_shortcode');
add_action('template_redirect', 'uc_crm_serve', 0);
add_action('admin_menu', 'uc_crm_admin_menu');
add_action('admin_post_uc_crm_reimport', 'uc_crm_reimport');
add_action('admin_post_uc_crm_settings', 'uc_crm_save_settings');
add_action('admin_post_uc_crm_set_password', 'uc_crm_set_password');

function uc_crm_activate() {
    UC_CRM_Book::activate();
    $existing = get_page_by_path('crm', OBJECT, 'page');
    if ($existing && $existing->post_status !== 'trash') {
        update_option('uc_crm_page_id', (int) $existing->ID);
    } else {
        $id = wp_insert_post(array(
            'post_title' => 'CRM',
            'post_name' => 'crm',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_content' => '[unicybers_crm]',
        ));
        if (!is_wp_error($id)) update_option('uc_crm_page_id', (int) $id);
    }
    if (!get_option('uc_crm_import')) {
        // Never overwrite an existing WordPress CRM database during plugin activation.
        // The bundled master file is only used for a genuinely empty first installation.
        $existing_book = new UC_CRM_Book();
        $existing_counts = $existing_book->counts();
        if (!empty($existing_counts)) {
            update_option('uc_crm_import', array(
                'imported_at' => current_time('mysql'),
                'source' => 'existing_wordpress_database',
                'sheets' => count($existing_counts),
                'rows' => array_sum($existing_counts),
                'counts' => $existing_counts,
                'mismatch' => array(),
                'preserved_existing_data' => true,
            ), false);
        } else {
            UC_CRM_Import::import_master($existing_book);
        }
    }
    uc_crm_settings_get();
    uc_crm_schedule();
    uc_crm_ensure_capture_page();
}

/** Admin-AJAX transport fallback for hosts/CDN layers that return HTML on REST URLs.
 * CRM has its own session token authentication inside UC_CRM_Engine.
 */
function uc_crm_ajax_rpc() {
    nocache_headers();
    $raw = isset($_POST['payload']) ? wp_unslash($_POST['payload']) : '';
    $body = json_decode($raw, true);
    if (!is_array($body) || empty($body['fn'])) {
        wp_send_json(array('ok' => false, 'error' => 'Missing CRM action.'));
    }
    $book = new UC_CRM_Book();
    $engine = new UC_CRM_Engine($book);
    try {
        $data = $engine->call($body['fn'], isset($body['args']) ? $body['args'] : array());
        $book->flush();
        wp_send_json(array('ok' => true, 'data' => $data));
    } catch (Throwable $e) {
        $book->flush();
        wp_send_json(array('ok' => false, 'error' => $e->getMessage()));
    }
}

function uc_crm_routes() {
    register_rest_route('uc-crm/v1', '/rpc', array(
        'methods' => 'POST',
        'callback' => 'uc_crm_rpc',
        'permission_callback' => '__return_true',
    ));
    register_rest_route('uc-crm/v1', '/capture', array(
        'methods' => 'POST',
        'callback' => 'uc_crm_capture',
        'permission_callback' => '__return_true',
    ));
}

function uc_crm_rpc(WP_REST_Request $request) {
    $body = json_decode($request->get_body(), true);
    if (!is_array($body) || empty($body['fn'])) {
        return array('ok' => false, 'error' => 'Missing CRM action.');
    }
    $book = new UC_CRM_Book();
    $engine = new UC_CRM_Engine($book);
    try {
        $data = $engine->call($body['fn'], isset($body['args']) ? $body['args'] : array());
        $book->flush();
        return array('ok' => true, 'data' => $data);
    } catch (Throwable $e) {
        $book->flush();
        return array('ok' => false, 'error' => $e->getMessage());
    }
}

function uc_crm_request_path() {
    $path = wp_parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    $home = wp_parse_url(home_url('/'), PHP_URL_PATH);
    $path = '/' . trim((string) $path, '/');
    $home = '/' . trim((string) $home, '/');
    if ($home !== '/' && strpos($path, $home) === 0) {
        $path = substr($path, strlen($home));
        if ($path === '') $path = '/';
    }
    $path = untrailingslashit($path);
    return ($path === '' || $path === '/') ? '/' : $path;
}

function uc_crm_owns_front_door() {
    // The CRM is installed on its own host (crm.unicybers.com). If the Academy
    // plugin is also enabled on this WordPress install for data sync, it must
    // not take over the CRM host's landing or login routes.
    return true;
}

function uc_crm_send_app() {
    nocache_headers();
    header('Content-Type: text/html; charset=UTF-8');
    $html = file_get_contents(UC_CRM_DIR . 'assets/app.html');
    $finance_nav = '';
    if (shortcode_exists('unicybers_books')) {
        $finance_nav = '<a class="nav-i uc-finance-nav" data-page="finance" href="#p-finance" onclick="go(\'finance\');return false"><svg fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M7 15h4"/></svg><span class="nav-lbl">Finance</span></a>';
    }
    $html = str_replace('<!-- UC_FINANCE_NAV -->', $finance_nav, $html);
    $finance_frame = '';
    if (shortcode_exists('unicybers_books')) {
        $finance_frame = '<iframe class="uc-finance-frame" title="UniCybers Finance" data-src="' . esc_url(home_url('/finance/?uc_embed=1')) . '" loading="lazy" referrerpolicy="same-origin"></iframe>';
    }
    $html = str_replace('<!-- UC_FINANCE_FRAME -->', $finance_frame, $html);
    $html = str_replace('{{UC_LOGO}}', esc_url(plugins_url('assets/unicybers-logo.png', UC_CRM_FILE)), $html);
    $boot = '<script>if(/[?&]password=/i.test(location.search))history.replaceState(null,"",location.pathname);</script><script>window.UC_CRM_RPC=' . wp_json_encode(rest_url('uc-crm/v1/rpc')) . ';window.UC_CRM_AJAX=' . wp_json_encode(admin_url('admin-ajax.php')) . ';window.UC_CRM_NONCE=' . wp_json_encode(wp_create_nonce('wp_rest')) . ';'
        . file_get_contents(UC_CRM_DIR . 'assets/bridge.js') . '</script>';
    $html = preg_replace('/<head>/', '<head>' . $boot, $html, 1);
    // Working layout from theme.css + crm.css. lms.css is colour/type only.
    $theme_version = is_file(UC_CRM_DIR . 'assets/theme.css') ? filemtime(UC_CRM_DIR . 'assets/theme.css') : UC_CRM_VERSION;
    $crm_version = is_file(UC_CRM_DIR . 'assets/crm.css') ? filemtime(UC_CRM_DIR . 'assets/crm.css') : UC_CRM_VERSION;
    $theme_css = add_query_arg('ver', $theme_version, plugins_url('assets/theme.css', UC_CRM_FILE));
    $crm_css = add_query_arg('ver', $crm_version, plugins_url('assets/crm.css', UC_CRM_FILE));
    $lms_version = is_file(UC_CRM_DIR . 'assets/lms.css') ? filemtime(UC_CRM_DIR . 'assets/lms.css') : UC_CRM_VERSION;
    $lms_css = add_query_arg('ver', $lms_version, plugins_url('assets/lms.css', UC_CRM_FILE));
    $hero = esc_url(plugins_url('assets/hero-desk.webp', UC_CRM_FILE));
    $styles = '<link rel="stylesheet" id="uc-theme-final" href="' . esc_url($theme_css) . '"><link rel="stylesheet" id="uc-crm-refinement" href="' . esc_url($crm_css) . '"><link rel="stylesheet" id="uc-lms-theme" href="' . esc_url($lms_css) . '"><style id="uc-hero-desk">#uc-dash-hero{--uc-hero:url("' . $hero . '")}</style>';
    $html = preg_replace('/<\/head>/', $styles . '</head>', $html, 1);
    $live = '<script>' . file_get_contents(UC_CRM_DIR . 'assets/live.js') . '</script>';
    $html = preg_replace('/<\/body>/', $live . '</body>', $html, 1);
    echo $html;
    exit;
}

function uc_crm_send_home() {
    nocache_headers();
    header('Content-Type: text/html; charset=UTF-8');
    $settings = uc_crm_settings_get();
    $brand = isset($settings['account_name']) && $settings['account_name'] !== '' ? $settings['account_name'] : 'UniCybers';
    $html = file_get_contents(UC_CRM_DIR . 'assets/home.html');
    $replace = array(
        '{{brand}}' => esc_html($brand),
        '{{login}}' => esc_url(home_url('/login')),
        '{{enquire}}' => esc_url(home_url('/crm-lead/')),
        '{{year}}' => esc_html(gmdate('Y')),
    );
    echo strtr($html, $replace);
    exit;
}

function uc_crm_serve() {
    $page_id = (int) get_option('uc_crm_page_id');
    $path = uc_crm_request_path();
    if (uc_crm_owns_front_door() && $path === '/') {
        uc_crm_send_home();
    }
    if (uc_crm_owns_front_door() && $path === '/login') {
        uc_crm_send_app();
    }
    // Academy LMS also has a /dashboard route. On the CRM host the CRM app
    // owns this familiar entry URL, so it must be served before the LMS router.
    if (uc_crm_owns_front_door() && $path === '/dashboard') {
        uc_crm_send_app();
    }
    if ($page_id && is_page($page_id)) {
        uc_crm_send_app();
    }
}

function uc_crm_admin_menu() {
    add_menu_page('UniCybers CRM', 'UniCybers CRM', 'manage_options', 'uc-crm', 'uc_crm_admin_page', 'dashicons-groups', 58);
}

function uc_crm_admin_page() {
    if (!current_user_can('manage_options')) return;
    $import = get_option('uc_crm_import', array());
    $settings = get_option('uc_crm_settings', array());
    if (!is_array($settings)) $settings = array();
    $page_id = (int) get_option('uc_crm_page_id');
    $url = $page_id ? get_permalink($page_id) : home_url('/crm/');
    $counts = isset($import['counts']) && is_array($import['counts']) ? $import['counts'] : array();
    $focus = array('LEADS','COLLEGES','VISIT_PLAN','USERS','QUOTATIONS','AUDIT_TRAIL','TASKS','COMPANIES','CONTACTS','ARCHIVE');
    echo '<div class="wrap"><h1>UniCybers CRM</h1>';
    if (!empty($_GET['imported'])) echo '<div class="notice notice-success"><p>Master workbook imported again. Live edits made in WordPress before this were replaced by the packaged workbook.</p></div>';
    if (!empty($_GET['settings'])) echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    if (!empty($_GET['password'])) echo '<div class="notice notice-success"><p>Password updated. Sign in at the CRM with that email and the new password.</p></div>';
    if (!empty($_GET['password_error'])) echo '<div class="notice notice-error"><p>' . esc_html(sanitize_text_field(wp_unslash($_GET['password_error']))) . '</p></div>';
    echo '<p><a class="button button-primary" href="' . esc_url(home_url('/dashboard/')) . '">Open CRM</a> ';
    echo '<a class="button" href="' . esc_url(home_url('/')) . '">Landing page</a></p>';
    echo '<p class="description">On the CRM site, /dashboard/ opens the CRM and /login opens sign-in. /crm/ also opens the same desk. Keep the Academy LMS installed on lms.unicybers.com so its portal remains separate.</p>';
    echo '<h2>Imported data</h2>';
    if (!$import) {
        echo '<p>The workbook has not been imported yet. Activate the plugin again, or use the button below.</p>';
    } else {
        echo '<p>Source: <code>' . esc_html(isset($import['source']) ? $import['source'] : '') . '</code> � '
            . esc_html(isset($import['imported_at']) ? $import['imported_at'] : '')
            . ' � ' . (int) (isset($import['sheets']) ? $import['sheets'] : 0) . ' sheets � '
            . (int) (isset($import['rows']) ? $import['rows'] : 0) . ' rows</p>';
        if (!empty($import['mismatch'])) {
            echo '<div class="notice notice-error"><p>Some sheets did not match the workbook manifest. Reimport before using the CRM.</p></div>';
        }
        echo '<table class="widefat striped" style="max-width:520px"><thead><tr><th>Sheet</th><th>Rows</th></tr></thead><tbody>';
        foreach ($focus as $name) {
            echo '<tr><td>' . esc_html($name) . '</td><td>' . (int) (isset($counts[$name]) ? $counts[$name] : 0) . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<p class="description">Row counts include blank spacer rows from the workbook. Leads without an ID stay stored and stay off the Leads screen, the same way the sheet CRM skipped them.</p>';
    }
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:16px">';
    wp_nonce_field('uc_crm_reimport');
    echo '<input type="hidden" name="action" value="uc_crm_reimport">';
    echo '<p><label><input type="checkbox" name="confirm" value="1"> Replace the current CRM database with the packaged master workbook</label></p>';
    echo '<p><button class="button">Reimport master data</button></p></form>';

    echo '<h2>Set a CRM password</h2>';
    echo '<p class="description">The CRM stores a hash, so the current password cannot be shown. Set a new one here, then sign in at /login. This does not change the WordPress password.</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('uc_crm_set_password');
    echo '<input type="hidden" name="action" value="uc_crm_set_password"><table class="form-table">';
    echo '<tr><th><label>CRM email</label></th><td><input class="regular-text" type="email" name="crm_email" required autocomplete="off"></td></tr>';
    echo '<tr><th><label>New password</label></th><td><input class="regular-text" type="password" name="crm_password" required autocomplete="new-password" minlength="8"></td></tr>';
    echo '</table><p><button class="button button-primary">Set password</button></p></form>';

    echo '<h2>Account, email, Telegram and AI</h2>';
    $settings = uc_crm_settings_get();
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('uc_crm_settings');
    echo '<input type="hidden" name="action" value="uc_crm_settings"><table class="form-table">';
    $capture = (int) get_option('uc_crm_capture_page');
    $capture_url = $capture ? get_permalink($capture) : home_url('/crm-lead/');
    echo '<p>Account <code>' . esc_html($settings['account_id']) . '</code>. This install is one CRM account. A later hosted service can give each customer their own install and their own account id. Paste Telegram and AI keys here. Leave a saved secret blank to keep it. Type a single hyphen to clear it.</p>';
    echo '<p>Public lead form: <a href="' . esc_url($capture_url) . '">' . esc_html($capture_url) . '</a></p>';
    $fields = array(
        'account_name' => 'Account name',
        'timezone' => 'Timezone',
        'currency' => 'Currency',
        'tax_mode' => 'Tax (gst18, vat14, or none)',
        'from_name' => 'Mail from name',
        'from_email' => 'Mail from address',
        'report_recipients' => 'Report recipient emails',
        'report_from_email' => 'Report sender email',
        'public_phone' => 'Phone on outgoing mail',
        'default_owner' => 'Owner for website leads',
        'legacy_email_from' => 'Old email suffix still accepted at sign-in',
        'legacy_email_to' => 'Suffix stored for that sign-in',
        'lms_url' => 'Academy Handoff URL',
        'lms_sync_url' => 'Academy Batch Sync API URL',
        'lms_secret' => 'Academy Sync Shared Secret',
        'telegram_token' => 'Telegram bot token',
        'telegram_chat' => 'Telegram chat id',
        'ai_provider' => 'AI provider (claude or openai)',
        'anthropic_key' => 'Anthropic API key',
        'openai_key' => 'OpenAI API key',
        'ai_budget' => 'Monthly AI budget (USD)',
    );
    $secrets = array('lms_secret','telegram_token','telegram_chat','anthropic_key','openai_key');
    foreach ($fields as $key => $label) {
        $secret = in_array($key, $secrets, true);
        $val = $secret ? '' : (isset($settings[$key]) ? $settings[$key] : '');
        if ($key === 'report_recipients') {
            echo '<tr><th><label>' . esc_html($label) . '</label></th><td><textarea class="large-text" rows="3" name="report_recipients" placeholder="rafi@unicybers.com, coordinator@unicybers.com">' . esc_textarea($val) . '</textarea><p class="description">Comma-separate the email addresses that should receive daily, weekly and monthly CRM reports. Remove an address here to stop sending reports to it.</p></td></tr>';
            continue;
        }
        $type = $secret ? 'password' : (strpos($key, 'email') !== false ? 'email' : 'text');
        $hint = ($secret && !empty($settings[$key])) ? ' <span class="description">Saved. Paste a new value to replace it.</span>' : '';
        if ($key === 'report_from_email') $hint = ' <span class="description">Reports use this From address. Set Fluent SMTP to the same address and make sure the mailbox or domain is verified.</span>';
        if ($key === 'lms_sync_url') $hint = ' <span class="description">Read-only Academy batches endpoint. The Academy LMS must be updated and use the same shared secret below.</span>';
        if ($key === 'lms_secret') $hint .= ' <span class="description">Enter this same secret in Academy LMS Settings under Finance batch sync.</span>';
        $row_id = $key === 'lms_sync_url' ? ' id="academy-sync-settings"' : '';
        echo '<tr' . $row_id . '><th><label>' . esc_html($label) . '</label></th><td><input class="regular-text" type="' . $type . '" name="' . esc_attr($key) . '" value="' . esc_attr($val) . '" autocomplete="off">' . $hint . '</td></tr>';
    }
    echo '</table><p><button class="button button-primary">Save settings</button></p></form></div>';
}

function uc_crm_reimport() {
    if (!current_user_can('manage_options') || !check_admin_referer('uc_crm_reimport')) wp_die('Not allowed');
    if (empty($_POST['confirm'])) {
        wp_safe_redirect(admin_url('admin.php?page=uc-crm'));
        exit;
    }
    UC_CRM_Book::activate();
    delete_option('uc_crm_import');
    UC_CRM_Import::import_master(new UC_CRM_Book());
    wp_safe_redirect(admin_url('admin.php?page=uc-crm&imported=1'));
    exit;
}

function uc_crm_set_password() {
    if (!current_user_can('manage_options') || !check_admin_referer('uc_crm_set_password')) wp_die('Not allowed');
    $email = isset($_POST['crm_email']) ? sanitize_email(wp_unslash($_POST['crm_email'])) : '';
    $pw = isset($_POST['crm_password']) ? (string) wp_unslash($_POST['crm_password']) : '';
    $book = new UC_CRM_Book();
    $engine = new UC_CRM_Engine($book);
    $error = $engine->set_user_password($email, $pw);
    if ($error === '') $book->flush();
    $url = $error === '' ? admin_url('admin.php?page=uc-crm&password=1') : add_query_arg('password_error', rawurlencode($error), admin_url('admin.php?page=uc-crm'));
    wp_safe_redirect($url);
    exit;
}

function uc_crm_save_settings() {
    if (!current_user_can('manage_options') || !check_admin_referer('uc_crm_settings')) wp_die('Not allowed');
    $keys = array('account_name','timezone','currency','tax_mode','from_name','from_email','report_recipients','report_from_email','public_phone','default_owner','legacy_email_from','legacy_email_to','lms_url','lms_sync_url','lms_secret','telegram_token','telegram_chat','ai_provider','anthropic_key','openai_key','ai_budget');
    $secrets = array('lms_secret','telegram_token','telegram_chat','anthropic_key','openai_key');
    $prev = uc_crm_settings_get();
    $out = $prev;
    foreach ($keys as $key) {
        $val = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
        if ($key === 'report_recipients') $val = implode(', ', uc_crm_normalize_email_list($val));
        if ($key === 'report_from_email') $val = sanitize_email($val);
        if ($key === 'lms_sync_url') $val = esc_url_raw($val);
        if (in_array($key, $secrets, true)) {
            if ($val === '') $val = isset($prev[$key]) ? $prev[$key] : '';
            if ($val === '-') $val = '';
        }
        $out[$key] = $val;
    }
    update_option('uc_crm_settings', $out, false);
    wp_safe_redirect(admin_url('admin.php?page=uc-crm&settings=1'));
    exit;
}

function uc_crm_settings_get() {
    $defaults = array(
        'account_id' => '',
        'account_name' => 'UniCybers',
        'timezone' => 'Asia/Kolkata',
        'currency' => 'INR',
        'tax_mode' => 'gst18',
        'from_name' => 'UniCybers',
        'from_email' => '',
        'report_email' => '',
        'report_recipients' => 'rafi@unicybers.com, coordinator@unicybers.com',
        'report_from_email' => 'academy@unicybers.com',
        'public_phone' => '',
        'default_owner' => 'Sofia',
        'legacy_email_from' => '@unicybers.online',
        'legacy_email_to' => '@unicybers.com',
        'lms_url' => '',
        'lms_sync_url' => 'https://lms.unicybers.com/wp-json/uc-lms/v1/finance-batches',
        'lms_secret' => '',
        'capture_token' => '',
        'plan' => 'internal',
        'telegram_token' => '',
        'telegram_chat' => '',
        'ai_provider' => 'claude',
        'anthropic_key' => '',
        'openai_key' => '',
        'ai_budget' => '5',
    );
    $saved = get_option('uc_crm_settings', array());
    if (!is_array($saved)) $saved = array();
    $out = array_merge($defaults, $saved);
    if (!array_key_exists('report_recipients', $saved)) {
        $legacy_recipient = isset($saved['report_email']) ? trim((string) $saved['report_email']) : '';
        $out['report_recipients'] = implode(', ', array_unique(array_merge(
            uc_crm_normalize_email_list($defaults['report_recipients']),
            uc_crm_normalize_email_list($legacy_recipient)
        )));
    }
    $out['report_recipients'] = implode(', ', uc_crm_normalize_email_list($out['report_recipients']));
    if (trim((string) $out['report_from_email']) === '') $out['report_from_email'] = $defaults['report_from_email'];
    $dirty = array_keys($saved) != array_keys($out) || $out['account_id'] === '' || $out['capture_token'] === '';
    if ($out['account_id'] === '') $out['account_id'] = 'acc_' . wp_generate_password(12, false, false);
    if ($out['capture_token'] === '') $out['capture_token'] = wp_generate_password(24, false, false);
    if ($dirty) update_option('uc_crm_settings', $out, false);
    return $out;
}

function uc_crm_normalize_email_list($raw) {
    if (is_array($raw)) $raw = implode(',', $raw);
    $items = preg_split('/[\\s,;]+/', (string) $raw, -1, PREG_SPLIT_NO_EMPTY);
    $emails = array();
    foreach ($items as $item) {
        $email = strtolower(sanitize_email(trim($item)));
        if ($email !== '' && is_email($email) && !in_array($email, $emails, true)) $emails[] = $email;
    }
    return $emails;
}

function uc_crm_schedule() {
    if (!wp_next_scheduled('uc_crm_hourly')) wp_schedule_event(time() + 120, 'hourly', 'uc_crm_hourly');
    uc_crm_ensure_capture_page();
}

function uc_crm_hourly_jobs() {
    $book = new UC_CRM_Book();
    $engine = new UC_CRM_Engine($book);
    $zone = 'Asia/Kolkata';
    $settings = uc_crm_settings_get();
    if (!empty($settings['timezone'])) {
        try { new DateTimeZone($settings['timezone']); $zone = $settings['timezone']; } catch (Exception $e) {}
    }
    $now = new DateTime('now', new DateTimeZone($zone));
    $hour = (int) $now->format('G');
    $day = (int) $now->format('N');
    if ($hour === 7) {
        $engine->job_digest();
        $engine->job_visit_reminders();
    }
    if ($hour === 18 && $day === 5) $engine->job_weekly();
    $month_key = $now->format('Y-m');
    if ((int) $now->format('j') <= 7 && $hour >= 7 && get_option('uc_crm_monthly_report_sent') !== $month_key) {
        if ($engine->job_monthly()) update_option('uc_crm_monthly_report_sent', $month_key, false);
    }
    $book->flush();
}

function uc_crm_ensure_capture_page() {
    if (get_option('uc_crm_capture_page')) return;
    $existing = get_page_by_path('crm-lead', OBJECT, 'page');
    if ($existing && $existing->post_status !== 'trash') {
        update_option('uc_crm_capture_page', (int) $existing->ID);
        return;
    }
    $id = wp_insert_post(array(
        'post_title' => 'Talk to us',
        'post_name' => 'crm-lead',
        'post_status' => 'publish',
        'post_type' => 'page',
        'post_content' => '[unicybers_crm_capture]',
    ));
    if (!is_wp_error($id)) update_option('uc_crm_capture_page', (int) $id);
}

function uc_crm_capture_shortcode() {
    $settings = uc_crm_settings_get();
    $token = esc_attr($settings['capture_token']);
    $endpoint = esc_url(rest_url('uc-crm/v1/capture'));
    $brand = esc_html($settings['account_name']);
    return '<form class="uc-crm-capture" method="post" action="' . $endpoint . '" onsubmit="return window.ucCrmCapture?ucCrmCapture(this):true">'
        . '<p><label>Name<br><input name="name" required maxlength="160"></label></p>'
        . '<p><label>Phone<br><input name="phone" maxlength="40"></label></p>'
        . '<p><label>Email<br><input name="email" type="email" maxlength="160"></label></p>'
        . '<p><label>Organisation<br><input name="org" maxlength="180"></label></p>'
        . '<p><label>What do you need?<br><textarea name="notes" rows="4" maxlength="2000"></textarea></label></p>'
        . '<p style="position:absolute;left:-9999px" aria-hidden="true"><label>Leave blank<input name="company_fax" tabindex="-1" autocomplete="off"></label></p>'
        . '<input type="hidden" name="token" value="' . $token . '">'
        . '<p><button type="submit">Send</button></p>'
        . '<p class="uc-crm-capture-note">This note goes to ' . $brand . '.</p></form>'
        . '<script>function ucCrmCapture(f){var b=new FormData(f);fetch(f.action,{method:"POST",body:b}).then(function(r){return r.json()}).then(function(j){f.innerHTML=(j&&j.ok)?"Thank you. We have your note.":(j&&j.error?j.error:"Could not send.");}).catch(function(){f.insertAdjacentHTML("beforeend","<p>Could not send.</p>");});return false;}</script>';
}

function uc_crm_capture(WP_REST_Request $request) {
    $settings = uc_crm_settings_get();
    $token = (string) $request->get_param('token');
    if ($token === '' || !hash_equals((string) $settings['capture_token'], $token)) {
        return new WP_REST_Response(array('ok' => false, 'error' => 'This form is not active.'), 403);
    }
    if (trim((string) $request->get_param('company_fax')) !== '') {
        return array('ok' => true);
    }
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '0';
    $key = 'uc_crm_cap_' . md5($ip);
    $n = (int) get_transient($key);
    if ($n > 8) return new WP_REST_Response(array('ok' => false, 'error' => 'Too many notes from this network. Try again later.'), 429);
    set_transient($key, $n + 1, HOUR_IN_SECONDS);
    $book = new UC_CRM_Book();
    $engine = new UC_CRM_Engine($book);
    try {
        $id = $engine->capture_public(array(
            'name' => $request->get_param('name'),
            'phone' => $request->get_param('phone'),
            'email' => $request->get_param('email'),
            'org' => $request->get_param('org'),
            'notes' => $request->get_param('notes'),
            'source' => 'Website',
        ));
        $book->flush();
        return array('ok' => true, 'id' => $id);
    } catch (Throwable $e) {
        $book->flush();
        return new WP_REST_Response(array('ok' => false, 'error' => $e->getMessage()), 400);
    }
}
