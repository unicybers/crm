<?php
if (!defined('ABSPATH')) exit;

/**
 * LMS ↔ Career Proxy bridge.
 *
 * RapidAPI / OpenAI / Anthropic / Jooble keys stay in Apps Script Script Properties.
 * WordPress only stores the Apps Script /exec URL and SHARED_TOKEN.
 * The browser never sees either. Students cannot supply another email.
 */
final class UC_LMS_Career_Bridge {
    const REST_NS = 'uc-career/v1';

    public static function boot() {
        add_action('rest_api_init', [self::class, 'routes']);
        add_action('uc_career_nightly_sync', [self::class, 'cron_sync']);
        if (!wp_next_scheduled('uc_career_nightly_sync')) {
            wp_schedule_event(time() + 3600, 'twicedaily', 'uc_career_nightly_sync');
        }
    }

    public static function configured() {
        foreach (self::endpoints() as $ep) {
            if ($ep['url'] !== '' && $ep['token'] !== '') return true;
        }
        return false;
    }

    public static function routes() {
        register_rest_route(self::REST_NS, '/route', [
            'methods' => 'POST',
            'permission_callback' => function () { return is_user_logged_in(); },
            'callback' => [self::class, 'route'],
        ]);
        register_rest_route(self::REST_NS, '/dashboard', [
            'methods' => 'GET',
            'permission_callback' => function () { return is_user_logged_in(); },
            'callback' => [self::class, 'dashboard'],
        ]);
        register_rest_route(self::REST_NS, '/sync', [
            'methods' => 'POST',
            'permission_callback' => function () {
                if (!is_user_logged_in()) return false;
                $u = wp_get_current_user();
                $email = strtolower((string) $u->user_email);
                return $email === 'rafi@unicybers.com' || $email === 'academy@unicybers.com';
            },
            'callback' => [self::class, 'sync'],
        ]);
    }

    public static function source_label($source) {
        $s = strtolower((string) $source);
        if ($s === 'client') return 'Client mandate';
        if ($s === 'referral') return 'Referral';
        if ($s === 'board') return 'Job board';
        return 'Academy desk';
    }

    public static function dashboard() {
        $u = wp_get_current_user();
        return self::forward('getCareerDashboard', ['email' => strtolower((string) $u->user_email)]);
    }

    public static function endpoints() {
        $rows = get_option('uc_job_apis', []);
        $out = [];
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $url = trim((string)($row['url'] ?? ''));
                if ($url === '') continue;
                $out[] = ['url'=>$url, 'token'=>(string)($row['token'] ?? '')];
            }
        }
        if (!$out) {
            $url = trim((string)get_option('uc_jobs_api_url', ''));
            if ($url === '') $url = trim((string)get_option('uc_career_exec_url', ''));
            if ($url !== '') $out[] = ['url'=>$url, 'token'=>(string)get_option('uc_career_shared_token', '')];
        }
        return $out;
    }

    public static function sync() {
        $payload = [
            'persist' => true,
            'date_posted' => 'week',
            'queries' => [
                ['keywords' => 'SOC analyst', 'location' => 'India', 'country' => 'in', 'track' => 'Cybersecurity'],
                ['keywords' => 'cybersecurity analyst', 'location' => 'Bengaluru, India', 'country' => 'in', 'track' => 'Cybersecurity'],
                ['keywords' => 'information security', 'location' => 'Hyderabad, India', 'country' => 'in', 'track' => 'Cybersecurity'],
            ],
        ];
        $ends = self::endpoints();
        if (!$ends) return self::forward('syncJobs', $payload);
        $returned = 0;
        $last = ['ok'=>false, 'error'=>'No jobs API answered.'];
        foreach ($ends as $ep) {
            $res = self::post_exec($ep['url'], $ep['token'] !== '' ? $ep['token'] : (string)get_option('uc_career_shared_token', ''), 'syncJobs', $payload);
            $last = $res;
            if (!empty($res['returned'])) $returned += (int)$res['returned'];
            elseif (!empty($res['found'])) $returned += (int)$res['found'];
            elseif (!empty($res['ok'])) $returned += 0;
        }
        $last['returned'] = $returned;
        return $last;
    }

    public static function route(WP_REST_Request $req) {
        $body = $req->get_json_params();
        if (!is_array($body)) $body = [];
        $action = sanitize_key($body['action'] ?? 'getCareerDashboard');
        $u = wp_get_current_user();
        $email = strtolower((string) $u->user_email);
        $staff = in_array($email, ['rafi@unicybers.com', 'academy@unicybers.com', 'coordinator@unicybers.com', 'sofia@unicybers.com', 'noori@unicybers.com'], true)
            || user_can($u, 'manage_options');

        $student_only = ['getCareerDashboard', 'getOpportunityFeed', 'getOpportunityRanking', 'getJobMatches', 'rebuildCareerDashboard'];
        if (in_array($action, $student_only, true)) {
            $body['email'] = $email;
            unset($body['token']);
            return self::forward($action, $body);
        }
        if (!$staff) {
            return new WP_Error('forbidden', 'Staff only.', ['status' => 403]);
        }
        unset($body['token']);
        return self::forward($action, $body);
    }

    public static function cron_sync() {
        if (!self::configured()) return;
        self::sync();
    }

    public static function forward($action, $payload = []) {
        $url = trim((string) get_option('uc_career_exec_url', ''));
        if ($action === 'syncJobs') {
            $jobs = trim((string) get_option('uc_jobs_api_url', ''));
            if ($jobs !== '') $url = $jobs;
        }
        $token = (string) get_option('uc_career_shared_token', '');
        if ($url === '' || $token === '') {
            return ['ok' => false, 'mode' => 'unconfigured', 'error' => 'Set the jobs API or Apps Script /exec URL, and the shared token, in LMS Settings. The pull does not invent jobs.'];
        }
        return self::post_exec($url, $token, $action, $payload);
    }

    private static function post_exec($url, $token, $action, $payload) {
        $payload['action'] = $action;
        $payload['token'] = $token;
        $res = wp_remote_post($url, [
            'timeout' => 45,
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
        ]);
        if (is_wp_error($res)) {
            return ['ok' => false, 'error' => $res->get_error_message()];
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $text = (string) wp_remote_retrieve_body($res);
        $data = json_decode($text, true);
        if (!is_array($data)) {
            return ['ok' => false, 'error' => 'Career Proxy returned non-JSON', 'status' => $code, 'raw' => substr($text, 0, 400)];
        }
        $data['mode'] = 'live';
        $data['httpStatus'] = $code;
        return $data;
    }
}
UC_LMS_Career_Bridge::boot();
