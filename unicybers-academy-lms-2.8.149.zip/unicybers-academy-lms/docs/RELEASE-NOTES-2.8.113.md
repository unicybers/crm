# UniCybers Academy LMS 2.8.113

## Sidebar brand sizing and cache correction

- Retains the exact supplied logo URL: https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp
- Keeps the original globe and embedded UNICYBERS wordmark.
- Overlays orange ACADEMY on the original tagline position.
- The ACADEMY line uses the same measured 52% wordmark width as the embedded UNICYBERS text.
- Fixes the cause of the oversized sidebar screenshot: the portal asset version remained 2.8.110, allowing browsers to reuse stale CSS after the 2.8.112 update.
- Bumps the plugin and portal asset versions to 2.8.113.
- Adds a small inline brand-lockup fallback after the stylesheet link, so stale cached CSS cannot render the 512x512 source at intrinsic dimensions or move ACADEMY below the image.
- No database schema or LMS record changes.
