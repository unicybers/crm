<?php
/**
 * UniCybers Academy LMS: Multi-Tenant, Branding & Messaging Handlers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Handler_Tenants {

    public static function tenant_save($portal){
        $portal->guard('uc_portal_tenant_save',['super_admin']);
        global $wpdb;
        if (!$portal->has_table('tenants')) { $portal->set_flash('Tenants table is missing. Re-activate the plugin.','warn'); $portal->back('tenants'); }
        $id = absint($_POST['id'] ?? 0);
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        if ($name === '') { $portal->set_flash('Enter the academy name.','warn'); $portal->back('tenants'); }
        $slug = sanitize_title(wp_unslash($_POST['slug'] ?? '')) ?: sanitize_title($name);
        $taken = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$portal->t('tenants')} WHERE slug=%s AND id<>%d", $slug, $id));
        if ($taken) { $portal->set_flash('That slug is already used.','warn'); $portal->back('tenants'); }
        $row = $id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('tenants')} WHERE id=%d", $id)) : null;
        $logo = $row->logo_url ?? '';
        if (!empty($_FILES['logo']['tmp_name'])) {
            require_once ABSPATH.'wp-admin/includes/file.php';
            $up = wp_handle_upload($_FILES['logo'], ['test_form'=>false]);
            if (!empty($up['url']) && empty($up['error'])) $logo = $up['url'];
            elseif (!empty($up['error'])) { $portal->set_flash('Logo upload failed: '.$up['error'],'warn'); $portal->back('tenants'); }
        }
        $data = [
            'slug' => $row && (int)$row->is_home ? $row->slug : $slug,
            'name' => $name,
            'legal_name' => sanitize_text_field(wp_unslash($_POST['legal_name'] ?? '')) ?: $name,
            'tagline' => sanitize_text_field(wp_unslash($_POST['tagline'] ?? '')),
            'product_label' => strtoupper(sanitize_text_field(wp_unslash($_POST['product_label'] ?? 'ACADEMY'))),
            'logo_url' => $logo,
            'accent' => sanitize_hex_color(wp_unslash($_POST['accent'] ?? '')) ?: '#FF6B1A',
            'accent2' => sanitize_hex_color(wp_unslash($_POST['accent2'] ?? '')) ?: '#FF8A3D',
            'support_email' => sanitize_email(wp_unslash($_POST['support_email'] ?? '')),
            'mail_from' => sanitize_email(wp_unslash($_POST['mail_from'] ?? '')),
            'website' => esc_url_raw(wp_unslash($_POST['website'] ?? '')),
            'timezone' => sanitize_text_field(wp_unslash($_POST['timezone'] ?? 'Asia/Kolkata')),
            'phone' => sanitize_text_field(wp_unslash($_POST['phone'] ?? '')),
            'status' => sanitize_key($_POST['status'] ?? 'draft') === 'live' ? 'live' : 'draft',
            'notes' => sanitize_textarea_field(wp_unslash($_POST['notes'] ?? '')),
            'updated_at' => current_time('mysql'),
        ];
        if ($id && $row) {
            $wpdb->update($portal->t('tenants'), $data, ['id'=>$id]);
        } else {
            $data['is_home'] = 0;
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($portal->t('tenants'), $data);
            $id = (int)$wpdb->insert_id;
        }
        $posted = array_map('absint', (array)($_POST['member_ids'] ?? []));
        if (!$row || !(int)$row->is_home) {
            $prev = get_users(['meta_key'=>'uc_tenant_id','meta_value'=>$id,'number'=>2000,'fields'=>['ID']]);
            foreach ($prev as $u) {
                if (!in_array((int)$u->ID, $posted, true)) delete_user_meta((int)$u->ID, 'uc_tenant_id');
            }
            foreach ($posted as $uid) {
                if ($uid) update_user_meta($uid, 'uc_tenant_id', $id);
            }
        }
        $portal->set_flash('Saved '.$name.'. Use Preview to see their logo on the rail and login.');
        $portal->back('tenants', ['edit'=>$id]);
    }

    public static function tenant_preview($portal){
        $portal->guard('uc_portal_tenant_preview',['super_admin']);
        $id = absint($_POST['id'] ?? 0);
        $path = defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/';
        $domain = defined('COOKIE_DOMAIN') && COOKIE_DOMAIN ? COOKIE_DOMAIN : '';
        if ($id) {
            setcookie('uc_preview_tenant', (string)$id, time()+8*HOUR_IN_SECONDS, $path, $domain, is_ssl(), true);
            $portal->set_flash('Previewing this academy. Login, rail and portal pages use their logo and details.');
        } else {
            setcookie('uc_preview_tenant', '', time()-3600, $path, $domain, is_ssl(), true);
            $portal->set_flash('Back to home academy branding.');
        }
        $portal->back('tenants', $id ? ['edit'=>$id] : []);
    }

    public static function footer_links($portal){
        $portal->guard('uc_portal_footer_links',['super_admin']);
        update_option('uc_privacy_url', esc_url_raw(wp_unslash($_POST['privacy'] ?? ''))); update_option('uc_terms_url', esc_url_raw(wp_unslash($_POST['terms'] ?? '')));
        $portal->set_flash('Footer links saved.'); $portal->back('settings', ['_hash'=>'footer-links']);
    }

    public static function message_send($portal){
        $portal->guard('uc_portal_message_send',['super_admin','coordinator','trainer','student']);
        global $wpdb;
        $batch = absint($_POST['batch_id'] ?? 0);
        if (!in_array($batch, $portal->batch_ids(), true)) wp_die('That batch is not yours.',403);
        $body = trim(sanitize_textarea_field(wp_unslash($_POST['body'] ?? '')));
        $scope = sanitize_key($_POST['scope'] ?? 'batch');
        $to = absint($_POST['to_user_id'] ?? 0);
        if ($body === '') $portal->back('messages', ['batch'=>$batch, 'room'=>($scope==='dm'?'trainer':'class'), 'with'=>$to]);
        if ($scope === 'dm') {
            if (!$to) { $portal->set_flash('Choose who to message.','warn'); $portal->back('messages', ['batch'=>$batch,'room'=>'trainer']); }
            $portal->insert_row('messages', ['scope'=>'dm','batch_id'=>$batch,'from_user_id'=>get_current_user_id(),'to_user_id'=>$to,'body'=>$body,'created_at'=>current_time('mysql')]);
            $portal->back('messages', ['batch'=>$batch, 'room'=>'trainer', 'with'=>$to]);
        }
        $portal->insert_row('messages', ['scope'=>'batch','batch_id'=>$batch,'from_user_id'=>get_current_user_id(),'body'=>$body,'created_at'=>current_time('mysql')]);
        $portal->back('messages', ['batch'=>$batch, 'room'=>'class']);
    }

    public static function client_preview($portal){
        $portal->guard('uc_portal_client_preview', ['super_admin']);
        global $wpdb;
        if (!$portal->has_table('tenants')) { $portal->set_flash('The brand table is missing. Re-activate the plugin.','warn'); $portal->back('settings', ['_hash'=>'client-preview']); }
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        if ($name === '') { $portal->set_flash('Enter the academy name.','warn'); $portal->back('settings', ['_hash'=>'client-preview']); }
        $accent = sanitize_hex_color(wp_unslash($_POST['accent'] ?? '')) ?: '#1D4ED8';
        $table = $portal->t('tenants');
        $row = $wpdb->get_row("SELECT * FROM {$table} WHERE slug='client-preview' LIMIT 1");
        $logo = $row->logo_url ?? '';
        if (!empty($_FILES['logo']['tmp_name'])) {
            require_once ABSPATH.'wp-admin/includes/file.php';
            $up = wp_handle_upload($_FILES['logo'], ['test_form'=>false]);
            if (!empty($up['url']) && empty($up['error'])) $logo = $up['url'];
            elseif (!empty($up['error'])) { $portal->set_flash('Logo upload failed: '.$up['error'],'warn'); $portal->back('settings', ['_hash'=>'client-preview']); }
        }
        $data = [
            'slug'=>'client-preview','name'=>$name,'legal_name'=>$name,'tagline'=>'Sample academy',
            'product_label'=>'ACADEMY','logo_url'=>$logo,'accent'=>$accent,'accent2'=>$accent,
            'status'=>'live','is_home'=>0,'timezone'=>'Asia/Kolkata','updated_at'=>current_time('mysql'),
        ];
        if ($row) $wpdb->update($table, $data, ['id'=>(int)$row->id]);
        else {
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($table, $data);
            $row = $wpdb->get_row("SELECT * FROM {$table} WHERE slug='client-preview' LIMIT 1");
        }
        $tid = (int)($row->id ?? $wpdb->insert_id);
        if (sanitize_key($_POST['do'] ?? '') !== 'seats') {
            $portal->set_flash('Preview brand saved. Issue passwords when you are ready to hand the seats over.');
            $portal->back('settings', ['_hash'=>'client-preview']);
        }
        $seat_role = [1=>'student',2=>'trainer',3=>'coordinator',4=>'hr',5=>'super_admin'];
        $lines = [];
        for ($i = 1; $i <= 5; $i++) {
            $email = 'preview'.$i.'@unicybers.com';
            $user = get_user_by('email', $email);
            $pw = class_exists('UC_LMS_Security') ? UC_LMS_Security::temp_password() : wp_generate_password(12, false);
            if (!$user) {
                $id = wp_insert_user(['user_login'=>'preview'.$i,'user_email'=>$email,'user_pass'=>$pw,'display_name'=>'Preview '.$i,'role'=>'uc_student']);
                if (is_wp_error($id)) continue;
                $user = get_user_by('id', $id);
            } else {
                wp_set_password($pw, $user->ID);
                $wp_user = new WP_User($user->ID);
                $wp_user->set_role('uc_student');
            }
            delete_user_meta($user->ID, 'uc_must_change');
            delete_user_meta($user->ID, 'uc_demo_guest');
            update_user_meta($user->ID, 'uc_client_preview', '1');
            update_user_meta($user->ID, 'uc_tenant_id', $tid);
            update_user_meta($user->ID, 'uc_preview_role', $seat_role[$i]);
            update_user_meta($user->ID, 'uc_preview_password', $pw);
            $lines[] = $email.' '.$pw;
        }
        $portal->set_flash('Five preview seats are ready. They see sample data in this brand.', 'ok', implode("\n", $lines));
        $portal->back('settings', ['_hash'=>'client-preview']);
    }

    public static function preview_role($portal){
        if (!is_user_logged_in() || get_user_meta(get_current_user_id(), 'uc_client_preview', true) !== '1') {
            wp_die('This seat only shows sample data.', 'Preview', 403);
        }
        $nonce = isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '';
        if ($nonce === '' || !wp_verify_nonce($nonce, 'uc_portal_preview_role')) {
            wp_die('This form expired. Reload the page and try again.', 'Preview', 400);
        }
        $role = sanitize_key(wp_unslash($_POST['preview_role'] ?? ''));
        $allowed = ['student','trainer','coordinator','hr','super_admin'];
        if (!in_array($role, $allowed, true)) $role = 'student';
        update_user_meta(get_current_user_id(), 'uc_preview_role', $role);
        $portal->back('dashboard');
    }
}
