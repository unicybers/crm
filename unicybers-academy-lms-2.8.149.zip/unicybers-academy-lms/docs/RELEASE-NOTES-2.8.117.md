# UniCybers Academy LMS 2.8.117

## Sidebar logo correction

- Uses the exact supplied master image URL: `https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp`.
- Corrects the crop to match the square source image rather than treating it as a 2:1 horizontal image.
- Places the cropped original globe mark on the left and the two-line `UNICYBERS` / orange `ACADEMY` wordmark on the right.
- Uses the portal font measurement helper to make the visible word lines the same rendered width.
- No database schema changes or LMS data changes.

## Validation

Run PHP syntax checks, JavaScript syntax checks and ZIP integrity validation. Live visual verification is still required after cache purge.
