<?php
/**
 * UniCybers Academy LMS: Portal Login Assets & Styling Tokens.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Login_Assets {

    public static function standalone_login_css($scene = '') {
        $plugin_file = defined('UC_LMS_FILE') ? UC_LMS_FILE : __DIR__ . '/../../unicybers-academy-lms.php';
        $bright = esc_url(plugins_url('assets/login-bright.webp', $plugin_file));
        $dark = esc_url(plugins_url('assets/login-dark.webp', $plugin_file));
        $css = <<<'UCLOGINCSS'
:root{--bg:#F3F6FB;--text:#0A1628;--text2:#243B5E;--muted:#4B6180;--label:#0369A1;--border:#DCE4F0;--border2:#C5D2E4;--card:#FFFFFF;--field:#FFFFFF;--accent-ink:#C2410C;--cyan:#0891B2;--cyan-ring:rgba(8,145,178,.16);--sec-bg:#FFFFFF;--ok:#047A55;
--display:'Sora',system-ui,sans-serif;--body:'Plus Jakarta Sans',system-ui,-apple-system,'Segoe UI',sans-serif;--mono:'JetBrains Mono',ui-monospace,Menlo,monospace}
[data-theme="dark"]{--bg:#05080D;--text:#F4F7FC;--text2:#CAD5E6;--muted:#97A8C4;--label:#5CC8FF;--border:rgba(140,175,230,.13);--border2:rgba(160,190,240,.24);--card:rgba(10,16,27,.9);--field:#0A111C;--accent-ink:#FF8F52;--cyan:#22D3EE;--cyan-ring:rgba(34,211,238,.18);--sec-bg:rgba(255,255,255,.04);--ok:#3CE0A0;
--display:'Space Grotesk',system-ui,sans-serif;--body:'Figtree',system-ui,-apple-system,'Segoe UI',sans-serif}
*,*:before,*:after{box-sizing:border-box}
html,body{margin:0!important;padding:0!important;width:100%!important;height:100%!important;overflow:hidden!important;scrollbar-width:none;-ms-overflow-style:none}html::-webkit-scrollbar,body::-webkit-scrollbar,*::-webkit-scrollbar{width:0;height:0;display:none}
body{font-family:var(--body)!important;font-size:15px;line-height:1.55;background:var(--bg);color:var(--text);-webkit-font-smoothing:antialiased;transition:background-color .25s,color .25s}
:focus-visible{outline:2px solid var(--cyan);outline-offset:2px}
svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:0 0 auto}
.uc-standalone{height:100vh;height:100dvh;max-height:100dvh;min-height:0;position:relative;overflow:hidden;isolation:isolate;display:flex;flex-direction:column;
background:radial-gradient(700px 520px at 100% 100%,rgba(255,107,26,.20),transparent 62%),radial-gradient(800px 600px at 60% 0%,rgba(8,145,178,.08),transparent 60%),linear-gradient(rgba(10,40,90,.045) 1px,transparent 1px) 0 0/32px 32px,linear-gradient(90deg,rgba(10,40,90,.045) 1px,transparent 1px) 0 0/32px 32px,linear-gradient(135deg,#F8FBFF 0%,#EEF4FB 60%,#F7FAFD 100%)}
[data-theme="dark"] .uc-standalone{background:radial-gradient(900px 600px at 0% 100%,rgba(255,107,26,.16),transparent 60%),radial-gradient(900px 600px at 100% 0%,rgba(34,211,238,.08),transparent 60%),linear-gradient(rgba(255,255,255,.028) 1px,transparent 1px) 0 0/32px 32px,linear-gradient(90deg,rgba(255,255,255,.028) 1px,transparent 1px) 0 0/32px 32px,#05080D}
[data-theme="dark"] .uc-standalone:before{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;background:linear-gradient(35deg,rgba(255,107,26,.55) 0%,rgba(255,107,26,.12) 18%,transparent 34%);clip-path:polygon(0 58%,42% 100%,0 100%)}
[data-theme="dark"] .uc-standalone:after{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;background:linear-gradient(215deg,rgba(255,107,26,.5) 0%,rgba(255,107,26,.1) 16%,transparent 30%);clip-path:polygon(100% 0,100% 44%,72% 0)}
.login-nav{height:64px;flex:0 0 auto;width:min(1400px,calc(100vw - 72px));margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:30px;position:relative;z-index:3}
.login-brand{display:flex;align-items:center;gap:16px;text-decoration:none;color:var(--text)}
.login-brand img{width:104px;height:48px;object-fit:contain}
.login-brand span{font-family:var(--display);font-size:17px;font-weight:600;letter-spacing:-.01em;border-left:1px solid var(--border2);padding-left:16px}
.login-nav-right{display:flex;align-items:center;gap:26px}
.login-nav nav{font-family:var(--mono);font-size:12px;font-weight:500;letter-spacing:.12em;color:var(--text);text-transform:uppercase}
.login-nav nav i{font-style:normal;color:#FF6B1A;margin:0 10px}
.login-theme{display:inline-flex;align-items:center;gap:8px;height:40px;border:1px solid var(--border2);background:var(--sec-bg);color:var(--text);border-radius:999px;padding:0 15px;font:600 13.5px var(--body);cursor:pointer;transition:border-color .15s,box-shadow .15s}
.login-theme:hover{border-color:var(--cyan);box-shadow:0 0 0 3px var(--cyan-ring)}
.login-theme span{color:var(--accent-ink);font-size:16px;line-height:1}
.login-layout{flex:1 1 auto;min-height:0;width:min(1400px,calc(100vw - 72px));margin:0 auto;display:grid;grid-template-columns:minmax(0,1fr) minmax(400px,440px);gap:clamp(24px,4vw,64px);align-items:center;padding:0 0 4px;position:relative;overflow:hidden}
.login-hero{position:relative;min-height:0;display:flex;flex-direction:column;justify-content:center;padding:0}
.hero-scene{position:absolute;pointer-events:none;background-repeat:no-repeat;background-size:cover;background-position:center;border-radius:28px;z-index:0}
.hero-bright{right:0;top:8%;width:min(420px,48%);height:min(460px,78%);background-image:url("BRIGHT");box-shadow:0 24px 60px rgba(10,40,90,.18);-webkit-mask-image:linear-gradient(90deg,transparent 0%,#000 12%,#000 88%,transparent 100%);mask-image:linear-gradient(90deg,transparent 0%,#000 12%,#000 88%,transparent 100%)}
.hero-dark{display:none;right:0;top:4%;width:min(420px,48%);height:min(480px,86%);background-image:url("DARK");background-position:center top;box-shadow:0 24px 60px rgba(0,0,0,.35);-webkit-mask-image:linear-gradient(90deg,transparent 0%,#000 14%,#000 90%,transparent 100%);mask-image:linear-gradient(90deg,transparent 0%,#000 14%,#000 90%,transparent 100%)}
[data-theme="dark"] .hero-bright{display:none}[data-theme="dark"] .hero-dark{display:block}
.login-kicker{position:relative;font-family:var(--mono);font-size:12px;font-weight:500;letter-spacing:.2em;color:var(--accent-ink);text-transform:uppercase;margin-bottom:10px}
.login-kicker:before{content:"// "}[data-theme="dark"] .login-kicker:before{content:"> "}
.login-hero h1{position:relative;z-index:1;margin:0;font-family:var(--display);color:var(--text);font-size:clamp(46px,5.4vh,72px);line-height:.98;letter-spacing:-.035em;font-weight:700;max-width:12ch}
.login-hero h1 em{font-style:normal;background:linear-gradient(90deg,#FF5A0A,#FF8A3D);-webkit-background-clip:text;background-clip:text;color:transparent}
.login-hero h1.h-dark{display:none}
[data-theme="dark"] .login-hero h1.h-bright{display:none}[data-theme="dark"] .login-hero h1.h-dark{display:block;text-shadow:0 2px 30px rgba(0,0,0,.6)}
[data-theme="dark"] .login-hero h1 em{background:none;color:#FF6B1A;text-shadow:0 0 34px rgba(255,107,26,.45)}
.login-hero>p{position:relative;max-width:500px;margin:12px 0 16px;color:var(--text2);font-size:15px;line-height:1.45}
.login-features{position:relative;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;max-width:640px}
.login-features article{display:flex;flex-direction:column;gap:10px}
.login-features article>span{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;flex:0 0 auto}
.login-features article>span svg{width:23px;height:23px}
.login-features article:nth-child(1)>span{background:#FFE9DB;color:#C2410C}.login-features article:nth-child(2)>span{background:#E3EEFF;color:#0B63CE}.login-features article:nth-child(3)>span{background:#DDF6EB;color:#047A55}.login-features article:nth-child(4)>span{background:#EEE7FF;color:#6D3FD1}
[data-theme="dark"] .login-features article>span{background:rgba(255,107,26,.08)!important;color:#FF8F52!important;border:1px solid rgba(255,138,76,.55);box-shadow:0 0 18px rgba(255,107,26,.2)}
.login-features strong,.login-features small{display:block}
.login-features strong{font-size:14.5px;font-weight:700;color:var(--text);margin-bottom:2px}
.login-features small{font-size:13px;color:var(--text2);line-height:1.45}
.login-quote{position:relative;display:flex;align-items:center;gap:14px;margin-top:14px;color:var(--text);font-size:13.5px;font-weight:600}
.login-quote b{display:block;width:44px;height:3px;border-radius:3px;background:linear-gradient(90deg,#FF6B1A,#22D3EE)}
[data-theme="dark"] .login-quote{font-family:var(--mono);font-size:13px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;color:#D3DDEC}
[data-theme="dark"] .login-quote b{background:#FF6B1A;box-shadow:0 0 10px #FF6B1A}
.login-card{position:relative;z-index:2;background:var(--card);border:1px solid var(--border);border-radius:22px;padding:24px 30px 18px;box-shadow:0 30px 70px rgba(10,40,90,.14),0 0 0 6px rgba(255,255,255,.55);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}
.login-card:before{content:"";position:absolute;left:40px;right:40px;top:-1px;height:2px;background:linear-gradient(90deg,transparent,#FF6B1A,#22D3EE,transparent)}
[data-theme="dark"] .login-card,[data-theme="dark"] .signed-card{border-color:rgba(255,138,76,.55);box-shadow:0 0 0 1px rgba(255,107,26,.08),0 0 40px rgba(255,107,26,.18),0 30px 60px rgba(0,0,0,.5)}
.card-logo{text-align:center;margin-bottom:6px}
.card-logo img{width:150px;height:62px;object-fit:contain}
.login-eyebrow{display:block;text-align:center;font-family:var(--mono);color:var(--accent-ink);font-size:11px;font-weight:500;letter-spacing:.2em;margin-top:0}
.login-card h2{text-align:center;margin:6px 0 4px;font-family:var(--display);font-size:32px;font-weight:700;line-height:1.08;letter-spacing:-.025em;color:var(--text)}
.login-description{text-align:center;color:var(--text2);font-size:14.5px;line-height:1.45;margin:0 auto 12px;max-width:380px}
.login-form label{display:block;color:var(--text);font-size:14px;font-weight:600;margin:10px 0 6px}
.login-field{height:46px;border:1px solid var(--border2);background:var(--field);border-radius:12px;display:flex;align-items:center;gap:10px;padding:0 6px 0 14px;transition:border-color .15s,box-shadow .15s}
.login-field:focus-within{border-color:var(--cyan);box-shadow:0 0 0 3px var(--cyan-ring)}
.login-field>span{color:var(--text2);display:inline-flex}
.login-field input{flex:1;min-width:0;width:100%;border:0;outline:0;background:transparent;color:var(--text);font:500 15px var(--body)}
.login-field input::placeholder{color:var(--muted)}
.login-field button{width:40px;height:40px;border:0;border-radius:10px;background:none;color:var(--text2);cursor:pointer;display:grid;place-items:center}
.login-field button:hover{background:rgba(127,156,196,.12)}
.login-field button.on{color:var(--accent-ink)}
.login-options{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:8px 0 10px;font-size:13px}
.login-options label{margin:0;color:var(--text);font-weight:500;display:flex;align-items:center;gap:8px}
.login-options input{width:18px;height:18px;accent-color:#FF6B1A}
.login-options a{color:var(--accent-ink);font-weight:600;text-decoration:none}
.login-options a:hover{text-decoration:underline}
.login-primary{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;height:48px;border:0;border-radius:12px;background:linear-gradient(180deg,#FF8036,#FF5F0F);color:#150A02;text-decoration:none;font:700 16px var(--body);cursor:pointer;box-shadow:0 6px 18px rgba(255,107,26,.34),inset 0 1px 0 rgba(255,255,255,.35);transition:transform .15s,filter .15s}
[data-theme="dark"] .login-primary{box-shadow:0 0 0 1px rgba(255,140,80,.45),0 8px 28px rgba(255,107,26,.45),inset 0 1px 0 rgba(255,255,255,.35)}
.login-primary:hover{transform:translateY(-1px);filter:brightness(1.06)}
.login-or{display:flex;align-items:center;gap:12px;margin:10px 0 8px;color:var(--muted);font-family:var(--mono);font-size:11px;letter-spacing:.12em}
.login-or span{height:1px;background:var(--border2);flex:1}
.login-support{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.login-support a{height:38px;border:1px solid var(--border2);border-radius:12px;display:flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;color:var(--text);font-size:13px;font-weight:600;background:var(--sec-bg);transition:border-color .15s,box-shadow .15s}
.login-support a:hover{border-color:var(--cyan);box-shadow:0 0 0 3px var(--cyan-ring)}
.login-secure{display:flex;align-items:center;justify-content:center;gap:8px;color:var(--text2);font-size:12.5px;margin-top:8px}
.login-secure svg{width:15px;height:15px;color:var(--ok)}
.login-coordinator{text-align:center;color:var(--text2);font-size:12.5px;margin:6px 0 0}
.login-error{background:#FFEBEB;border:1px solid #FFC9C9;color:#B42318;padding:11px 14px;border-radius:10px;font-size:14px;font-weight:500;margin-bottom:12px}
[data-theme="dark"] .login-error{background:rgba(255,80,80,.12);border-color:rgba(255,107,107,.4);color:#FFB3B3}
.login-footer{flex:0 0 auto;width:min(1400px,calc(100vw - 72px));margin:0 auto;display:flex;justify-content:space-between;gap:20px;padding:2px 0 10px;color:var(--text2);font-size:12.5px}
.login-footer a{color:inherit;text-decoration:none;font-weight:650}
.login-footer a:hover{color:#FF6B1A}
.signed-card{position:relative;width:min(540px,calc(100vw - 40px));margin:8vh auto 0;background:var(--card);border:1px solid var(--border);border-radius:22px;padding:42px;box-shadow:0 30px 70px rgba(10,40,90,.14);text-align:center}
.signed-logo{width:200px;height:86px;object-fit:contain}
.signed-card h1{font-family:var(--display);font-size:32px;font-weight:700;letter-spacing:-.02em;margin:12px 0 8px;color:var(--text)}
.signed-card p{color:var(--text2);font-size:15px}
.signed-card .login-primary{margin-top:22px}
.signed-out{display:inline-block;margin-top:14px;color:var(--text2);font-size:14px;text-decoration:none}
.signed-out:hover{color:var(--accent-ink)}
@media(max-width:1100px){.login-layout{grid-template-columns:minmax(0,1fr);max-width:480px;overflow:auto}.login-hero,.login-footer{display:none}.login-card{max-width:440px;width:100%;margin:0 auto}.login-nav nav{display:none}}
@media(max-height:720px){.login-features,.login-quote{display:none}.login-hero>p{margin:8px 0}.login-card{padding:16px 24px 12px}}
@media(max-width:680px){.login-nav{width:calc(100vw - 32px);height:60px}.login-brand img{width:96px;height:44px}.login-brand span{font-size:14px;padding-left:12px}.login-layout{width:calc(100vw - 32px);overflow:hidden}.login-card{padding:16px 18px 12px;border-radius:18px}.card-logo img{width:112px;height:46px}.login-card h2{font-size:26px}.hero-scene{display:none!important}.theme-text{display:none}}
@media(max-width:680px){.login-card{order:-1}.login-hero{padding-top:18px}.login-features,.login-quote{display:none}}

.login-support button{height:38px;border:1px solid var(--border2);border-radius:12px;background:transparent;color:var(--text2);font:600 13px var(--body);display:flex;align-items:center;justify-content:center;gap:8px;cursor:pointer}
.login-support button:hover{border-color:var(--cyan);color:var(--text)}
.login-help{display:grid;gap:10px;margin:14px 0 4px;padding:16px;border:1px solid var(--border2);border-radius:14px;background:var(--field)}
.login-help[hidden]{display:none}
.login-help strong{font:700 14px var(--display);color:var(--text)}
.login-help label{display:grid;gap:5px;font:600 12.5px var(--body);color:var(--text2)}
.login-help input,.login-help select,.login-help textarea{font:500 14px var(--body);color:var(--text);background:var(--card);border:1px solid var(--border2);border-radius:10px;padding:10px 12px}
.login-help-msg{margin:12px 0 0;padding:11px 13px;border-radius:12px;font:600 13px var(--body);background:rgba(245,158,11,.12);color:var(--text)}
.login-help-msg.ok{background:rgba(16,185,129,.13)}
UCLOGINCSS;
        return str_replace(['url("BRIGHT")', 'url("DARK")'], ['url("'.$bright.'")', 'url("'.$dark.'")'], $css);
    }

    public static function login_css_payload() {
        ob_start();
        self::login_page_styles();
        $css = ob_get_clean();
        $css = preg_replace('/^<style[^>]*>/i', '', $css);
        $css = preg_replace('/<\/style>\s*$/i', '', $css);
        return $css ?: '';
    }

    public static function login_page_styles() {
        if (!is_singular() || is_user_logged_in()) return;
        global $post;
        if (!$post || (!has_shortcode($post->post_content, 'uc_login') && !has_shortcode($post->post_content, 'uc_lms_dashboard'))) return;
        echo '<style id="uc-login-premium-css">
        html,body{background:#02060b!important;margin:0!important;padding:0!important}
        body.uc-login-mode{overflow:hidden!important} body.uc-login-mode-active{overflow:hidden!important} body.uc-login-mode-active>*:not(.uc-login-page-shell):not(#wpadminbar){visibility:hidden!important;pointer-events:none!important} body.uc-login-mode-active .uc-login-page-shell{visibility:visible!important;pointer-events:auto!important}
        body.uc-login-mode #wpadminbar{display:none!important}
        body.uc-login-mode .wp-site-blocks,body.uc-login-mode .wp-site-blocks>main,body.uc-login-mode main,body.uc-login-mode .entry-content,body.uc-login-mode .wp-block-post-content{width:100%!important;max-width:none!important;margin:0!important;padding:0!important;box-sizing:border-box!important}
        body.uc-login-mode .wp-site-blocks>header,body.uc-login-mode .wp-site-blocks>footer,body.uc-login-mode header,body.uc-login-mode footer,body.uc-login-mode .wp-block-post-title{display:none!important}
        .uc-login-page-shell{position:fixed!important;left:50vw!important;right:auto!important;top:0!important;bottom:0!important;width:100vw!important;max-width:100vw!important;transform:translateX(-50%)!important;height:auto!important;min-width:0!important;min-height:100svh!important;margin:0!important;padding:0!important;z-index:2147483000!important;box-sizing:border-box!important;overflow-y:auto!important;overflow-x:hidden!important;background:radial-gradient(circle at 82% 8%,rgba(255,107,26,.17),transparent 23%),radial-gradient(circle at 48% 55%,rgba(21,105,175,.13),transparent 30%),linear-gradient(120deg,#02060b 0%,#06111c 53%,#02060b 100%);color:#f6f8fb;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
        .uc-login-page-shell:before{content:"";position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:48px 48px;mask-image:linear-gradient(90deg,#000 0%,#000 66%,transparent 100%);pointer-events:none}
        .uc-login-page-shell:after{content:"";position:absolute;width:650px;height:650px;right:-260px;bottom:-320px;border-radius:50%;background:radial-gradient(circle,rgba(255,107,26,.22),rgba(255,107,26,0) 68%);pointer-events:none}
        .uc-login-nav{position:relative;z-index:3;width:100%;max-width:1500px;margin:0 auto;padding:24px 5vw 0;text-align:right;font-size:11px;font-weight:900;letter-spacing:2px;color:#a5b2c0;white-space:nowrap}.uc-login-nav span{margin:0 12px;color:#455361}
        .uc-login-layout{position:relative;z-index:2;display:grid;grid-template-columns:minmax(0,1fr) minmax(450px,570px);gap:5vw;align-items:center;max-width:1500px;min-height:calc(100svh - 55px);margin:0 auto;padding:28px 5vw 50px;box-sizing:border-box}
        .uc-login-pitch{max-width:680px;padding-bottom:15px}.uc-login-kicker{font-size:13px;font-weight:950;letter-spacing:2.7px;color:#ff7830;margin-bottom:19px}.uc-login-pitch h2{font-size:clamp(62px,6.4vw,98px);line-height:.88;letter-spacing:-5px;margin:0 0 26px;font-weight:950;color:#f7f8fa}.uc-login-pitch h2 em{font-style:normal;color:#ff6b1a}.uc-login-pitch p{max-width:600px;font-size:19px;line-height:1.55;color:#b2bfcc;margin:0 0 36px}
        .uc-login-pillars{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;max-width:650px}.uc-login-pillars div{min-height:125px;padding:19px;border:1px solid rgba(128,163,195,.22);border-radius:15px;background:rgba(5,15,25,.56);box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}.uc-login-pillars b{display:block;font-size:18px;color:#f5f7fa;margin-bottom:9px}.uc-login-pillars span{font-size:12px;line-height:1.5;color:#8d9bab}.uc-login-quote{margin-top:28px;color:#7e93a7;font-size:12px;font-weight:800;letter-spacing:2.4px;text-transform:uppercase}
        .uc-login-card{width:100%;max-width:570px;box-sizing:border-box;padding:40px 42px 29px;border:1px solid rgba(90,150,197,.58);border-radius:24px;background:linear-gradient(145deg,rgba(10,23,38,.985),rgba(3,10,18,.985));box-shadow:0 35px 100px rgba(0,0,0,.58),0 0 70px rgba(255,107,26,.07),inset 0 1px 0 rgba(255,255,255,.07);backdrop-filter:blur(20px);justify-self:end}
        .uc-login-logo img{display:block;width:auto;height:92px;max-width:320px;object-fit:contain;margin:0 0 25px;border-radius:0}.uc-login-portal-label{font-size:11px;font-weight:950;letter-spacing:2.8px;color:#ff6b1a;margin-bottom:9px}.uc-login-card h1{font-size:clamp(50px,4.1vw,68px);line-height:.92;letter-spacing:-3.5px;margin:0;color:#f7f8fa;font-weight:950}.uc-login-rule{width:58px;height:4px;border-radius:5px;background:#ff6b1a;margin:18px 0 18px}.uc-login-description{font-size:14px;line-height:1.6;color:#9eacbc;margin:0 0 23px;max-width:480px}
        .uc-login-error{padding:11px 13px;margin:0 0 16px;border:1px solid rgba(255,91,91,.35);border-radius:10px;background:rgba(150,30,35,.13);color:#ff9b9b;font-size:12px}.uc-login-form label{display:block;font-size:12px;font-weight:850;color:#edf1f5;margin:0 0 8px}.uc-login-input{position:relative;display:flex;align-items:center;margin-bottom:17px}.uc-login-input>span{position:absolute;left:16px;color:#8ea0b4;font-size:18px;z-index:1}.uc-login-input input{width:100%;height:56px;box-sizing:border-box;padding:0 48px;border:1px solid #3a4c60;border-radius:11px;background:#081523;color:#f4f7fa;font-size:15px;outline:none}.uc-login-input input:focus{border-color:#ff7b32;box-shadow:0 0 0 3px rgba(255,107,26,.11)}.uc-login-input input::placeholder{color:#657689}.uc-login-input button{position:absolute;right:9px;border:0;background:transparent;color:#8ea0b4;cursor:pointer;width:34px;height:34px;display:grid;place-items:center}.uc-login-input button.is-open{color:#f4f7fa}.uc-login-options{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:1px 0 18px;font-size:12px}.uc-login-remember{display:flex!important;align-items:center;gap:8px!important;margin:0!important;font-weight:600!important;color:#91a0b0!important}.uc-login-remember input{width:15px;height:15px;accent-color:#ff6b1a}.uc-login-options a{color:#ff965f;text-decoration:none;font-weight:800}.uc-login-submit{width:100%;height:56px;border:1px solid #ff6b1a;border-radius:11px;background:#ff6b1a;color:#fff;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:11px;font-size:14px;font-weight:900;cursor:pointer;box-shadow:0 12px 30px rgba(255,107,26,.18);transition:.18s ease}.uc-login-submit:hover{background:#ff7b32;transform:translateY(-1px)}.uc-login-submit span{font-size:19px}.uc-login-help{display:block;margin:14px auto 0;border:0;background:none;color:#8e9baa;font-size:12px;cursor:pointer}.uc-login-or{display:flex;align-items:center;gap:12px;margin:18px 0 12px;color:#667789;font-size:9px;letter-spacing:1.7px}.uc-login-or span{height:1px;background:#2a3948;flex:1}.uc-login-support{display:grid;grid-template-columns:1fr 1fr;gap:10px}.uc-login-support a{height:43px;display:flex;align-items:center;justify-content:center;border:1px solid #34485b;border-radius:10px;background:rgba(3,9,15,.5);color:#d9e0e7;text-decoration:none;font-size:11px;font-weight:850}.uc-login-support a:hover{border-color:#ff6b1a;color:#fff}.uc-login-secure{display:flex;align-items:center;justify-content:center;gap:8px;border-top:1px solid rgba(255,255,255,.08);margin-top:18px;padding-top:14px;color:#748496;font-size:10.5px}.uc-login-secure span{color:#ff6b1a;font-size:15px}.uc-login-already{position:relative!important;right:auto!important;top:auto!important;max-width:570px;margin:12vh auto!important}
        @media(max-width:1100px){.uc-login-layout{grid-template-columns:1fr;max-width:680px;padding-top:45px}.uc-login-pitch{display:none}.uc-login-nav{display:none}.uc-login-card{max-width:570px;margin:0 auto;justify-self:center}.uc-login-layout{min-height:100svh}}
        @media(max-width:600px){.uc-login-layout{padding:22px 14px 35px}.uc-login-card{padding:30px 20px 24px;border-radius:18px}.uc-login-logo img{height:76px;max-width:280px;margin-bottom:21px}.uc-login-card h1{font-size:43px;letter-spacing:-2.3px}.uc-login-description{font-size:13px}.uc-login-support{grid-template-columns:1fr}.uc-login-options{font-size:11px}.uc-login-options a{white-space:nowrap}.uc-login-input input{height:54px}.uc-login-submit{height:55px}}
        </style>';
    }

    public static function frontend_assets() {
        if (!is_singular()) return;
        global $post;
        if (!$post) return;
        if (has_shortcode($post->post_content, 'uc_lms_dashboard') || has_shortcode($post->post_content, 'uc_trainer_dashboard') || has_shortcode($post->post_content, 'uc_course_catalog')) {
            wp_register_style('uc-front', false);
            wp_enqueue_style('uc-front');
            wp_add_inline_style('uc-front', '.uc-front{max-width:1100px;margin:20px auto;font-family:system-ui}.uc-card{background:#fff;border:1px solid #ddd;border-radius:12px;padding:20px;margin:12px 0}.uc-btn{display:inline-block;background:#ff6b1a;color:#fff!important;text-decoration:none;padding:10px 16px;border-radius:8px;font-weight:700;margin:4px}.uc-muted{color:#666}.uc-grid-front{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px}
            .uc-student-shell{max-width:1180px;margin:34px auto 70px;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#102033}.uc-student-top{display:flex;align-items:center;justify-content:space-between;padding:10px 0 24px;border-bottom:1px solid #e6ebf0}.uc-student-top img{width:auto;height:48px;max-width:230px;object-fit:contain}.uc-student-user{display:flex;align-items:center;gap:14px;font-size:12px;color:#718096}.uc-student-user span{padding:6px 10px;border-radius:20px;background:#f2f5f8;color:#657386;font-weight:700}.uc-student-user strong{color:#1b2a3a}.uc-student-user a{color:#ff6b1a;text-decoration:none;font-weight:800}.uc-student-hero{margin-top:28px;padding:42px 46px;border-radius:22px;background:linear-gradient(125deg,#07111c,#0c1c2b 60%,#13293b);color:#fff;display:flex;justify-content:space-between;align-items:center;overflow:hidden;position:relative}.uc-student-hero:after{content:"";position:absolute;width:360px;height:360px;right:-140px;top:-170px;border-radius:50%;background:rgba(255,107,26,.16)}.uc-student-kicker{font-size:11px;letter-spacing:2.5px;font-weight:900;color:#ff8b4a;margin-bottom:10px}.uc-student-hero h1{font-size:clamp(34px,4vw,54px);letter-spacing:-2px;line-height:1;margin:0 0 12px}.uc-student-hero p{margin:0;color:#b6c3d1;font-size:15px}.uc-student-hero-mark{position:relative;z-index:1;width:110px;height:110px;border:1px solid rgba(255,255,255,.2);border-radius:24px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:34px;font-weight:950;color:#ff7a32;letter-spacing:-2px}.uc-student-hero-mark span{font-size:10px;letter-spacing:3px;color:#aab7c5;margin-top:3px}.uc-student-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:16px 0 44px}.uc-student-stats>div{padding:20px 22px;background:#fff;border:1px solid #e3e9ef;border-radius:14px}.uc-student-stats span{display:block;color:#7b8795;font-size:11px;text-transform:uppercase;letter-spacing:1px;font-weight:800}.uc-student-stats strong{display:block;margin-top:8px;font-size:30px;line-height:1;color:#172636}.uc-student-section{margin-bottom:42px}.uc-section-heading{display:flex;justify-content:space-between;align-items:end;margin-bottom:16px}.uc-section-heading span{font-size:10px;letter-spacing:2px;font-weight:900;color:#ff6b1a}.uc-section-heading h2{margin:5px 0 0;font-size:29px;letter-spacing:-.8px;color:#152536}.uc-course-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}.uc-course-card{display:flex;gap:18px;padding:22px;background:#fff;border:1px solid #e3e9ef;border-radius:16px;box-shadow:0 8px 25px rgba(18,36,53,.04)}.uc-course-icon{width:52px;height:52px;flex:0 0 52px;border-radius:14px;background:#0a1825;color:#ff6b1a;display:flex;align-items:center;justify-content:center;font-weight:950;letter-spacing:-1px}.uc-small-label{font-size:9px;letter-spacing:1.5px;font-weight:900;color:#8794a2}.uc-course-body h3,.uc-class-info h3{margin:5px 0 4px;font-size:19px;color:#18293a}.uc-course-body p{margin:0;color:#697888;font-size:13px}.uc-course-date{margin-top:14px;font-size:11px;color:#8b98a5}.uc-class-list{display:grid;gap:10px}.uc-class-row{display:grid;grid-template-columns:72px minmax(0,1fr) auto;gap:20px;align-items:center;padding:17px 18px;background:#fff;border:1px solid #e3e9ef;border-radius:14px}.uc-class-date{width:58px;height:58px;border-radius:12px;background:#fff2ea;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#ff6b1a}.uc-class-date strong{font-size:22px;line-height:1}.uc-class-date span{font-size:9px;font-weight:900;letter-spacing:1px;margin-top:4px}.uc-class-info p{margin:6px 0 0;color:#718091;font-size:12px}.uc-class-actions{display:flex;justify-content:flex-end}.uc-live-btn,.uc-outline-btn{display:inline-flex;align-items:center;gap:8px;padding:11px 16px;border-radius:9px;text-decoration:none;font-size:11px;font-weight:900}.uc-live-btn{background:#ff6b1a;color:#fff!important}.uc-outline-btn{border:1px solid #d5dde5;color:#243548!important}.uc-live-btn span{font-size:16px}.uc-status{font-size:11px;color:#8a96a3;font-weight:700}.uc-student-columns{display:grid;grid-template-columns:1fr 1fr;gap:22px}.uc-resource{display:flex;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid #e8edf1}.uc-resource-icon{width:34px;height:34px;border-radius:9px;background:#0b1825;color:#ff6b1a;display:flex;align-items:center;justify-content:center;font-weight:900}.uc-resource div:nth-child(2){flex:1}.uc-resource strong,.uc-resource span{display:block}.uc-resource strong{font-size:13px;color:#243548}.uc-resource span{font-size:10px;color:#8793a0;margin-top:3px}.uc-resource a{font-size:10px;color:#ff6b1a;text-decoration:none;font-weight:900}.uc-notice{padding:14px 0;border-bottom:1px solid #e8edf1}.uc-notice strong{font-size:13px;color:#243548}.uc-notice>span{display:block;font-size:9px;color:#8c98a5;margin:4px 0 7px}.uc-notice div{font-size:12px;line-height:1.5;color:#667586}.uc-empty{padding:22px;border:1px dashed #cfd8e1;border-radius:14px;color:#7b8794;background:#fbfcfd}
            @media(max-width:760px){.uc-student-shell{margin:18px 12px 50px}.uc-student-top{align-items:flex-start}.uc-student-top img{height:39px;max-width:180px}.uc-student-user{flex-wrap:wrap;justify-content:flex-end;gap:7px}.uc-student-hero{padding:30px 25px}.uc-student-hero-mark{display:none}.uc-student-stats{grid-template-columns:1fr 1fr;margin-bottom:34px}.uc-student-columns{grid-template-columns:1fr}.uc-class-row{grid-template-columns:58px 1fr}.uc-class-actions{grid-column:2;justify-content:flex-start}.uc-course-grid{grid-template-columns:1fr}}
            @media(max-width:460px){.uc-student-user strong{display:none}.uc-student-stats strong{font-size:25px}.uc-student-hero h1{font-size:34px}.uc-section-heading h2{font-size:25px}}
            ');
            $ver = defined('UC_Academy_LMS::VERSION') ? UC_Academy_LMS::VERSION : '2.8.75';
            wp_register_script('uc-front-js', false, [], $ver, true);
            wp_enqueue_script('uc-front-js');
            wp_add_inline_script('uc-front-js', "(function(){var timers={};document.addEventListener('click',function(e){var a=e.target.closest('[data-uc-join]');if(!a)return;var sid=a.getAttribute('data-uc-join'),nonce=a.getAttribute('data-uc-nonce');if(!sid||!nonce||timers[sid])return;var endpoint='" . esc_js(rest_url('uc-lms/v1/attendance/heartbeat')) . "';var ping=function(){fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','X-WP-Nonce':nonce},body:JSON.stringify({session_id:sid}),credentials:'same-origin'}).catch(function(){});};ping();timers[sid]=window.setInterval(ping,60000);});})();");
        }
    }
}
