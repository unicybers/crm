<?php
/**
 * UniCybers Academy LMS: Admin Students & Trainers Management.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Admin_Students extends UC_LMS_Admin_Base {
    public static function instance() {
        static $i = null;
        if (!$i) $i = new self();
        return $i;
    }

    public function students_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $batch_filter = absint($_GET['batch_id'] ?? 0);
        $students = $this->student_users();
        $batches = $wpdb->get_results("SELECT id, name FROM {$this->table('batches')} ORDER BY name");
        echo '<div class="wrap"><h1>Students</h1>';
        $this->render_notice();
        echo '<div class="uc-panel"><h2>Create Student</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('uc_save_student');
        echo '<input type="hidden" name="action" value="uc_save_student"><table class="form-table"><tr><th>Name</th><td><input name="name" required class="regular-text"></td></tr><tr><th>Email</th><td><input name="email" type="email" required class="regular-text"></td></tr><tr><th>Phone</th><td><input name="phone" class="regular-text"></td></tr><tr><th>Password</th><td><input name="password" type="password" class="regular-text" placeholder="Leave blank to generate"></td></tr></table>';
        submit_button('Create Student');
        echo '</form></div>';
        echo '<div class="uc-panel"><h2>Enroll Student</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('uc_enrol_student');
        echo '<input type="hidden" name="action" value="uc_enrol_student"><select name="user_id" required><option value="">Select student</option>';
        foreach ($students as $u) echo '<option value="' . absint($u->ID) . '">' . esc_html($u->display_name . ' | ' . $u->user_email) . '</option>';
        echo '</select> <select name="batch_id" required><option value="">Select batch</option>';
        foreach ($batches as $b) echo '<option value="' . absint($b->id) . '" ' . selected($batch_filter, $b->id, false) . '>' . esc_html($b->name) . '</option>';
        echo '</select> ';
        submit_button('Enroll', 'primary', 'submit', false);
        echo '</form></div>';
        echo '<h2>Student Accounts</h2><table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Batches</th></tr></thead><tbody>';
        foreach ($students as $u) {
            $phone = get_user_meta($u->ID, 'uc_phone', true);
            $b = $wpdb->get_results($wpdb->prepare("SELECT ba.name FROM {$this->table('batches')} ba JOIN {$this->table('enrolments')} e ON e.batch_id=ba.id WHERE e.user_id=%d AND e.status='active'", $u->ID));
            echo '<tr><td>' . esc_html($u->display_name) . '</td><td>' . esc_html($u->user_email) . '</td><td>' . esc_html($phone) . '</td><td>' . esc_html(implode(', ', wp_list_pluck($b, 'name'))) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function save_student() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_student')) wp_die('Not allowed');
        $email = sanitize_email($_POST['email'] ?? '');
        $name = sanitize_text_field($_POST['name'] ?? '');
        if (!$email || !$name) wp_die('Name and email are required.');
        if (email_exists($email)) $this->redirect('uc-students', $this->notice('error', 'A WordPress user already exists with this email.'));
        $password = $_POST['password'] ?? '';
        $password = $password ?: wp_generate_password(16, true, true);
        $uid = wp_create_user($email, $password, $email);
        if (is_wp_error($uid)) $this->redirect('uc-students', $this->notice('error', $uid->get_error_message()));
        wp_update_user(['ID' => $uid, 'display_name' => $name, 'role' => 'uc_student']);
        update_user_meta($uid, 'uc_phone', sanitize_text_field($_POST['phone'] ?? ''));
        $this->audit('student', $uid, 'create', null, ['email' => $email, 'name' => $name]);
        $this->redirect('uc-students', $this->notice('success', 'Student created. Password was ' . ($password ? 'generated or supplied' : 'generated') . '. Use WordPress password reset or your normal onboarding email for delivery.'));
    }

    public function enrol_student() {
        if (!$this->can_manage() || !check_admin_referer('uc_enrol_student')) wp_die('Not allowed');
        global $wpdb;
        $uid = absint($_POST['user_id'] ?? 0);
        $bid = absint($_POST['batch_id'] ?? 0);
        if (!$uid || !$bid) wp_die('Select a student and batch.');
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table('enrolments')} WHERE batch_id=%d AND user_id=%d", $bid, $uid));
        if ($exists) $this->redirect('uc-students', $this->notice('error', 'Student is already enrolled in this batch.'));
        $wpdb->insert($this->table('enrolments'), ['batch_id' => $bid, 'user_id' => $uid, 'status' => 'active', 'enrolled_at' => $this->now()]);
        $this->audit('enrolment', $wpdb->insert_id, 'create');
        $this->redirect('uc-students', $this->notice('success', 'Student enrolled.'));
    }

    public function remove_enrolment() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_GET['id'] ?? 0);
        check_admin_referer('uc_remove_enrolment_' . $id);
        global $wpdb;
        $wpdb->update($this->table('enrolments'), ['status' => 'inactive'], ['id' => $id]);
        $this->redirect('uc-students', $this->notice('success', 'Enrollment disabled.'));
    }

    public function trainers_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $trainers = $this->trainer_users();
        $batches = $wpdb->get_results("SELECT id, name, trainer_user_id FROM {$this->table('batches')} ORDER BY name ASC");
        echo '<div class="wrap"><h1>Trainers</h1>';
        $this->render_notice();
        echo '<div class="uc-panel"><h2>Create Trainer</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('uc_save_trainer');
        echo '<input type="hidden" name="action" value="uc_save_trainer"><table class="form-table"><tr><th>Name</th><td><input name="name" required class="regular-text"></td></tr><tr><th>Email</th><td><input name="email" type="email" required class="regular-text"></td></tr><tr><th>Phone</th><td><input name="phone" class="regular-text"></td></tr><tr><th>Password</th><td><input name="password" type="password" class="regular-text" placeholder="Leave blank to generate"></td></tr></table>';
        submit_button('Create Trainer');
        echo '</form></div>';
        echo '<div class="uc-panel"><h2>Assign Trainer to Batch</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('uc_assign_trainer_batch');
        echo '<input type="hidden" name="action" value="uc_assign_trainer_batch"><select name="trainer_user_id" required><option value="">Select trainer</option>';
        foreach ($trainers as $u) echo '<option value="' . absint($u->ID) . '">' . esc_html($u->display_name . ' | ' . $u->user_email) . '</option>';
        echo '</select> <select name="batch_id" required><option value="">Select batch</option>';
        foreach ($batches as $b) echo '<option value="' . absint($b->id) . '">' . esc_html($b->name) . '</option>';
        echo '</select> ';
        submit_button('Assign', 'primary', 'submit', false);
        echo '</form></div>';
        echo '<h2>Trainer Accounts</h2><table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Assigned Batches</th></tr></thead><tbody>';
        foreach ($trainers as $u) {
            $phone = get_user_meta($u->ID, 'uc_phone', true);
            $assigned = $wpdb->get_results($wpdb->prepare("SELECT name FROM {$this->table('batches')} WHERE trainer_user_id=%d", $u->ID));
            echo '<tr><td>' . esc_html($u->display_name) . '</td><td>' . esc_html($u->user_email) . '</td><td>' . esc_html($phone) . '</td><td>' . esc_html(implode(', ', wp_list_pluck($assigned, 'name'))) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function assign_trainer_batch() {
        if (!$this->can_manage() || !check_admin_referer('uc_assign_trainer_batch')) wp_die('Not allowed');
        global $wpdb;
        $trainer_id = absint($_POST['trainer_user_id'] ?? 0);
        $batch_id = absint($_POST['batch_id'] ?? 0);
        if (!$trainer_id || !$batch_id) wp_die('Select trainer and batch.');
        $wpdb->update($this->table('batches'), ['trainer_user_id' => $trainer_id, 'updated_at' => $this->now()], ['id' => $batch_id]);
        $this->refresh_session_links($batch_id);
        $this->audit('batch', $batch_id, 'assign_trainer', null, ['trainer_id' => $trainer_id]);
        $this->redirect('uc-trainers', $this->notice('success', 'Trainer assigned to batch.'));
    }

    public function save_trainer() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_trainer')) wp_die('Not allowed');
        $email = sanitize_email($_POST['email'] ?? '');
        $name = sanitize_text_field($_POST['name'] ?? '');
        if (!$email || !$name) wp_die('Name and email are required.');
        if (email_exists($email)) $this->redirect('uc-trainers', $this->notice('error', 'A user already exists with this email.'));
        $password = $_POST['password'] ?? '';
        $password = $password ?: wp_generate_password(16, true, true);
        $uid = wp_create_user($email, $password, $email);
        if (is_wp_error($uid)) $this->redirect('uc-trainers', $this->notice('error', $uid->get_error_message()));
        wp_update_user(['ID' => $uid, 'display_name' => $name, 'role' => 'uc_trainer']);
        update_user_meta($uid, 'uc_phone', sanitize_text_field($_POST['phone'] ?? ''));
        $this->audit('trainer', $uid, 'create', null, ['email' => $email, 'name' => $name]);
        $this->redirect('uc-trainers', $this->notice('success', 'Trainer created.'));
    }
}
