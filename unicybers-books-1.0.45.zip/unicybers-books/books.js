(function () {
  var form = document.getElementById('ubDoc');
  if (form) {
    var preview = document.getElementById('ubPreview');
    var money = function (n) { return (Math.round(n * 100) / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var q = function (name) { var el = form.elements[name]; return el ? el.value : ''; };
    var sacFor = function (text) {
      var t = (text || '').toLowerCase();
      if (/host/.test(t)) return { code: '998315', why: 'The line mentions hosting, so the suggestion is SAC 998315, Hosting and information technology (IT) infrastructure provisioning services.', rate: 18 };
      if (/licen[cs]e|software/.test(t) && !/train|coach|course/.test(t)) return { code: '998316', why: 'The line mentions software or a licence, so the suggestion is SAC 998316, Information technology infrastructure and network management services. Change it if this is only a software licence.', rate: 18 };
      return { code: '999293', why: 'Commercial cybersecurity training, coaching, or LMS training is suggested as SAC 999293, Commercial training and coaching services, at 18% unless you override it.', rate: 18 };
    };
    var paint = function () {
      if (!preview) return;
      var customer = q('customer_type') === 'individual' ? 'individual' : 'b2b';
      var supply = q('supply');
      var country = (q('contact_country') || 'India').trim();
      var state = (q('contact_state') || '').trim();
      var place = (q('place_state') || '').trim();
      if (customer === 'individual' && !place) place = 'Andhra Pradesh';
      var gstin = customer === 'individual' ? '' : (q('contact_gstin') || '').toUpperCase();
      var text = (q('component') || '') + ' ' + (q('scope') || '');
      var sac = sacFor(text);
      var typed = (q('sac') || '').replace(/[^0-9a-z]/gi, '').toUpperCase();
      if (typed) sac = { code: typed, why: 'SAC ' + typed + ' is the code on this line. ' + sac.why, rate: sac.rate };
      var rateField = q('tax_rate');
      var rate = rateField === '' ? sac.rate : (parseFloat(rateField) || 0);
      var amount = parseFloat(q('amount')) || 0;
      var mode = q('price_mode') === 'excl' ? 'excl' : 'incl';
      var india = country.toLowerCase() === 'india' || country === '';
      var code = gstin.slice(0, 2);
      var pos = customer === 'b2b' ? (state || place) : place;
      var same = /^[0-9]{2}$/.test(code) && customer === 'b2b' ? code === '37' : (pos === '' || /andhra/i.test(pos) || pos === '37');
      var charge = supply === 'domestic' && india;
      var exception = false;
      var why = '';
      if (supply === 'export_lut') why = 'Zero-rated export of services under LUT, not a domestic supply. GST is not charged.';
      else if (supply === 'no_gst') {
        why = (q('supply_reason') || '').trim() || 'GST not applicable, with a reason still to type.';
        if (india) exception = true;
        charge = false;
      } else if (!india) {
        charge = false;
        exception = true;
        why = 'The customer country is outside India, but the treatment is still domestic. Pick export of services under LUT, or GST not applicable with a reason.';
      } else if (customer === 'individual') why = 'A registered supplier charges GST on taxable coaching even when the student is an individual. Place of supply is ' + pos + '.';
      else why = same ? 'Same state as this firm (Andhra Pradesh, code 37), so the tax splits into CGST and SGST.' : 'The customer is in another Indian state, so the tax is IGST.';
      if (exception && customer === 'individual' && india && supply === 'no_gst') why += ' Ordinary commercial coaching by this registered LLP is taxable, so no tax is not the default for an Indian individual. This stays on the review list.';
      var base = amount, tax = 0;
      if (charge && rate) {
        if (mode === 'incl') { base = amount / (1 + rate / 100); tax = amount - base; }
        else { tax = amount * rate / 100; base = amount; }
      }
      var cgst = 0, sgst = 0, igst = 0;
      if (charge) { if (same) { cgst = tax / 2; sgst = tax / 2; } else igst = tax; }
      var total = mode === 'incl' || !charge ? amount : base + tax;
      var technical = /call centre|call center|technical service/i.test(text);
      var tdsRate = technical ? 2 : 10;
      var tds;
      if (supply === 'export_lut' || !india) tds = 'TDS not required. The payer is outside India.';
      else if (customer !== 'b2b') tds = 'TDS not required. The payer is an individual.';
      else if (amount < 50000) tds = 'TDS not required. Under the 194J limit of Rs 50,000 for this payee this year.';
      else tds = 'Expected TDS receivable. Section 194J at ' + tdsRate + '%. The customer may deduct. Track it. Do not reduce the GST invoice total. TDS does not reduce the taxable value for GST.';
      var set = function (id, text) { var n = preview.querySelector('[data-f="' + id + '"]'); if (n) n.textContent = text; };
      set('type', ({quote:'Quotation',proforma:'Proforma',invoice:'Tax Invoice',purchase_order:'Purchase Order',credit_note:'Credit Note',delivery_note:'Delivery Note'})[q('doc_type')] || 'Document');
      set('contact', q('contact_name') || 'Customer');
      set('ctype', customer === 'individual' ? 'Individual' : 'B2B');
      set('component', q('component') || 'LMS service');
      set('basis', q('basis') || 'One Time');
      set('scope', q('scope') || '');
      set('sac', sac.code);
      set('cur', q('currency') || 'INR');
      set('base', money(base));
      set('total', money(total));
      set('cgst', money(cgst));
      set('sgst', money(sgst));
      set('igst', money(igst));
      set('tds', tds);
      set('why', why);
      var taxRow = preview.querySelector('[data-tax]');
      if (taxRow) taxRow.hidden = !charge;
      var lut = preview.querySelector('[data-lut]');
      if (lut) lut.hidden = supply !== 'export_lut';
      var nogst = preview.querySelector('[data-nogst]');
      if (nogst) nogst.hidden = !(supply === 'no_gst' || exception);
      var stamp = preview.querySelector('[data-stamp]');
      if (stamp) stamp.hidden = !form.elements.include_stamp || !form.elements.include_stamp.checked;
      var pill = document.getElementById('ubSupplyPill');
      if (pill) {
        pill.textContent = !charge ? 'No GST' : (same ? 'CGST + SGST' : 'IGST');
        pill.className = 'pill ' + (supply === 'export_lut' ? 'export_lut' : 'sent');
      }
      var b2b = form.querySelector('[data-b2b]');
      if (b2b) b2b.hidden = customer === 'individual';
      var reason = form.querySelector('[data-reason]');
      if (reason) reason.hidden = supply !== 'no_gst';
      var bankSel = form.elements.bank_key;
      if (bankSel && bankSel.selectedOptions && bankSel.selectedOptions[0]) {
        var opt = bankSel.selectedOptions[0];
        set('bank', opt.getAttribute('data-line') || '');
        var bankP = preview.querySelector('[data-bank]');
        if (bankP) {
          var extra = bankP.querySelector('[data-extra]');
          if (!extra) {
            extra = document.createElement('span');
            extra.setAttribute('data-extra', '');
            bankP.appendChild(document.createElement('br'));
            bankP.appendChild(extra);
          }
          var head = bankP.querySelector('strong');
          if (head) head.textContent = 'Payment Details' + (opt.getAttribute('data-personal') === '1' ? ' - Personal - use only when the client requires this account' : '');
          extra.textContent = opt.getAttribute('data-extra') || '';
        }
      }
      var assist = document.getElementById('ubAssist');
      if (assist) {
        var split = !charge ? 'No GST charged' : (same ? 'CGST + SGST' : 'IGST');
        assist.textContent = split + '. ' + why + ' ' + sac.why + ' TDS: ' + tds + ' This is a guide for the owner. It does not file and it does not replace a chartered accountant. The pack is ready for review.';
      }
      var terms = preview.querySelector('.sheet-terms');
      if (terms) {
        var safe = (q('terms') || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\n/g, '<br>');
        terms.innerHTML = '<strong>Terms And Conditions</strong><br>' + safe;
      }
    };
    form.addEventListener('input', paint);
    form.addEventListener('change', paint);
    if (form.elements.sac) form.elements.sac.addEventListener('input', function () { form.elements.sac.dataset.touched = '1'; });
    paint();
  }

  // Shared Books search. One control is rendered in the Books navigation on every page.
  // Search filters visible records on the current Books page without touching form fields.
  function applyBooksSearch(value) {
    var term = String(value || '').trim().toLowerCase();
    var selector = [
      '.ub-table tbody tr', '.person-row', '.tax-card', '.bill-card',
      '.reminder-row', '.bank-line', '.ub-record-row', '.ub-finance-searchable',
      '.doc-row', '.invoice-row', '.ub-doc-list-item', '.ub-report-row',
      '.ub-subscription-row', '.ub-people-list .person-row', '.ub-lms-people .person-row'
    ].join(',');
    var candidates = document.querySelectorAll(selector);
    candidates.forEach(function (node) {
      if (node.closest('.ub-doc-composer') || node.closest('#ubPreview') || node.closest('.ub-books-global-search')) return;
      node.hidden = !!term && node.textContent.toLowerCase().indexOf(term) === -1;
    });
    var clear = document.getElementById('ubBooksSearchClear');
    if (clear) clear.hidden = !term;
    document.documentElement.classList.toggle('ub-books-search-active', !!term);
  }
  var booksSearch = document.getElementById('ubBooksGlobalSearch');
  if (booksSearch) {
    try { booksSearch.value = sessionStorage.getItem('ub_books_global_search') || ''; } catch (e) {}
    applyBooksSearch(booksSearch.value);
    booksSearch.addEventListener('input', function () {
      try { sessionStorage.setItem('ub_books_global_search', booksSearch.value); } catch (e) {}
      applyBooksSearch(booksSearch.value);
    });
    var clearBooksSearch = document.getElementById('ubBooksSearchClear');
    if (clearBooksSearch) clearBooksSearch.addEventListener('click', function () {
      booksSearch.value = '';
      try { sessionStorage.removeItem('ub_books_global_search'); } catch (e) {}
      applyBooksSearch('');
      booksSearch.focus();
    });
  }

  var exp = document.getElementById('ubExpense');
  if (exp) {
    var title = exp.elements.title;
    var cat = exp.elements.category;
    var guess = {
      hosting: /host|server|domain|aws|cloud/i,
      software: /zoom|software|saas|adobe|microsoft|google/i,
      rent: /rent|lease/i,
      power: /power|electric/i,
      internet: /internet|broadband|airtel|jio/i,
      travel: /flight|uber|ola|travel|hotel|train/i,
      labs: /lab/i
    };
    title.addEventListener('input', function () {
      if (cat.dataset.touched) return;
      var v = title.value;
      Object.keys(guess).forEach(function (k) { if (guess[k].test(v)) cat.value = k; });
    });
    cat.addEventListener('change', function () { cat.dataset.touched = '1'; });
  }
  document.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('[data-copy]') : null;
    if (!btn) return;
    var box = document.querySelector(btn.getAttribute('data-copy'));
    if (!box) return;
    var table = box.querySelector('table');
    var text = table ? table.innerText : box.innerText;
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text);
    btn.textContent = 'Copied';
  });
  // Student lookup against the logged-in LMS/WordPress user directory.
  var studentInput = document.getElementById('ubStudentName');
  var studentId = document.getElementById('ubStudentId');
  var studentEmail = document.getElementById('ubStudentEmail');
  var studentList = document.getElementById('ubStudentSuggestions');
  if (studentInput && studentList) {
    var lookupTimer = null;
    var activeItems = [];
    var closeStudentList = function () { studentList.hidden = true; studentList.innerHTML = ''; };
    var chooseStudent = function (item) {
      studentInput.value = item.name || '';
      if (studentId) studentId.value = item.id || '';
      if (studentEmail) studentEmail.value = item.email || '';
      closeStudentList();
    };
    studentInput.addEventListener('input', function () {
      if (studentId) studentId.value = '';
      if (studentEmail) studentEmail.value = '';
      var term = (studentInput.value || '').trim();
      window.clearTimeout(lookupTimer);
      if (term.length < 2) { closeStudentList(); return; }
      lookupTimer = window.setTimeout(function () {
        var ajax = window.ajaxurl || (window.location.origin + '/wp-admin/admin-ajax.php');
        var nonce = studentInput.getAttribute('data-nonce') || '';
        var url = ajax + '?action=ub_student_lookup&nonce=' + encodeURIComponent(nonce) + '&term=' + encodeURIComponent(term);
        fetch(url, {credentials:'same-origin'}).then(function (r) { return r.json(); }).then(function (payload) {
          var items = payload && payload.success && Array.isArray(payload.data) ? payload.data : [];
          activeItems = items;
          studentList.innerHTML = '';
          if (!items.length) { closeStudentList(); return; }
          items.forEach(function (item) {
            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'ub-autocomplete-item';
            button.setAttribute('role', 'option');
            var name = document.createElement('strong');
            name.textContent = item.name || '';
            var email = document.createElement('small');
            email.textContent = item.email || '';
            button.appendChild(name);
            button.appendChild(email);
            button.addEventListener('click', function () { chooseStudent(item); });
            studentList.appendChild(button);
          });
          studentList.hidden = false;
        }).catch(closeStudentList);
      }, 180);
    });
    studentInput.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') closeStudentList();
      if (event.key === 'Enter' && !studentList.hidden && activeItems.length) {
        event.preventDefault();
        chooseStudent(activeItems[0]);
      }
    });
    document.addEventListener('click', function (event) {
      if (!event.target.closest || !event.target.closest('.ub-student-field')) closeStudentList();
    });
  }

  var themeBtn = document.getElementById('themeToggle');
  if (themeBtn) themeBtn.addEventListener('click', function () {
    var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    document.body.setAttribute('data-theme', next);
    try { localStorage.setItem('uc_lms_theme', next); } catch (e) {}
  });
  var meBtn = document.getElementById('meBtn');
  var meMenu = document.getElementById('meMenu');
  if (meBtn && meMenu) {
    meBtn.addEventListener('click', function (ev) {
      ev.stopPropagation();
      var open = meMenu.hasAttribute('hidden');
      if (open) meMenu.removeAttribute('hidden'); else meMenu.setAttribute('hidden', '');
      meBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('click', function (ev) {
      if (meMenu.hasAttribute('hidden')) return;
      if (ev.target.closest && ev.target.closest('.rail-me')) return;
      meMenu.setAttribute('hidden', '');
      meBtn.setAttribute('aria-expanded', 'false');
    });
  }
})();
