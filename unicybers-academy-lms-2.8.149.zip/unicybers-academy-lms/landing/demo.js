(function () {
  var PATHS = {
    dashboard:'<path d="M4 13h6V4H4zM4 20h6v-4H4zM14 20h6v-9h-6zM14 4v4h6V4z"/>',
    courses:'<path d="M5 5h5a2 2 0 0 1 2 2v12a2 2 0 0 0-2-2H5zM19 5h-5a2 2 0 0 0-2 2v12a2 2 0 0 1 2-2h5z"/>',
    batches:'<path d="M4 7h16M4 12h16M4 17h10"/><circle cx="18" cy="17" r="2"/>',
    classes:'<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
    materials:'<path d="M6 3h8l4 4v14H6zM14 3v4h4M9 12h6M9 16h6"/>',
    people:'<circle cx="9" cy="8" r="3"/><path d="M3.5 19c.4-3.1 2.2-5 5.5-5s5.1 1.9 5.5 5M16 11a3 3 0 1 0 0-6M16.5 14c2.6.2 4.2 1.7 4.6 4.5"/>',
    announcements:'<path d="M4 11h4l8-4v10l-8-4H4zM8 15l1 4M19 10a3 3 0 0 1 0 4"/>',
    messages:'<path d="M4 5h16v11H8l-4 4z"/><path d="M8 9h8M8 12h5"/>',
    reports:'<path d="M5 19V10M12 19V5M19 19v-6M3 21h18"/>',
    tenants:'<path d="M4 20V8l8-4 8 4v12M9 20v-6h6v6"/>',
    placement:'<path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6z"/><path d="M9 12h6M12 9v6"/>',
    practice:'<path d="M8 4h8l2 2v14H6V4zM9 9h6M9 13h6M9 17h3"/>',
    help:'<circle cx="12" cy="12" r="9"/><path d="M9.6 9.4a2.5 2.5 0 1 1 4.2 1.8c-.9.8-1.8 1.1-1.8 2.3M12 17h.01"/>',
    labs:'<path fill="currentColor" stroke="none" d="M9 3h6v2h-1v4.3l5.4 9.1A2 2 0 0 1 17.7 21H6.3a2 2 0 0 1-1.7-2.6L10 9.3V5H9V3zm1.2 8.2L7.2 16h9.6l-3-4.8H10.2z"/>',
    search:'<circle cx="11" cy="11" r="6"/><path d="m20 20-4.2-4.2"/>',
    bell:'<path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4zM10 20a2 2 0 0 0 4 0"/>',
    sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon:'<path d="M20 14.5A8 8 0 1 1 9.5 4 6.5 6.5 0 0 0 20 14.5z"/>',
    chev:'<path d="m6 9 6 6 6-6"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    play:'<path d="m9 7 8 5-8 5z"/>',
    key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l2 2"/>',
    signout:'<path d="M10 5H5v14h5M14 8l4 4-4 4M8 12h10"/>',
    x:'<path d="M6 6l12 12M18 6 6 18"/>',
    shield:'<path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6z"/><path d="m9 12 2 2 4-4"/>',
    alert:'<path d="M12 4 2.5 20h19zM12 10v4M12 17h.01"/>',
    device:'<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>'
  };
  var NAV = {
    super_admin: ['dashboard','courses','batches','classes','practice','materials','people','placement','announcements','messages','reports'],
    coordinator: ['dashboard','courses','batches','classes','practice','materials','people','placement','announcements','messages','reports'],
    trainer: ['dashboard','courses','batches','classes','practice','materials','announcements','messages','reports'],
    student: ['dashboard','courses','classes','practice','materials','profile','placement','announcements','messages','reports']
  };
  var WHO = {
    super_admin: { name: 'Rida', email: 'rida.admin@academy.test', role: 'Super Admin', initials: 'RD' },
    coordinator: { name: 'Rida', email: 'rida.coordinator@academy.test', role: 'Coordinator', initials: 'RD' },
    trainer: { name: 'Rida', email: 'rida.trainer@academy.test', role: 'Trainer', initials: 'RD' },
    student: { name: 'Rida', email: 'rida.student@academy.test', role: 'Student', initials: 'RD' }
  };
  var role = 'coordinator';
  var page = 'dashboard';

  function ico(n) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + (PATHS[n] || '<circle cx="12" cy="12" r="5"/>') + '</svg>'; }
  function pill(t, k) { return '<span class="pill p-' + k + '">' + t + '</span>'; }
  function label(p) {
    if (p === 'courses' && role === 'student') return 'My Courses';
    if (p === 'classes' && role === 'student') return 'My Classes';
    if (p === 'reports' && role === 'student') return 'My Attendance';
    if (p === 'reports' && role === 'coordinator') return 'Student Report';
    if (p === 'batches' && role === 'trainer') return 'My Batches';
    var map = { dashboard:'Dashboard', courses:'Courses', batches:'Batches', classes:'Classes', practice:'Practice', materials:'Materials & Recordings', people:'People', tenants:'Tenants', placement:'Placement Desk', announcements:'Announcements', messages:'Messages', reports:'Reports', profile:'My Profile', help:'Help & Support', classroom:'Class Room' };
    return map[p] || p;
  }
  function staff() { return role !== 'student'; }
  function ops() { return role === 'super_admin' || role === 'coordinator'; }
  function greeting() {
    var h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }
  function todayLine() {
    return new Date().toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
  }
  function flash(msg) {
    var el = document.getElementById('flash');
    if (!el) return;
    el.hidden = false;
    el.innerHTML = '<span>' + msg + '</span><button class="flash-x" type="button" id="flashX">×</button>';
    document.getElementById('flashX').onclick = function () { el.hidden = true; };
  }
  function sample(msg) {
    flash(msg || 'Preview. On your academy this button saves or opens the real record.');
  }

  function hero() {
    var first = WHO[role].name.split(' ')[0];
    var line = role === 'student' ? 'Your classes, materials and attendance.' : 'Here\'s what needs your attention today.';
    var h = '<div class="hero-row"><section class="hero" style="--hero-desk:url(\'assets/hero-desk.jpg\')"><div class="hero-main"><span class="eyebrow on-dark">' + todayLine().toUpperCase() + '</span><h2>' + greeting() + ', ' + first + '.</h2><p>' + line + '</p></div></section>';
    h += '<div class="next"><div class="next-top"><span class="next-ico">' + ico('classes') + '</span><span class="eyebrow">NEXT CLASS</span></div><strong>SIEM triage lab</strong><small>SOC Weekday · 7:00 PM to 9:00 PM IST</small>';
    h += '<div class="cd"><span><b>0</b>d</span><span><b>02</b>h</span><span><b>14</b>m</span><span><b>08</b>s</span></div>';
    h += '<div class="next-act"><button class="btn primary sm" type="button" data-go="classes">' + (role === 'student' ? 'Join Class' : 'Start Class') + '</button></div></div></div>';
    return h;
  }
  function kpi(labelText, value, sub, icon, tone) {
    return '<div class="kpi k-' + tone + '"><span class="kpi-ico">' + ico(icon) + '</span><div><small>' + labelText + '</small><strong>' + value + '</strong><em>' + sub + '</em></div></div>';
  }
  function classRow(title, meta, live) {
    var tone = live ? 'live' : 'info';
    var btn = live
      ? '<button class="btn primary sm" type="button" data-sample="Preview. Students join from 20 minutes before the start. Attendance is noted on the way into the meeting.">Join Class</button>'
      : '<button class="btn ghost sm" type="button" data-go="classroom">Open Class Room</button>';
    return '<div class="att-row" data-q="' + (title + ' ' + meta).toLowerCase() + '"><span class="att-ico t-' + tone + '">' + ico('classes') + '</span><span><strong>' + title + '</strong><small>' + meta + '</small></span>' + btn + '</div>';
  }

  function dashboard() {
    var o = hero();
    if (role === 'student') {
      o += '<div class="kpis">' + kpi('My Courses','1','Enrolled Programmes','courses','blue') + kpi('Upcoming Classes','2','Scheduled Sessions','classes','violet') + kpi('Materials','6','Shared With Your Batch','materials','amber') + kpi('Attendance','92%','Classes Present','reports','indigo') + '</div>';
      o += '<section class="panel"><div class="ph"><div><span class="eyebrow">YOUR PROGRESS</span><h3>SOC Weekday</h3></div>' + pill('On track','ok') + '</div><ul class="cr-prog-list"><li><span>Classes finished</span><b>11</b></li><li><span>Attendance</span><b>92%</b></li><li><span>Recordings watched</span><b>2 of 3</b></li><li><span>Assignments</span><b>75%</b></li><li><span>Overall</span><b>84%</b></li></ul></section>';
      o += '<div class="dash-grid"><section class="panel"><div class="ph"><div><span class="eyebrow">LIVE SCHEDULE</span><h3>Upcoming classes</h3></div><button class="link" type="button" data-go="classes">All classes →</button></div><div class="att">' + classRow('SIEM triage lab','Wed · SOC Weekday · 7:00 PM to 9:00 PM IST', true) + classRow('Alert writing','Thu · SOC Weekday · 7:00 PM to 9:00 PM IST', false) + '</div></section>';
      o += '<section class="panel"><div class="ph"><div><span class="eyebrow">ACADEMY</span><h3>Latest announcements</h3></div></div><div class="nrows"><article class="nrow"><div class="n-top">' + pill('Batch','info') + '<small>Today</small></div><strong>Lab files are open</strong><p>The SIEM worksheet is in Materials. It stays closed until the trainer opens it.</p></article></div></section></div>';
      return o;
    }
    o += '<div class="kpis">' + kpi('Active Students','18','Demo Seats Excluded','people','green') + kpi('Active Batches','2','Currently Running','batches','teal') + kpi('Classes Today','1','Scheduled For Today','classes','violet') + kpi('Recordings','3','Available To Learners','materials','amber') + '</div>';
    o += '<div class="dash-grid"><section class="panel"><div class="ph"><div><span class="eyebrow">LIVE SCHEDULE</span><h3>Today And Next Up</h3></div><button class="link" type="button" data-go="classes">All Classes →</button></div><div class="att">' + classRow('SIEM triage lab','Today · SOC Weekday · 7:00 PM to 9:00 PM IST', true) + classRow('Alert writing','Thu · SOC Weekday · 7:00 PM to 9:00 PM IST', false) + '</div></section>';
    o += '<section class="panel"><div class="ph"><div><span class="eyebrow">NEEDS ATTENTION</span><h3>Action Items</h3></div></div><div class="att">';
    o += '<div class="att-row" data-q="sign in request"><span class="att-ico t-live">' + ico('alert') + '</span><span><strong>1 sign in request waiting</strong><small>People › Access requests</small></span><i>›</i></div>';
    o += '<div class="att-row" data-q="recording"><span class="att-ico t-info">' + ico('play') + '</span><span><strong>1 recent class without a recording</strong><small>Press Sync recordings. Zoom files pull in automatically. Meet and Teams appear after you paste the recording link.</small></span><i>›</i></div>';
    o += '</div></section></div>';
    return o;
  }

  function courses() {
    var o = '<div class="course-filters"><span>Level</span><button type="button" class="on">All</button><button type="button">Intermediate</button><span>Category</span><button type="button" class="on">All</button><button type="button">Security Operations</button></div>';
    o += '<div class="cards"><article class="ccard" data-q="soc analyst professional security operations"><div class="cbody"><span class="cat">Security Operations</span><h3>SOC Analyst Professional</h3><p class="cmeta">Intermediate · Live · 12 weeks</p><p class="cblurb">Live batch for analysts who will triage alerts, write tickets, and brief a shift lead.</p></div><div class="cfoot"><div class="cstats"><span><b>1</b> batches</span><span><b>18</b> learners</span>' + pill('Active','ok') + '</div>';
    if (ops()) o += '<div class="cacts"><button class="btn ghost sm" type="button" data-sample="Preview. Share copies the public programme link. Sending interest does not enrol anyone.">Share</button><button class="btn ghost sm" type="button" data-modal="course">Edit</button></div>';
    o += '</div></article></div>';
    return o;
  }

  function batches() {
    if (!staff()) return empty('Not available', 'Your batches are shown on your dashboard.', 'batches');
    var o = '<section class="panel flush"><div class="tablewrap"><table><thead><tr><th>Batch</th><th>Course</th><th>Trainer</th><th>Learners</th><th>Classes</th><th>Term progress</th><th>Status</th><th></th></tr></thead><tbody>';
    o += '<tr data-q="soc weekday"><td><strong>SOC Weekday</strong><small class="sub">Online · India</small></td><td>SOC Analyst Professional</td><td><span class="who"><span class="avatar xs">RD</span>Rida</span></td><td><b>18</b></td><td>14</td><td><div class="prog"><i style="width:62%"></i></div><small class="sub">2 Sep → 24 Nov 2026</small></td><td>' + pill('Active','ok') + '</td><td class="acts"><button class="btn ghost sm" type="button" data-modal="batch">Edit</button><button class="btn ghost sm" type="button" data-sample="Preview. The students panel lists who is enrolled, and can add or import a learner.">Students</button></td></tr>';
    o += '<tr data-q="ceh weekend"><td><strong>CEH Weekend</strong><small class="sub">Online · UAE</small></td><td>Certified Ethical Hacking Lab Track</td><td>' + pill('Not assigned','warn') + '</td><td><b>0</b></td><td>0</td><td><div class="prog"><i style="width:0%"></i></div><small class="sub">Starts 8 Dec 2026</small></td><td>' + pill('Paused','mut') + '</td><td class="acts"><button class="btn ghost sm" type="button" data-modal="batch">Edit</button></td></tr>';
    o += '</tbody></table></div></section>';
    return o;
  }

  function classes() {
    var live = '<article class="crow is-live" data-q="siem triage soc weekday zoom"><div class="crow-top"><div class="dtile"><b>' + new Date().getDate() + '</b><span>' + new Date().toLocaleString('en-GB',{month:'short'}).toUpperCase() + '</span></div><span class="plat zoom">ZOOM</span></div><div class="cmain"><strong>SIEM triage lab</strong><small>Today · SOC Weekday · 7:00 PM to 9:00 PM IST</small></div><div class="cact"><button class="btn primary sm" type="button" data-sample="Preview. Staff can start from 3 hours before until 20 minutes after. The button says Start Class for staff and Join Class for students.">' + (role === 'student' ? 'Join Class' : 'Start Class') + '</button></div></article>';
    var next = '<article class="crow" data-q="alert writing soc weekday zoom"><div class="crow-top"><div class="dtile"><b>06</b><span>NOV</span></div><span class="plat zoom">ZOOM</span></div><div class="cmain"><strong>Alert writing</strong><small>Thu · SOC Weekday · 7:00 PM to 9:00 PM IST</small></div><div class="cact"><span class="pill p-mut">Opens 6:40 PM</span>' + (staff() ? '<button class="btn ghost sm" type="button" data-modal="class">Edit</button>' : '') + '</div></article>';
    var done = '<article class="crow" data-q="log sources soc weekday zoom"><div class="crow-top"><div class="dtile"><b>28</b><span>OCT</span></div><span class="plat zoom">ZOOM</span></div><div class="cmain"><strong>Log sources</strong><small>Wed · SOC Weekday · 7:00 PM to 9:00 PM IST</small></div><div class="cact"><button class="btn ghost sm" type="button" data-go="classroom">Open Class Room</button></div></article>';
    var meet = '<article class="crow" data-q="guest brief soc weekday meet"><div class="crow-top"><div class="dtile"><b>21</b><span>OCT</span></div><span class="plat meet">MEET</span></div><div class="cmain"><strong>Guest brief</strong><small>Wed · SOC Weekday · 7:00 PM to 8:00 PM IST</small></div><div class="cact"><button class="btn ghost sm" type="button" data-go="classroom">Open Class Room</button></div></article>';
    var zoho = '<article class="crow" data-q="office hours soc weekday zoho"><div class="crow-top"><div class="dtile"><b>12</b><span>NOV</span></div><span class="plat" style="color:#E24B4B;background:rgba(226,75,75,.12)">ZOHO</span></div><div class="cmain"><strong>Office hours</strong><small>Thu · SOC Weekday · 8:00 PM to 8:40 PM IST</small></div><div class="cact"><span class="pill p-mut">Link pasted</span></div></article>';
    return '<div class="groups"><details class="grp accent-live" open><summary><span class="g-dot"></span><span class="g-copy"><strong>Happening now</strong><small>1 class in the join window.</small></span><span class="chev">' + ico('chev') + '</span></summary><div class="crows">' + live + '</div></details><details class="grp" open><summary><span class="g-dot"></span><span class="g-copy"><strong>SOC Weekday</strong><small>Upcoming in this batch.</small></span><span class="chev">' + ico('chev') + '</span></summary><div class="crows">' + next + zoho + '</div></details><details class="grp" open><summary><span class="g-dot"></span><span class="g-copy"><strong>Class Room</strong><small>2 finished classes. Reopen anytime.</small></span><span class="chev">' + ico('chev') + '</span></summary><div class="crows">' + done + meet + '</div></details></div>';
  }

  function practice() {
    return '<div class="cards"><article class="ccard" data-q="ticket quality assignment"><div class="cbody"><span class="cat">Assignment</span><h3>Ticket quality</h3><p class="cmeta">Due Thu · SOC Weekday</p><p class="cblurb">Rewrite three noisy alerts into a shift ticket. Mark complete when the brief is done.</p></div><div class="cfoot"><div class="cstats"><span><b>14</b> of 18</span>' + pill('78%','ok') + '</div></div></article><article class="ccard" data-q="mock interview"><div class="cbody"><span class="cat">Mock</span><h3>Shift-lead mock</h3><p class="cmeta">Sat · 10:00 AM IST</p><p class="cblurb">A scheduled mock. Students do not mark a mock complete.</p></div><div class="cfoot"><div class="cstats">' + pill('Scheduled','info') + '</div></div></article></div>';
  }

  function materials() {
    var o = '<div class="lib-tabs" style="margin-bottom:12px"><button type="button" class="on">All</button><button type="button">Notes</button><button type="button">Recordings</button><button type="button">Labs</button></div>';
    o += '<div class="cards">';
    o += mat('Notes','Alert writing worksheet','PDF · SOC Weekday','Open');
    o += mat('Recordings','Log sources','Zoom · 1 h 52 m','Open');
    o += mat('Labs','SIEM range brief','Closed for students','Closed');
    o += '</div>';
    return o;
  }
  function mat(cat, name, meta, state) {
    var pillHtml = state === 'Closed' ? pill('Closed for students','warn') : pill('Open for students','ok');
    return '<article class="ccard" data-q="' + (cat + ' ' + name).toLowerCase() + '"><div class="cbody"><span class="cat">' + cat + '</span><h3>' + name + '</h3><p class="cmeta">' + meta + '</p></div><div class="cfoot"><div class="cstats">' + pillHtml + '</div>' + (staff() && state === 'Closed' ? '<div class="cacts"><button class="btn ghost sm" type="button" data-sample="Preview. Students do not see a closed item. Staff still do.">Open for students</button></div>' : '') + '</div></article>';
  }

  function people() {
    if (!ops()) return empty('Not available', 'People is for Super Admin and Coordinator.', 'people');
    var rows = [
      ['Asha Menon','asha@academy.test','Student','India','Active','1 of 3','Today'],
      ['Dev Patel','dev@academy.test','Student','India','Not activated','0 of 3','Never'],
      ['Rida','rida.trainer@academy.test','Trainer','India','Active','2 of 5','Today']
    ];
    var o = '<section class="panel flush"><div class="toolbar"><div class="seg"><button type="button" class="on">Students <b>18</b></button><button type="button">Disabled <b>0</b></button><button type="button">Archived <b>0</b></button><button type="button">Staff <b>3</b></button><button type="button">Demo <b>20</b></button><button type="button">All <b>41</b></button></div></div>';
    o += '<div class="tablewrap"><table id="peopleTable"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Country</th><th>Status</th><th>Devices</th><th>Last sign-in</th><th></th></tr></thead><tbody>';
    rows.forEach(function (r) {
      o += '<tr data-q="' + r.join(' ').toLowerCase() + '"><td><span class="who"><span class="avatar xs">' + r[0].split(' ').map(function (w){return w[0]}).join('') + '</span><strong>' + r[0] + '</strong></span></td><td>' + r[1] + '</td><td>' + r[2] + '</td><td>' + r[3] + '</td><td>' + (r[4] === 'Active' ? pill('Active','ok') : pill(r[4],'warn')) + '</td><td class="devs">' + r[5] + '</td><td>' + r[6] + '</td><td class="acts"><button class="btn ghost sm" type="button" data-sample="Preview. Edit covers name, phone, country, currency, role, and the device limit of 3 or 5.">Edit</button></td></tr>';
    });
    o += '</tbody></table></div></section>';
    return o;
  }

  function placement() {
    if (role === 'trainer') return empty('Not available', 'Placement Desk is run by Super Admin, Coordinators and the candidate.', 'placement');
    if (role === 'student') {
      return '<section class="panel"><div class="ph"><div><span class="eyebrow">UC-SOC-1042</span><h3>Placement Desk</h3></div>' + pill('Incomplete','warn') + '</div><p>Your Career ID is created when you open this page. The client pack still needs a resume.</p><ul class="pack-miss"><li>Resume / CV</li></ul><div class="att" style="margin-top:12px"><div class="att-row"><span class="att-ico t-info">' + ico('placement') + '</span><span><strong>SOC Analyst · Rida Client · Bengaluru</strong><small>Skill match 78%. You can save a status and a note.</small></span>' + pill('Recommended','info') + '</div></div></section>';
    }
    var o = '<div class="kpis">' + kpi('Career IDs','12','On the desk','placement','amber') + kpi('Placement Ready','4','Complete client pack','people','green') + kpi('Open Jobs','3','Accepted on the desk','classes','violet') + kpi('Live Applications','6','Not closed','reports','indigo') + '</div>';
    o += '<section class="panel flush"><div class="ph" style="padding:14px 16px 0"><div><span class="eyebrow">CANDIDATES</span><h3>Career ID</h3></div></div><div class="tablewrap"><table class="cand-table"><thead><tr><th>Career ID</th><th>Candidate</th><th>Pack</th><th>Best open match</th><th>Stage</th><th></th></tr></thead><tbody>';
    o += '<tr data-q="asha menon"><td><span class="desk-id">UC-SOC-1042</span></td><td><strong>Asha Menon</strong><small class="sub">asha@academy.test</small></td><td>' + pill('Incomplete','warn') + '</td><td><span class="match-title">SOC Analyst · 78%</span><small class="match-meta">Rida Client · Bengaluru</small></td><td>Preparing</td><td class="acts"><button class="btn ghost sm" type="button" data-sample="Preview. Client link copies the public candidate page once the pack is complete.">Client link</button></td></tr>';
    o += '<tr data-q="kabir shah"><td><span class="desk-id">UC-SOC-1048</span></td><td><strong>Kabir Shah</strong><small class="sub">kabir@academy.test</small></td><td>' + pill('Complete','ok') + '</td><td><span class="match-title">SOC Analyst · 91%</span><small class="match-meta">Rida Client · Hyderabad</small></td><td>Interview</td><td class="acts"><button class="btn ghost sm" type="button" data-sample="Preview. The public page shows the Career ID and the pack that is safe to share. It is not a login.">Client link</button></td></tr>';
    o += '</tbody></table></div></section>';
    return o;
  }

  function announcements() {
    return '<section class="panel"><div class="ph"><div><span class="eyebrow">BOARD</span><h3>Latest</h3></div>' + (staff() ? '<button class="btn primary sm" type="button" data-modal="notice">Post</button>' : '') + '</div><div class="nrows"><article class="nrow" data-q="lab files"><div class="n-top">' + pill('SOC Weekday','info') + '<small>Today</small></div><strong>Lab files are open</strong><p>The SIEM worksheet is in Materials.</p></article><article class="nrow" data-q="mock saturday"><div class="n-top">' + pill('SOC Weekday','info') + '<small>Yesterday</small></div><strong>Saturday mock</strong><p>The shift-lead mock is on Practice. Join from the card.</p></article></div></section>';
  }

  function messages() {
    return '<div class="dash-grid"><section class="panel"><div class="ph"><div><span class="eyebrow">BATCH</span><h3>SOC Weekday</h3></div></div><div class="att"><button class="att-row" type="button" data-sample="Preview. Class chat is the batch room."><span class="att-ico t-info">' + ico('messages') + '</span><span><strong>Class chat</strong><small>Everyone on the batch</small></span></button><button class="att-row" type="button" data-sample="Preview. Ask trainer is a private thread with that batch’s trainer."><span class="att-ico t-info">' + ico('people') + '</span><span><strong>Ask trainer</strong><small>Private with Rida</small></span></button></div><div class="share-grid" style="margin-top:12px"><button class="share-ch" type="button" data-sample="Preview. WhatsApp, Telegram, Discord, and one other group open only when the batch has a link saved.">WhatsApp</button><button class="share-ch" type="button" data-sample="Preview. The group link is saved on the batch.">Telegram</button></div></section><section class="panel"><div class="ph"><div><span class="eyebrow">CLASS CHAT</span><h3>SOC Weekday</h3></div></div><article class="nrow"><strong>Rida</strong><p>Worksheet is open in Materials. Bring one alert you would escalate.</p><small class="sub">Today · 4:12 PM</small></article></section></div>';
  }

  function reports() {
    if (role === 'student') {
      return '<div class="kpis">' + kpi('Present','11','Classes','reports','green') + kpi('Absent','1','Classes','reports','indigo') + kpi('Hours attended','18','From stored minutes','classes','violet') + kpi('Hours delivered','22','From class length','batches','teal') + '</div><section class="panel flush"><div class="tablewrap"><table><thead><tr><th>Date</th><th>Class</th><th>Minutes</th><th></th></tr></thead><tbody><tr data-q="log sources"><td>28 Oct</td><td>Log sources</td><td>104</td><td>' + pill('Present','ok') + '</td></tr><tr data-q="guest brief"><td>21 Oct</td><td>Guest brief</td><td>20</td><td>' + pill('Absent','warn') + '</td></tr></tbody></table></div></section>';
    }
    var tabs = role === 'coordinator'
      ? ['Student Report','Report cards','Weekly Ops','Monthly Ops','Attendance']
      : ['Report cards','Weekly Ops','Monthly Ops','Attendance','Trainer hours'];
    var o = '<div class="lib-tabs" style="margin-bottom:12px">';
    tabs.forEach(function (t, i) { o += '<button type="button" class="' + (i === 0 ? 'on' : '') + '">' + t + '</button>'; });
    o += '</div><section class="panel"><div class="ph"><div><span class="eyebrow">SOC WEEKDAY</span><h3>Report cards</h3></div><span class="count">Demo seats skipped</span></div>';
    o += '<article class="nrow" data-q="asha menon"><strong>Asha Menon</strong><p>18 hours in class. 4 of 6 materials opened. 2 of 3 recordings opened. Assignments 75%.</p><small class="sub">The note is written inside the LMS from those counts.</small></article></section>';
    return o;
  }

  function tenants() {
    if (role !== 'super_admin') return empty('Not available', 'Tenants are Super Admin only.', 'tenants');
    return '<section class="panel flush"><div class="tablewrap"><table><thead><tr><th>Academy</th><th>Mail-from</th><th>Tax</th><th>Status</th><th></th></tr></thead><tbody><tr data-q="unicybers"><td><strong>UniCybers</strong><small class="sub">Home tenant</small></td><td>academy@unicybers.com</td><td>18% GST</td><td>' + pill('Live','ok') + '</td><td class="acts"><button class="btn ghost sm" type="button" data-sample="Preview. Preview shows that logo on the login, the rail, and invoices.">Preview</button></td></tr><tr data-q="northwind"><td><strong>Northwind Cyber</strong><small class="sub">northwind.example</small></td><td>hello@northwind.example</td><td>5% VAT</td><td>' + pill('Draft','mut') + '</td><td class="acts"><button class="btn ghost sm" type="button" data-modal="tenant">Edit</button></td></tr></tbody></table></div></section>';
  }

  function profile() {
    return '<section class="panel"><div class="ph"><div><span class="eyebrow">CAREER FILE</span><h3>My Profile</h3></div>' + pill('Pack incomplete','warn') + '</div><div class="fgrid"><label>Phone<input value="+91 90000 00000" readonly></label><label>City<input value="Bengaluru" readonly></label><label>Preferred role<input value="SOC Analyst" readonly></label><label>Notice period<input value="30 days" readonly></label></div><p class="hint">Documents on a real profile: Resume / CV, Government ID, Degree or marksheet, Cybersecurity certificate. This preview does not collect them.</p></section>';
  }

  function help() {
    return '<div class="kpis">' + kpi('Support reference','UC-4F2A','Quote this without your email','help','orange') + kpi('Devices','1 of 3','Browsers signed in','people','indigo') + '</div><section class="panel"><div class="ph"><div><span class="eyebrow">HELP</span><h3>Help & Support</h3></div></div><div class="att"><div class="att-row"><span class="att-ico t-info">' + ico('labs') + '</span><span><strong>Labs Arena</strong><small>Opens labs.unicybers.com in a new tab. It is outside this plugin.</small></span></div><div class="att-row"><span class="att-ico t-info">' + ico('key') + '</span><span><strong>Change password</strong><small>Minimum 8 characters.</small></span></div></div><p class="hint">WhatsApp and email for the academy sit on this page in the product. Plugin licensing questions use the website support desk.</p></section>';
  }

  function classroom() {
    var ring = '<div class="cr-ring-wrap"><svg class="cr-ring" viewBox="0 0 96 96"><circle cx="48" cy="48" r="36"/><circle cx="48" cy="48" r="36" stroke-dasharray="196 226"/></svg><div class="cr-ring-pct">86%</div></div>';
    var o = '<div class="cr"><nav class="cr-bc"><span>SOC Analyst Professional</span><span>›</span><span>SOC Weekday</span><span>›</span><strong>Log sources</strong></nav>';
    o += '<header class="cr-hero"><div class="cr-hero-title"><span class="cr-flag"></span><h2>Log sources</h2>' + pill('Class Completed','ok') + '</div><div class="cr-meta"><span>SOC Weekday</span><span>28 Oct 2026</span><span>7:00 PM to 9:00 PM (120 mins)</span><span>Trainer: Rida</span></div></header>';
    o += '<div class="cr-tabs"><button type="button" class="on" data-tab="room">Class Room</button><button type="button" data-tab="summary">Summary</button><button type="button" data-tab="transcript">Transcript</button><button type="button" data-tab="tasks">Tasks</button><button type="button" data-tab="polls">Polls & Quiz</button><button type="button" data-tab="materials">Materials</button></div>';
    o += '<div class="cr-pane" data-pane="room"><div class="cr-grid"><div class="cr-stage"><div class="cr-player viewer"><div class="v-frame"><div class="cr-poster"><div class="cr-poster-art" style="background:radial-gradient(420px 180px at 20% 80%,rgba(255,107,26,.45),transparent 60%),#07090c"></div></div><div class="cr-play-caption"><strong>Log sources</strong></div><div class="cr-ch"><h3>AI GENERATED</h3><ol><li><button type="button"><em>00:04</em><span>Why a source matters</span></button></li><li><button type="button"><em>18:20</em><span>Windows and firewall</span></button></li><li><button type="button"><em>46:02</em><span>What the shift lead reads</span></button></li></ol></div></div></div></div>';
    o += '<aside class="cr-rail"><section class="cr-card"><h3>Summary</h3><p>The class walked through which logs a SOC keeps, and how a noisy source hides the one alert that matters. Staff publish this before students see it.</p></section><section class="cr-card"><h3>Tasks</h3><ul class="cr-tasks"><li><span class="cr-box"></span><span>Name three sources you would onboard first<small>From Zoom</small></span><em class="cr-tag">TASK</em></li></ul></section></aside></div>';
    o += '<div class="cr-bottom" style="margin-top:12px"><section class="cr-card cr-att"><h3>Attendance</h3><div class="cr-att-row">' + ring + '<ul><li class="ok"><span>Present</span><b>15</b></li><li class="warn"><span>Partial</span><b>2</b></li><li><span>Absent</span><b>1</b></li></ul></div><p class="hint">Present defaults to 90% of scheduled time. Partial defaults to 50%.</p></section></div></div>';
    o += '<div class="cr-pane" data-pane="summary" hidden><section class="cr-card"><h3>AI Class Summary</h3><p>Recap, topics, and next steps come from the Zoom recording files. Staff can edit and publish. Students see the summary after it is published. Chapters are labelled AI Generated for that reason.</p></section></div>';
    o += '<div class="cr-pane" data-pane="transcript" hidden><section class="cr-card"><h3>Transcript</h3><ul class="cr-tr"><li><button class="cr-seek" type="button">00:04:12</button><span>We start with the source, not the alert.</span></li><li><button class="cr-seek" type="button">18:20:04</button><span>Windows security and the firewall tell different stories.</span></li></ul></section></div>';
    o += '<div class="cr-pane" data-pane="tasks" hidden><section class="cr-card"><h3>Tasks</h3><p>Pulled from Zoom. Staff publish them. Students see published tasks.</p></section></div>';
    o += '<div class="cr-pane" data-pane="polls" hidden><section class="cr-card"><h3>Polls & Quiz</h3><p>Polls and quiz results are pulled from Zoom, then published by staff. This portal does not include a separate question bank.</p></section></div>';
    o += '<div class="cr-pane" data-pane="materials" hidden><section class="cr-card"><h3>Materials</h3><ul class="cr-mats"><li><b>PDF</b><span>Log source checklist<small>Open for students</small></span></li></ul></section></div>';
    o += '</div>';
    return o;
  }

  function empty(title, text, icon) {
    return '<section class="panel"><div class="empty"><span class="empty-ico">' + ico(icon) + '</span><strong>' + title + '</strong><p>' + text + '</p></div></section>';
  }

  var SCREENS = { dashboard:dashboard, courses:courses, batches:batches, classes:classes, practice:practice, materials:materials, people:people, placement:placement, announcements:announcements, messages:messages, reports:reports, tenants:tenants, profile:profile, help:help, classroom:classroom };

  function actionButton() {
    if (page === 'courses' && ops()) return '<button class="btn primary" type="button" data-modal="course">' + ico('plus') + 'Add Course</button>';
    if (page === 'batches' && ops()) return '<button class="btn primary" type="button" data-modal="batch">' + ico('plus') + 'Add Batch</button>';
    if (page === 'classes' && staff()) return '<button class="btn primary" type="button" data-modal="class">' + ico('plus') + 'Add Class</button>';
    if (page === 'practice' && staff()) return '<button class="btn primary" type="button" data-modal="practice">' + ico('plus') + 'Add assignment or mock</button>';
    if (page === 'materials' && staff()) return (ops() ? '<button class="btn ghost" type="button" data-sample="Preview. Sync recordings pulls Zoom cloud files for ended Zoom classes. Meet and Teams are skipped.">' + ico('play') + 'Sync recordings</button>' : '') + '<button class="btn primary" type="button" data-modal="material">' + ico('plus') + 'Add Material</button>';
    if (page === 'tenants' && role === 'super_admin') return '<button class="btn primary" type="button" data-modal="tenant">' + ico('plus') + 'Add client academy</button>';
    return '';
  }

  function paintNav() {
    var html = '';
    NAV[role].forEach(function (p) {
      var on = (p === page) || (page === 'classroom' && p === 'classes');
      html += '<a class="nav i-' + p + (on ? ' on' : '') + '" href="#' + p + '" data-go="' + p + '"><span class="ico">' + ico(p) + '</span><span>' + label(p) + '</span></a>';
    });
    document.getElementById('navlist').innerHTML = html;
    var who = WHO[role];
    document.getElementById('meName').textContent = who.name;
    document.getElementById('meRole').textContent = who.role;
    document.getElementById('meInitials').textContent = who.initials;
    document.getElementById('meEmail').textContent = who.email;
    document.querySelectorAll('[data-set-role]').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-set-role') === role); });
    fitBrand();
  }

  function show(next) {
    if (!SCREENS[next]) next = 'dashboard';
    if (NAV[role].indexOf(next) === -1 && next !== 'classroom' && next !== 'help' && next !== 'profile') next = 'dashboard';
    page = next;
    document.body.className = 'pg-' + (page === 'classroom' ? 'classroom' : page);
    document.getElementById('pageTitle').textContent = label(page);
    document.getElementById('pageActions').innerHTML = actionButton();
    var content = document.getElementById('content');
    content.className = 'content c-' + page;
    document.getElementById('content').innerHTML = '<div id="flash" class="flash" hidden></div>' + SCREENS[page]() + '<footer class="foot"><span>© ' + new Date().getFullYear() + ' UniCybers Academy</span><span class="foot-links"><span>Privacy</span><span>Support</span></span></footer>';
    paintNav();
    var help = document.querySelector('.i-help');
    if (help) help.classList.toggle('on', page === 'help');
  }

  function fitBrand() {
    var a = document.getElementById('ucBrandName');
    var b = document.getElementById('ucBrandSub');
    if (!a || !b) return;
    function w(el) { var r = document.createRange(); r.selectNodeContents(el); var n = r.getBoundingClientRect().width; return n; }
    a.style.transform = 'none';
    b.style.transform = 'none';
    var sw = w(a), ew = w(b);
    if (sw > 8 && ew > 8) {
      b.style.transformOrigin = 'left center';
      b.style.transform = 'scaleX(' + (sw / ew) + ')';
    }
  }

  var MODALS = {
    course: ['CATALOGUE','Add Course','<div class="fgrid"><label>Course name<input name="name" placeholder="SOC Analyst Professional"></label><label>Category<input placeholder="Security Operations"></label><label>Level<select><option>Beginner</option><option selected>Intermediate</option><option>Advanced</option></select></label><label>Duration<input placeholder="12 weeks"></label><label>Mode<select><option>Live</option><option>Online</option><option>Hybrid</option></select></label><label>Status<select><option>Active</option><option>Draft</option><option>Archived</option></select></label></div><label>About this course<textarea rows="2" placeholder="Short description shown on the course card"></textarea></label><label>Outline<textarea rows="2" placeholder="What the course covers, module by module"></textarea></label><label class="check"><input type="checkbox" checked> Open for enrolment</label>'],
    batch: ['DELIVERY','Add Batch','<div class="fgrid"><label>Batch name<input placeholder="SOC Weekday"></label><label>Course<select><option>SOC Analyst Professional</option></select></label><label>Trainer<select><option>Rida</option></select></label><label>Support host<select><option>Rida</option></select></label><label>Mode<select><option>Online</option><option>Hybrid</option><option>Classroom</option></select></label><label>Country<input placeholder="India"></label><label>Currency<input placeholder="The currency this batch charges"></label><label>Timezone<select><option>India IST</option><option>Botswana</option><option>UAE</option><option>South Africa</option><option>UTC</option></select></label></div>'],
    class: ['CLASS','Add Class','<div class="fgrid"><label>Batch<select><option>SOC Weekday</option></select></label><label>Title<input placeholder="SIEM triage lab"></label><label>Date<input type="date"></label><label>Platform<select><option>Zoom</option><option>Google Meet</option><option>Microsoft Teams</option></select></label><label>Start<input type="time" value="19:00"></label><label>End<input type="time" value="21:00"></label><label>Timezone<select><option>India IST</option></select></label><label>Repeat through<input type="date"><small class="sub">Leave blank to stop at the batch end date.</small></label></div><p class="hint">A Zoom class with no pasted link gets a room when Zoom is connected. Meet and Teams ask you to paste the link.</p>'],
    practice: ['PRACTICE','Add assignment or mock','<div class="fgrid"><label>Batch<select><option>SOC Weekday</option></select></label><label>Kind<select><option>Assignment</option><option>Mock</option></select></label><label>Title<input placeholder="Ticket quality"></label><label>Link<input placeholder="https://"></label></div><label>Details<textarea rows="3"></textarea></label>'],
    material: ['LIBRARY','Add Material','<div class="fgrid"><label>Batch<select><option>SOC Weekday</option></select></label><label>Category<select><option>Notes</option><option>Slides</option><option>Labs</option><option>Assignments</option><option>Recordings</option><option>Links</option><option>Other</option></select></label><label>Display name<input></label></div><p class="hint">PDF, PPT, PPTX, DOC, DOCX, XLS, XLSX, ZIP, PNG, JPG. Over 50 MB is refused. Paste a Drive or https link instead. Students can open a file. They cannot download it from the library.</p>'],
    notice: ['BOARD','Post announcement','<label>Title<input></label><label>Message<textarea rows="4"></textarea></label><label>Audience<select><option>SOC Weekday</option><option>Everyone</option><option>All students</option><option>Staff only</option></select></label>'],
    tenant: ['BRAND','Add client academy','<div class="fgrid"><label>Academy name<input placeholder="Northwind Cyber"></label><label>Legal name<input placeholder="For invoices"></label><label>Product line<input value="Academy LMS"></label><label>Tagline<input></label><label>Mail-from<input placeholder="hello@northwind.example"></label><label>Tax<select><option>18% GST</option><option>14% VAT</option><option>5%</option><option>None</option></select></label></div><p class="hint">A client hostname pointed at this site loads that logo, colours, tax, and mail-from.</p>']
  };

  function openModal(key) {
    var m = MODALS[key];
    if (!m) return;
    document.getElementById('modalIn').innerHTML = '<form class="form" id="sampleForm"><div class="mhead"><div><span class="eyebrow">' + m[0] + '</span><h3>' + m[1] + '</h3></div><button type="button" class="iconbtn mclose" data-close aria-label="Close">' + ico('x') + '</button></div>' + m[2] + '<div class="mfoot" style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px"><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary">Save</button></div><p class="hint">Preview. Save does not store this.</p></form>';
    document.getElementById('modal').showModal();
  }

  document.addEventListener('click', function (e) {
    var go = e.target.closest('[data-go]');
    if (go) { e.preventDefault(); show(go.getAttribute('data-go')); return; }
    var modal = e.target.closest('[data-modal]');
    if (modal) { openModal(modal.getAttribute('data-modal')); return; }
    var sampleBtn = e.target.closest('[data-sample]');
    if (sampleBtn) { e.preventDefault(); sample(sampleBtn.getAttribute('data-sample')); return; }
    var tab = e.target.closest('[data-tab]');
    if (tab) {
      document.querySelectorAll('[data-tab]').forEach(function (b) { b.classList.toggle('on', b === tab); });
      document.querySelectorAll('[data-pane]').forEach(function (p) { p.hidden = p.getAttribute('data-pane') !== tab.getAttribute('data-tab'); });
      return;
    }
    if (e.target.closest('[data-close]')) document.getElementById('modal').close();
    var roleBtn = e.target.closest('[data-set-role]');
    if (roleBtn) {
      role = roleBtn.getAttribute('data-set-role');
      if (NAV[role].indexOf(page) === -1 && page !== 'help') page = 'dashboard';
      show(page);
    }
  });

  document.addEventListener('submit', function (e) {
    if (e.target.id === 'sampleForm') {
      e.preventDefault();
      document.getElementById('modal').close();
      sample('Preview. Nothing was saved.');
    }
  });

  document.getElementById('themeToggle').onclick = function () {
    var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('uc_lms_theme', next); } catch (err) {}
  };
  document.getElementById('pageFilter').addEventListener('input', function () {
    var q = this.value.trim().toLowerCase();
    document.querySelectorAll('[data-q]').forEach(function (el) {
      el.style.display = !q || el.getAttribute('data-q').indexOf(q) !== -1 ? '' : 'none';
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
      e.preventDefault();
      document.getElementById('pageFilter').focus();
    }
  });
  document.getElementById('meBtn').onclick = function () {
    var open = this.getAttribute('aria-expanded') === 'true';
    this.setAttribute('aria-expanded', open ? 'false' : 'true');
    document.getElementById('meMenu').hidden = open;
  };
  document.getElementById('menu').onclick = function () {
    document.getElementById('rail').classList.toggle('open');
    document.getElementById('scrim').classList.toggle('on');
  };
  document.getElementById('scrim').onclick = function () {
    document.getElementById('rail').classList.remove('open');
    this.classList.remove('on');
  };

  window.addEventListener('message', function (e) {
    var d = e.data || {};
    if (d.type !== 'uc-demo') return;
    if (d.role && NAV[d.role]) role = d.role;
    show(d.page || page);
  });

  show('dashboard');
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitBrand);
})();
