<?php
/**
 * UniCybers Academy LMS: Cross-Portal Global Search Service.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Search {

    public static function register_routes($portal) {
        register_rest_route(UC_LMS_Portal::REST_NS, '/global-search', [
            'methods'             => 'GET',
            'permission_callback' => function() {
                return is_user_logged_in();
            },
            'callback'            => [__CLASS__, 'handle_search']
        ]);
    }

    public static function handle_search(WP_REST_Request $request) {
        if (get_user_meta(get_current_user_id(), 'uc_client_preview', true) === '1') {
            return new WP_REST_Response(['query'=>'','total'=>0,'results'=>[]], 200);
        }
        global $wpdb;
        $portal = class_exists('UC_LMS_Portal') ? UC_LMS_Portal::instance() : null;
        if (!$portal) {
            return new WP_REST_Response(['results' => [], 'total' => 0], 200);
        }

        $query = trim(sanitize_text_field($request->get_param('q') ?? ''));
        if (strlen($query) < 2) {
            return new WP_REST_Response(['results' => [], 'total' => 0], 200);
        }

        $like = '%' . $wpdb->esc_like($query) . '%';
        $batch_ids = $portal->batch_ids();
        $in_batches = $batch_ids ? implode(',', array_map('intval', $batch_ids)) : '0';
        $is_staff = $portal->staff();
        $results = [];

        // 1. Courses
        if ($portal->has_table('courses')) {
            $tb_courses = $portal->t('courses');
            $courses = $wpdb->get_results($wpdb->prepare(
                "SELECT id, name, mode, level FROM `$tb_courses` WHERE name LIKE %s OR description LIKE %s ORDER BY name ASC LIMIT 6",
                $like, $like
            ));
            foreach ($courses as $c) {
                $results[] = [
                    'title'    => $c->name,
                    'category' => 'Courses',
                    'page'     => 'Courses',
                    'meta'     => ucfirst($c->mode ?: 'live') . ($c->level ? ' · ' . ucfirst($c->level) : ''),
                    'url'      => home_url('/courses/'),
                ];
            }
        }

        // 2. Batches
        if ($portal->has_table('batches')) {
            $tb_batches = $portal->t('batches');
            $batches = $wpdb->get_results($wpdb->prepare(
                "SELECT id, name, mode, country FROM `$tb_batches` WHERE id IN ({$in_batches}) AND (name LIKE %s OR country LIKE %s) ORDER BY name ASC LIMIT 6",
                $like, $like
            ));
            foreach ($batches as $b) {
                $results[] = [
                    'title'    => $b->name,
                    'category' => 'Batches',
                    'page'     => 'Batches',
                    'meta'     => ucfirst($b->mode ?: 'online') . ($b->country ? ' · ' . $b->country : ''),
                    'url'      => home_url('/batches/'),
                ];
            }
        }

        // 3. Classes
        if ($portal->has_table('sessions')) {
            $tb_sessions = $portal->t('sessions');
            $tb_batches  = $portal->t('batches');
            $sessions = $wpdb->get_results($wpdb->prepare(
                "SELECT s.id, s.title, s.session_date, b.name as batch_name 
                 FROM `$tb_sessions` s 
                 LEFT JOIN `$tb_batches` b ON b.id=s.batch_id 
                 WHERE s.batch_id IN ({$in_batches}) AND s.hidden=0 AND s.title LIKE %s 
                 ORDER BY s.session_date DESC LIMIT 6",
                $like
            ));
            foreach ($sessions as $s) {
                $d = $s->session_date ? date_i18n('j M Y', strtotime($s->session_date)) : '';
                $results[] = [
                    'title'    => $s->title,
                    'category' => 'Classes',
                    'page'     => 'Classes',
                    'meta'     => ($s->batch_name ? $s->batch_name . ' · ' : '') . $d,
                    'url'      => home_url('/lms-class/' . (int)$s->id . '/'),
                ];
            }
        }

        // 4. Materials & Recordings
        if ($portal->has_table('materials')) {
            $tb_materials = $portal->t('materials');
            $tb_batches   = $portal->t('batches');
            $materials = $wpdb->get_results($wpdb->prepare(
                "SELECT m.id, m.title, m.type, b.name as batch_name 
                 FROM `$tb_materials` m 
                 LEFT JOIN `$tb_batches` b ON b.id=m.batch_id 
                 WHERE m.batch_id IN ({$in_batches}) AND m.visible=1 AND m.title LIKE %s 
                 ORDER BY m.id DESC LIMIT 6",
                $like
            ));
            foreach ($materials as $m) {
                $results[] = [
                    'title'    => $m->title,
                    'category' => 'Materials & Recordings',
                    'page'     => 'Materials',
                    'meta'     => ucfirst($m->type ?: 'doc') . ($m->batch_name ? ' · ' . $m->batch_name : ''),
                    'url'      => home_url('/lms-view/material/' . (int)$m->id . '/'),
                ];
            }
        }

        // Recordings from sessions
        if ($portal->has_table('sessions')) {
            $tb_sessions = $portal->t('sessions');
            $tb_batches  = $portal->t('batches');
            $recordings = $wpdb->get_results($wpdb->prepare(
                "SELECT s.id, s.title, s.recording_notes, b.name as batch_name 
                 FROM `$tb_sessions` s 
                 LEFT JOIN `$tb_batches` b ON b.id=s.batch_id 
                 WHERE s.batch_id IN ({$in_batches}) AND s.hidden=0 
                   AND (s.recording_url <> '' OR s.recording_status='available') 
                   AND (s.title LIKE %s OR s.recording_notes LIKE %s) 
                 ORDER BY s.session_date DESC LIMIT 6",
                $like, $like
            ));
            foreach ($recordings as $r) {
                $results[] = [
                    'title'    => $r->title,
                    'category' => 'Materials & Recordings',
                    'page'     => 'Recordings',
                    'meta'     => 'Recording · ' . ($r->batch_name ?: 'Batch'),
                    'url'      => home_url('/lms-view/recording/' . (int)$r->id . '/'),
                ];
            }
        }

        // 5. Practice & Mocks
        if ($portal->has_table('practice')) {
            $tb_practice = $portal->t('practice');
            $tb_batches  = $portal->t('batches');
            $practices = $wpdb->get_results($wpdb->prepare(
                "SELECT p.id, p.title, p.kind, b.name as batch_name 
                 FROM `$tb_practice` p 
                 LEFT JOIN `$tb_batches` b ON b.id=p.batch_id 
                 WHERE p.batch_id IN ({$in_batches}) AND (p.title LIKE %s OR p.body LIKE %s) 
                 ORDER BY p.id DESC LIMIT 6",
                $like, $like
            ));
            foreach ($practices as $p) {
                $results[] = [
                    'title'    => $p->title,
                    'category' => 'Practice & Mocks',
                    'page'     => 'Practice',
                    'meta'     => ucfirst($p->kind ?: 'assignment') . ($p->batch_name ? ' · ' . $p->batch_name : ''),
                    'url'      => home_url('/practice/'),
                ];
            }
        }

        // 6. People (Staff only)
        if ($is_staff) {
            $users = $wpdb->get_results($wpdb->prepare(
                "SELECT ID, display_name, user_email FROM {$wpdb->users} 
                 WHERE display_name LIKE %s OR user_email LIKE %s 
                 ORDER BY display_name ASC LIMIT 6",
                $like, $like
            ));
            foreach ($users as $u) {
                $results[] = [
                    'title'    => $u->display_name,
                    'category' => 'People',
                    'page'     => 'People',
                    'meta'     => $u->user_email,
                    'url'      => home_url('/people/'),
                ];
            }
        }

        return new WP_REST_Response([
            'query'   => $query,
            'total'   => count($results),
            'results' => $results
        ], 200);
    }
}
