<?php
/**
 * UniCybers Academy LMS: Batches Module.
 *
 * Manages batches, delivery mode, term progress, trainer assignment,
 * students roster, and after-class community groups.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Batches {
    public static function render($portal) {
        global $wpdb;
        if (!UC_LMS_Portal_Context::staff()) {
            return $portal->empty_state('Not available', 'Your batches are shown on your dashboard.', 'batches');
        }

        $canEdit = UC_LMS_Portal_Context::ops();
        $ids     = UC_LMS_Portal_Context::in_ids();

        $tb_batches    = UC_LMS_Database::table('batches');
        $tb_courses    = UC_LMS_Database::table('courses');
        $tb_enrolments = UC_LMS_Database::table('enrolments');
        $tb_sessions   = UC_LMS_Database::table('sessions');

        $demo_filter = $portal->demo_sql();

        $rows = $wpdb->get_results(
            "SELECT b.*, c.name course_name, 
                (SELECT COUNT(*) FROM `$tb_enrolments` e JOIN {$wpdb->users} u ON u.ID=e.user_id WHERE e.batch_id=b.id AND e.status='active' AND {$demo_filter}) learners, 
                (SELECT COUNT(*) FROM `$tb_sessions` s WHERE s.batch_id=b.id AND s.hidden=0 AND LOWER(s.status)<>'cancelled') classes 
            FROM `$tb_batches` b 
            LEFT JOIN `$tb_courses` c ON c.id=b.course_id 
            WHERE b.id IN ({$ids}) 
            ORDER BY b.status='active' DESC, b.start_date DESC"
        );

        $o = '';
        if (!$rows) {
            return $o . ($canEdit ? self::modal_tpl($portal) : '') . $portal->empty_state('No batches yet', 'Batches you create will appear here.', 'batches');
        }

        $o .= '<section class="panel flush"><div class="tablewrap"><table><thead><tr><th>Batch</th><th>Course</th><th>Trainer</th><th>Learners</th><th>Classes</th><th>Term progress</th><th>Status</th><th></th></tr></thead><tbody>';
        $now = current_time('timestamp');

        foreach ($rows as $b) {
            $t = $b->trainer_user_id ? get_user_by('id', (int)$b->trainer_user_id) : null;
            $s = strtotime((string)$b->start_date);
            $e = strtotime((string)$b->end_date);
            $pct = ($s && $e && $e > $s) ? max(0, min(100, round(($now - $s) * 100 / ($e - $s)))) : 0;
            $dates = ($s ? date_i18n('j M', $s) : 'TBA') . ' → ' . ($e ? date_i18n('j M Y', $e) : 'TBA');
            $st = strtolower($b->status) === 'active' ? $portal->pill('Active', 'ok') : $portal->pill(ucfirst($b->status), 'mut');
            $live = $portal->batch_next_session((int)$b->id);

            $o .= '<tr data-q="' . esc_attr(strtolower($b->name . ' ' . $b->course_name)) . '"><td><strong>' . $portal->e($b->name) . '</strong><small class="sub">' . $portal->e(ucfirst($b->mode ?: 'online')) . ($b->country ? ' · ' . $portal->e($b->country) : '') . '</small></td><td>' . $portal->e($b->course_name ?: 'Unassigned') . '</td>';
            $o .= '<td>' . ($t ? '<span class="who"><span class="avatar xs">' . $portal->e($portal->initials($t->display_name)) . '</span>' . $portal->e($t->display_name) . '</span>' : $portal->pill('Not assigned', 'warn')) . '</td><td><b>' . (int)$b->learners . '</b></td><td>' . (int)$b->classes . '</td>';
            $o .= '<td><div class="prog"><i style="width:' . $pct . '%"></i></div><small class="sub">' . $portal->e($dates) . '</small></td><td>' . $st . '</td>';

            if ($canEdit) {
                $edit = [
                    'id'                  => (int)$b->id,
                    'name'                => $b->name,
                    'course_id'           => (int)$b->course_id,
                    'mode'                => $b->mode,
                    'default_meeting_provider' => $b->default_meeting_provider ?? 'zoom',
                    'country'             => $b->country,
                    'location'            => $b->location,
                    'start_date'          => $b->start_date,
                    'end_date'            => $b->end_date,
                    'trainer_user_id'     => (int)$b->trainer_user_id,
                    'coordinator_user_id' => (int)($b->coordinator_user_id ?? 0),
                    'status'              => $b->status,
                    'timezone'            => $b->timezone ?: 'Asia/Kolkata',
                    'recurrence_days'     => array_values(array_filter(explode(',', (string)($b->recurrence_days ?? '')))),
                    'whatsapp_url'        => $b->whatsapp_url ?? '',
                    'telegram_url'        => $b->telegram_url ?? '',
                    'discord_url'         => $b->discord_url ?? '',
                    'group_url'           => $b->group_url ?? ''
                ];
                $o .= '<td class="acts">';
                if (strtolower((string)$b->status) === 'active' && $live) {
                    $o .= $portal->join_button($live[0], $live[1]);
                }
                $o .= '<button type="button" class="btn ghost sm" data-edit-batch=\'' . esc_attr(wp_json_encode($edit)) . '\'>Edit</button>';
                $o .= '<a class="btn ghost sm" href="' . esc_url(add_query_arg('students', (int)$b->id, $portal->url('batches'))) . '">Students</a>';
                $o .= '<a class="btn ghost sm" href="' . esc_url($portal->url('classes')) . '">Schedule</a></td>';
            } else {
                $o .= '<td class="acts">';
                if (strtolower((string)$b->status) === 'active' && $live) {
                    $o .= $portal->join_button($live[0], $live[1]);
                }
                $o .= '</td>';
            }
            $o .= '</tr>';
        }

        $o .= '</tbody></table></div></section>';
        if (UC_LMS_Portal_Context::staff() && method_exists($portal, 'batch_class_history')) {
            $o .= $portal->batch_class_history();
        }
        if ($canEdit) {
            $o .= self::students_panel($portal) . self::modal_tpl($portal);
        }
        return $o;
    }

    public static function modal_tpl($portal) {
        global $wpdb;
        $tb_courses = UC_LMS_Database::table('courses');
        $courses = $wpdb->get_results("SELECT id, name FROM `$tb_courses` ORDER BY name");
        $trainers = $portal->batch_trainers();

        $o = '<template id="tplBatch"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="form"><input type="hidden" name="action" value="uc_portal_batch_save">' . wp_nonce_field('uc_portal_batch_save', '_wpnonce', true, false) . '<input type="hidden" name="id"><input type="hidden" name="do" value="save">';
        $o .= $portal->mhead('DELIVERY', 'Add Batch', true) . '<div class="fgrid">';
        $o .= '<label>Batch name<input name="name" required placeholder="SOC R030926"></label><label>Course<select name="course_id" required><option value="">Select a course</option>';
        foreach ($courses as $c) {
            $o .= '<option value="' . (int)$c->id . '">' . $portal->e($c->name) . '</option>';
        }
        $o .= '</select></label><label>Trainer<select name="trainer_user_id"><option value="">Not assigned</option>';
        foreach ($trainers as $t) {
            $lr = $portal->lms_role_of($t);
            $o .= '<option value="' . (int)$t->ID . '">' . $portal->e($t->display_name) . ' · ' . $portal->e(ucwords($lr)) . '</option>';
        }
        $o .= '</select></label><label>Support host<select name="coordinator_user_id"><option value="">None</option>';
        foreach ($portal->support_hosts() as $h) {
            $o .= '<option value="' . (int)$h->ID . '">' . $portal->e($h->display_name) . ' · ' . $portal->e(ucwords($portal->lms_role_of($h))) . '</option>';
        }
        $o .= '</select></label><label>Meeting provider<select name="default_meeting_provider"><option value="zoom">Zoom</option><option value="google_meet">Google Meet</option><option value="teams">Microsoft Teams</option><option value="zoho">Zoho Meeting</option></select></label><label>Mode<select name="mode"><option value="online">Online</option><option value="hybrid">Hybrid</option><option value="classroom">Classroom</option></select></label>';
        $o .= '<label>Country<input name="country" placeholder="India, Botswana…"></label><label>Location<input name="location" placeholder="Optional city or venue"></label>';
        $o .= '<label>Status<select name="status"><option value="active">Active</option><option value="paused">Paused</option><option value="completed">Completed</option><option value="archived">Archived</option></select></label>';
        $o .= '<label>Start date<input type="date" name="start_date"></label><label>End date<input type="date" name="end_date"></label>';
        $o .= '<label>Timezone<select name="timezone">' . $portal->tz_options('Asia/Kolkata') . '</select></label></div>';
        $o .= '<div class="fgrid-full" style="margin:6px 0 10px"><label class="lbl-block">Class days (select days on which classes run)</label><div class="check-row weekday-picker">';
        foreach (['2'=>'Mon','3'=>'Tue','4'=>'Wed','5'=>'Thu','6'=>'Fri','7'=>'Sat','1'=>'Sun'] as $k => $label) {
            $o .= '<label class="daychk"><input type="checkbox" name="recurrence_days[]" value="' . esc_attr($k) . '"><span class="day-short">' . esc_html($label) . '</span></label>';
        }
        $o .= '</div></div>';
        $o .= '<div data-editonly><div class="msub">After-class groups</div><div class="fgrid">';
        $o .= '<label>WhatsApp group<input name="whatsapp_url" placeholder="https://chat.whatsapp.com/…"></label>';
        $o .= '<label>Telegram group<input name="telegram_url" placeholder="https://t.me/…"></label>';
        $o .= '<label>Discord server<input name="discord_url" placeholder="https://discord.gg/…"></label>';
        $o .= '<label>Other group link<input name="group_url" placeholder="Any https:// invite"></label></div></div>';
        $o .= '<div class="mfoot"><div class="mfoot-l" data-editonly><button type="button" class="btn danger sm" data-do="delete" data-confirm="Delete this batch? Its classes, attendance and materials are removed too. This cannot be undone.">Delete</button></div><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary" name="do" value="save">Save</button></div></form></template>';
        return $o;
    }

    public static function students_panel($portal) {
        global $wpdb;
        $bid = absint($_GET['students'] ?? 0);
        $ids = UC_LMS_Portal_Context::batch_ids();
        if (!$bid || !in_array($bid, $ids, true)) return '';

        $tb_batches    = UC_LMS_Database::table('batches');
        $tb_enrolments = UC_LMS_Database::table('enrolments');

        $b = $wpdb->get_row($wpdb->prepare("SELECT name FROM `$tb_batches` WHERE id=%d", $bid));
        if (!$b) return '';

        $rows = $wpdb->get_results($wpdb->prepare("SELECT u.ID, u.display_name, u.user_email FROM `$tb_enrolments` e JOIN {$wpdb->users} u ON u.ID=e.user_id WHERE e.batch_id=%d AND e.status='active' ORDER BY u.display_name", $bid));
        $on = [];
        foreach ($rows as $r) $on[(int)$r->ID] = true;

        $roster = [];
        foreach (get_users(['role' => 'uc_student', 'orderby' => 'display_name', 'number' => 800]) as $u) {
            if (!empty($on[(int)$u->ID])) continue;
            if (UC_LMS_Security::is_demo($u)) continue;
            $roster[] = $u;
        }

        $o = '<div class="modal open" id="batch-students"><div class="uc-card"><div class="mhead"><div><span class="eyebrow">STUDENTS</span><h3>' . $portal->e($b->name) . '</h3></div><a class="iconbtn mclose" href="' . esc_url($portal->url('batches')) . '" aria-label="Close">' . $portal->icon('x') . '</a></div>';
        $o .= '<p class="muted">' . count($rows) . ' on this batch</p>';
        if (!$rows) {
            $o .= '<p class="muted">No students on this batch yet.</p>';
        } else {
            $o .= '<div class="tablewrap"><table><thead><tr><th>Name</th><th>Email</th><th></th></tr></thead><tbody>';
            foreach ($rows as $r) {
                $u = get_user_by('id', (int)$r->ID);
                $demo = $u && UC_LMS_Security::is_demo($u);
                $student = $u && $portal->lms_role_of($u) === 'student' && !$demo;
                $o .= '<tr><td>' . $portal->e($r->display_name) . '</td><td>' . $portal->e($r->user_email) . '</td><td class="acts">';
                if ($student) {
                    $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_student_remove">' . wp_nonce_field('uc_portal_student_remove', '_wpnonce', true, false) . '<input type="hidden" name="batch_id" value="' . $bid . '"><input type="hidden" name="user_id" value="' . (int)$r->ID . '"><button class="btn ghost sm" data-confirm="Remove ' . $portal->e($r->display_name) . ' from this batch and revoke sign-in now?">Remove</button></form>';
                }
                $o .= '</td></tr>';
            }
            $o .= '</tbody></table></div>';
        }
        $o .= '<div class="msub">Add from academy roster</div>';
        $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="uc_portal_student_add">' . wp_nonce_field('uc_portal_student_add', '_wpnonce', true, false) . '<input type="hidden" name="batch_id" value="' . $bid . '">';
        if (!$roster) {
            $o .= '<p class="pick-empty">Every current student is already on this batch.</p>';
        } else {
            $o .= '<div class="pick-list">';
            foreach ($roster as $u) {
                $o .= '<label class="pick-row"><input type="checkbox" name="user_ids[]" value="' . (int)$u->ID . '"><span><strong>' . $portal->e($u->display_name) . '</strong><small>' . $portal->e($u->user_email) . '</small></span></label>';
            }
            $o .= '</div>';
        }
        $o .= '<div class="right"><button class="btn primary"' . ($roster ? '' : ' disabled') . '>Add selected</button></div></form>';
        $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="form" style="margin-top:14px"><input type="hidden" name="action" value="uc_portal_student_import">' . wp_nonce_field('uc_portal_student_import', '_wpnonce', true, false) . '<input type="hidden" name="batch_id" value="' . $bid . '">';
        $o .= '<label>New students<textarea name="rows" rows="4" placeholder="Name, email, phone&#10;Aakash, aakash@example.com, 9876543210"></textarea></label>';
        $o .= '<label class="check"><input type="checkbox" name="send" value="1" checked> Email each new password</label>';
        $o .= '<div class="right"><button class="btn ghost">Create and add</button></div></form></div></div>';
        return $o;
    }

    public static function batch_class_history($portal, $for_classroom=false) {
        if (!$portal->has_table('intel_status')) return '';
        global $wpdb;
        $ids = $portal->in_ids($portal->batch_ids());
        $rows = $wpdb->get_results("SELECT s.id,s.title,s.session_date,s.batch_id,b.name batch_name,c.name course_name,
            (SELECT COUNT(*) FROM {$portal->t('enrolments')} e WHERE e.batch_id=s.batch_id AND e.status='active') students,
            st.recording_state, st.summary_state, st.transcript_state, st.tasks_state, st.attendance_state
            FROM {$portal->t('sessions')} s
            JOIN {$portal->t('batches')} b ON b.id=s.batch_id
            LEFT JOIN {$portal->t('courses')} c ON c.id=b.course_id
            LEFT JOIN {$portal->t('intel_status')} st ON st.session_id=s.id
            WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(IFNULL(s.status,''))<>'cancelled' AND {$portal->class_finished_sql('s')}
            ORDER BY s.session_date DESC LIMIT 40");
        if (!$rows) return '';
        if ($for_classroom) {
            $o = '<details class="cr-overview"><summary>Batch overview</summary><div class="cr-overview-body"><table><thead><tr><th>Date</th><th>Topic</th><th>Students</th><th>Attendance</th><th>Recording</th><th>Summary</th></tr></thead><tbody>';
        } else {
            $o = '<section class="panel" style="margin-top:16px"><div class="ph"><div><span class="eyebrow">BATCH</span><h3>Class history</h3></div></div><div class="tablewrap"><table><thead><tr><th>Date</th><th>Topic</th><th>Batch</th><th>Students</th><th>Attendance</th><th>Recording</th><th>Summary</th><th>Transcript</th><th>Tasks</th></tr></thead><tbody>';
        }
        foreach ($rows as $r) {
            $pct = '';
            if ($portal->has_table('intel_participants')) {
                $n = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('intel_participants')} WHERE session_id=%d", $r->id));
                $ok = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('intel_participants')} WHERE session_id=%d AND attendance_status='present'", $r->id));
                if ($n) $pct = round($ok * 100 / $n).'%';
            }
            $dot = function ($st) {
                $ok = strtolower((string)$st) === 'available';
                return $ok ? '✓' : '–';
            };
            if ($for_classroom) {
                $o .= '<tr><td>'.$portal->e($portal->fdate($r->session_date,'j M')).'</td><td><a href="'.esc_url(home_url('/lms-class/'.(int)$r->id.'/')).'">'.$portal->e($r->title).'</a></td><td>'.(int)$r->students.'</td><td>'.$portal->e($pct ?: '–').'</td><td>'.$dot($r->recording_state).'</td><td>'.$dot($r->summary_state).'</td></tr>';
            } else {
                $o .= '<tr><td>'.$portal->e($portal->fdate($r->session_date,'j M')).'</td><td><a href="'.esc_url(home_url('/lms-class/'.(int)$r->id.'/')).'">'.$portal->e($r->title).'</a></td><td>'.$portal->e($r->batch_name).'</td><td>'.(int)$r->students.'</td><td>'.$portal->e($pct ?: '–').'</td><td>'.$dot($r->recording_state).'</td><td>'.$dot($r->summary_state).'</td><td>'.$dot($r->transcript_state).'</td><td>'.$dot($r->tasks_state).'</td></tr>';
            }
        }
        return $o.'</tbody></table></div>'.($for_classroom ? '</details>' : '</section>');
    }

    public static function course_interest_list($portal){
        $rows = get_option('uc_course_enquiries');
        if (!is_array($rows)) $rows = [];
        $open = []; $closed = [];
        foreach ($rows as $i => $r) {
            if (empty($r['id'])) $r['id'] = 'e'.$i;
            $st = $r['status'] ?? 'open';
            if ($st === 'open') $open[] = $r; else $closed[] = $r;
        }
        $post = esc_url(admin_url('admin-post.php'));
        $nonce = wp_nonce_field('uc_portal_enquiry_status','_wpnonce',true,false);
        $o = '<section class="panel flush"><div class="ph" style="padding:16px 18px 0"><div><span class="eyebrow">ENQUIRIES</span><h3>Course interest</h3></div></div>';
        $o .= '<p class="hint" style="padding:0 18px">These arrive when someone opens a programme link you shared and asks to enrol. Archive a row, or mark it not interested, when they go quiet or say no.</p>';
        $o .= '<div class="tablewrap"><table><thead><tr><th>When</th><th>Course</th><th>Name</th><th>Email</th><th>Phone</th><th>Note</th><th></th></tr></thead><tbody>';
        if (!$open) $o .= '<tr><td colspan="7">No open interest.</td></tr>';
        foreach (array_reverse($open) as $r) {
            $o .= '<tr><td>'.$portal->e($r['at'] ?? '').'</td><td>'.$portal->e($r['course'] ?? '').'</td><td>'.$portal->e($r['name'] ?? '').'</td><td>'.$portal->e($r['email'] ?? '').'</td><td>'.$portal->e($r['phone'] ?? '').'</td><td>'.$portal->e($r['note'] ?? '').'</td><td class="acts">';
            $o .= '<form method="post" action="'.$post.'" class="inline-form"><input type="hidden" name="action" value="uc_portal_enquiry_status">'.$nonce.'<input type="hidden" name="id" value="'.esc_attr($r['id']).'"><button class="btn ghost sm" name="status" value="archived">Archive</button><button class="btn ghost sm" name="status" value="not_interested">Not interested</button></form></td></tr>';
        }
        $o .= '</tbody></table></div>';
        if ($closed) {
            $o .= '<details class="lib-inner" style="margin:0 18px 14px"><summary>Archived and not interested <span class="count">'.count($closed).'</span></summary>';
            foreach (array_reverse($closed) as $r) {
                $lab = ($r['status'] ?? '') === 'archived' ? 'Archived' : 'Not interested';
                $o .= '<div class="req"><div><strong>'.$portal->e($r['name'] ?? '').'</strong><small>'.$portal->e($r['course'] ?? '').' · '.$portal->e($r['email'] ?? '').' · '.$lab.'</small></div>';
                $o .= '<form method="post" action="'.$post.'" class="inline-form"><input type="hidden" name="action" value="uc_portal_enquiry_status">'.$nonce.'<input type="hidden" name="id" value="'.esc_attr($r['id']).'"><button class="btn ghost sm" name="status" value="open">Restore</button></form></div>';
            }
            $o .= '</details>';
        }
        return $o.'</section>';
    }

    public static function support_hosts($portal){
        $out = [];
        foreach (get_users(['number'=>300,'orderby'=>'display_name']) as $u) {
            $r = $portal->lms_role_of($u);
            if ($r === 'coordinator' || $r === 'super_admin') $out[] = $u;
        }
        return $out;
    }

    public static function zoom_alt_hosts($portal, $batch_id = 0){
        global $wpdb;
        $emails = [];
        $push = function ($email) use (&$emails) {
            $email = strtolower(trim((string)$email));
            if (!$email || !is_email($email) || $email === 'training@unicybers.com') return;
            if (!in_array($email, $emails, true)) $emails[] = $email;
        };
        if ($batch_id) {
            $b = $wpdb->get_row($wpdb->prepare("SELECT trainer_user_id, coordinator_user_id FROM {$portal->t('batches')} WHERE id=%d", $batch_id));
            if ($b) {
                if (!empty($b->trainer_user_id)) { $t = get_user_by('id', (int)$b->trainer_user_id); if ($t) $push($t->user_email); }
                if (!empty($b->coordinator_user_id)) { $c = get_user_by('id', (int)$b->coordinator_user_id); if ($c) $push($c->user_email); }
            }
        }
        foreach (['rafi@unicybers.com','coordinator@unicybers.com','sofia@unicybers.com','noori@unicybers.com','ranjan@unicybers.com','shoaib@unicybers.com'] as $staff) {
            $push($staff);
        }
        return implode(',', $emails);
    }

    public static function batch_next_session($portal, $batch_id = 0){
        $rows = $portal->sessions('s.batch_id='.(int)$batch_id.' AND LOWER(s.status)<>\'cancelled\'', 's.session_date,s.start_time', 40);
        foreach ($rows as $s) {
            $w = $portal->window($s);
            if (!$w['done']) return [$s, $w];
        }
        return null;
    }

}
