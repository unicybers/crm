<?php
/**
 * Plugin Name: UniCybers Books
 * Description: Academy ledger for UniCybers VTZ LLP. Quotes, proforma, tax invoices, expenses, and India GST/TDS working papers. It prepares paste sheets and reminders. It does not log into the GST portal and it does not file returns.
 * Version: 1.0.45
 * Author: UniCybers
 * Text Domain: unicybers-books
 * Requires at least: 6.4
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__.'/class-reconcile.php';

final class UC_Books {
    const VERSION = '1.0.45';

    public static function boot() {
        $self = new self();
        $GLOBALS['uc_books_app'] = $self;
        register_activation_hook(__FILE__, [$self, 'activate']);
        add_action('init', [$self, 'ensure_page']);
        add_action('wp_ajax_ub_student_lookup', [$self, 'student_lookup']);
        add_action('init', [$self, 'upgrade']);
        add_filter('template_include', [$self, 'template_include'], 99);
        add_filter('redirect_canonical', [$self, 'prevent_finance_canonical_redirect'], 10, 2);
        add_filter('body_class', [$self, 'body_class']);
        add_shortcode('unicybers_books', [$self, 'shortcode']);
        add_action('admin_post_ub_login', [$self, 'login']);
        add_action('admin_post_nopriv_ub_login', [$self, 'login']);
        add_action('admin_post_ub_logout', [$self, 'logout']);
        add_action('ub_filing_digest', [$self, 'filing_digest']);
        add_action('ub_weekly_report', [$self, 'weekly_report']);
        add_action('ub_monthly_report', [$self, 'monthly_report']);
        add_action('ub_recurring_tick', [$self, 'recurring_tick']);
        foreach (['save_doc','delete_doc','payment','expense','settings','user','migrate','profile','tds','report','match','share','payout','recur','bill_read','bill_file','password','fin_pay','fin_share','fin_expense','sub','reminder','chase','lead_sync','loan_create','loan_approve','loan_repay','reminder_manage','zoho_export'] as $a) {
            add_action('admin_post_ub_'.$a, [$self, $a]);
        }
        foreach (['import'=>'import','confirm'=>'confirm','reject'=>'reject','adjust'=>'adjust','lock'=>'lock'] as $hook=>$method) {
            add_action('admin_post_ub_recon_'.$hook, ['UC_Books_Reconcile', $method]);
        }
    }

    private function t($name) {
        global $wpdb;
        return $wpdb->prefix.'ub_'.$name;
    }

    public function activate() {
        $this->install();
        $this->ensure_page();
        flush_rewrite_rules(false);
    }

    private function install() {
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $docs = $this->t('docs');
        $lines = $this->t('lines');
        $pays = $this->t('pays');
        $ex = $this->t('expenses');
        $shares = $this->t('shares');
        $payouts = $this->t('payouts');
        $profiles = $this->t('profiles');
        $tds = $this->t('tds');
        $sql = [];
        $sql[] = "CREATE TABLE $docs (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            doc_type varchar(30) NOT NULL DEFAULT 'invoice',
            number varchar(60) NULL,
            status varchar(20) NOT NULL DEFAULT 'draft',
            contact_name varchar(191) NULL,
            contact_email varchar(191) NULL,
            contact_phone varchar(60) NULL,
            contact_address text NULL,
            contact_country varchar(80) NOT NULL DEFAULT 'India',
            contact_state varchar(80) NULL,
            contact_gstin varchar(20) NULL,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            supply varchar(20) NOT NULL DEFAULT 'domestic',
            price_mode varchar(10) NOT NULL DEFAULT 'incl',
            tax_rate decimal(6,2) NOT NULL DEFAULT 18,
            subtotal decimal(12,2) NOT NULL DEFAULT 0,
            cgst decimal(12,2) NOT NULL DEFAULT 0,
            sgst decimal(12,2) NOT NULL DEFAULT 0,
            igst decimal(12,2) NOT NULL DEFAULT 0,
            total decimal(12,2) NOT NULL DEFAULT 0,
            paid decimal(12,2) NOT NULL DEFAULT 0,
            doc_date date NULL,
            due_date date NULL,
            terms text NULL,
            notes text NULL,
            parent_id bigint unsigned NULL,
            source varchar(40) NULL,
            source_id bigint unsigned NULL,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            customer_type varchar(20) NOT NULL DEFAULT 'b2b',
            supply_reason text NULL,
            sac varchar(20) NULL,
            tds_mode varchar(30) NULL,
            tds_section varchar(20) NULL,
            tds_rate decimal(6,2) NOT NULL DEFAULT 0,
            tds_note text NULL,
            assistant_note text NULL,
            bank_key varchar(40) NULL,
            include_stamp tinyint(1) NOT NULL DEFAULT 0,
            place_state varchar(80) NULL,
            gst_exception tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY doc_type (doc_type),
            KEY source_key (source, source_id)
        ) $c;";
        $sql[] = "CREATE TABLE $lines (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            doc_id bigint unsigned NOT NULL,
            component varchar(255) NOT NULL,
            basis varchar(80) NULL,
            scope text NULL,
            amount decimal(12,2) NOT NULL DEFAULT 0,
            sac varchar(20) NULL,
            PRIMARY KEY  (id),
            KEY doc_id (doc_id)
        ) $c;";
        $sql[] = "CREATE TABLE $pays (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            doc_id bigint unsigned NOT NULL,
            amount decimal(12,2) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            paid_on date NULL,
            method varchar(60) NULL,
            reference varchar(191) NULL,
            created_by bigint unsigned NULL,
            PRIMARY KEY  (id),
            KEY doc_id (doc_id)
        ) $c;";
        $sql[] = "CREATE TABLE $ex (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            category varchar(80) NOT NULL DEFAULT 'other',
            amount decimal(12,2) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            spent_on date NULL,
            vendor varchar(191) NULL,
            vendor_gstin varchar(20) NULL,
            tax_rate decimal(6,2) NOT NULL DEFAULT 0,
            itc tinyint(1) NOT NULL DEFAULT 1,
            notes text NULL,
            tds_section varchar(20) NULL,
            tds_note text NULL,
            matched_2b tinyint(1) NOT NULL DEFAULT 0,
            source varchar(40) NULL,
            source_id bigint unsigned NULL,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id)
        ) $c;";
        $sql[] = "CREATE TABLE $shares (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            trainer_name varchar(191) NULL,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            earned decimal(12,2) NOT NULL DEFAULT 0,
            source_id bigint unsigned NULL,
            PRIMARY KEY  (id)
        ) $c;";
        $sql[] = "CREATE TABLE $payouts (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            trainer_name varchar(191) NULL,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            amount decimal(12,2) NOT NULL DEFAULT 0,
            source_id bigint unsigned NULL,
            PRIMARY KEY  (id)
        ) $c;";
        $rec = $this->t('recurring');
        $sql[] = "CREATE TABLE $rec (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            category varchar(80) NOT NULL DEFAULT 'other',
            amount decimal(12,2) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            day_of_month tinyint unsigned NOT NULL DEFAULT 1,
            active tinyint(1) NOT NULL DEFAULT 1,
            last_ym char(7) NULL,
            PRIMARY KEY  (id)
        ) $c;";
        $sql[] = "CREATE TABLE $profiles (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            code varchar(20) NOT NULL,
            label varchar(80) NOT NULL,
            rate decimal(6,2) NOT NULL DEFAULT 0,
            reg_number varchar(40) NULL,
            legal_name varchar(191) NULL,
            address text NULL,
            period varchar(20) NULL,
            active tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY code (code)
        ) $c;";
        $sql[] = "CREATE TABLE $tds (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            section varchar(20) NOT NULL,
            deductee varchar(191) NOT NULL,
            pan varchar(12) NULL,
            base decimal(12,2) NOT NULL DEFAULT 0,
            rate decimal(6,2) NOT NULL DEFAULT 0,
            tax decimal(12,2) NOT NULL DEFAULT 0,
            quarter varchar(12) NULL,
            PRIMARY KEY  (id)
        ) $c;";
        $subs = $this->t('subs');
        $rems = $this->t('reminders');
        $audit = $this->t('audit');
        $leads = $this->t('leads');
        $sql[] = "CREATE TABLE $subs (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            kind varchar(20) NOT NULL DEFAULT 'labs',
            contact_name varchar(191) NULL,
            contact_email varchar(191) NULL,
            batch_name varchar(191) NULL,
            amount decimal(12,2) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            course_days int unsigned NOT NULL DEFAULT 45,
            lab_free_days int unsigned NOT NULL DEFAULT 30,
            charge_monthly tinyint(1) NOT NULL DEFAULT 1,
            next_on date NULL,
            active tinyint(1) NOT NULL DEFAULT 1,
            last_ym char(7) NULL,
            doc_id bigint unsigned NULL,
            note text NULL,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY kind (kind)
        ) $c;";
        $sql[] = "CREATE TABLE $rems (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            due_on date NULL,
            kind varchar(30) NOT NULL DEFAULT 'other',
            contact_name varchar(191) NULL,
            note text NULL,
            recurrence varchar(20) NOT NULL DEFAULT 'none',
            advance_days smallint unsigned NOT NULL DEFAULT 7,
            assignee varchar(191) NULL,
            next_due_on date NULL,
            done tinyint(1) NOT NULL DEFAULT 0,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id)
        ) $c;";
        $loans = $this->t('loans');
        $loan_txns = $this->t('loan_txns');
        $loan_schedule = $this->t('loan_schedule');
        $sql[] = "CREATE TABLE $loans (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            loan_number varchar(40) NOT NULL,
            loan_type varchar(20) NOT NULL,
            borrower_type varchar(20) NOT NULL DEFAULT 'external',
            borrower_name varchar(191) NOT NULL,
            principal decimal(12,2) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            repayment_amount decimal(12,2) NOT NULL DEFAULT 0,
            frequency varchar(20) NOT NULL DEFAULT 'monthly',
            issue_date date NULL,
            first_due date NULL,
            reason text NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            approved_by bigint unsigned NULL,
            approved_at datetime NULL,
            outstanding decimal(12,2) NOT NULL DEFAULT 0,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY loan_number (loan_number), KEY status (status), KEY loan_type (loan_type)
        ) $c;";
        $sql[] = "CREATE TABLE $loan_txns (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            loan_id bigint unsigned NOT NULL,
            txn_type varchar(20) NOT NULL,
            amount decimal(12,2) NOT NULL DEFAULT 0,
            txn_date date NULL,
            method varchar(60) NULL,
            reference varchar(191) NULL,
            payout_id bigint unsigned NULL,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY loan_id (loan_id), KEY txn_type (txn_type)
        ) $c;";
        $sql[] = "CREATE TABLE $loan_schedule (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            loan_id bigint unsigned NOT NULL,
            due_date date NOT NULL,
            amount decimal(12,2) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            transaction_id bigint unsigned NULL,
            PRIMARY KEY (id), KEY loan_id (loan_id), KEY due_date (due_date)
        ) $c;";
        $sql[] = "CREATE TABLE $audit (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NULL,
            action varchar(40) NOT NULL,
            object_type varchar(40) NULL,
            object_id bigint unsigned NULL,
            detail text NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id)
        ) $c;";
        $sql[] = "CREATE TABLE $leads (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            lms_user_id bigint unsigned NOT NULL,
            name varchar(191) NULL,
            email varchar(191) NULL,
            kind varchar(30) NOT NULL DEFAULT 'student',
            synced_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY lms_user_id (lms_user_id)
        ) $c;";
        foreach ($sql as $q) dbDelta($q);
        UC_Books_Reconcile::install();
        $this->ensure_columns();
        $this->seed_company();
        if (!$wpdb->get_var("SELECT id FROM $profiles LIMIT 1")) {
            $rows = [
                ['india','India GST',18,'', '', '', 'unconfirmed',1],
                ['botswana','Botswana VAT',14,'','','','',0],
                ['uae','UAE VAT',5,'','','','',0],
                ['saudi','Saudi VAT',15,'','','','',0],
            ];
            foreach ($rows as $r) {
                $wpdb->insert($profiles, [
                    'code'=>$r[0],'label'=>$r[1],'rate'=>$r[2],'reg_number'=>$r[3],'legal_name'=>$r[4],'address'=>$r[5],'period'=>$r[6],'active'=>$r[7],
                ]);
            }
        }
        if (!get_role('ub_accountant')) add_role('ub_accountant', 'UniCybers Accountant', ['read'=>true]);
        if (!get_role('uc_trainer')) add_role('uc_trainer', 'Trainer', ['read'=>true]);
    }

    public function upgrade() {
        if (get_option('ub_books_db') === self::VERSION) {
            $this->maybe_schedule();
            return;
        }
        $this->install();
        update_option('ub_books_db', self::VERSION, false);
        $this->maybe_schedule();
    }

    public function ensure_page() {
        // Do not trust the stored ID by itself: it may point to a deleted,
        // trashed, unpublished, or repurposed page from an earlier install.
        $stored_id = (int) get_option('ub_books_page');
        if ($stored_id) {
            $stored = get_post($stored_id);
            if ($stored instanceof WP_Post && $stored->post_type === 'page' &&
                $stored->post_status === 'publish' && $stored->post_name === 'books') {
                return;
            }
        }

        $existing = get_page_by_path('books', OBJECT, 'page');
        if ($existing instanceof WP_Post && $existing->post_status !== 'trash') {
            update_option('ub_books_page', (int) $existing->ID, false);
            return;
        }

        $id = wp_insert_post([
            'post_title' => 'Books',
            'post_name' => 'books',
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_content' => '[unicybers_books]',
        ], true);
        if ($id && !is_wp_error($id)) {
            update_option('ub_books_page', (int) $id, false);
        }
    }

    public function company() {
        $c = get_option('ub_company');
        return is_array($c) ? $c : [];
    }

    private function ensure_columns() {
        global $wpdb;
        $adds = [
            'docs' => [
                'customer_type' => "varchar(20) NOT NULL DEFAULT 'b2b'",
                'supply_reason' => 'text NULL',
                'sac' => 'varchar(20) NULL',
                'tds_mode' => 'varchar(30) NULL',
                'tds_section' => 'varchar(20) NULL',
                'tds_rate' => 'decimal(6,2) NOT NULL DEFAULT 0',
                'tds_note' => 'text NULL',
                'assistant_note' => 'text NULL',
                'bank_key' => 'varchar(40) NULL',
                'include_stamp' => 'tinyint(1) NOT NULL DEFAULT 0',
                'place_state' => 'varchar(80) NULL',
                'gst_exception' => 'tinyint(1) NOT NULL DEFAULT 0',
                'product_line' => "varchar(20) NOT NULL DEFAULT 'other'",
                'course_days' => 'int unsigned NOT NULL DEFAULT 45',
                'lab_free_days' => 'int unsigned NOT NULL DEFAULT 30',
                'lab_fee' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'lms_fee' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'batch_label' => 'varchar(191) NULL',
            ],
            'lines' => ['sac' => 'varchar(20) NULL'],
            'expenses' => [
                'tds_section' => 'varchar(20) NULL',
                'tds_note' => 'text NULL',
                'matched_2b' => 'tinyint(1) NOT NULL DEFAULT 0',
                'bill_number' => 'varchar(80) NULL',
                'taxable' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'cgst' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'sgst' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'igst' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'sac' => 'varchar(20) NULL',
                'attachment' => 'varchar(191) NULL',
                'attachment_name' => 'varchar(191) NULL',
            ],
            'shares' => [
                'trainer_user_id' => 'bigint unsigned NULL',
                'batch_name' => 'varchar(191) NULL',
                'doc_id' => 'bigint unsigned NULL',
                'fee_received' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'fee_base' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'share_percent' => 'decimal(6,2) NOT NULL DEFAULT 0',
                'expenses' => 'decimal(12,2) NOT NULL DEFAULT 0',
                'note' => 'text NULL',
            ],
            'payouts' => [
                'trainer_user_id' => 'bigint unsigned NULL',
                'paid_on' => 'date NULL',
                'note' => 'text NULL',
            ],
            'leads' => [
                'phone' => 'varchar(40) NULL',
                'country' => 'varchar(80) NULL',
                'currency' => 'varchar(10) NULL',
                'lms_role' => 'varchar(40) NULL',
                'status' => 'varchar(30) NULL',
                'batch_name' => 'varchar(191) NULL',
                'last_login' => 'varchar(40) NULL',
            ],
        ];
        foreach ($adds as $table => $cols) {
            $t = $this->t($table);
            $have = $wpdb->get_col("SHOW COLUMNS FROM $t", 0);
            if (!$have) continue;
            foreach ($cols as $name => $def) {
                if (!in_array($name, $have, true)) $wpdb->query("ALTER TABLE $t ADD COLUMN $name $def");
            }
        }
    }

    private function default_banks() {
        return [
            [
                'key' => 'hdfc',
                'name' => 'UNICYBERS VTZ LLP',
                'bank' => 'HDFC Bank',
                'number' => '50200066899016',
                'ifsc' => 'HDFC0000050',
                'branch' => 'Potluri Castle, 1st floor above Raymond Showroom, 48-14-9, Dwaraka Nagar, Visakhapatnam, Andhra Pradesh 530016',
                'type' => 'current',
                'holder' => 'firm',
                'product' => 'SMARTUP ALPHA CA',
                'branch_code' => '0050',
                'default' => 1,
                'label' => '',
            ],
            [
                'key' => 'bob',
                'name' => 'Mohammed Karimul Rafi',
                'bank' => 'Bank of Baroda',
                'number' => '36560100001083',
                'ifsc' => 'BARB0MURALI',
                'branch' => 'Murali Nagar, Visakhapatnam 530007',
                'type' => 'savings',
                'holder' => 'personal',
                'product' => '',
                'branch_code' => '',
                'default' => 0,
                'label' => 'Personal - use only when the client requires this account',
            ],
        ];
    }

    private function seed_company() {
        $c = get_option('ub_company');
        if (!is_array($c)) $c = [];
        $fill = [
            'legal_name' => 'UNICYBERS VTZ LLP',
            'nature' => 'Limited Liability Partnership',
            'llpin' => 'ABA-5359',
            'incorporated' => '07/02/2022',
            'city' => 'Visakhapatnam',
            'state' => 'Andhra Pradesh',
            'state_code' => '37',
            'address' => 'Door No 57-15-20/4, Subhash Nagar, Kancharapalem, Visakhapatnam, Andhra Pradesh, 530008',
            'mca_address' => '57 15 20 4, Subhash Nagar, Kancharapalem, Near Municipal School, Visakhapatnam Urban, Visakhapatnam, Andhra Pradesh, 530008, India',
            'gst_principal' => '57-15-20/4, Near Municipal School, Subhash Nagar, Kancharapalem, Visakhapatnam, Andhra Pradesh, 530008',
            'gst_additional' => 'Beside The Visakhapatnam Cooperative Bank Ltd, 4th Floor, 401, Bharat Towers, 54th Lane, Dwarakanagar, Visakhapatnam, Andhra Pradesh, 530016',
            'partners' => 'Mohammed Karimul Rafi, Designated Partner; Sajida Ruman Mohammad, Designated Partner',
            'gst_valid_from' => '21/03/2022',
            'gst_cert_issued' => '29/04/2023',
            'gst_type' => 'Regular',
            'center_jurisdiction' => 'MARRIPALEM',
            'state_jurisdiction' => 'DABA GARDENS',
            'gstin' => '37AAHFU2360G1Z5',
            'pan' => 'AAHFU2360G',
            'iec' => 'AAHFU2360G',
            'iec_issued' => '06/07/2025',
            'iec_office' => 'DGFT Visakhapatnam',
            'iec_file' => 'VSPIIECPAPPLY00002857AM26',
            'iec_signatory' => 'Mohammed Karimul Rafi',
            'lut' => '1',
            'lut_number' => 'AD3712250049171',
            'lut_arn' => 'AD3712250049171',
            'lut_filed' => '16/12/2025',
            'lut_time' => '20:33',
            'lut_filed_by' => 'MOHAMMED RAFI',
            'lut_fy_inferred' => '2025-26',
            'lut_fy_printed' => '',
            'udyam_number' => 'UDYAM-AP-10-0023080',
            'udyam_printed' => '15/04/2022',
            'phone' => '+91 86880 22686',
            'email' => 'info@unicybers.com',
            'web' => 'unicybers.com',
            'learn' => 'learn.unicybers.com',
            'signatory' => 'Mohammed Karimul Rafi',
            'designation' => 'Designated Partner',
            'gst_period' => 'quarterly',
            'tds_sections' => '',
            'digest_cron' => '1',
            'weekly_cron' => '1',
            'monthly_cron' => '1',
            'digest_email' => 'rafi@unicybers.com',
        ];
        foreach ($fill as $k => $v) {
            if (!isset($c[$k]) || $c[$k] === '' || $c[$k] === null) $c[$k] = $v;
        }
        if (($c['gst_period'] ?? '') === 'unconfirmed' || ($c['gst_period'] ?? '') === '') $c['gst_period'] = 'quarterly';
        if (($c['signatory'] ?? '') === 'Karimul Rafi Mohammed') $c['signatory'] = 'Mohammed Karimul Rafi';
        if (($c['legal_name'] ?? '') === 'UniCybers VTZ LLP') $c['legal_name'] = 'UNICYBERS VTZ LLP';
        if (empty($c['banks']) || !is_array($c['banks'])) $c['banks'] = $this->default_banks();
        $c['gstin'] = strtoupper((string) $c['gstin']);
        update_option('ub_company', $c, false);
    }

    private function bank_by($key) {
        $banks = $this->company()['banks'] ?? [];
        $firm = null;
        foreach ($banks as $b) {
            if (($b['holder'] ?? '') === 'firm' && !empty($b['default'])) $firm = $b;
            if ($key && ($b['key'] ?? '') === $key) return $b;
        }
        if (!$firm) {
            foreach ($banks as $b) {
                if (($b['holder'] ?? '') === 'firm') return $b;
            }
        }
        return $firm;
    }

    private function suggest_sac($text) {
        $t = strtolower((string) $text);
        if (preg_match('/host|hosting/', $t)) {
            return ['code'=>'998315','desc'=>'Hosting and information technology (IT) infrastructure provisioning services','rate'=>18,'why'=>'The line mentions hosting, so the suggestion is SAC 998315, Hosting and information technology (IT) infrastructure provisioning services.'];
        }
        if (preg_match('/licen[cs]e|software/', $t) && !preg_match('/train|coach|course/', $t)) {
            return ['code'=>'998316','desc'=>'Information technology infrastructure and network management services','rate'=>18,'why'=>'The line mentions software or a licence, so the suggestion is SAC 998316, Information technology infrastructure and network management services. Change it if this is only a software licence.'];
        }
        return ['code'=>'999293','desc'=>'Commercial training and coaching services','rate'=>18,'why'=>'Commercial cybersecurity training, coaching, or LMS training is suggested as SAC 999293, Commercial training and coaching services, at 18% unless you override it.'];
    }

    private function tds_sales($customer, $supply, $country, $amount, $text) {
        $abroad = $supply === 'export_lut' || (strcasecmp((string)$country, 'India') !== 0 && $country !== '');
        if ($abroad) {
            return ['mode'=>'not_required','section'=>'','rate'=>0,'note'=>'Not required. Assumption: the payer is outside India, so this invoice has no Indian TDS deduction.'];
        }
        if ($customer !== 'b2b') {
            return ['mode'=>'not_required','section'=>'','rate'=>0,'note'=>'Not required. Assumption: the payer is an individual, so they generally do not deduct TDS on this training fee unless they were tax-audited in the preceding year.'];
        }
        $technical = preg_match('/call centre|call center|technical service/', strtolower((string)$text));
        $rate = $technical ? 2 : 10;
        $kind = $technical ? 'technical services or a call centre, commonly 2%' : 'professional or technical fees, commonly 10%';
        if ((float)$amount < 50000) {
            return ['mode'=>'not_required','section'=>'194J','rate'=>$rate,'note'=>'TDS not required. Under the 194J limit of Rs 50,000 for this payee this year.'];
        }
        return ['mode'=>'expected','section'=>'194J','rate'=>$rate,'note'=>'Expected TDS receivable. Section 194J, '.$kind.'. The customer may deduct. Track it. Do not reduce the GST invoice total. TDS does not reduce the taxable value for GST.'];
    }

    private function tds_expense($title, $cat, $amount) {
        $title = (string) $title;
        $cat = (string) $cat;
        if (preg_match('/personal|private|reimburse me/', strtolower($title)) || $cat === 'personal') {
            return ['section'=>'','note'=>'Not required. This reads as a personal expense, so the LLP does not deduct TDS on it.'];
        }
        if (in_array($cat, ['professional','trainer'], true)) {
            if ((float)$amount < 50000) return ['section'=>'194J','note'=>'Not required on this bill. Assumption: it is under the section 194J threshold of ₹50,000 per payee for the year (from 1 April 2025). The LLP may have to deduct once the year total crosses that. This does not change the bill total.'];
            return ['section'=>'194J','note'=>'The LLP may have to deduct section 194J (commonly 10% for professional fees, 2% for technical services) when it pays this. This suggestion does not deduct money from the bill.'];
        }
        if ($cat === 'rent') {
            return ['section'=>'194I','note'=>'Rent paid by the LLP may fall under section 194I. Confirm the rate for the asset type. This suggestion does not deduct money from the bill.'];
        }
        return ['section'=>'','note'=>'Not required on the information here. No TDS section is suggested for this category.'];
    }

    private function assess($p) {
        $customer = (($p['customer_type'] ?? '') === 'individual') ? 'individual' : 'b2b';
        $supply = $p['supply'] ?? 'domestic';
        if (!in_array($supply, ['domestic','export_lut','no_gst'], true)) $supply = 'domestic';
        $country = trim((string)($p['country'] ?? 'India'));
        if ($country === '') $country = 'India';
        $state = trim((string)($p['state'] ?? ''));
        $place = trim((string)($p['place'] ?? ''));
        if ($customer === 'individual' && $place === '') $place = 'Andhra Pradesh';
        $gstin = strtoupper(trim((string)($p['gstin'] ?? '')));
        if ($customer === 'individual') $gstin = '';
        $text = trim((string)($p['component'] ?? '').' '.(string)($p['scope'] ?? ''));
        $sac = $this->suggest_sac($text);
        $typed = strtoupper(preg_replace('/[^0-9A-Za-z]/', '', (string)($p['sac'] ?? '')));
        if ($typed !== '') {
            $sac['code'] = $typed;
            $sac['why'] = 'SAC '.$typed.' is the code on this line. '.$sac['why'];
        }
        $rate = array_key_exists('tax_rate', $p) && $p['tax_rate'] !== '' ? (float)$p['tax_rate'] : (float)$sac['rate'];
        $reason = trim((string)($p['reason'] ?? ''));
        $india = strcasecmp($country, 'India') === 0;
        $code = substr($gstin, 0, 2);
        $pos = $customer === 'b2b' ? ($state !== '' ? $state : $place) : $place;
        if ($customer === 'b2b' && preg_match('/^[0-9]{2}$/', $code)) $same = $code === '37';
        else $same = ($pos === '' || stripos($pos, 'andhra') !== false || $pos === '37');
        $charge = ($supply === 'domestic' && $india);
        $exception = 0;
        $why = '';
        if ($supply === 'export_lut') {
            $why = 'Zero-rated export of services under LUT, not a domestic supply. GST is not charged.';
        } elseif ($supply === 'no_gst') {
            $why = $reason !== '' ? $reason : 'GST not applicable, with a reason still to type.';
            if ($india) $exception = 1;
        } elseif (!$india) {
            $charge = false;
            $exception = 1;
            $why = 'The customer country is outside India, but the treatment is still domestic. Pick export of services under LUT, or GST not applicable with a reason. GST is not shown until that choice is saved.';
        } elseif ($customer === 'individual') {
            $why = 'A registered supplier charges GST on taxable coaching even when the student is an individual. Place of supply is '.$pos.'.';
        } else {
            $why = $same ? 'Same state as this firm (Andhra Pradesh, code 37), so the tax splits into CGST and SGST.' : 'The customer is in another Indian state, so the tax is IGST.';
        }
        if ($exception && $customer === 'individual' && $india && $supply === 'no_gst') {
            $why .= ' Ordinary commercial coaching by this registered LLP is taxable, so no tax is not the default for an Indian individual. Stored as an exception to review.';
        }
        $amount = (float)($p['amount'] ?? 0);
        $mode = (($p['mode'] ?? 'incl') === 'excl') ? 'excl' : 'incl';
        $base = $amount;
        $tax = 0;
        if ($charge && $rate > 0) {
            if ($mode === 'incl') { $base = $amount / (1 + $rate / 100); $tax = $amount - $base; }
            else $tax = $amount * $rate / 100;
        }
        $cgst = $sgst = $igst = 0;
        if ($charge) {
            if ($same) { $cgst = $tax / 2; $sgst = $tax / 2; }
            else $igst = $tax;
        }
        $total = ($mode === 'incl' || !$charge) ? $amount : $base + $tax;
        $tds = $this->tds_sales($customer, ($supply === 'export_lut' || !$india) ? 'export_lut' : $supply, $country, $amount, $text);
        $split = !$charge ? 'No GST charged' : ($same ? 'CGST + SGST' : 'IGST');
        $next = $this->next_due_label();
        $assistant = $split.'. '.$why.' '.$sac['why'].' TDS: '.$tds['note'].' Next date: '.$next.'. This is a guide for the owner. It does not file and it does not replace a chartered accountant. The pack is ready for review.';
        return [
            'customer'=>$customer,'supply'=>$supply,'gstin'=>$gstin,'place'=>$pos,'same'=>$same,'charge'=>$charge,
            'base'=>$base,'cgst'=>$cgst,'sgst'=>$sgst,'igst'=>$igst,'total'=>$total,'rate'=>$rate,
            'sac'=>$sac,'tds'=>$tds,'why'=>$why,'exception'=>$exception,'assistant'=>$assistant,'reason'=>$reason,
        ];
    }

    private function rule_line() {
        return '';
    }

    private function filing_events() {
        $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Asia/Kolkata');
        $now = new DateTimeImmutable('now', $tz);
        $y = (int) $now->format('Y');
        $events = [];
        foreach ([$y - 1, $y, $y + 1] as $year) {
            foreach ([3, 6, 9, 12] as $endMonth) {
                $after = (new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $endMonth), $tz))->modify('first day of next month');
                $events[] = ['GSTR-1', $after->setDate((int)$after->format('Y'), (int)$after->format('n'), 13)];
                $events[] = ['GSTR-3B', $after->setDate((int)$after->format('Y'), (int)$after->format('n'), 22)];
            }
            foreach ([1, 2, 4, 5, 7, 8, 10, 11] as $m) {
                $events[] = ['PMT-06', new DateTimeImmutable(sprintf('%04d-%02d-25', $year, $m), $tz)];
            }
            foreach (['07-31','10-31','01-31','05-31'] as $md) {
                $events[] = ['TDS return', new DateTimeImmutable(sprintf('%04d-%s', $year, $md), $tz)];
            }
        }
        $c = $this->company();
        if (preg_match('/^(\d{4})-(\d{2})$/', (string)($c['lut_fy_inferred'] ?? ''), $m)) {
            $endYear = (int) $m[1] + 1;
            $events[] = ['LUT renewal', new DateTimeImmutable($endYear.'-03-31', $tz)];
        }
        usort($events, function ($a, $b) { return $a[1] <=> $b[1]; });
        return $events;
    }

    private function next_event($label = '') {
        $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Asia/Kolkata');
        $today = new DateTimeImmutable('today', $tz);
        foreach ($this->filing_events() as $ev) {
            if ($label && $ev[0] !== $label) continue;
            if ($ev[1] >= $today) return $ev;
        }
        return null;
    }

    private function maybe_schedule() {
        $c = $this->company();
        $this->schedule_hook('ub_filing_digest', !isset($c['digest_cron']) || (string)$c['digest_cron'] === '1', 'daily');
        $weekly = wp_get_schedule('ub_weekly_report');
        if ($weekly && $weekly !== 'daily') wp_unschedule_event(wp_next_scheduled('ub_weekly_report'), 'ub_weekly_report');
        $this->schedule_hook('ub_weekly_report', !isset($c['weekly_cron']) || (string)$c['weekly_cron'] === '1', 'daily');
        $this->schedule_hook('ub_monthly_report', !isset($c['monthly_cron']) || (string)$c['monthly_cron'] === '1', 'daily');
        $this->schedule_hook('ub_recurring_tick', true, 'daily');
    }

    private function schedule_hook($hook, $on, $recurrence) {
        $stamp = wp_next_scheduled($hook);
        if ($on && !$stamp) wp_schedule_event(time() + HOUR_IN_SECONDS, $recurrence, $hook);
        if (!$on && $stamp) wp_unschedule_event($stamp, $hook);
    }

    public function filing_digest() {
        $c = $this->company();
        if (isset($c['digest_cron']) && (string)$c['digest_cron'] !== '1') return;
        $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Asia/Kolkata');
        $today = new DateTimeImmutable('today', $tz);
        $near = false;
        foreach ($this->filing_events() as $ev) {
            $days = (int) $today->diff($ev[1])->format('%r%a');
            if ($days >= 0 && $days <= 7 && in_array($ev[0], ['GSTR-1','GSTR-3B','PMT-06','LUT renewal'], true)) $near = true;
        }
        if (!$near) return;
        if (get_option('ub_digest_last') === $today->format('Y-m-d')) return;
        $to = $c['digest_email'] ?? 'rafi@unicybers.com';
        if ($to !== 'rafi@unicybers.com') $to = 'rafi@unicybers.com';
        wp_mail($to, 'UniCybers Books - filing dates', $this->reminder_text(), ['From: UniCybers Books <info@unicybers.com>']);
        update_option('ub_digest_last', $today->format('Y-m-d'), false);
    }

    public function access() {
        if (!is_user_logged_in()) return '';
        $u = wp_get_current_user();
        $meta = (string) get_user_meta($u->ID, 'ub_role', true);
        if (in_array($meta, ['owner','accountant','coordinator','trainer'], true)) return $meta;
        if (user_can($u, 'manage_options')) return 'owner';
        if (in_array('uc_coordinator', (array)$u->roles, true)) return 'coordinator';
        if (in_array('uc_trainer', (array)$u->roles, true)) return 'trainer';
        if (in_array('ub_accountant', (array)$u->roles, true)) return 'accountant';
        return '';
    }

    public function caps() {
        $a = $this->access();
        $all = ['sales'=>1,'finance'=>1,'expenses'=>1,'bank'=>1,'trainer_pay'=>1,'tax'=>1,'reports'=>1,'people'=>1,'settings'=>1];
        if ($a === 'owner') return $all;
        if ($a === 'accountant') {
            $saved = get_user_meta(get_current_user_id(), 'ub_caps', true);
            if (!is_array($saved) || !$saved) return ['sales'=>1,'finance'=>1,'expenses'=>1,'bank'=>1,'reports'=>1];
            return $saved;
        }
        if ($a === 'coordinator') return ['sales'=>1];
        return [];
    }

    public function cap($key) {
        $caps = $this->caps();
        return !empty($caps[$key]);
    }

    public function can($need) {
        $a = $this->access();
        if ($need === 'sales') return $a === 'owner' || $a === 'coordinator' || $this->cap('sales');
        if ($need === 'money') return $this->cap('finance');
        if ($need === 'owner') return $a === 'owner';
        if (in_array($need, ['expenses','trainer_pay','tax','people','settings','bank'], true)) return $this->cap($need);
        return false;
    }

    private function role_label($role) {
        $map = ['owner'=>'Super Admin','accountant'=>'Admin','coordinator'=>'Coordinator','trainer'=>'Trainer'];
        return $map[$role] ?? ucfirst((string)$role);
    }

    private function mail_from() {
        return 'UniCybers Books <rafi@unicybers.com>';
    }

    public function body_class($classes) {
        if ($this->is_books_request()) $classes[] = 'ub-books';
        return $classes;
    }

    private function is_books_request() {
        if (is_admin() || wp_doing_ajax()) return false;
        $path = (string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        // CRM 2.1.x embeds Books at /finance/?uc_embed=1. The application
        // previously intercepted only /books/, so WordPress rendered its 404.
        if ($path && preg_match('#/(?:books|finance)/?$#i', $path)) return true;
        if (function_exists('is_page') && (is_page('books') || is_page('finance'))) return true;
        $page_id = (int) get_option('ub_books_page');
        if ($page_id && function_exists('is_page') && is_page($page_id)) return true;
        if (!function_exists('is_singular') || !is_singular()) return false;
        $post = get_queried_object();
        if (!($post instanceof WP_Post)) return false;
        if (has_shortcode((string) $post->post_content, 'unicybers_books')) return true;
        $elementor = get_post_meta($post->ID, '_elementor_data', true);
        return is_string($elementor) && strpos($elementor, 'unicybers_books') !== false;
    }

    public function prevent_finance_canonical_redirect($redirect, $requested) {
        if (is_admin()) return $redirect;
        $path = (string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        if ($path && preg_match('#/finance/?$#i', untrailingslashit($path).'/')) return false;
        return $redirect;
    }

    public function template_include($template) {
        if (!$this->is_books_request()) return $template;
        if (!empty($_GET['elementor-preview']) || (isset($_GET['action']) && $_GET['action'] === 'elementor')) return $template;
        $file = plugin_dir_path(__FILE__).'templates/standalone.php';
        return file_exists($file) ? $file : $template;
    }

    public function render_front() {
        if (!is_user_logged_in()) return $this->login_screen();
        $html = $this->shortcode();
        return $html !== '' ? $html : $this->login_screen();
    }

    public function shortcode() {
        if (!is_user_logged_in()) return $this->login_screen();
        if (!$this->access()) return '<div class="ub"><div class="ub-content"><div class="ub-card"><h1>Books is for the academy team</h1><p>Ask an owner to give you a Books role. Students stay in the LMS.</p></div></div></div>';
        $page = sanitize_key($_GET['ub'] ?? '');
        if ($page === '' ) $page = $this->access() === 'trainer' ? 'my' : 'home';
        if (get_user_meta(get_current_user_id(), 'ub_must_change', true)) $page = 'account';
        return $this->shell($page);
    }

    public function assets() {
        $css = plugins_url('books.css', __FILE__);
        $js = plugins_url('books.js', __FILE__);
        $v = self::VERSION;
        return '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet">'
            .'<link rel="stylesheet" href="'.esc_url($css.'?v='.$v).'">'
            .'<script src="'.esc_url($js.'?v='.$v).'" defer></script>';
    }

    public function url($args = []) {
        $path = (string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        $on_finance_alias = $path && preg_match('#/finance/?$#i', untrailingslashit($path).'/');
        if ($on_finance_alias) {
            $base = home_url('/finance/');
            $args = array_merge(['uc_embed' => '1'], (array) $args);
        } else {
            $base = get_permalink((int) get_option('ub_books_page')) ?: home_url('/books/');
        }
        return add_query_arg($args, $base);
    }

    private function login_screen() {
        $err = sanitize_key($_GET['ub_err'] ?? '');
        $msg = $err === 'invalid' ? 'That email or password did not match.' : '';
        $html = '<div class="login-wrap"><form class="login-card" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<img class="ub-logo" src="'.esc_url(plugins_url('assets/logo.png', __FILE__)).'" alt="UniCybers">';
        $html .= '<p class="login-kicker">UNICYBERS</p>';
        $html .= '<h1>Sign in</h1><p class="login-lead">Use your academy email and password.</p>';
        if ($msg) $html .= '<p class="note">'.esc_html($msg).'</p>';
        $html .= '<input type="hidden" name="action" value="ub_login">';
        $html .= wp_nonce_field('ub_login','_wpnonce', true, false);
        $html .= '<label style="display:block;font-weight:700;margin:10px 0">Email<input name="log" type="email" required style="display:block;width:100%;margin-top:6px;height:44px;border-radius:12px;border:1px solid #CBD7E7;padding:0 12px"></label>';
        $html .= '<label style="display:block;font-weight:700;margin:10px 0">Password<input name="pwd" type="password" required style="display:block;width:100%;margin-top:6px;height:44px;border-radius:12px;border:1px solid #CBD7E7;padding:0 12px"></label>';
        $html .= '<button class="btn primary" style="width:100%;margin-top:8px" type="submit">Continue</button></form></div>';
        return $html;
    }

    public function login() {
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'ub_login')) wp_die('Form expired.');
        $login = sanitize_text_field(wp_unslash($_POST['log'] ?? ''));
        if (is_email($login)) {
            $found = get_user_by('email', $login);
            if ($found) $login = $found->user_login;
        }
        $user = wp_signon([
            'user_login' => $login,
            'user_password' => (string) wp_unslash($_POST['pwd'] ?? ''),
            'remember' => true,
        ], is_ssl());
        $back = $this->url();
        if (is_wp_error($user)) {
            wp_safe_redirect(add_query_arg('ub_err','invalid', $back));
            exit;
        }
        wp_safe_redirect($back);
        exit;
    }

    public function logout() {
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'ub_logout')) wp_die('Form expired.');
        wp_logout();
        wp_safe_redirect($this->url());
        exit;
    }

    public function guard($action, $level) {
        if (!$this->can($level) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), $action)) wp_die('Not allowed.', 403);
    }

    private function icon($name) {
        $paths = [
            'home'=>'<path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z"/>',
            'invoices'=>'<path d="M7 3h7l5 5v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
            'finance'=>'<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M7 15h4"/>',
            'reconcile'=>'<path d="M4 7h16M4 12h10M4 17h16"/><path d="M16 10l4 2-4 2"/>',
            'expenses'=>'<path d="M4 7h16v12H4z"/><path d="M4 11h16M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
            'trainers'=>'<path d="M16 19v-1a3 3 0 0 0-3-3H7a3 3 0 0 0-3 3v1"/><circle cx="10" cy="8" r="3"/><path d="M20 19v-1a3 3 0 0 0-2.2-2.9M16 5.1a3 3 0 0 1 0 5.8"/>',
            'tax'=>'<path d="M12 3v18M7 8h7.5a2.5 2.5 0 0 1 0 5H9.5a2.5 2.5 0 0 0 0 5H17"/>',
            'people'=>'<path d="M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1"/><circle cx="9.5" cy="7" r="3"/>',
            'reports'=>'<path d="M4 19V5M4 19h16"/><path d="M8 16v-5M12 16V8M16 16v-3"/>',
            'settings'=>'<circle cx="12" cy="12" r="3"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"/>',
            'guide'=>'<path d="M6 4h11a1 1 0 0 1 1 1v15l-6-3-6 3V5a1 1 0 0 1 1-1z"/>',
            'share'=>'<path d="M8 12h8M12 8l4 4-4 4"/><circle cx="6" cy="12" r="2"/>',
            'sun'=>'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
            'moon'=>'<path d="M20 14.5A8 8 0 1 1 9.5 4 6.5 6.5 0 0 0 20 14.5z"/>',
            'key'=>'<circle cx="8" cy="15" r="4"/><path d="M11.5 12.5 20 4l-2 0 0 3-2 0 0 2-2 0"/>',
            'out'=>'<path d="M10 7V4H4v16h6v-3M10 12h10M16 8l4 4-4 4"/>',
        ];
        $d = $paths[$name] ?? $paths['home'];
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$d.'</svg>';
    }

    private function shell($page) {
        $a = $this->access();
        $must = (bool) get_user_meta(get_current_user_id(), 'ub_must_change', true);
        if ($a === 'trainer') {
            $items = ['my'=>'My Pay'];
        } else {
            $items = [];
            if ($a !== 'coordinator') $items['home'] = 'Home';
            else $items['home'] = 'Home';
            if ($this->can('sales')) $items['invoices'] = 'Sales';
            if ($this->cap('finance') || $this->cap('expenses') || $this->cap('bank') || $this->cap('tax') || $this->cap('trainer_pay')) $items['finance'] = 'Finance';
            if ($this->cap('people')) $items['people'] = 'People';
            if ($this->cap('reports')) $items['reports'] = 'Reports';
            if ($this->cap('settings')) $items['settings'] = 'Settings';
        }
        $tones = ['home'=>'i-home','invoices'=>'i-invoices','finance'=>'i-finance','reconcile'=>'i-reconcile','expenses'=>'i-expenses','trainers'=>'i-trainers','tax'=>'i-tax','people'=>'i-people','reports'=>'i-reports','settings'=>'i-settings','guide'=>'i-guide','my'=>'i-share'];
        $labels = ['home'=>'Today','invoices'=>'Sales','finance'=>'Finance','reconcile'=>'Bank','doc'=>'Document','subs'=>'Subscriptions','expenses'=>'Expenses','tax'=>'Tax Desk','people'=>'People','settings'=>'Settings','vat'=>'VAT Profiles','migrate'=>'Copy From LMS','reports'=>'Reports','trainers'=>'Trainer Pay','my'=>'My Pay','account'=>'Account'];
        $me = wp_get_current_user();
        $name = $this->nice_name($me->display_name ?: $me->user_email);
        $initials = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $name) ?: 'U', 0, 2));
        $role_label = $this->role_label($a);
        $logo = plugins_url('assets/logo.png', __FILE__);
        // CRM embeds Books inside its existing application shell at /finance/?uc_embed=1.
        // In that context, the CRM sidebar is the only persistent vertical navigation.
        $embedded = isset($_GET['uc_embed']) && (string) wp_unslash($_GET['uc_embed']) === '1';
        $html = '<div class="ub app'.($embedded ? ' ub-embedded' : '').'">';
        if (!$embedded) {
            $html .= '<aside class="ub-rail" id="rail"><a class="ub-brand" href="'.esc_url($this->url(['ub'=>'home'])).'"><span class="brand-mark"><img src="'.esc_url($logo).'" alt=""></span><span class="brand-copy"><strong>UNICYBERS</strong><em>BOOKS</em></span></a><nav class="ub-nav navlist">';
        }
        if (!$must && !$embedded) {
            foreach ($items as $k=>$label) {
                $on = ($page === $k) || ($k === 'finance' && in_array($page, ['expenses','tax','reconcile','trainers'], true)) || ($k === 'invoices' && in_array($page, ['doc','subs'], true));
                $html .= '<a class="nav '.$tones[$k].($on?' on':'').'" href="'.esc_url($this->url(['ub'=>$k])).'"><span class="ico">'.$this->icon($k==='my'?'share':$k).'</span><span>'.esc_html($label).'</span></a>';
            }
        }
        if (!$embedded) {
        $html .= '</nav><div class="rail-me"><button class="rail-me-btn" id="meBtn" type="button" aria-haspopup="menu" aria-expanded="false">';
        $html .= '<span class="avatar">'.esc_html($initials).'</span><span class="me-copy"><strong>'.esc_html($name).'</strong><small>'.esc_html($role_label).'</small></span></button>';
        $html .= '<div class="menu" id="meMenu" hidden>';
        $html .= '<div class="menu-head"><strong>'.esc_html($name).'</strong><small>'.esc_html($me->user_email).'</small></div>';
        $html .= '<a href="'.esc_url($this->url(['ub'=>'account'])).'">'.$this->icon('key').'Change password</a>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('ub_logout','_wpnonce', true, false);
        $html .= '<input type="hidden" name="action" value="ub_logout"><button class="menu-out" type="submit">'.$this->icon('out').'Log out</button></form>';
        $html .= '</div></div></aside>';
        }
        $sub = $this->page_lead($page, $a);
        $html .= '<div class="ub-main"><header class="ub-top"><div class="ub-grow pagehead"><h1>'.esc_html($labels[$page] ?? 'Books').'</h1>'.($sub !== '' ? '<p>'.esc_html($sub).'</p>' : '').'</div><div class="tools">';
        if (in_array($page, ['doc','account'], true) || ($page === 'people' && isset($_GET['edit']))) {
            $back_url = $page === 'people' ? $this->url(['ub'=>'people']) : ($page === 'account' ? $this->url(['ub'=>'home']) : $this->url(['ub'=>'invoices']));
            $back_label = $page === 'people' ? 'Back to People' : ($page === 'account' ? 'Back' : 'Back to Sales');
            $html .= '<a class="ub-top-back" href="'.esc_url($back_url).'">← '.esc_html($back_label).'</a>';
        }
        $html .= '<button class="iconbtn" id="themeToggle" type="button" aria-label="Switch light or dark"><span class="t-sun">'.$this->icon('sun').'</span><span class="t-moon">'.$this->icon('moon').'</span></button>';
        $html .= '</div></header>';
        if ($embedded && !$must) {
            $html .= '<nav class="ub-workspace-nav" aria-label="Books navigation">';
            foreach ($items as $k=>$label) {
                $on = ($page === $k) || ($k === 'finance' && in_array($page, ['expenses','tax','reconcile','trainers'], true)) || ($k === 'invoices' && in_array($page, ['doc','subs'], true));
                $html .= '<a class="'.($on?'on':'').'" href="'.esc_url($this->url(['ub'=>$k])).'">'.esc_html($label).'</a>';
            }
            $back_url = '';
            $back_label = '';
            if (in_array($page, ['doc','subs'], true)) { $back_url = $this->url(['ub'=>'invoices']); $back_label = 'Back to Sales'; }
            elseif ($page === 'people' && isset($_GET['edit'])) { $back_url = $this->url(['ub'=>'people']); $back_label = 'Back to People'; }
            elseif (in_array($page, ['vat','migrate'], true)) { $back_url = $this->url(['ub'=>'settings']); $back_label = 'Back to Settings'; }
            elseif ($page === 'account') { $back_url = $this->url(['ub'=>'home']); $back_label = 'Back'; }
            // Keep one Books-wide search, grouped immediately beside the contextual Back action.
            $html .= '<div class="ub-nav-tools"><label class="ub-books-global-search" aria-label="Search Books records"><span aria-hidden="true">⌕</span><input id="ubBooksGlobalSearch" type="search" placeholder="Search Books records..." autocomplete="off"><button type="button" id="ubBooksSearchClear" aria-label="Clear Books search" hidden>×</button></label>';
            if ($back_url !== '') $html .= '<a class="ub-workspace-back" href="'.esc_url($back_url).'">← '.esc_html($back_label).'</a>';
            $html .= '</div></nav>';
        }
        $html .= '<div class="ub-content"><div class="stage">';
        $html .= $this->view($page, $a).'</div></div></div>';
        if (!$embedded) {
        $tabs = $a === 'trainer' ? ['my'=>'My Pay'] : ['home'=>'Home','invoices'=>'Sales'];
        if ($this->cap('finance') || $this->cap('expenses')) $tabs['finance'] = 'Finance';
        $html .= '<nav class="ub-tabbar">';
        if (!$must) {
            foreach ($tabs as $k=>$label) $html .= '<a class="'.($page===$k?'on':'').'" href="'.esc_url($this->url(['ub'=>$k])).'">'.esc_html($label).'</a>';
        }
        $html .= '</nav></div>';
        } else {
            $html .= '</div>'; // close embedded application wrapper
        }
        return $html;
    }

    private function page_lead($page, $a) {
        if ($page === 'home') return '';
        return '';
    }

    private function create_menu($a) {
        $html = '<details class="ub-create"><summary>Create</summary><div class="ub-menu">';
        foreach (['invoice'=>'Tax invoice','quote'=>'Quote','proforma'=>'Proforma'] as $t=>$l) {
            $html .= '<a href="'.esc_url($this->url(['ub'=>'doc','type'=>$t])).'">'.esc_html($l).'</a>';
        }
        if ($a === 'owner') {
            $html .= '<a href="'.esc_url($this->url(['ub'=>'doc','type'=>'purchase_order'])).'">Purchase order</a>';
            $html .= '<a href="'.esc_url($this->url(['ub'=>'expenses','edit'=>'new'])).'">Expense</a>';
        }
        $html .= '</div></details>';
        return $html;
    }

    private function view($page, $a) {
        if ($page === 'invoices') return $this->can('sales') ? $this->view_docs() : $this->deny();
        if ($page === 'finance' || in_array($page, ['expenses','tax','reconcile','trainers'], true)) return $this->finance_screen($page);
        if ($page === 'doc') return $this->can('sales') ? $this->view_doc() : $this->deny();
        if ($page === 'subs') return $this->can('sales') ? $this->subs_panel() : $this->deny();
        if ($page === 'people') return $this->cap('people') ? $this->view_people() : $this->deny();
        if ($page === 'my') return $a === 'trainer' ? $this->view_my_share() : $this->deny();
        if ($page === 'settings') return $this->cap('settings') ? $this->view_settings() : $this->deny();
        if ($page === 'vat') return $this->cap('settings') ? $this->view_vat() : $this->deny();
        if ($page === 'migrate') return $this->cap('settings') ? $this->view_migrate() : $this->deny();
        if ($page === 'reports') return $this->cap('reports') ? $this->view_reports() : $this->deny();
        if ($page === 'guide') return $this->view_home($a);
        if ($page === 'account') return $this->view_account();
        if ($a === 'trainer') return $this->view_my_share();
        return $this->view_home($a);
    }

    private function finance_screen($page) {
        $tab = sanitize_key($_GET['tab'] ?? '');
        if ($page === 'expenses') $tab = 'expenses';
        if ($page === 'tax') $tab = 'tax';
        if ($page === 'reconcile') $tab = 'bank';
        if ($page === 'trainers') $tab = 'trainers';
        if ($tab === '') $tab = 'payments';
        $allowed = $tab === 'payments' && $this->cap('finance');
        if ($tab === 'expenses' && $this->cap('expenses')) $allowed = true;
        if ($tab === 'bank' && $this->cap('bank')) $allowed = true;
        if ($tab === 'tax' && $this->cap('tax')) $allowed = true;
        if ($tab === 'trainers' && $this->cap('trainer_pay')) $allowed = true;
        if (in_array($tab, ['loans','reminders'], true) && $this->cap('finance')) $allowed = true;
        if (!$allowed && !$this->cap('finance')) return $this->deny();
        if (!$allowed) $tab = 'payments';
        $html = $this->finance_tabs($tab);
        if ($tab === 'expenses') return $html.$this->view_expenses();
        if ($tab === 'bank') return $html.UC_Books_Reconcile::page($this);
        if ($tab === 'tax') return $html.$this->view_tax();
        if ($tab === 'trainers') return $html.$this->view_trainers();
        if ($tab === 'loans') return $html.$this->view_loans();
        if ($tab === 'reminders') return $html.$this->view_finance_reminders();
        return $html.$this->view_finance();
    }

    private function finance_tabs($on) {
        $tabs = [];
        if ($this->cap('finance')) $tabs['payments'] = 'Payments';
        if ($this->cap('expenses')) $tabs['expenses'] = 'Expenses';
        if ($this->cap('trainer_pay')) $tabs['trainers'] = 'Trainer Pay';
        if ($this->cap('finance')) { $tabs['loans'] = 'Loans'; $tabs['reminders'] = 'Reminders'; }
        if ($this->cap('bank')) $tabs['bank'] = 'Banking';
        if ($this->cap('tax')) $tabs['tax'] = 'Tax Desk';
        $html = '<div class="pipe" style="margin-bottom:14px">';
        foreach ($tabs as $k=>$l) {
            $html .= '<a class="'.($on===$k?'on':'').'" href="'.esc_url($this->url(['ub'=>'finance','tab'=>$k])).'">'.esc_html($l).'</a>';
        }
        return $html.'</div>';
    }

    public function deny() {
        return '<div class="ub-card"><strong>This section is closed for this role.</strong><p>A coordinator sees students and their documents. Trainer pay, expenses, and tax stay with Super Admin.</p></div>';
    }

    private function money($n) { return number_format((float)$n, 2); }

    private function pill($status) {
        $map = ['draft'=>'Draft','sent'=>'Sent','part_paid'=>'Part-paid','paid'=>'Paid','overdue'=>'Overdue','export_lut'=>'Export LUT'];
        $key = isset($map[$status]) ? $status : 'draft';
        return '<span class="pill '.$key.'">'.esc_html($map[$key]).'</span>';
    }

    private function docs($where = '') {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$this->t('docs')} $where ORDER BY id DESC LIMIT 200") ?: [];
    }

    private function derived_status($d) {
        if ($d->supply === 'export_lut' && $d->status !== 'draft') {
            /* status word stays payment state; badge added separately */
        }
        $due = $d->due_date && $d->due_date < current_time('Y-m-d') && (float)$d->paid + 0.001 < (float)$d->total && $d->status !== 'draft';
        if ($due) return 'overdue';
        if ((float)$d->paid <= 0) return $d->status ?: 'draft';
        if ((float)$d->paid + 0.001 < (float)$d->total) return 'part_paid';
        return 'paid';
    }

    private function view_home($a) {
        global $wpdb;
        $docs = $this->docs();
        $today = current_time('Y-m-d');
        $month_start = current_time('Y-m-01');
        $currencies = [];
        $receivable = []; $received = []; $income = []; $expenses = [];
        $overdue_count = 0; $due_soon_count = 0; $invoice_count = 0;
        foreach ($docs as $d) {
            $cur = strtoupper($d->currency ?: 'INR');
            if (!isset($currencies[$cur])) $currencies[$cur] = ['receivable'=>0,'received'=>0,'income'=>0,'expenses'=>0];
            if ($d->doc_type !== 'invoice') continue;
            $invoice_count++;
            $status = $this->derived_status($d);
            $balance = max(0, (float)$d->total - (float)$d->paid);
            if (in_array($status, ['sent','part_paid','overdue'], true)) $currencies[$cur]['receivable'] += $balance;
            $currencies[$cur]['received'] += (float)$d->paid;
            if ($d->doc_date >= $month_start && $d->doc_date <= $today) $currencies[$cur]['income'] += (float)$d->total;
            if ($status === 'overdue') $overdue_count++;
            if ($d->due_date && $d->due_date >= $today && $d->due_date <= date('Y-m-d', strtotime($today.' +7 days')) && $balance > 0) $due_soon_count++;
        }
        $expense_rows = $wpdb->get_results($wpdb->prepare("SELECT currency, SUM(amount) total FROM {$this->t('expenses')} WHERE spent_on >= %s AND spent_on <= %s GROUP BY currency", $month_start, $today)) ?: [];
        foreach ($expense_rows as $r) {
            $cur = strtoupper($r->currency ?: 'INR');
            if (!isset($currencies[$cur])) $currencies[$cur] = ['receivable'=>0,'received'=>0,'income'=>0,'expenses'=>0];
            $currencies[$cur]['expenses'] = (float)$r->total;
        }
        $total_open_docs = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->t('docs')} WHERE doc_type IN ('invoice','quote','proforma') AND status NOT IN ('paid','cancelled')");
        $sub_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->t('subs')} WHERE active=1");
        $trainer_owed = [];
        if ($this->cap('trainer_pay')) foreach ($this->trainer_balances() as $b) {
            $cur = strtoupper($b['cur'] ?: 'INR');
            $trainer_owed[$cur] = ($trainer_owed[$cur] ?? 0) + (float)$b['owed'];
        }
        $loan_totals = $wpdb->get_results("SELECT loan_type, currency, SUM(outstanding) total, COUNT(*) qty FROM {$this->t('loans')} WHERE status='approved' GROUP BY loan_type,currency") ?: [];
        $loan_in = []; $loan_out = [];
        foreach ($loan_totals as $l) {
            $cur = strtoupper($l->currency ?: 'INR');
            if ($l->loan_type === 'in') $loan_in[$cur] = (float)$l->total;
            else $loan_out[$cur] = (float)$l->total;
        }
        $bank_balances = [];
        $stmt_table = $wpdb->prefix.'ub_bank_stmt';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $stmt_table)) === $stmt_table) {
            $latest = $wpdb->get_results("SELECT s.currency,s.bank_key,s.closing FROM {$stmt_table} s INNER JOIN (SELECT bank_key,MAX(id) id FROM {$stmt_table} GROUP BY bank_key) x ON x.id=s.id WHERE s.closing IS NOT NULL") ?: [];
            foreach ($latest as $b) { $cur = strtoupper($b->currency ?: 'INR'); $bank_balances[$cur] = ($bank_balances[$cur] ?? 0) + (float)$b->closing; }
        }
        $reminders = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->t('reminders')} WHERE done=0 AND (next_due_on IS NULL OR next_due_on <= %s) ORDER BY COALESCE(next_due_on,due_on) ASC LIMIT 5", date('Y-m-d', strtotime($today.' +30 days')))) ?: [];
        $recent_docs = $wpdb->get_results("SELECT id,doc_type,number,contact_name,total,currency,doc_date,status FROM {$this->t('docs')} ORDER BY id DESC LIMIT 5") ?: [];
        $recent_expenses = $wpdb->get_results("SELECT id,title,vendor,amount,currency,spent_on FROM {$this->t('expenses')} ORDER BY id DESC LIMIT 5") ?: [];
        $months = [];
        for ($i=5; $i>=0; $i--) { $key = date('Y-m', strtotime($today.' -'.$i.' months')); $months[$key] = ['label'=>date('M', strtotime($key.'-01')), 'income'=>0, 'expense'=>0]; }
        $from = array_key_first($months).'-01';
        $paid_rows = $wpdb->get_results($wpdb->prepare("SELECT DATE_FORMAT(paid_on,'%%Y-%%m') ym,currency,SUM(amount) total FROM {$this->t('pays')} WHERE paid_on >= %s AND paid_on <= %s GROUP BY ym,currency", $from, $today)) ?: [];
        foreach ($paid_rows as $r) { if (isset($months[$r->ym])) $months[$r->ym]['income'] += (float)$r->total; }
        $exp_months = $wpdb->get_results($wpdb->prepare("SELECT DATE_FORMAT(spent_on,'%%Y-%%m') ym,currency,SUM(amount) total FROM {$this->t('expenses')} WHERE spent_on >= %s AND spent_on <= %s GROUP BY ym,currency", $from, $today)) ?: [];
        foreach ($exp_months as $r) { if (isset($months[$r->ym])) $months[$r->ym]['expense'] += (float)$r->total; }
        $html = '<div class="ub-dash">';
        $html .= '<div class="ub-dash-head" aria-hidden="true"></div>';
        $html .= '<div class="ub-dash-kpis">';
        $html .= $this->dash_kpi('Receivables', $this->dash_currency_values($currencies,'receivable'), $overdue_count.' overdue · '.$due_soon_count.' due within 7 days', 'invoices', '#FF7272', $this->url(['ub'=>'invoices','pipe'=>'awaiting']));
        $html .= $this->dash_kpi('Payments received', $this->dash_currency_values($currencies,'received'), 'Total recorded against invoices', 'finance', '#36D99A', $this->url(['ub'=>'finance']));
        $html .= $this->dash_kpi('Cash and bank', $this->dash_values($bank_balances), $bank_balances ? 'Latest imported statement balances' : 'No closing balances imported', 'reconcile', '#61AFFF', $this->url(['ub'=>'finance','tab'=>'bank']));
        $html .= $this->dash_kpi('Payables', $this->dash_values($trainer_owed), 'Outstanding trainer payments', 'trainers', '#A78BFA', $this->url(['ub'=>'finance','tab'=>'trainers']));
        $html .= '</div>';
        $html .= '<div class="ub-dash-grid">';
        $html .= '<section class="ub-dash-panel ub-dash-trend"><div class="ub-dash-panel-head"><div><h3>Income and expenses</h3><p>Monthly totals across recorded currencies</p></div><span class="ub-dash-tag">6 MONTHS</span></div>';
        $max = 1; foreach ($months as $m) $max = max($max,$m['income'],$m['expense']);
        $html .= '<div class="ub-chart">'; foreach ($months as $m) { $ih=max(3,round($m['income']/$max*100)); $eh=max(3,round($m['expense']/$max*100)); $html .= '<div class="ub-chart-col"><div class="ub-chart-bars"><i class="income" style="height:'.$ih.'%" title="Income '.$this->money($m['income']).'"></i><i class="expense" style="height:'.$eh.'%" title="Expenses '.$this->money($m['expense']).'"></i></div><small>'.esc_html($m['label']).'</small></div>'; } $html .= '</div><div class="ub-chart-legend"><span><i class="income"></i> Income</span><span><i class="expense"></i> Expenses</span></div><p class="ub-dash-footnote">Values are shown as combined nominal totals. Different currencies are not converted.</p></section>';
        $html .= '<section class="ub-dash-panel"><div class="ub-dash-panel-head"><div><h3>Loans position</h3><p>Approved loan balances</p></div><a href="'.esc_url($this->url(['ub'=>'finance','tab'=>'loans'])).'">View loans</a></div>';
        $html .= $this->dash_metric_rows('Loan receivable', $loan_in).$this->dash_metric_rows('Loan payable', $loan_out);
        if (!$loan_in && !$loan_out) $html .= '<div class="ub-dash-empty">No approved loans recorded.</div>';
        $html .= '<div class="ub-dash-submetric"><span>Active subscriptions</span><strong>'.(int)$sub_count.'</strong></div></section>';
        $html .= '<section class="ub-dash-panel"><div class="ub-dash-panel-head"><div><h3>Upcoming reminders</h3><p>Open items due in the next 30 days</p></div><a href="'.esc_url($this->url(['ub'=>'finance','tab'=>'reminders'])).'">View all</a></div>';
        if ($reminders) { foreach ($reminders as $r) { $date = $r->next_due_on ?: $r->due_on; $html .= '<div class="ub-dash-list-row"><span class="ub-dash-dot"></span><div><strong>'.esc_html($r->title).'</strong><small>'.esc_html($r->kind).' · '.esc_html($r->contact_name ?: 'General').'</small></div><time>'.esc_html($date ? mysql2date('j M', $date) : 'Date unset').'</time></div>'; } }
        else $html .= '<div class="ub-dash-empty">No upcoming reminders recorded.</div>';
        $html .= '</section>';
        $html .= '<section class="ub-dash-panel"><div class="ub-dash-panel-head"><div><h3>Tax desk</h3><p>Next statutory filing dates</p></div><a href="'.esc_url($this->url(['ub'=>'finance','tab'=>'tax'])).'">Open tax desk</a></div><div class="ub-dash-tax"><span class="ub-tax-icon">₹</span><div><strong>'.esc_html($this->next_due_bits()['lead']).'</strong><small>'.esc_html($this->next_due_bits()['rest']).'</small></div></div><p class="ub-dash-footnote">Filing dates are reminders for review. Returns are not filed by this plugin.</p></section>';
        $html .= '<section class="ub-dash-panel ub-dash-recent"><div class="ub-dash-panel-head"><div><h3>Recent financial activity</h3><p>Latest invoices and expenses</p></div><a href="'.esc_url($this->url(['ub'=>'reports'])).'">Reports</a></div><div class="table-wrap"><table class="ub-table"><thead><tr><th>Activity</th><th>Contact / vendor</th><th>Date</th><th>Amount</th></tr></thead><tbody>';
        $activity=[]; foreach ($recent_docs as $r) $activity[]=['id'=>$r->id,'type'=>ucwords(str_replace('_',' ',$r->doc_type)),'name'=>$r->contact_name,'date'=>$r->doc_date,'amount'=>$r->total,'currency'=>$r->currency,'url'=>$this->url(['ub'=>'doc','id'=>$r->id])];
        foreach ($recent_expenses as $r) $activity[]=['id'=>$r->id,'type'=>'Expense','name'=>$r->vendor ?: $r->title,'date'=>$r->spent_on,'amount'=>$r->amount,'currency'=>$r->currency,'url'=>$this->url(['ub'=>'expenses'])];
        usort($activity, function($x,$y){ return strcmp((string)$y['date'],(string)$x['date']); }); $activity=array_slice($activity,0,7);
        if (!$activity) $html .= '<tr><td colspan="4"><div class="ub-dash-empty">No financial activity recorded yet.</div></td></tr>';
        foreach ($activity as $r) $html .= '<tr><td><a href="'.esc_url($r['url']).'">'.esc_html($r['type']).'</a></td><td>'.esc_html($r['name'] ?: '—').'</td><td>'.esc_html($r['date'] ? mysql2date('j M Y',$r['date']) : '—').'</td><td><strong>'.esc_html($r['currency'].' '.$this->money($r['amount'])).'</strong></td></tr>';
        $html .= '</tbody></table></div></section></div></div>';
        return $html;
    }

    private function dash_values($values) {
        if (!$values) return '<span class="ub-dash-zero">Not recorded</span>';
        $parts=[]; foreach ($values as $cur=>$amount) $parts[] = esc_html($cur.' '.$this->money($amount));
        return implode('<br>', $parts);
    }

    private function dash_currency_values($currencies, $key) {
        $values=[]; foreach ($currencies as $cur=>$v) if (abs((float)$v[$key]) > 0.0001) $values[$cur]=$v[$key];
        return $this->dash_values($values);
    }

    private function dash_kpi($label, $value, $note, $icon, $color, $url) {
        return '<a class="ub-dash-kpi" style="--dash-k:'.esc_attr($color).'" href="'.esc_url($url).'"><span class="ub-dash-kpi-icon">'.$this->icon($icon).'</span><span class="ub-dash-kpi-copy"><small>'.esc_html($label).'</small><strong>'.$value.'</strong><em>'.esc_html($note).'</em></span></a>';
    }

    private function dash_metric_rows($label, $values) {
        if (!$values) return '';
        $html='<div class="ub-dash-submetric"><span>'.esc_html($label).'</span><strong>'.$this->dash_values($values).'</strong></div>';
        return $html;
    }

    private function next_due_bits() {
        $c = $this->company();
        if (($c['gst_period'] ?? '') === 'monthly') {
            $ev = $this->next_event('GSTR-1');
            return ['lead'=>$ev ? 'GSTR-1 '.$ev[1]->format('j M Y') : 'GSTR-1 date', 'rest'=>'Monthly'];
        }
        $g1 = $this->next_event('GSTR-1');
        $g3 = $this->next_event('GSTR-3B');
        return [
            'lead' => $g1 ? 'GSTR-1 '.$g1[1]->format('j M') : 'GSTR-1',
            'rest' => ($g3 ? 'GSTR-3B '.$g3[1]->format('j M').' - ' : '').'Quarterly QRMP',
        ];
    }

    private function next_due_label() {
        $b = $this->next_due_bits();
        return trim($b['lead'].($b['rest'] !== '' ? ' - '.$b['rest'] : ''));
    }

    private function nice_name($name) {
        $name = trim((string) $name);
        if ($name === '' || strpos($name, '@') !== false) return $name;
        if (preg_match('/[A-Z]/', $name)) return $name;
        return mb_convert_case($name, MB_CASE_TITLE, 'UTF-8');
    }

    private function show_in_people($u) {
        $login = strtolower((string) $u->user_login);
        $blob = strtolower($login.' '.$u->display_name.' '.$u->user_email);
        if (strpos($blob, 'manage-system') !== false) return false;
        if ($u->user_email === '') return false;
        return true;
    }

    private function reminder_text() {
        $c = $this->company();
        $lines = ["UniCybers Books reminder. The pack is ready for review.", ''];
        $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Asia/Kolkata');
        $today = new DateTimeImmutable('today', $tz);
        $lines[] = 'Coming dates:';
        $n = 0;
        foreach ($this->filing_events() as $ev) {
            if ($ev[1] < $today) continue;
            $lines[] = $ev[0].' '.$ev[1]->format('j M Y');
            if (++$n >= 6) break;
        }
        if (!empty($c['lut_fy_inferred'])) {
            $lines[] = '';
            $lines[] = 'LUT filing acknowledgement ARN '.$c['lut_arn'].' was filed on '.($c['lut_filed'] ?? '').'. The PDF does not print a separate LUT bond number or a financial year. The filing date falls in '.$c['lut_fy_inferred'].'. Renew before 31 March at the end of that year.';
        }
        if (($c['udyam_number'] ?? '') === '') {
            $lines[] = 'Udyam number is blank. The certificate dated '.($c['udyam_printed'] ?? '').' could not be read as text.';
        } else {
            $lines[] = 'Udyam registration '.$c['udyam_number'].' for '.($c['legal_name'] ?? 'UNICYBERS VTZ LLP').'.';
        }
        global $wpdb;
        $docs = $wpdb->get_results("SELECT * FROM {$this->t('docs')} WHERE doc_type='invoice' ORDER BY id DESC LIMIT 80");
        $gaps = [];
        foreach ($docs as $d) {
            $why = [];
            if ($d->status === 'draft') $why[] = 'still a draft';
            if (($d->customer_type ?? '') === 'b2b' && $d->supply === 'domestic' && $d->contact_gstin === '') $why[] = 'B2B without a customer GSTIN';
            if ($d->supply === 'domestic' && ($d->sac ?? '') === '') $why[] = 'domestic taxable without a SAC';
            if ($d->supply === 'export_lut' && ($c['lut_arn'] ?? '') === '' && ($c['lut_number'] ?? '') === '') $why[] = 'export without a LUT acknowledgement';
            if ($why) $gaps[] = ($d->number ?: 'Invoice '.$d->id).': '.implode(', ', $why);
        }
        if ($gaps) {
            $lines[] = '';
            $lines[] = 'Tax invoices to finish:';
            foreach (array_slice($gaps, 0, 12) as $g) $lines[] = $g;
        }
        $itc = $wpdb->get_results("SELECT * FROM {$this->t('expenses')} WHERE itc=1 AND (matched_2b=0 OR matched_2b IS NULL) LIMIT 12");
        if ($itc) {
            $lines[] = '';
            $lines[] = 'Input GST marked claimable and not matched to GSTR-2B:';
            foreach ($itc as $e) $lines[] = $e->title.' · '.$e->currency.' '.$this->money($e->amount);
        }
        $recv = $wpdb->get_results("SELECT * FROM {$this->t('docs')} WHERE tds_mode='expected' AND doc_type='invoice' LIMIT 12");
        if ($recv) {
            $lines[] = '';
            $lines[] = 'TDS the customer was expected to deduct (do not reduce the invoice):';
            foreach ($recv as $d) $lines[] = ($d->number ?: $d->id).' · '.$d->tds_section.' · '.$d->contact_name;
        }
        $sections = trim((string)($c['tds_sections'] ?? ''));
        $deducted = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->t('tds')}");
        if ($sections !== '' || $deducted) {
            $td = $this->next_event('TDS return');
            $lines[] = '';
            $lines[] = 'TDS the firm deducted is due with the quarterly return'.($td ? ' by '.$td[1]->format('j M Y') : '').'. Dates used: 31 July, 31 October, 31 January, 31 May.';
        }
        return implode("\n", $lines);
    }

    private function doc_table($rows, $cards = false) {
        if (!$rows) return '<p class="empty">No documents yet.</p>';
        $html = '<table class="ub-table"><thead><tr><th>Document</th><th>Customer</th><th>Amount</th><th>Status</th><th></th></tr></thead><tbody>';
        foreach ($rows as $d) {
            $st = $this->derived_status($d);
            $html .= '<tr><td data-l="Document"><a href="'.esc_url($this->url(['ub'=>'doc','id'=>(int)$d->id])).'"><strong>'.esc_html($d->number ?: ucfirst($d->doc_type)).'</strong></a></td>';
            $html .= '<td data-l="Customer">'.esc_html($this->nice_name($d->contact_name) ?: '-');
            if ($this->access() === 'owner' && !empty($d->created_by)) {
                $who = get_userdata((int)$d->created_by);
                if ($who) $html .= '<span class="sub">By '.esc_html($this->nice_name($who->display_name)).'</span>';
            }
            $html .= '</td>';
            $html .= '<td data-l="Amount"><span class="c">'.esc_html($d->currency).'</span> '.$this->money($d->total).'</td>';
            $html .= '<td data-l="Status">'.$this->pill($st);
            if ($d->supply === 'export_lut') $html .= ' '.$this->pill('export_lut');
            $html .= '</td><td data-l="Open"><a class="btn sm" href="'.esc_url($this->url(['ub'=>'doc','id'=>(int)$d->id,'mode'=>'view'])).'">View</a> <a class="btn sm" href="'.esc_url($this->url(['ub'=>'doc','id'=>(int)$d->id])).'">Edit</a>';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline">';
            $html .= '<input type="hidden" name="action" value="ub_delete_doc"><input type="hidden" name="id" value="'.(int)$d->id.'">'.wp_nonce_field('ub_delete_doc','_wpnonce', true, false);
            $html .= '<button class="btn sm danger" type="submit">Delete</button></form></td></tr>';
        }
        return $html.'</tbody></table>';
    }

    private function trainer_table() {
        $rows = $this->trainer_balances();
        if (!$rows) return '<p class="empty">Record a trainer share and the balance shows here, by currency.</p>';
        $html = '<table class="ub-table"><tbody>';
        foreach ($rows as $r) {
            $html .= '<tr><td data-l="Trainer">'.esc_html($r['name']).'</td><td data-l="Owed">'.esc_html($r['cur']).' '.$this->money($r['owed']).'</td></tr>';
        }
        return $html.'</tbody></table><p><a href="'.esc_url($this->url(['ub'=>'trainers'])).'">Open the trainer ledger</a></p>';
    }

    private function view_docs() {
        $pipe = sanitize_key($_GET['pipe'] ?? 'all');
        $rows = $this->docs();
        $html = '<div class="list-head"><div class="pipe">';
        foreach (['all'=>'All','draft'=>'Draft','sent'=>'Sent','awaiting'=>'Awaiting payment','paid'=>'Paid','overdue'=>'Overdue'] as $k=>$l) {
            $html .= '<a class="'.($pipe===$k?'on':'').'" href="'.esc_url($this->url(['ub'=>'invoices','pipe'=>$k])).'">'.esc_html($l).'</a>';
        }
        $html .= '</div><div class="page-actions"><a class="btn primary" href="'.esc_url($this->url(['ub'=>'doc','type'=>'invoice'])).'">Tax Invoice</a>';
        $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','type'=>'quote'])).'">Quotation</a>';
        $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','type'=>'proforma'])).'">Proforma</a>';
        $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','type'=>'credit_note'])).'">Credit Note</a>';
        $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','type'=>'delivery_note'])).'">Delivery Note</a>';
        if ($this->access() === 'owner' || $this->access() === 'accountant') $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','type'=>'purchase_order'])).'">Purchase Order</a>';
        $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'subs'])).'">Subscription</a>';
        if ($this->access() === 'owner' || $this->access() === 'accountant') $html .= '<form class="ub-export-inline" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_zoho_export">'.wp_nonce_field('ub_zoho_export','_wpnonce', true, false).'<button class="btn" type="submit" title="Export invoices as a CSV for Zoho Books">Zoho Export</button></form>';
        $html .= '</div></div>';
        $filtered = [];
        foreach ($rows as $d) {
            $st = $this->derived_status($d);
            if ($pipe === 'all') $filtered[] = $d;
            elseif ($pipe === 'awaiting' && in_array($st, ['sent','part_paid','overdue'], true)) $filtered[] = $d;
            elseif ($st === $pipe) $filtered[] = $d;
        }
        if (!$filtered) $list = $html.'<div class="empty"><div class="empty-ico">'.$this->icon('invoices').'</div><strong>Nothing In This Stage</strong><p>Start with a quotation, then a proforma, then a tax invoice.</p></div>';
        else $list = $html.'<div class="ub-card">'.$this->doc_table($filtered).'</div>';
        return $list;
    }

    private function view_doc() {
        global $wpdb;
        $id = absint($_GET['id'] ?? 0);
        $type = sanitize_key($_GET['type'] ?? 'invoice');
        $from = absint($_GET['from'] ?? 0);
        $doc = $id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('docs')} WHERE id=%d", $id)) : null;
        $line = $doc ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('lines')} WHERE doc_id=%d ORDER BY id ASC LIMIT 1", $id)) : null;
        if (!$doc && $from) {
            $doc = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('docs')} WHERE id=%d", $from));
            if ($doc) {
                $line = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('lines')} WHERE doc_id=%d ORDER BY id ASC LIMIT 1", $from));
                $doc->id = 0;
                $doc->doc_type = $type ?: 'invoice';
                $doc->number = '';
                $doc->status = 'draft';
                $doc->paid = 0;
            }
        }
        if (!$doc) {
            $doc = (object) [
                'id'=>0,'doc_type'=>$type,'number'=>'','status'=>'draft','contact_name'=>'','contact_email'=>'','contact_phone'=>'',
                'contact_address'=>'','contact_country'=>'India','contact_state'=>'Andhra Pradesh','contact_gstin'=>'','currency'=>'INR','supply'=>'domestic','price_mode'=>'incl',
                'tax_rate'=>18,'total'=>0,'paid'=>0,'doc_date'=>current_time('Y-m-d'),'due_date'=>'','terms'=>$this->default_terms($type),'notes'=>'',
                'customer_type'=>'b2b','supply_reason'=>'','sac'=>'999293','place_state'=>'Andhra Pradesh','bank_key'=>'','include_stamp'=>in_array($type, ['invoice','proforma'], true) ? 1 : 0,'assistant_note'=>'',
                'product_line'=>'training','course_days'=>45,'lab_free_days'=>30,'lab_fee'=>0,'lms_fee'=>0,'batch_label'=>'',
            ];
        }
        $amount = $line ? (float)$line->amount : (float)$doc->total;
        $banks = $this->company()['banks'] ?? [];
        if ($doc && !empty($doc->id) && sanitize_key($_GET['mode'] ?? '') === 'view') {
            return '<div class="actions no-print"><a class="btn" href="'.esc_url($this->url(['ub'=>'doc','id'=>(int)$doc->id])).'">Edit</a><button class="btn" type="button" onclick="window.print()">Download PDF</button></div><div class="ub-split"><div></div><div>'.$this->preview($doc, $line, $amount).$this->doc_actions($doc).'</div></div>';
        }
        $html = '<div class="ub-split ub-doc-workspace"><form class="ub-card ub-form ub-doc-composer" id="ubDoc" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<input type="hidden" name="action" value="ub_save_doc"><input type="hidden" name="id" value="'.(int)$doc->id.'">';
        $html .= wp_nonce_field('ub_save_doc','_wpnonce', true, false);
        $html .= '<section class="ub-doc-panel ub-doc-meta-panel"><div class="ub-doc-panel-head"><span>DOCUMENT SETUP</span><small>Choose the document type and currency</small></div><div class="ub-doc-panel-body"><div class="ub-2"><label>Type<select name="doc_type" id="ubDocType">';
        foreach (['quote'=>'Quotation','proforma'=>'Proforma','invoice'=>'Tax Invoice','credit_note'=>'Credit Note','delivery_note'=>'Delivery Note','purchase_order'=>'Purchase Order'] as $k=>$l) {
            if ($k === 'purchase_order' && !in_array($this->access(), ['owner','accountant'], true)) continue;
            $html .= '<option value="'.$k.'"'.selected($doc->doc_type,$k,false).'>'.$l.'</option>';
        }
        $html .= '</select></label><label>Currency<select name="currency">';
        foreach (['INR','USD','AED','BWP','ZAR'] as $cur) $html .= '<option'.selected($doc->currency,$cur,false).'>'.$cur.'</option>';
        $html .= '</select></label></div></div></section>';
        $html .= '<section class="ub-doc-panel"><div class="ub-doc-panel-head"><span>01 · CUSTOMER</span><small>Who are you billing?</small></div><div class="ub-doc-panel-body">';
        $ctype = $doc->customer_type ?? 'b2b';
        $html .= '<label>Customer type<select name="customer_type"><option value="b2b"'.selected($ctype,'b2b',false).'>B2B</option><option value="individual"'.selected($ctype,'individual',false).'>Individual</option></select></label>';
        $html .= '<div class="ub-2"><label>Customer legal name<input name="contact_name" value="'.esc_attr($doc->contact_name).'" required placeholder="Wayfarer Consulting"></label><label>Customer GSTIN<input name="contact_gstin" value="'.esc_attr($doc->contact_gstin).'" placeholder="15-character GSTIN"></label></div>';
        $html .= '<div class="ub-2"><label>Email<input type="email" name="contact_email" value="'.esc_attr($doc->contact_email).'"></label>';
        $html .= '<label>Phone<input name="contact_phone" value="'.esc_attr($doc->contact_phone).'"></label></div>';
        $html .= '<div class="ub-2"><label>Customer address<textarea name="contact_address" rows=2>'.esc_textarea($doc->contact_address ?? '').'</textarea></label><label>Place of supply<select name="place_state">'.$this->state_options($doc->place_state ?? 'Andhra Pradesh').'</select></label></div>';
        $html .= '<div class="ub-2"><label>Country<select name="contact_country">'.$this->country_options($doc->contact_country).'</select></label>';
        $html .= '<label>State<select name="contact_state">'.$this->state_options($doc->contact_state).'</select></label></div>';
        
        $html .= '</div></section><section class="ub-doc-panel"><div class="ub-doc-panel-head"><span>02 · ITEMS AND SERVICES</span><small>Describe the work and commercial value</small></div><div class="ub-doc-panel-body">';
        $html .= '<div class="ub-2"><label>Component<input name="component" value="'.esc_attr($line->component ?? '').'" placeholder="LMS Setup"></label><label>Scope<textarea name="scope" rows=2>'.esc_textarea($line->scope ?? '').'</textarea></label></div>';
        $html .= '<div class="ub-2"><label>Pricing basis<select name="basis">';
        $basis = $line->basis ?? 'One Time';
        foreach (['One Time','LMS Setup','Hosting','Monthly','Per Batch'] as $b) $html .= '<option'.selected($basis,$b,false).'>'.esc_html($b).'</option>';
        $html .= '</select></label>';
        $html .= '<label>Amount<input type="number" step="0.01" min="0" name="amount" value="'.esc_attr($amount).'"></label></div>';
        $lineNow = $doc->product_line ?? 'training';
        $html .= '<div class="ub-2"><label>This Invoice Is For<select name="product_line">';
        foreach (['training'=>'Training','labs'=>'Labs','lms'=>'LMS','other'=>'Other'] as $k=>$l) $html .= '<option value="'.$k.'"'.selected($lineNow,$k,false).'>'.$l.'</option>';
        $html .= '</select></label><label>Batch Or Company<input name="batch_label" value="'.esc_attr($doc->batch_label ?? '').'" placeholder="Company batch name"></label></div>';
        $html .= '<div class="ub-2"><label>Course Length In Days<input type="number" min="1" name="course_days" value="'.esc_attr($doc->course_days ?? 45).'"></label>';
        $html .= '<label>Lab Monthly Amount<input type="number" step="0.01" min="0" name="lab_fee" value="'.esc_attr($doc->lab_fee ?? '').'"></label></div>';
        $html .= '<label class="check ub-doc-check"><input type="checkbox" name="lab_follow" value="1"> First 30 days of lab access are free on a training of 30 days or more. Charge labs from the next month on a separate invoice.</label>';
        $html .= '<div class="ub-2"><label>LMS Monthly Amount<input type="number" step="0.01" min="0" name="lms_fee" value="'.esc_attr($doc->lms_fee ?? '').'"></label></div>';
        $html .= '<label class="check ub-doc-check"><input type="checkbox" name="lms_monthly" value="1"> Charge LMS hosting every month. Leave this off when setup and hosting were a one-time fee.</label>';
        $html .= '';
        $html .= '</div></section><section class="ub-doc-panel"><div class="ub-doc-panel-head"><span>03 · TAX AND PAYMENT</span><small>GST treatment, bank details and document dates</small></div><div class="ub-doc-panel-body">';
        $sacNow = $doc->sac ?? ($line->sac ?? '999293');
        $html .= '<label>SAC / HSN<select name="sac">';
        foreach (['999293'=>'999293 Commercial training','998315'=>'998315 Hosting','998316'=>'998316 Software or licence'] as $code=>$label) {
            $html .= '<option value="'.$code.'"'.selected($sacNow,$code,false).'>'.esc_html($label).'</option>';
        }
        $html .= '</select></label>';
        $html .= '<div class="ub-2"><label>Price<select name="price_mode"><option value="incl"'.selected($doc->price_mode,'incl',false).'>Inclusive of GST</option><option value="excl"'.selected($doc->price_mode,'excl',false).'>GST extra</option></select></label>';
        $html .= '<label>GST %<input type="number" step="0.01" name="tax_rate" value="'.esc_attr($doc->tax_rate).'"></label></div>';
        $html .= '<label>Supply treatment<select name="supply">';
        foreach (['domestic'=>'Domestic taxable','export_lut'=>'Export of services under LUT','no_gst'=>'GST not applicable'] as $k=>$l) {
            $html .= '<option value="'.$k.'"'.selected($doc->supply,$k,false).'>'.$l.'</option>';
        }
        $html .= '</select></label>';
        $html .= '<label data-reason>Reason if GST is not applicable<textarea name="supply_reason" rows="2" placeholder="Type the reason. An Indian individual is not tax-free by default.">'.esc_textarea($doc->supply_reason ?? '').'</textarea></label>';
        $html .= '<p id="ubSupplyPill" class="pill sent">Tax split</p>';
        $html .= '<label>Bank account on this invoice<select name="bank_key">';
        $chosen = $doc->bank_key ?? '';
        foreach ($banks as $b) {
            $isPersonal = ($b['holder'] ?? '') === 'personal';
            $sel = $chosen !== '' ? ($chosen === ($b['key'] ?? '')) : (!$isPersonal && !empty($b['default']));
            $label = ($b['bank'] ?? '').' - '.($b['type'] ?? '').($isPersonal ? ' - Personal' : ' - Firm');
            $html .= '<option value="'.esc_attr($b['key'] ?? '').'" data-line="'.esc_attr(($b['name'] ?? '').' - '.($b['bank'] ?? '').' - '.($b['number'] ?? '')).'" data-extra="'.esc_attr('IFSC '.($b['ifsc'] ?? '')).'" data-personal="'.($isPersonal?'1':'0').'"'.selected($sel, true, false).'>'.esc_html($label).'</option>';
        }
        $html .= '</select></label>';
        $html .= '<label><input type="checkbox" name="include_stamp" value="1"'.checked(!empty($doc->include_stamp), true, false).'> Include the firm stamp</label>';
        $html .= '</div></section><section class="ub-doc-panel"><div class="ub-doc-panel-head"><span>04 · FINALISATION</span><small>Terms, dates and document actions</small></div><div class="ub-doc-panel-body">';
        $html .= '<label class="ub-doc-terms">Terms and conditions<textarea name="terms" rows="3">'.esc_textarea($doc->terms ?: $this->default_terms($doc->doc_type)).'</textarea></label>';
        $html .= '<div class="ub-2"><label>Date<input type="date" name="doc_date" value="'.esc_attr($doc->doc_date).'"></label>';
        $html .= '<label>Due<input type="date" name="due_date" value="'.esc_attr($doc->due_date).'"></label></div>';
        $html .= '<div class="ub-assist" id="ubAssist">'.esc_html($doc->assistant_note ?? 'The note is saved when you save the document.').'</div>';
        $html .= '<div class="actions ub-doc-actions"><button class="btn primary sm" type="submit">Save document</button>';
        $html .= '<button class="btn" type="button" onclick="window.print()">Download PDF</button></div></div></section></form>';
        $html .= '<div>'.$this->preview($doc, $line, $amount);
        if ($doc->id) $html .= $this->doc_actions($doc);
        $html .= '</div></div>';
        return $html;
    }

    private function preview($doc, $line, $amount) {
        $c = $this->company();
        $tax = $this->assess([
            'customer_type'=>$doc->customer_type ?? 'b2b',
            'supply'=>$doc->supply,
            'country'=>$doc->contact_country,
            'state'=>$doc->contact_state,
            'place'=>$doc->place_state ?? '',
            'gstin'=>$doc->contact_gstin,
            'component'=>$line->component ?? '',
            'scope'=>$line->scope ?? '',
            'sac'=>$doc->sac ?? ($line->sac ?? ''),
            'tax_rate'=>$doc->tax_rate,
            'reason'=>$doc->supply_reason ?? '',
            'amount'=>$amount,
            'mode'=>$doc->price_mode,
        ]);
        $titles = ['quote'=>'Quotation','proforma'=>'Proforma','invoice'=>'Tax Invoice','credit_note'=>'Credit Note','delivery_note'=>'Delivery Note','purchase_order'=>'Purchase Order'];
        $showIds = $doc->doc_type === 'invoice';
        $bank = $this->bank_by($doc->bank_key ?? '');
        $stamp = plugins_url('assets/stamp.jpg', __FILE__);
        $logo = plugins_url('assets/logo.png', __FILE__);
        $supplier_name = $c['legal_name'] ?? 'UNICYBERS VTZ LLP';
        $supplier_address = $c['gst_principal'] ?? ($c['address'] ?? '');
        $html = '<article class="sheet" id="ubPreview"><header class="sheet-h"><div class="sheet-brand"><img src="'.esc_url($logo).'" alt=""><div><strong>'.esc_html($supplier_name).'</strong><em>Cybersecurity Training, Practical Labs, LMS</em><small>'.esc_html($supplier_address).'</small><small>GSTIN: '.esc_html($c['gstin'] ?? '').' · PAN: '.esc_html($c['pan'] ?? '').'</small><small>P '.esc_html($c['phone'] ?? '').' · E '.esc_html($c['email'] ?? 'info@unicybers.com').'</small><small>unicybers.com · learn.unicybers.com</small></div></div>';
        $html .= '<div style="text-align:right"><h2 data-f="type">'.esc_html($titles[$doc->doc_type] ?? 'Document').'</h2><small>'.esc_html($doc->number ?: 'Draft number on save').'</small><small>'.esc_html($doc->doc_date).'</small></div></header><div class="sheet-b">';
        $html .= '<p style="margin:0 0 8px"><strong>Prepared For</strong><br><span data-f="contact">'.esc_html($doc->contact_name ?: 'Customer').'</span>';
        if (!empty($doc->contact_address)) $html .= '<br>'.nl2br(esc_html($doc->contact_address));
        if ($doc->contact_state || $doc->contact_country) $html .= '<br>'.esc_html(trim(($doc->contact_state ? $doc->contact_state.', ' : '').($doc->contact_country ?? '')));
        if ($showIds && $tax['gstin']) $html .= '<br>Customer GSTIN <span data-f="cgstin">'.esc_html($tax['gstin']).'</span>';
        $html .= '</p>';
        if ($doc->doc_type === 'invoice') {
            $html .= '<div class="sheet-invoice-meta"><span><strong>Invoice number</strong>'.esc_html($doc->number ?: 'To be assigned').'</span><span><strong>Invoice date</strong>'.esc_html($doc->doc_date).'</span><span><strong>Place of supply</strong>'.esc_html($doc->place_state ?: $doc->contact_state ?: 'Andhra Pradesh').'</span><span><strong>Reverse charge</strong>No</span></div>';
        }
        $html .= '<table><thead><tr><th>Description</th><th>SAC / HSN</th><th>Pricing Basis</th><th>Scope</th><th>Amount</th></tr></thead><tbody><tr>';
        $html .= '<td data-f="component">'.esc_html($line->component ?? 'LMS Setup').'</td><td data-f="sac">'.esc_html($tax['sac']['code']).'</td><td data-f="basis">'.esc_html($line->basis ?? 'One Time').'</td><td data-f="scope">'.esc_html($line->scope ?? '').'</td><td data-f="base">'.$this->money($tax['base']).'</td></tr></tbody></table>';
        $html .= '<div class="tot" data-tax'.($tax['charge']?'':' hidden').'><div><span>CGST</span><span data-f="cgst">'.$this->money($tax['cgst']).'</span></div><div><span>SGST</span><span data-f="sgst">'.$this->money($tax['sgst']).'</span></div><div><span>IGST</span><span data-f="igst">'.$this->money($tax['igst']).'</span></div></div>';
        $html .= '<p data-lut'.($doc->supply==='export_lut'?'':' hidden').'>Export of services under LUT. GST is not charged. IEC '.esc_html($c['iec'] ?? '').'. LUT ARN '.esc_html($c['lut_arn'] ?? $c['lut_number'] ?? '').'.</p>';
        $html .= '<div class="tot"><div class="grand"><span>Total Payable</span><span><span data-f="cur">'.esc_html($doc->currency).'</span> <span data-f="total">'.$this->money($tax['total']).'</span></span></div></div>';
        $terms_text = trim((string)($doc->terms ?: $this->default_terms($doc->doc_type)));
        if ($terms_text !== '') $html .= '<p class="sheet-terms sheet-terms-short"><strong>Terms</strong> '.esc_html(wp_trim_words(preg_replace('/\s+/', ' ', $terms_text), 28, '…')).' <span>Full terms on accompanying terms sheet.</span></p>';
        if ($bank) {
            $personal = ($bank['holder'] ?? '') === 'personal';
            $html .= '<p data-bank><strong>Payment Details'.($personal ? ' - Personal - use only when the client requires this account' : '').'</strong><br><span data-f="bank">'.esc_html(($bank['name'] ?? '').' - '.($bank['bank'] ?? '').' - '.($bank['number'] ?? '')).'</span><br><span data-extra>IFSC '.esc_html($bank['ifsc'] ?? '').'</span></p>';
        }
        $html .= '<div class="sheet-sign"><div><p>For UniCybers VTZ LLP<br><strong>Authorised Signatory</strong><br>'.esc_html($c['signatory'] ?? '').'<br>'.esc_html($c['designation'] ?? '').'</p></div>';
        $html .= '<img class="stamp" data-stamp src="'.esc_url($stamp).'" alt="UniCybers VTZ LLP"'.(empty($doc->include_stamp)?' hidden':'').'></div>';
        $html .= '</div><footer>UniCybers VTZ LLP · unicybers.com · learn.unicybers.com · support@unicybers.com</footer></article>';
        if ($terms_text !== '') {
            $html .= '<article class="sheet sheet-terms-page"><header class="sheet-h"><div class="sheet-brand"><img src="'.esc_url($logo).'" alt=""><div><strong>'.esc_html($supplier_name).'</strong><small>'.esc_html($supplier_address).'</small><small>GSTIN: '.esc_html($c['gstin'] ?? '').'</small></div></div><div style="text-align:right"><h2>Terms and conditions</h2><small>'.esc_html($doc->number ?: 'Draft document').'</small></div></header><div class="sheet-b"><h3>Commercial terms</h3><div class="sheet-terms-full">'.nl2br(esc_html($terms_text)).'</div></div><footer>These terms form part of the accompanying '.esc_html($titles[$doc->doc_type] ?? 'document').'.</footer></article>';
        }
        return $html;
    }

    private function split($amount, $mode, $rate, $supply, $country, $state, $gstin) {
        $export = $supply === 'export_lut' || (strcasecmp((string)$country, 'India') !== 0 && $country !== '');
        $code = strtoupper(substr((string)$gstin, 0, 2));
        $same = !$export && ($code === '37' || stripos((string)$state, 'andhra') !== false || $state === '');
        if ($state === '' && $code && $code !== '37') $same = false;
        $base = (float)$amount; $tax = 0;
        if (!$export && $rate > 0) {
            if ($mode === 'incl') { $base = $amount / (1 + $rate / 100); $tax = $amount - $base; }
            else $tax = $amount * $rate / 100;
        }
        $cgst = $sgst = $igst = 0;
        if (!$export) {
            if ($same) { $cgst = $tax / 2; $sgst = $tax / 2; }
            else $igst = $tax;
        }
        $total = ($mode === 'incl' || $export) ? (float)$amount : $base + $tax;
        return ['base'=>$base,'cgst'=>$cgst,'sgst'=>$sgst,'igst'=>$igst,'total'=>$total,'export'=>$export];
    }

    private function doc_actions($doc) {
        $html = '<div class="ub-card no-print" style="margin-top:12px"><strong>Share</strong><div class="actions">';
        $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','id'=>(int)$doc->id,'mode'=>'view'])).'">Preview</a>';
        $html .= '<button class="btn" type="button" onclick="window.print()">Download PDF</button>';
        $text = rawurlencode(($doc->number ?: 'Invoice').' · '.$doc->currency.' '.$this->money($doc->total).' · '.$doc->contact_name);
        $html .= '<a class="btn" href="https://wa.me/?text='.$text.'">WhatsApp</a>';
        if ($doc->contact_email) {
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
            $html .= '<input type="hidden" name="action" value="ub_report"><input type="hidden" name="kind" value="doc"><input type="hidden" name="id" value="'.(int)$doc->id.'">';
            $html .= wp_nonce_field('ub_report','_wpnonce', true, false);
            $html .= '<button class="btn primary" type="submit">Email customer and rafi@unicybers.com</button></form>';
        }
        if ($doc->doc_type === 'quote') $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','from'=>(int)$doc->id,'type'=>'proforma'])).'">Convert To Proforma</a>';
        if ($doc->doc_type === 'proforma') $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'doc','from'=>(int)$doc->id,'type'=>'invoice'])).'">Convert To Tax Invoice</a>';
        $html .= '</div>';
        if (in_array($doc->doc_type, ['invoice','proforma'], true) && $this->can('sales')) {
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="ub-form" style="margin-top:10px">';
            $html .= '<input type="hidden" name="action" value="ub_payment"><input type="hidden" name="doc_id" value="'.(int)$doc->id.'">';
            $html .= wp_nonce_field('ub_payment','_wpnonce', true, false);
            $html .= '<div class="ub-2"><label>Payment Amount<input type="number" step="0.01" name="amount" required></label><label>Method<input name="method" placeholder="Bank transfer"></label></div>';
            $html .= '<button class="btn" type="submit">Record Payment</button></form>';
        }
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:8px">';
        $html .= '<input type="hidden" name="action" value="ub_delete_doc"><input type="hidden" name="id" value="'.(int)$doc->id.'">'.wp_nonce_field('ub_delete_doc','_wpnonce', true, false);
        $html .= '<button class="btn danger" type="submit">Delete document</button></form>';
        return $html.'</div>';
    }

    public function delete_doc() {
        $this->guard('ub_delete_doc', 'sales');
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        if (!$id) wp_die('Choose a document.');
        $paid = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->t('pays')} WHERE doc_id=%d", $id));
        if ($paid) wp_die('This document has a payment. Remove the payment before deleting it.');
        $wpdb->delete($this->t('lines'), ['doc_id'=>$id]);
        $wpdb->delete($this->t('docs'), ['id'=>$id]);
        wp_safe_redirect($this->url(['ub'=>'invoices']));
        exit;
    }

    private function default_terms($type) {
        $body = "White label and intellectual property: white-label work covers agreed LMS branding and configuration only. UniCybers retains the platform, source code, architecture, and reusable components. Source-code transfer, ownership transfer, sublicensing, and reverse engineering are not included.\n"
            ."Additional customisation is quoted separately and starts only after written approval.\n"
            ."Standard support covers reasonable help with the delivered configuration, routine troubleshooting, and hosting coordination during normal business hours.\n"
            ."Hosting depends on third-party infrastructure. UniCybers coordinates faults and does not guarantee uninterrupted availability.\n"
            ."The customer supplies logos, content, administrator details, and confirms the right to use them.\n"
            ."The start date and handover date are agreed after payment and receipt of the required inputs.\n"
            ."Renewal is payable in advance. Hosting or support may be suspended for an overdue invoice after written notice. Completed setup fees are non-refundable except where the law requires it.\n"
            ."Labs, training delivery, certification vouchers, and anything not written on this document need their own invoice.\n"
            ."Liability, to the extent the law allows, will not exceed the fees received for the affected period. This document is governed by Indian law and the courts at Visakhapatnam.\n"
            ."A change to scope, fees, or terms must be agreed in writing.\n"
            ."Technical support: support@unicybers.com. unicybers.com and learn.unicybers.com.\n"
            ."GST inclusive or GST extra is the choice on this document. It is not assumed in these terms.";
        if ($type === 'quote') return "This Quotation is valid for 15 days. It is not a tax invoice.\n100% advance before onboarding and workspace provisioning.\n".$body;
        if ($type === 'proforma') return "This Proforma is not a tax invoice.\n100% advance before onboarding and workspace provisioning.\n".$body;
        if ($type === 'purchase_order') return "This Purchase Order is for the supply written above.\nPayment follows the terms agreed with the supplier.\n".$body;
        if ($type === 'credit_note') return "This Credit Note reduces the related Tax Invoice.\n".$body;
        if ($type === 'delivery_note') return "This Delivery Note records handover of the work written above. It is not a tax invoice and it is not a demand for payment.\n".$body;
        return "This is a Tax Invoice.\n100% advance before onboarding and workspace provisioning, unless a due date is stated.\n".$body;
    }

    private function country_options($current) {
        $list = ['India','Botswana','United Arab Emirates','Saudi Arabia','South Africa','United States'];
        $current = $current ?: 'India';
        if (!in_array($current, $list, true)) array_unshift($list, $current);
        $html = '';
        foreach ($list as $c) $html .= '<option'.selected($current, $c, false).'>'.esc_html($c).'</option>';
        return $html;
    }

    private function state_options($current) {
        $list = ['Andhra Pradesh','Telangana','Tamil Nadu','Karnataka','Kerala','Maharashtra','Delhi','Gujarat','Rajasthan','Uttar Pradesh','West Bengal','Odisha','Madhya Pradesh','Punjab','Haryana','Bihar','Assam','Goa','Gaborone','South-East','Other'];
        $current = $current ?: 'Andhra Pradesh';
        if (!in_array($current, $list, true)) array_unshift($list, $current);
        $html = '';
        foreach ($list as $s) $html .= '<option'.selected($current, $s, false).'>'.esc_html($s).'</option>';
        return $html;
    }

    public function zoho_export() {
        $this->guard('ub_zoho_export', 'sales');
        if (!in_array($this->access(), ['owner','accountant'], true)) wp_die('Not allowed.', 403);
        global $wpdb;
        $docs = $wpdb->get_results("SELECT * FROM {$this->t('docs')} WHERE doc_type='invoice' ORDER BY doc_date ASC, id ASC") ?: [];
        if (!$docs) wp_die('There are no invoices to export yet.');
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename=unicybers-zoho-invoices-'.current_time('Ymd-His').'.csv');
        $out = fopen('php://output', 'w');
        // Zoho Books accepts CSV imports and lets the user map these source columns to its invoice fields.
        fputcsv($out, ['Customer Name','Invoice Number','Invoice Date','Due Date','Invoice Status','Item Name','Item Description','HSN/SAC','Quantity','Rate','Tax Name','Tax Percentage','Place Of Supply','Customer GSTIN','Customer Email','Customer Phone','Billing Address','Currency Code','Terms & Conditions','Notes']);
        foreach ($docs as $d) {
            $line = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('lines')} WHERE doc_id=%d ORDER BY id ASC LIMIT 1", (int)$d->id));
            $taxable = (float)$d->subtotal;
            $tax_rate = (float)$d->tax_rate;
            $tax_name = $tax_rate > 0 ? 'GST '.$this->money($tax_rate).'%' : 'No Tax';
            $status = $d->status === 'draft' ? 'Draft' : 'Open';
            $address = trim((string)$d->contact_address);
            $state = trim((string)($d->place_state ?: $d->contact_state));
            if ($state !== '') $address = trim($address.($address !== '' ? ', ' : '').$state.($d->contact_country ? ', '.$d->contact_country : ''));
            fputcsv($out, [
                (string)$d->contact_name,
                (string)$d->number,
                (string)$d->doc_date,
                (string)$d->due_date,
                $status,
                (string)($line->component ?? 'Training / Services'),
                (string)($line->scope ?? ''),
                (string)($line->sac ?? $d->sac ?? ''),
                '1',
                number_format($taxable, 2, '.', ''),
                $tax_name,
                number_format($tax_rate, 2, '.', ''),
                $state,
                (string)$d->contact_gstin,
                (string)$d->contact_email,
                (string)$d->contact_phone,
                $address,
                (string)$d->currency,
                (string)$d->terms,
                (string)$d->notes,
            ]);
        }
        fclose($out);
        exit;
    }

    public function save_doc() {
        $this->guard('ub_save_doc', 'sales');
        if (sanitize_key($_POST['doc_type'] ?? '') === 'purchase_order' && !in_array($this->access(), ['owner','accountant'], true)) wp_die('Not allowed.', 403);
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        $amount = (float) ($_POST['amount'] ?? 0);
        $type = sanitize_key($_POST['doc_type'] ?? 'invoice');
        $supply = sanitize_key($_POST['supply'] ?? 'domestic');
        if (!in_array($supply, ['domestic','export_lut','no_gst'], true)) $supply = 'domestic';
        $mode = sanitize_key($_POST['price_mode'] ?? 'incl') === 'excl' ? 'excl' : 'incl';
        $country = sanitize_text_field(wp_unslash($_POST['contact_country'] ?? 'India'));
        $state = sanitize_text_field(wp_unslash($_POST['contact_state'] ?? ''));
        $customer = sanitize_key($_POST['customer_type'] ?? 'b2b') === 'individual' ? 'individual' : 'b2b';
        $component = sanitize_text_field(wp_unslash($_POST['component'] ?? 'LMS service'));
        $scope = sanitize_textarea_field(wp_unslash($_POST['scope'] ?? ''));
        $tax = $this->assess([
            'customer_type'=>$customer,'supply'=>$supply,'country'=>$country,'state'=>$state,
            'place'=>sanitize_text_field(wp_unslash($_POST['place_state'] ?? '')),
            'gstin'=>sanitize_text_field(wp_unslash($_POST['contact_gstin'] ?? '')),
            'component'=>$component,'scope'=>$scope,
            'sac'=>sanitize_text_field(wp_unslash($_POST['sac'] ?? '')),
            'tax_rate'=>$_POST['tax_rate'] ?? '',
            'reason'=>sanitize_textarea_field(wp_unslash($_POST['supply_reason'] ?? '')),
            'amount'=>$amount,'mode'=>$mode,
        ]);
        $data = [
            'doc_type'=>$type,
            'contact_name'=>sanitize_text_field(wp_unslash($_POST['contact_name'] ?? '')),
            'contact_email'=>sanitize_email(wp_unslash($_POST['contact_email'] ?? '')),
            'contact_phone'=>sanitize_text_field(wp_unslash($_POST['contact_phone'] ?? '')),
            'contact_address'=>sanitize_textarea_field(wp_unslash($_POST['contact_address'] ?? '')),
            'contact_country'=>$country ?: 'India',
            'contact_state'=>$state,
            'contact_gstin'=>$tax['gstin'],
            'currency'=>sanitize_text_field($_POST['currency'] ?? 'INR'),
            'supply'=>$supply,
            'price_mode'=>$mode,
            'tax_rate'=>$tax['rate'],
            'subtotal'=>round($tax['base'],2),
            'cgst'=>round($tax['cgst'],2),
            'sgst'=>round($tax['sgst'],2),
            'igst'=>round($tax['igst'],2),
            'total'=>round($tax['total'],2),
            'doc_date'=>sanitize_text_field($_POST['doc_date'] ?? '') ?: current_time('Y-m-d'),
            'due_date'=>sanitize_text_field($_POST['due_date'] ?? '') ?: null,
            'terms'=>sanitize_textarea_field(wp_unslash($_POST['terms'] ?? '')),
            'customer_type'=>$customer,
            'supply_reason'=>$tax['reason'],
            'sac'=>$tax['sac']['code'],
            'tds_mode'=>$tax['tds']['mode'],
            'tds_section'=>$tax['tds']['section'],
            'tds_rate'=>$tax['tds']['rate'],
            'tds_note'=>$tax['tds']['note'],
            'assistant_note'=>$tax['assistant'],
            'bank_key'=>sanitize_key($_POST['bank_key'] ?? ''),
            'include_stamp'=>empty($_POST['include_stamp']) ? 0 : 1,
            'place_state'=>sanitize_text_field(wp_unslash($_POST['place_state'] ?? '')),
            'gst_exception'=>$tax['exception'],
            'product_line'=>sanitize_key($_POST['product_line'] ?? 'other') ?: 'other',
            'course_days'=>max(1, (int)($_POST['course_days'] ?? 45)),
            'lab_free_days'=>30,
            'lab_fee'=>round((float)($_POST['lab_fee'] ?? 0), 2),
            'lms_fee'=>round((float)($_POST['lms_fee'] ?? 0), 2),
            'batch_label'=>sanitize_text_field(wp_unslash($_POST['batch_label'] ?? '')),
        ];
        if ($id) {
            $wpdb->update($this->t('docs'), $data, ['id'=>$id]);
        } else {
            $data['number'] = $this->next_number($type);
            $data['status'] = 'sent';
            $data['created_by'] = get_current_user_id();
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($this->t('docs'), $data);
            $id = (int) $wpdb->insert_id;
        }
        $wpdb->delete($this->t('lines'), ['doc_id'=>$id]);
        $wpdb->insert($this->t('lines'), [
            'doc_id'=>$id,
            'component'=>$component,
            'basis'=>sanitize_text_field(wp_unslash($_POST['basis'] ?? '')),
            'scope'=>$scope,
            'amount'=>$amount,
            'sac'=>$tax['sac']['code'],
        ]);
        $this->audit('save', 'doc', $id, $type.' '.$data['contact_name']);
        $this->follow_on_subs($id, $data);
        wp_safe_redirect($this->url(['ub'=>'doc','id'=>$id]));
        exit;
    }

    private function next_number($type) {
        global $wpdb;
        $n = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->t('docs')} WHERE doc_type=%s", $type)) + 1;
        $y = current_time('Y');
        $map = ['quote'=>'UC/QK/','proforma'=>'UC/PF/','invoice'=>'UC/INV/','credit_note'=>'UC/CN/','purchase_order'=>'UC/PO/','delivery_note'=>'UC/DN/'];
        $prefix = $map[$type] ?? 'UC/DOC/';
        return $prefix.$y.'/'.str_pad((string)$n, 3, '0', STR_PAD_LEFT);
    }

    public function payment() {
        $this->guard('ub_payment', 'sales');
        global $wpdb;
        $id = absint($_POST['doc_id'] ?? 0);
        $amount = (float) ($_POST['amount'] ?? 0);
        $doc = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('docs')} WHERE id=%d", $id));
        if (!$doc || $amount <= 0) wp_die('Enter an amount.');
        $wpdb->insert($this->t('pays'), [
            'doc_id'=>$id,'amount'=>$amount,'currency'=>$doc->currency,'paid_on'=>current_time('Y-m-d'),
            'method'=>sanitize_text_field(wp_unslash($_POST['method'] ?? '')),'created_by'=>get_current_user_id(),
        ]);
        $paid = (float)$doc->paid + $amount;
        $status = $paid + 0.001 < (float)$doc->total ? 'part_paid' : 'paid';
        $wpdb->update($this->t('docs'), ['paid'=>$paid,'status'=>$status], ['id'=>$id]);
        wp_safe_redirect($this->url(['ub'=>'doc','id'=>$id]));
        exit;
    }

    private function money_options($selected = 'INR') {
        $html = '';
        foreach (['INR','BWP','USD','AED','ZAR'] as $c) $html .= '<option'.selected($selected, $c, false).'>'.$c.'</option>';
        return $html;
    }

    private function student_people($search = '', $limit = 100) {
        $search = trim((string)$search);
        $args = ['number'=>max(1,min(300,(int)$limit)), 'orderby'=>'display_name', 'order'=>'ASC'];
        if ($search !== '') {
            $args['search'] = '*'.esc_attr($search).'*';
            $args['search_columns'] = ['user_login','user_email','display_name'];
        }
        $users = get_users($args);
        $out = [];
        foreach ($users as $user) {
            $roles = strtolower(implode(' ', (array)($user->roles ?? [])));
            $meta_values = [];
            foreach (['ub_role','uc_role','user_type','uc_user_type','account_type','profile_type'] as $key) {
                $value = get_user_meta($user->ID, $key, true);
                if (is_scalar($value) && $value !== '') $meta_values[] = strtolower((string)$value);
            }
            $meta = implode(' ', $meta_values);
            $is_student = (bool)preg_match('/student|learner|subscriber|customer/', $roles.' '.$meta);
            $excluded = (bool)preg_match('/administrator|super.?admin|trainer|instructor|coordinator|editor|author/', $roles.' '.$meta);
            if ($is_student && !$excluded) $out[(int)$user->ID] = $user;
        }
        if (!$out && $search !== '') {
            foreach ($users as $user) {
                $roles = strtolower(implode(' ', (array)($user->roles ?? [])));
                if (!preg_match('/administrator|super.?admin|trainer|instructor|coordinator|editor|author/', $roles)) $out[(int)$user->ID] = $user;
            }
        }
        return array_values($out);
    }

    public function student_lookup() {
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Sign in required.'], 401);
        check_ajax_referer('ub_student_lookup', 'nonce');
        $term = sanitize_text_field(wp_unslash($_GET['term'] ?? ''));
        if (mb_strlen($term) < 2) wp_send_json_success([]);
        $items = [];
        foreach ($this->student_people($term, 25) as $user) {
            $items[] = ['id'=>(int)$user->ID, 'name'=>$this->nice_name($user->display_name), 'email'=>$user->user_email];
        }
        wp_send_json_success($items);
    }

    private function lms_batches() {
        global $wpdb;
        $candidates = [$wpdb->prefix.'uc_batches', $wpdb->prefix.'unicybers_batches', $wpdb->prefix.'uc_lms_batches'];
        $discovered = $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($wpdb->prefix).'%batch%')) ?: [];
        $candidates = array_values(array_unique(array_merge($candidates, $discovered)));
        foreach ($candidates as $table) {
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) continue;
            $columns = $wpdb->get_col("SHOW COLUMNS FROM `$table`", 0) ?: [];
            $name_col = '';
            foreach (['name','batch_name','title','label'] as $candidate) {
                if (in_array($candidate, $columns, true)) { $name_col = $candidate; break; }
            }
            if (!$name_col) continue;
            $id_col = in_array('id', $columns, true) ? 'id' : $name_col;
            $rows = $wpdb->get_results("SELECT `$id_col` AS id, `$name_col` AS name FROM `$table` WHERE `$name_col` <> '' ORDER BY `$name_col`");
            if ($rows) return $rows;
        }
        return [];
    }

    private function view_finance() {
        global $wpdb;
        $owner = $this->can('owner');
        $pay = $wpdb->get_row("SELECT COUNT(*) n, COALESCE(SUM(amount),0) s FROM {$this->t('pays')}");
        $inv = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->t('docs')} WHERE doc_type='invoice'");
        $tpn = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->t('payouts')}");
        $tp = (float) $wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$this->t('payouts')}");
        $html = '<div class="kpis">';
        $html .= '<a class="kpi" style="--k:#2CC4D9" href="#student-ledger"><span class="kpi-ico">'.$this->icon('finance').'</span><div><small>Payments</small><strong>'.(int)($pay->n ?? 0).'</strong><em>Student transactions</em></div></a>';
        $html .= '<a class="kpi" style="--k:#3FC172" href="#student-ledger"><span class="kpi-ico">'.$this->icon('reports').'</span><div><small>Received</small><strong>'.$this->money($pay->s ?? 0).'</strong><em>All currencies combined</em></div></a>';
        $html .= '<a class="kpi" style="--k:#5B93F5" href="'.esc_url($this->url(['ub'=>'invoices'])).'"><span class="kpi-ico">'.$this->icon('invoices').'</span><div><small>Invoices</small><strong>'.$inv.'</strong><em>Issued</em></div></a>';
        if ($owner) $html .= '<a class="kpi" style="--k:#A78BFA" href="#trainer-ledger"><span class="kpi-ico">'.$this->icon('trainers').'</span><div><small>Trainer payouts</small><strong>'.$tpn.'</strong><em>Paid '.$this->money($tp).' combined</em></div></a>';
        $html .= '</div><div class="fin-stack">';
        $students = $this->student_people('', 300);
        $trainers = $this->trainer_people();
        $batches = $this->lms_batches();
        $html .= '<section class="panel"><h3 class="fin-h">Record student payment</h3>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_fin_pay">'.wp_nonce_field('ub_fin_pay','_wpnonce', true, false);
        $html .= '<div class="fin-inline ub-payment-entry"><label class="ub-student-field">Student<input name="contact_name" id="ubStudentName" type="text" placeholder="Search student name" autocomplete="off" required aria-autocomplete="list" aria-controls="ubStudentSuggestions" data-nonce="'.esc_attr(wp_create_nonce('ub_student_lookup')).'"><input type="hidden" name="student_user_id" id="ubStudentId" value=""><div id="ubStudentSuggestions" class="ub-autocomplete" role="listbox" hidden></div></label><label>Email<input type="email" name="contact_email" id="ubStudentEmail" placeholder="Student email"></label>';
        $html .= '<label>Batch<select name="batch_name"><option value="">Not tied to a batch</option>';
        foreach ($batches as $b) $html .= '<option>'.esc_html($b->name).'</option>';
        $html .= '</select></label><label>Amount<input type="number" step="0.01" min="0" name="amount" required></label><label>Currency<select name="currency">'.$this->money_options().'</select></label>';
        $html .= '<label>Tax<select name="tax_percent"><option value="0">No tax</option><option value="5">5%</option><option value="12">12%</option><option value="14">14% VAT</option><option value="18" selected>18% GST</option></select></label>';
        $html .= '<label>Tax label<input name="tax_label" value="GST"></label><label>Method<input name="method" placeholder="Bank transfer, card"></label><label>Reference<input name="reference" placeholder="Optional"></label>';
        $html .= '<div class="fin-act"><button class="btn primary" type="submit">Record payment</button></div></div>';
        $html .= '<div class="fin-sub"><label class="check"><input type="checkbox" name="send_invoice" value="1" checked> Send invoice to student</label></div></form></section>';
        if ($owner) {
            $docs = $wpdb->get_results("SELECT d.id, d.number, d.contact_name, d.currency, d.total, d.subtotal, d.tax_rate, d.paid, d.doc_date, d.notes FROM {$this->t('docs')} d WHERE d.doc_type='invoice' AND (d.paid > 0 OR EXISTS (SELECT 1 FROM {$this->t('pays')} p WHERE p.doc_id=d.id)) ORDER BY d.id DESC LIMIT 200");
            $html .= '<section class="panel"><h3 class="fin-h">Record trainer share</h3>';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" id="finShare"><input type="hidden" name="action" value="ub_fin_share">'.wp_nonce_field('ub_fin_share','_wpnonce', true, false);
            $html .= '<div class="fin-inline"><label>Trainer<select name="trainer_user_id" required><option value="">Select trainer</option>';
            foreach ($trainers as $u) $html .= '<option value="'.(int)$u->ID.'">'.esc_html($this->nice_name($u->display_name)).'</option>';
            $html .= '</select></label><label>Batch<select name="batch_name"><option value="">All batches</option>';
            foreach ($batches as $b) $html .= '<option>'.esc_html($b->name).'</option>';
            $html .= '</select></label><label>Student payment<select name="doc_id" class="calc-base" required><option value="">Select payment</option>';
            foreach ($docs as $d) $html .= '<option value="'.(int)$d->id.'" data-amt="'.esc_attr($d->subtotal > 0 ? $d->subtotal : $d->total).'" data-fee="'.esc_attr($d->paid > 0 ? $d->paid : $d->total).'">'.esc_html($this->nice_name($d->contact_name).' · '.($d->number ?: 'Invoice').' · '.($d->doc_date ? mysql2date('d M Y', $d->doc_date) : 'Date not set').' · '.$d->currency.' '.$this->money($d->paid > 0 ? $d->paid : $d->total)).'</option>';
            $html .= '</select></label><label class="fin-pct">Trainer share %<input type="number" step="0.1" min="0" max="100" name="share_percent" class="calc-pct2" value="60" required></label>';
            $html .= '<label>Trainer earning<input class="calc-earn" readonly placeholder="Auto calculated"></label>';
            $html .= '<label>Payment date<input type="date" name="paid_on" value="'.esc_attr(current_time('Y-m-d')).'"></label>';
            $html .= '<div class="fin-act"><button class="btn primary" type="submit">Record share</button></div></div></form>';
            $html .= '<script>(function(){var f=document.getElementById("finShare");if(!f)return;function calc(){var o=f.querySelector(".calc-base"),p=f.querySelector(".calc-pct2"),e=f.querySelector(".calc-earn");if(!o||!p||!e)return;var opt=o.options[o.selectedIndex];var base=opt?parseFloat(opt.getAttribute("data-amt")||"0"):0;var pct=parseFloat(p.value||"0");e.value=isFinite(base*pct)?(base*pct/100).toFixed(2):""}f.addEventListener("input",calc);f.addEventListener("change",calc)})();</script></section>';
            $html .= '<section class="panel"><h3 class="fin-h">Record trainer payment</h3>';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_payout"><input type="hidden" name="back" value="finance">'.wp_nonce_field('ub_payout','_wpnonce', true, false);
            $html .= '<div class="fin-inline"><label>Trainer<select name="trainer_user_id" required><option value="">Select a trainer</option>';
            foreach ($trainers as $u) $html .= '<option value="'.(int)$u->ID.'">'.esc_html($this->nice_name($u->display_name)).'</option>';
            $html .= '</select></label><label class="fin-curr">Currency<select name="currency">'.$this->money_options().'</select></label>';
            $html .= '<label class="fin-amt">Amount<input type="number" step="0.01" min="0" name="amount" required></label><label>Method<input name="method" placeholder="Bank transfer, card"></label>';
            $html .= '<label>Reference<input name="reference" placeholder="Optional"></label><label>Notes<input name="note" placeholder="Optional"></label>';
            $html .= '<div class="fin-act"><button class="btn primary" type="submit">Record payment</button></div></div></form></section>';
            $html .= $this->finance_payout_ledger();
            $html .= '<section class="panel"><h3 class="fin-h">Record expense</h3>';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_fin_expense">'.wp_nonce_field('ub_fin_expense','_wpnonce', true, false);
            $html .= '<div class="fin-inline"><label>Category<select name="category">';
            foreach (['Rent','Power','Internet','Labs','LMS','Materials','Trainer advance','Travel','Software','Other'] as $c) $html .= '<option>'.$c.'</option>';
            $html .= '</select></label><label>Title<input name="title" required placeholder="September internet, SOC labs"></label>';
            $html .= '<label class="fin-amt">Amount<input type="number" step="0.01" min="0" name="amount" required></label><label class="fin-curr">Currency<select name="currency">'.$this->money_options().'</select></label>';
            $html .= '<label>Date<input type="date" name="spent_on" value="'.esc_attr(current_time('Y-m-d')).'"></label>';
            $html .= '<label>Method<input name="method" placeholder="UPI, cash, card"></label><label>Notes<input name="notes" placeholder="Optional"></label>';
            $html .= '<div class="fin-act"><button class="btn primary" type="submit">Record expense</button></div></div></form></section>';
            $html .= $this->finance_expense_ledger();
        }
        $html .= $this->finance_payment_ledger();
        if ($owner) $html .= $this->finance_balance();
        return $html.'</div>';
    }

    private function finance_payment_ledger() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT p.*, d.number, d.contact_name FROM {$this->t('pays')} p LEFT JOIN {$this->t('docs')} d ON d.id=p.doc_id ORDER BY p.id DESC LIMIT 80") ?: [];
        $html = '<section class="panel flush" id="student-ledger"><h3 class="fin-h fin-h-pad">Student payment ledger <span class="count">'.count($rows).'</span></h3><div class="table-wrap"><table class="ub-table"><thead><tr><th>Date</th><th>Student</th><th>Amount</th><th>Invoice</th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="4"><p class="empty">No payments recorded yet. Payments you record above appear here.</p></td></tr>';
        foreach ($rows as $r) {
            $html .= '<tr><td>'.esc_html($this->nice_day($r->paid_on)).'</td><td><strong>'.esc_html($this->nice_name($r->contact_name) ?: '-').'</strong></td>';
            $html .= '<td>'.esc_html($r->currency).' '.$this->money($r->amount).'</td><td>';
            $html .= $r->number ? '<a href="'.esc_url($this->url(['ub'=>'doc','id'=>(int)$r->doc_id,'mode'=>'view'])).'">'.esc_html($r->number).'</a>' : '-';
            $html .= '</td></tr>';
        }
        return $html.'</tbody></table></div></section>';
    }

    private function finance_payout_ledger() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('payouts')} ORDER BY id DESC LIMIT 80") ?: [];
        $html = '<section class="panel flush" id="trainer-ledger"><h3 class="fin-h fin-h-pad">Trainer payment ledger <span class="count">'.count($rows).'</span></h3><div class="table-wrap"><table class="ub-table"><thead><tr><th>Date</th><th>Trainer</th><th>Amount</th><th>Note</th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="4"><p class="empty">No trainer payouts yet. Record a trainer payment above and it lands here.</p></td></tr>';
        foreach ($rows as $r) {
            $html .= '<tr><td>'.esc_html($this->nice_day($r->paid_on ?? '')).'</td><td><strong>'.esc_html($this->nice_name($r->trainer_name)).'</strong></td>';
            $html .= '<td>'.esc_html($r->currency).' '.$this->money($r->amount).'</td><td>'.esc_html($r->note ?: '-').'</td></tr>';
        }
        return $html.'</tbody></table></div></section>';
    }

    private function finance_expense_ledger() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('expenses')} ORDER BY id DESC LIMIT 40") ?: [];
        $html = '<section class="panel flush"><h3 class="fin-h fin-h-pad">Expense ledger <span class="count">'.count($rows).'</span></h3><div class="table-wrap"><table class="ub-table"><thead><tr><th>Date</th><th>What</th><th>Category</th><th>Amount</th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="4"><p class="empty">No expenses yet. Rent, labs, LMS and trainer advances you record above appear here.</p></td></tr>';
        foreach ($rows as $r) {
            $html .= '<tr><td>'.esc_html($this->nice_day($r->spent_on)).'</td><td><strong>'.esc_html($r->title).'</strong></td><td>'.esc_html(ucfirst((string)$r->category)).'</td>';
            $html .= '<td>'.esc_html($r->currency).' '.$this->money($r->amount).'</td></tr>';
        }
        return $html.'</tbody></table></div></section>';
    }

    private function finance_balance() {
        $rows = $this->trainer_balances();
        $html = '<section class="panel flush"><h3 class="fin-h fin-h-pad">Trainer balance</h3><div class="table-wrap"><table class="ub-table"><thead><tr><th>Trainer</th><th>Currency</th><th>Earned</th><th>Paid</th><th>Expenses</th><th>Outstanding</th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="6"><p class="empty">A balance appears once a trainer share is recorded.</p></td></tr>';
        foreach ($rows as $r) {
            $html .= '<tr><td><strong>'.esc_html($this->nice_name($r['name'])).'</strong></td><td>'.esc_html($r['cur']).'</td>';
            $html .= '<td>'.$this->money($r['earned']).'</td><td>'.$this->money($r['paid']).'</td><td>'.$this->money($r['expenses']).'</td><td><b>'.$this->money($r['owed']).'</b></td></tr>';
        }
        return $html.'</tbody></table></div></section>';
    }

    public function fin_pay() {
        $this->guard('ub_fin_pay', 'sales');
        global $wpdb;
        $name = sanitize_text_field(wp_unslash($_POST['contact_name'] ?? ''));
        $uid = absint($_POST['student_user_id'] ?? 0);
        $user = $uid ? get_userdata($uid) : null;
        if (!$user && $name !== '') {
            foreach ($this->student_people($name, 100) as $candidate) {
                if (strcasecmp($this->nice_name($candidate->display_name), $name) === 0) { $user = $candidate; $uid = (int)$candidate->ID; break; }
            }
        }
        if ($user) $name = $user->display_name;
        $email = $user ? $user->user_email : sanitize_email(wp_unslash($_POST['contact_email'] ?? ''));
        if ($name === '') wp_die('Choose a student.');
        $fee = (float) ($_POST['amount'] ?? 0);
        if ($fee <= 0) wp_die('Enter an amount.');
        $rate = (float) ($_POST['tax_percent'] ?? 0);
        $tax = round($fee * $rate / 100, 2);
        $half = round($tax / 2, 2);
        $total = round($fee + $tax, 2);
        $cur = sanitize_text_field(wp_unslash($_POST['currency'] ?? 'INR')) ?: 'INR';
        $batch = sanitize_text_field(wp_unslash($_POST['batch_name'] ?? ''));
        $method = sanitize_text_field(wp_unslash($_POST['method'] ?? ''));
        $ref = sanitize_text_field(wp_unslash($_POST['reference'] ?? ''));
        $label = sanitize_text_field(wp_unslash($_POST['tax_label'] ?? 'GST')) ?: 'GST';
        $wpdb->insert($this->t('docs'), [
            'doc_type'=>'invoice','number'=>$this->next_number('invoice'),'status'=>'paid',
            'contact_name'=>$name,'contact_email'=>$email,'contact_country'=>'India','currency'=>$cur,
            'supply'=>$rate > 0 ? 'domestic' : 'no_gst','price_mode'=>'excl','tax_rate'=>$rate,
            'subtotal'=>$fee,'cgst'=>$rate > 0 ? $half : 0,'sgst'=>$rate > 0 ? ($tax - $half) : 0,'igst'=>0,
            'total'=>$total,'paid'=>$total,'doc_date'=>current_time('Y-m-d'),
            'notes'=>trim($label.($batch !== '' ? ' - '.$batch : '').($ref !== '' ? ' - '.$ref : '')),
            'customer_type'=>'individual','sac'=>'999293','source'=>'finance','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),
        ]);
        $id = (int) $wpdb->insert_id;
        $wpdb->insert($this->t('lines'), ['doc_id'=>$id,'component'=>'Training fee','basis'=>'One time','scope'=>$batch,'amount'=>$fee,'sac'=>'999293']);
        $wpdb->insert($this->t('pays'), [
            'doc_id'=>$id,'amount'=>$total,'currency'=>$cur,'paid_on'=>current_time('Y-m-d'),
            'method'=>$method,'reference'=>$ref,'created_by'=>get_current_user_id(),
        ]);
        if (!empty($_POST['send_invoice']) && $email) {
            wp_mail($email, 'UniCybers Books - invoice', "Invoice for {$name}\n{$cur} ".$this->money($total)."\nOpen Books to print the PDF.", ['Cc: rafi@unicybers.com', 'From: UniCybers Books <info@unicybers.com>']);
        }
        wp_safe_redirect($this->url(['ub'=>'finance']));
        exit;
    }

    public function fin_share() {
        $this->guard('ub_fin_share', 'trainer_pay');
        global $wpdb;
        $uid = absint($_POST['trainer_user_id'] ?? 0);
        $user = get_userdata($uid);
        if (!$user) wp_die('Choose a trainer.');
        $doc_id = absint($_POST['doc_id'] ?? 0);
        $doc = $doc_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('docs')} WHERE id=%d", $doc_id)) : null;
        if (!$doc) wp_die('Choose a student payment.');
        $percent = (float) ($_POST['share_percent'] ?? 0);
        $fee = (float) $doc->total;
        $base = (float) $doc->subtotal > 0 ? (float) $doc->subtotal : $fee;
        $earned = round($base * $percent / 100, 2);
        $batch = sanitize_text_field(wp_unslash($_POST['batch_name'] ?? ''));
        if ($batch === '') $batch = $doc->number ?: 'Invoice';
        $wpdb->insert($this->t('shares'), [
            'trainer_name'=>$user->display_name,'trainer_user_id'=>$uid,'batch_name'=>$batch,'doc_id'=>$doc_id,
            'currency'=>$doc->currency,'fee_received'=>$fee,'fee_base'=>$base,'share_percent'=>$percent,'earned'=>$earned,'expenses'=>0,'note'=>'pre_gst',
        ]);
        $body = "Batch: {$batch}\nAmount received: {$doc->currency} ".$this->money($fee)."\nShare base: {$doc->currency} ".$this->money($base)."\nPercent: {$percent}\nNet share: {$doc->currency} ".$this->money($earned)."\n";
        wp_mail($user->user_email, 'UniCybers Books - trainer share', $body, ['Cc: rafi@unicybers.com', 'From: UniCybers Books <info@unicybers.com>']);
        wp_safe_redirect($this->url(['ub'=>'finance']));
        exit;
    }

    public function fin_expense() {
        $this->guard('ub_fin_expense', 'expenses');
        global $wpdb;
        $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        $amount = (float) ($_POST['amount'] ?? 0);
        if ($title === '' || $amount <= 0) wp_die('Type the expense and the amount.');
        $cat = sanitize_title(wp_unslash($_POST['category'] ?? 'other'));
        $method = sanitize_text_field(wp_unslash($_POST['method'] ?? ''));
        $notes = sanitize_text_field(wp_unslash($_POST['notes'] ?? ''));
        $wpdb->insert($this->t('expenses'), [
            'title'=>$title,'category'=>$cat ?: 'other','amount'=>$amount,
            'currency'=>sanitize_text_field(wp_unslash($_POST['currency'] ?? 'INR')) ?: 'INR',
            'spent_on'=>sanitize_text_field(wp_unslash($_POST['spent_on'] ?? '')) ?: current_time('Y-m-d'),
            'notes'=>trim($method.($notes !== '' ? ' - '.$notes : '')),
            'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),
        ]);
        wp_safe_redirect($this->url(['ub'=>'finance']));
        exit;
    }

    private function view_expenses() {
        $this->post_due_recurring();
        $id = absint($_GET['id'] ?? 0);
        $edit = isset($_GET['edit']) ? sanitize_text_field(wp_unslash($_GET['edit'])) : '';
        if ($id && $edit === '') return $this->expense_view($id);
        if ($edit !== '') return $this->expense_form($edit === 'new' ? 0 : absint($edit));
        return $this->expense_list();
    }

    private function expense_list() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('expenses')} ORDER BY id DESC LIMIT 80");
        $html = $this->recurring_panel();
        $html .= '<div class="actions" style="margin:12px 0"><a class="btn primary" href="'.esc_url($this->url(['ub'=>'expenses','edit'=>'new'])).'">Add expense</a></div>';
        $html .= '<div class="ub-card"><table class="ub-table"><thead><tr><th>Date</th><th>What</th><th>Supplier</th><th>Amount</th><th>2B</th><th></th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="6"><p class="empty">No expenses yet. Add one and upload the supplier invoice if you have it.</p></td></tr>';
        foreach ($rows as $r) {
            $html .= '<tr><td data-l="Date">'.esc_html($r->spent_on).'</td><td data-l="What"><strong>'.esc_html($r->title).'</strong></td>';
            $html .= '<td data-l="Supplier">'.esc_html($r->vendor ?: '-').'</td><td data-l="Amount">'.esc_html($r->currency).' '.$this->money($r->amount).'</td><td data-l="2B">';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_match"><input type="hidden" name="id" value="'.(int)$r->id.'">'.wp_nonce_field('ub_match','_wpnonce', true, false);
            if (!empty($r->matched_2b)) $html .= '<input type="hidden" name="on" value="0"><button class="btn sm" type="submit">Matched</button>';
            else $html .= '<input type="hidden" name="on" value="1"><button class="btn sm" type="submit">Not on 2B</button>';
            $html .= '</form></td><td data-l="Open"><a class="btn sm" href="'.esc_url($this->url(['ub'=>'expenses','id'=>(int)$r->id])).'">View</a> ';
            $html .= '<a class="btn sm" href="'.esc_url($this->url(['ub'=>'expenses','edit'=>(int)$r->id])).'">Edit</a></td></tr>';
        }
        return $html.'</tbody></table></div>';
    }

    private function expense_blank() {
        return [
            'title'=>'','category'=>'other','vendor'=>'','vendor_gstin'=>'','bill_number'=>'',
            'spent_on'=>current_time('Y-m-d'),'taxable'=>'','tax_rate'=>'','cgst'=>'','sgst'=>'','igst'=>'',
            'amount'=>'','sac'=>'','currency'=>'INR','itc'=>'1',
        ];
    }

    private function expense_form($id) {
        global $wpdb;
        $row = $id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('expenses')} WHERE id=%d", $id)) : null;
        if ($id && !$row) return '<div class="ub-card"><p class="empty">That expense is not on the list. Add a new one.</p></div>';
        $vals = $this->expense_blank();
        if ($row) {
            foreach ($vals as $k => $v) {
                if (!isset($row->$k)) continue;
                $vals[$k] = ($row->$k === null || $row->$k === '') ? '' : (string) $row->$k;
            }
            foreach (['taxable','tax_rate','cgst','sgst','igst','amount'] as $k) {
                if (isset($row->$k) && (float)$row->$k == 0) $vals[$k] = '';
            }
            if ((float)$row->amount > 0) $vals['amount'] = (string) $row->amount;
        }
        $token = sanitize_text_field(wp_unslash($_GET['bill'] ?? ''));
        $stash = ($token !== '') ? get_transient('ub_bill_'.$token) : false;
        $missing = [];
        $notice = '';
        if (is_array($stash) && (int)($stash['user'] ?? 0) === get_current_user_id()) {
            $notice = (string)($stash['notice'] ?? '');
            $missing = (array)($stash['missing'] ?? []);
            foreach ((array)($stash['fields'] ?? []) as $k => $v) {
                if ($v === null || $v === '') continue;
                $vals[$k] = (string) $v;
            }
            if (in_array('spent_on', $missing, true)) $vals['spent_on'] = '';
        } else {
            $token = '';
        }
        $ph = 'Could not read - type it';
        $cats = ['rent'=>'Rent','salary'=>'Salary','internet'=>'Internet','power'=>'Power','hosting'=>'Hosting','software'=>'Software','labs'=>'Labs','marketing'=>'Marketing','bank'=>'Bank Charges','professional'=>'Professional Fees','travel'=>'Travel','repairs'=>'Repairs','trainer'=>'Trainer Advance','other'=>'Other'];
        $html = '<p class="actions"><a class="btn sm" href="'.esc_url($this->url(['ub'=>'expenses'])).'">Back to expenses</a></p>';
        $html .= '<form class="ub-card ub-form" id="ubExpense" method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<h2>'.($id ? 'Edit expense' : 'Add an expense').'</h2>';
        $html .= '<p>Upload the supplier invoice as a PDF, JPG, JPEG, PNG, or WEBP. Press Read invoice, check the figures, then save. A photo is kept with the expense. Books does not send the file anywhere.</p>';
        $html .= '<input type="hidden" name="expense_id" value="'.(int)$id.'">';
        $html .= '<input type="hidden" name="bill_token" value="'.esc_attr($token).'">';
        $html .= wp_nonce_field('ub_expense','_wpnonce', true, false);
        $html .= wp_nonce_field('ub_bill_read','_ub_bill_nonce', true, false);
        $html .= '<label>Supplier invoice<input type="file" name="bill" accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"></label>';
        if ($row && !empty($row->attachment_name)) {
            $html .= '<p>Current file: '.esc_html($row->attachment_name).' · <a href="'.esc_url($this->bill_link((int)$row->id)).'">Download</a></p>';
        }
        $html .= '<button class="btn" type="submit" name="action" value="ub_bill_read">Read invoice</button>';
        if ($notice !== '' || $token !== '') $html .= $this->bill_card($vals, $missing, $notice);
        $html .= '<div class="ub-2"><label>What<input name="title" value="'.esc_attr($vals['title']).'" placeholder="'.esc_attr(in_array('title', $missing, true) ? $ph : 'October hosting').'"></label>';
        $html .= '<label>Category<select name="category">';
        foreach ($cats as $k=>$l) $html .= '<option value="'.$k.'"'.selected($vals['category'], $k, false).'>'.$l.'</option>';
        $html .= '</select></label></div>';
        $html .= '<div class="ub-2"><label>Supplier<input name="vendor" value="'.esc_attr($vals['vendor']).'" placeholder="'.esc_attr(in_array('vendor', $missing, true) ? $ph : 'Supplier name').'"></label>';
        $html .= '<label>Supplier GSTIN<input name="vendor_gstin" value="'.esc_attr($vals['vendor_gstin']).'" placeholder="'.esc_attr(in_array('vendor_gstin', $missing, true) ? $ph : '15 characters').'"></label></div>';
        $html .= '<div class="ub-2"><label>Supplier invoice number<input name="bill_number" value="'.esc_attr($vals['bill_number']).'" placeholder="'.esc_attr(in_array('bill_number', $missing, true) ? $ph : '').'"></label>';
        $html .= '<label>Invoice date<input type="date" name="spent_on" value="'.esc_attr($vals['spent_on']).'"></label></div>';
        $html .= '<div class="ub-2"><label>Taxable value<input type="number" step="0.01" name="taxable" value="'.esc_attr($vals['taxable']).'" placeholder="'.esc_attr(in_array('taxable', $missing, true) ? $ph : '').'"></label>';
        $html .= '<label>GST %<input type="number" step="0.01" name="tax_rate" value="'.esc_attr($vals['tax_rate']).'" placeholder="'.esc_attr(in_array('tax_rate', $missing, true) ? $ph : '').'"></label></div>';
        $html .= '<div class="ub-2"><label>CGST<input type="number" step="0.01" name="cgst" value="'.esc_attr($vals['cgst']).'" placeholder="'.esc_attr(in_array('cgst', $missing, true) ? $ph : '').'"></label>';
        $html .= '<label>SGST<input type="number" step="0.01" name="sgst" value="'.esc_attr($vals['sgst']).'" placeholder="'.esc_attr(in_array('sgst', $missing, true) ? $ph : '').'"></label></div>';
        $html .= '<div class="ub-2"><label>IGST<input type="number" step="0.01" name="igst" value="'.esc_attr($vals['igst']).'" placeholder="'.esc_attr(in_array('igst', $missing, true) ? $ph : '').'"></label>';
        $html .= '<label>Total<input type="number" step="0.01" name="amount" value="'.esc_attr($vals['amount']).'" placeholder="'.esc_attr(in_array('amount', $missing, true) ? $ph : '').'"></label></div>';
        $html .= '<div class="ub-2"><label>SAC or HSN<input name="sac" value="'.esc_attr($vals['sac']).'" placeholder="'.esc_attr(in_array('sac', $missing, true) ? $ph : 'If the bill prints one').'"></label>';
        $html .= '<label>Currency<select name="currency">';
        foreach (['INR','USD','AED','BWP'] as $cur) $html .= '<option'.selected($vals['currency'], $cur, false).'>'.$cur.'</option>';
        $html .= '</select></label></div>';
        $html .= '<label><input type="checkbox" name="itc" value="1"'.checked($vals['itc'], '1', false).'> Eligible to claim as input GST</label>';
        $html .= '<button class="btn primary" type="submit" name="action" value="ub_expense">Save expense</button></form>';
        return $html;
    }

    private function bill_card($vals, $missing, $notice) {
        $rows = [
            'vendor'=>'Supplier','vendor_gstin'=>'Supplier GSTIN','bill_number'=>'Invoice number','spent_on'=>'Invoice date',
            'taxable'=>'Taxable value','tax_rate'=>'GST %','cgst'=>'CGST','sgst'=>'SGST','igst'=>'IGST','amount'=>'Total','sac'=>'SAC / HSN',
        ];
        $html = '<article class="bill-card"><h3>Read from the invoice</h3>';
        if ($notice !== '') $html .= '<p>'.esc_html($notice).'</p>';
        $html .= '<ul>';
        foreach ($rows as $k => $label) {
            $known = !in_array($k, $missing, true) && isset($vals[$k]) && $vals[$k] !== '';
            $html .= '<li><span>'.esc_html($label).'</span> ';
            $html .= $known ? '<strong>'.esc_html($vals[$k]).'</strong>' : '<em>Could not read - type it</em>';
            $html .= '</li>';
        }
        $html .= '</ul><p>Check these, change anything wrong, then save. Nothing here is filed.</p></article>';
        return $html;
    }

    private function expense_view($id) {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('expenses')} WHERE id=%d", $id));
        if (!$row) return '<div class="ub-card"><p class="empty">That expense is not on the list.</p></div>';
        $html = '<p class="actions"><a class="btn sm" href="'.esc_url($this->url(['ub'=>'expenses'])).'">Back</a> <a class="btn sm" href="'.esc_url($this->url(['ub'=>'expenses','edit'=>$id])).'">Edit</a></p>';
        $html .= '<article class="ub-card bill-view"><h2>'.esc_html($row->title).'</h2><dl>';
        $pairs = [
            'Supplier' => $row->vendor, 'GSTIN' => $row->vendor_gstin, 'Invoice number' => $row->bill_number,
            'Date' => $row->spent_on,             'Taxable value' => (isset($row->taxable) && (float)$row->taxable > 0) ? $this->money($row->taxable) : '-',
            'GST %' => (float)$row->tax_rate > 0 ? $row->tax_rate : '-', 'CGST' => (float)($row->cgst ?? 0) > 0 ? $this->money($row->cgst) : '-', 'SGST' => (float)($row->sgst ?? 0) > 0 ? $this->money($row->sgst) : '-',
            'IGST' => (float)($row->igst ?? 0) > 0 ? $this->money($row->igst) : '-', 'GST amount' => ((float)($row->cgst ?? 0) + (float)($row->sgst ?? 0) + (float)($row->igst ?? 0)) > 0 ? $this->money((float)$row->cgst + (float)$row->sgst + (float)$row->igst) : '-',
            'Total' => $row->currency.' '.$this->money($row->amount), 'SAC / HSN' => $row->sac ?? '',
            'Claim input GST' => !empty($row->itc) ? 'Yes' : 'No',
        ];
        foreach ($pairs as $label => $value) {
            $html .= '<div><dt>'.esc_html($label).'</dt><dd>'.esc_html($value !== '' && $value !== null ? $value : '-').'</dd></div>';
        }
        $html .= '</dl>';
        if (!empty($row->attachment_name)) {
            $html .= '<p><strong>Supplier invoice</strong><br>'.esc_html($row->attachment_name).'<br><a class="btn sm" href="'.esc_url($this->bill_link((int)$row->id)).'">Download</a></p>';
        } else {
            $html .= '<p class="empty">No supplier invoice is attached. Edit the expense to upload one.</p>';
        }
        return $html.'</article>';
    }

    private function expense_taxable($e) {
        if (isset($e->taxable) && (float)$e->taxable > 0) return (float)$e->taxable;
        return (float)$e->amount;
    }

    private function expense_gst($e) {
        $gst = (float)($e->cgst ?? 0) + (float)($e->sgst ?? 0) + (float)($e->igst ?? 0);
        if ($gst > 0) return $gst;
        $rate = (float)($e->tax_rate ?? 0);
        if ($rate > 0) return $this->expense_taxable($e) * $rate / 100;
        return 0;
    }

    private function bill_dir() {
        $uploads = wp_upload_dir();
        $dir = trailingslashit($uploads['basedir']).'unicybers-books-private';
        if (!is_dir($dir)) wp_mkdir_p($dir);
        if (is_dir($dir) && !file_exists($dir.'/.htaccess')) {
            file_put_contents($dir.'/.htaccess', "Deny from all\n");
            file_put_contents($dir.'/index.php', "<?php\n// Private supplier invoices.\n");
        }
        return $dir;
    }

    private function bill_link($id) {
        return wp_nonce_url(admin_url('admin-post.php?action=ub_bill_file&id='.(int)$id), 'ub_bill_file_'.$id);
    }

    public function bill_file() {
        if (!$this->can('owner')) wp_die('Not allowed.', 403);
        $id = absint($_GET['id'] ?? 0);
        if (!$id || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? '')), 'ub_bill_file_'.$id)) wp_die('Form expired.');
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('expenses')} WHERE id=%d", $id));
        $file = $row ? basename((string)$row->attachment) : '';
        $path = $file !== '' ? $this->bill_dir().'/'.$file : '';
        if (!$row || $file === '' || !is_file($path)) wp_die('That file is not on this expense.');
        $type = 'application/octet-stream';
        if (function_exists('mime_content_type')) {
            $found = mime_content_type($path);
            if (is_string($found) && $found !== '') $type = $found;
        }
        $name = $row->attachment_name ?: $file;
        nocache_headers();
        header('Content-Type: '.$type);
        header('Content-Disposition: attachment; filename="'.rawurlencode($name).'"');
        header('Content-Length: '.filesize($path));
        header('X-Robots-Tag: noindex, nofollow');
        readfile($path);
        exit;
    }

    public function bill_read() {
        if (!$this->can('owner') || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_ub_bill_nonce'] ?? '')), 'ub_bill_read')) wp_die('Not allowed.', 403);
        $id = absint($_POST['expense_id'] ?? 0);
        $stored = $this->store_bill_upload();
        if (is_wp_error($stored)) wp_die(esc_html($stored->get_error_message()));
        $read = $this->read_supplier_bill($stored['path'], $stored['ext']);
        $fields = $this->posted_expense_fields();
        $missing = [];
        foreach ($read['fields'] as $k => $v) {
            if ($v === null || $v === '') {
                $missing[] = $k;
                if ($k === 'spent_on') $fields[$k] = '';
            } else {
                $fields[$k] = $v;
            }
        }
        if ($fields['title'] === '' && !empty($fields['vendor'])) $fields['title'] = $fields['vendor'];
        $token = wp_generate_password(16, false, false);
        set_transient('ub_bill_'.$token, [
            'user' => get_current_user_id(),
            'file' => $stored['file'],
            'original' => $stored['original'],
            'notice' => $read['notice'],
            'fields' => $fields,
            'missing' => $missing,
        ], HOUR_IN_SECONDS);
        wp_safe_redirect($this->url(['ub'=>'expenses','edit'=>$id ? $id : 'new','bill'=>$token]));
        exit;
    }

    private function posted_expense_fields() {
        $vals = $this->expense_blank();
        $vals['title'] = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        $vals['category'] = sanitize_key($_POST['category'] ?? 'other');
        $vals['vendor'] = sanitize_text_field(wp_unslash($_POST['vendor'] ?? ''));
        $vals['vendor_gstin'] = strtoupper(sanitize_text_field(wp_unslash($_POST['vendor_gstin'] ?? '')));
        $vals['bill_number'] = sanitize_text_field(wp_unslash($_POST['bill_number'] ?? ''));
        $vals['spent_on'] = sanitize_text_field($_POST['spent_on'] ?? '');
        $vals['sac'] = preg_replace('/\D/', '', (string)($_POST['sac'] ?? ''));
        $vals['currency'] = sanitize_text_field($_POST['currency'] ?? 'INR') ?: 'INR';
        $vals['itc'] = empty($_POST['itc']) ? '0' : '1';
        foreach (['taxable','tax_rate','cgst','sgst','igst','amount'] as $k) {
            $raw = trim((string) wp_unslash($_POST[$k] ?? ''));
            $vals[$k] = $raw === '' ? '' : (string) (float) $raw;
        }
        return $vals;
    }

    private function store_bill_upload() {
        if (empty($_FILES['bill']['name'])) return new WP_Error('ub_bill', 'Choose the supplier invoice first.');
        $orig = sanitize_file_name(wp_unslash($_FILES['bill']['name']));
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $allowed = ['pdf'=>'application/pdf','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'];
        if (!isset($allowed[$ext])) return new WP_Error('ub_bill', 'Use a PDF, JPG, JPEG, PNG, or WEBP file.');
        if (!empty($_FILES['bill']['size']) && (int)$_FILES['bill']['size'] > 8 * 1024 * 1024) return new WP_Error('ub_bill', 'That file is larger than 8 MB.');
        $tmp = $_FILES['bill']['tmp_name'] ?? '';
        if (!$tmp || !is_uploaded_file($tmp)) return new WP_Error('ub_bill', 'The upload did not arrive. Try again.');
        $mime = '';
        if (function_exists('finfo_open')) {
            $fi = finfo_open(FILEINFO_MIME_TYPE);
            if ($fi) { $mime = (string) finfo_file($fi, $tmp); finfo_close($fi); }
        }
        if ($mime !== '' && $mime !== $allowed[$ext]) return new WP_Error('ub_bill', 'That file is not a PDF or an image.');
        $dir = $this->bill_dir();
        $file = wp_generate_password(20, false, false).'.'.$ext;
        $path = $dir.'/'.$file;
        if (!move_uploaded_file($tmp, $path)) return new WP_Error('ub_bill', 'The file could not be stored.');
        return ['file'=>$file,'path'=>$path,'ext'=>$ext,'original'=>$orig];
    }

    private function read_supplier_bill($path, $ext) {
        $empty = [
            'vendor'=>null,'vendor_gstin'=>null,'bill_number'=>null,'spent_on'=>null,'taxable'=>null,
            'tax_rate'=>null,'cgst'=>null,'sgst'=>null,'igst'=>null,'amount'=>null,'sac'=>null,
        ];
        if ($ext !== 'pdf') {
            return ['notice'=>'This scan has no text layer - type the GST figures', 'fields'=>$empty];
        }
        $text = $this->pdf_text((string) file_get_contents($path));
        $letters = preg_replace('/[^A-Za-z0-9]/', '', $text);
        if (!is_string($letters) || strlen($letters) < 20) {
            return ['notice'=>'This scan has no text layer - type the GST figures', 'fields'=>$empty];
        }
        $fields = $empty;
        $firm = strtoupper((string)($this->company()['gstin'] ?? ''));
        if (preg_match_all('/\b([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][A-Z0-9]Z[A-Z0-9])\b/', strtoupper($text), $gs)) {
            foreach ($gs[1] as $g) {
                if ($firm !== '' && $g === $firm) continue;
                $fields['vendor_gstin'] = $g;
                break;
            }
        }
        if (preg_match('/(?:supplier|seller|billed\s+by|bill\s+from)\s*[:\-]\s*([A-Z][A-Za-z0-9 .,&\-]{2,80})/', $text, $m)) {
            $fields['vendor'] = trim($m[1]);
        }
        if (preg_match('/(?:invoice|bill)\s*(?:no\.?|number|#)\s*[:\-]?\s*([A-Z0-9][A-Z0-9\/\-]{1,40})/i', $text, $m)) {
            $fields['bill_number'] = trim($m[1]);
        }
        if (preg_match('/(?:invoice\s*date|bill\s*date|dated)\s*[:\-]?\s*(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{4}[\/\-.]\d{1,2}[\/\-.]\d{1,2})/i', $text, $m)) {
            $fields['spent_on'] = $this->normal_date($m[1]);
        }
        $fields['taxable'] = $this->labeled_amount($text, 'taxable\s*(?:value|amount)');
        $fields['cgst'] = $this->labeled_amount($text, 'c\.?\s*gst|central\s+tax');
        $fields['sgst'] = $this->labeled_amount($text, 's\.?\s*gst|state\s+tax');
        $fields['igst'] = $this->labeled_amount($text, 'i\.?\s*gst|integrated\s+tax');
        $fields['amount'] = $this->labeled_amount($text, 'grand\s+total|invoice\s+total|total\s+amount|amount\s+payable|net\s+payable');
        if (preg_match('/(?<![\w])(?:gst|tax)\s*@\s*(\d{1,2}(?:\.\d{1,2})?)\s*%/i', $text, $m)) {
            $fields['tax_rate'] = (float) $m[1];
        }
        if (preg_match('/(?:HSN|SAC)(?:\s*\/\s*(?:HSN|SAC))?\s*[:\-]?\s*(\d{4,8})/i', $text, $m)) {
            $fields['sac'] = $m[1];
        }
        $gstAmt = $this->labeled_amount($text, '(?<![\w])gst|tax\s+amount');
        $splitMissing = $fields['cgst'] === null && $fields['sgst'] === null && $fields['igst'] === null;
        $code = $fields['vendor_gstin'] ? substr($fields['vendor_gstin'], 0, 2) : '';
        if ($splitMissing && $gstAmt !== null && $gstAmt > 0 && $fields['tax_rate'] !== null && $code !== '') {
            if ($code === '37') {
                $half = round($gstAmt / 2, 2);
                $fields['cgst'] = $half;
                $fields['sgst'] = round($gstAmt - $half, 2);
            } else {
                $fields['igst'] = $gstAmt;
            }
        }
        if ($fields['tax_rate'] === null && $fields['taxable'] !== null && $fields['taxable'] > 0) {
            $sum = (float)($fields['cgst'] ?? 0) + (float)($fields['sgst'] ?? 0) + (float)($fields['igst'] ?? 0);
            if ($sum > 0) $fields['tax_rate'] = round($sum / $fields['taxable'] * 100, 2);
        }
        return ['notice'=>'Check the figures below. Anything missing was not on the text of this PDF.', 'fields'=>$fields];
    }

    private function labeled_amount($text, $label) {
        $re = '/(?:'.$label.')(?:\s*[:\-])?(?:\s*[0-9.]+\s*%)?\s*(?:INR|Rs\.?|₹)?\s*([0-9][0-9,]*(?:\.\d{1,2})?)(?!\s*%)/i';
        if (!preg_match($re, $text, $m)) return null;
        return (float) str_replace(',', '', $m[1]);
    }

    private function normal_date($raw) {
        $raw = trim(str_replace('.', '/', str_replace('-', '/', $raw)));
        $parts = explode('/', $raw);
        if (count($parts) !== 3) return null;
        if (strlen($parts[0]) === 4) {
            $y = (int)$parts[0]; $m = (int)$parts[1]; $d = (int)$parts[2];
        } else {
            $d = (int)$parts[0]; $m = (int)$parts[1]; $y = (int)$parts[2];
            if ($y < 100) $y += 2000;
        }
        if (!checkdate($m, $d, $y)) return null;
        return sprintf('%04d-%02d-%02d', $y, $m, $d);
    }

    private function pdf_text($bin) {
        if ($bin === '' || strpos($bin, '%PDF') !== 0) return '';
        $out = '';
        $offset = 0;
        $len = strlen($bin);
        while (($s = strpos($bin, 'stream', $offset)) !== false) {
            $start = $s + 6;
            if ($start < $len && substr($bin, $start, 2) === "\r\n") $start += 2;
            elseif ($start < $len && $bin[$start] === "\n") $start += 1;
            $end = strpos($bin, 'endstream', $start);
            if ($end === false) break;
            $chunk = rtrim(substr($bin, $start, $end - $start), "\r\n");
            $before = substr($bin, max(0, $s - 400), min(400, $s));
            $decoded = $chunk;
            if (stripos($before, 'FlateDecode') !== false) {
                $try = @gzuncompress($chunk);
                if ($try === false) $try = @gzinflate($chunk);
                if ($try === false && strlen($chunk) > 2) $try = @gzinflate(substr($chunk, 2));
                if ($try !== false) $decoded = $try;
            }
            $out .= "\n".$this->pdf_operators($decoded);
            $offset = $end + 9;
        }
        return trim($out);
    }

    private function pdf_operators($s) {
        $text = '';
        if (preg_match_all('/\[(.*?)\]\s*TJ/s', $s, $arrays)) {
            foreach ($arrays[1] as $arr) $text .= $this->pdf_strings($arr)."\n";
        }
        if (preg_match_all('/(?:\((?:\\\\.|[^\\\\)])*\)|<([0-9A-Fa-f \r\n]+)>)\s*Tj/s', $s, $shown)) {
            foreach ($shown[0] as $piece) $text .= $this->pdf_strings($piece)."\n";
        }
        return $text;
    }

    private function pdf_strings($chunk) {
        $text = '';
        if (preg_match_all('/\((?:\\\\.|[^\\\\)])*\)/', $chunk, $lits)) {
            foreach ($lits[0] as $lit) $text .= $this->pdf_literal($lit);
        }
        if (preg_match_all('/<([0-9A-Fa-f \r\n]+)>/', $chunk, $hexes)) {
            foreach ($hexes[1] as $hex) {
                $hex = preg_replace('/\s+/', '', $hex);
                if ($hex === '' || strlen($hex) % 2) continue;
                $bytes = hex2bin($hex);
                if ($bytes === false) continue;
                if (substr($bytes, 0, 2) === "\xFE\xFF" && function_exists('mb_convert_encoding')) $bytes = mb_convert_encoding(substr($bytes, 2), 'UTF-8', 'UTF-16BE');
                $text .= $bytes;
            }
        }
        return $text;
    }

    private function pdf_literal($raw) {
        $raw = substr($raw, 1, -1);
        $raw = preg_replace_callback('/\\\\([0-7]{1,3})/', function ($m) { return chr(octdec($m[1])); }, $raw);
        $raw = str_replace(['\\n','\\r','\\t','\\(','\\)','\\\\'], ["\n","\r","\t",'(',')','\\'], $raw);
        if (substr($raw, 0, 2) === "\xFE\xFF" && function_exists('mb_convert_encoding')) $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16BE');
        return $raw;
    }

    public function expense() {
        $this->guard('ub_expense', 'expenses');
        global $wpdb;
        $id = absint($_POST['expense_id'] ?? 0);
        $fields = $this->posted_expense_fields();
        $title = $fields['title'];
        if ($title === '') wp_die('Type what this expense is.');
        if ($fields['amount'] === '') wp_die('Type the invoice total.');
        $cat = $fields['category'];
        if ($cat === 'other') $cat = $this->guess_category($title);
        $amount = $fields['amount'] === '' ? 0 : (float)$fields['amount'];
        $tds = $this->tds_expense($title, $cat, $amount);
        $data = [
            'title'=>$title,
            'category'=>$cat,
            'amount'=>$amount,
            'currency'=>$fields['currency'],
            'spent_on'=>$fields['spent_on'] !== '' ? $fields['spent_on'] : null,
            'vendor'=>$fields['vendor'],
            'vendor_gstin'=>$fields['vendor_gstin'],
            'bill_number'=>$fields['bill_number'],
            'taxable'=>$fields['taxable'] === '' ? 0 : (float)$fields['taxable'],
            'tax_rate'=>$fields['tax_rate'] === '' ? 0 : (float)$fields['tax_rate'],
            'cgst'=>$fields['cgst'] === '' ? 0 : (float)$fields['cgst'],
            'sgst'=>$fields['sgst'] === '' ? 0 : (float)$fields['sgst'],
            'igst'=>$fields['igst'] === '' ? 0 : (float)$fields['igst'],
            'sac'=>$fields['sac'],
            'itc'=>$fields['itc'] === '1' ? 1 : 0,
            'tds_section'=>$tds['section'],
            'tds_note'=>$tds['note'],
        ];
        $token = sanitize_text_field(wp_unslash($_POST['bill_token'] ?? ''));
        $stash = $token !== '' ? get_transient('ub_bill_'.$token) : false;
        $existing = $id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('expenses')} WHERE id=%d", $id)) : null;
        if (is_array($stash) && (int)($stash['user'] ?? 0) === get_current_user_id() && !empty($stash['file'])) {
            $data['attachment'] = basename((string)$stash['file']);
            $data['attachment_name'] = sanitize_file_name((string)($stash['original'] ?? $stash['file']));
            delete_transient('ub_bill_'.$token);
        }
        $tokenFile = isset($data['attachment']) ? $data['attachment'] : '';
        if (!empty($_FILES['bill']['name'])) {
            $stored = $this->store_bill_upload();
            if (is_wp_error($stored)) wp_die(esc_html($stored->get_error_message()));
            if ($tokenFile !== '' && $tokenFile !== $stored['file']) {
                $orphan = $this->bill_dir().'/'.basename($tokenFile);
                if (is_file($orphan)) @unlink($orphan);
            }
            $data['attachment'] = $stored['file'];
            $data['attachment_name'] = $stored['original'];
        }
        if ($existing && !empty($data['attachment']) && !empty($existing->attachment) && $existing->attachment !== $data['attachment']) {
            $old = $this->bill_dir().'/'.basename($existing->attachment);
            if (is_file($old)) @unlink($old);
        }
        if ($existing) {
            $wpdb->update($this->t('expenses'), $data, ['id'=>$id]);
        } else {
            $data['created_by'] = get_current_user_id();
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($this->t('expenses'), $data);
            $id = (int) $wpdb->insert_id;
        }
        wp_safe_redirect($this->url(['ub'=>'expenses','id'=>$id]));
        exit;
    }

    private function guess_category($title) {
        $map = ['hosting'=>'/host|server|domain|aws|cloud/i','software'=>'/zoom|software|saas/i','rent'=>'/rent/i','power'=>'/power|electric/i','internet'=>'/internet|broadband/i','travel'=>'/flight|uber|hotel|travel/i','labs'=>'/lab/i','trainer'=>'/trainer/i'];
        foreach ($map as $k=>$re) if (preg_match($re, $title)) return $k;
        return 'other';
    }

    public function match() {
        $this->guard('ub_match', 'bank');
        global $wpdb;
        $wpdb->update($this->t('expenses'), ['matched_2b'=> ((string)($_POST['on'] ?? '0') === '1') ? 1 : 0], ['id'=>absint($_POST['id'] ?? 0)]);
        wp_safe_redirect($this->url(['ub'=>'expenses']));
        exit;
    }

    private function view_tax() {
        $html = '<div class="note">These are working papers. The pack is ready for review. UniCybers Books does not file on the GST or TRACES portal and does not replace a chartered accountant.</div>';
        return $html.$this->paste_sheets();
    }

    private function paste_sheets() {
        global $wpdb;
        $docs = $wpdb->get_results("SELECT * FROM {$this->t('docs')} WHERE doc_type IN ('invoice','credit_note') ORDER BY doc_date, id");
        $heads = ['Type','Number','Date','Party','Customer','GSTIN','SAC','Taxable','CGST','SGST','IGST','Supply'];
        $g1rows = [];
        $out = $cgst = $sgst = $igst = $zero = 0;
        $b2b = $b2c = 0;
        $exceptions = [];
        $credits = 0;
        foreach ($docs as $d) {
            $sign = $d->doc_type === 'credit_note' ? -1 : 1;
            if ($d->doc_type === 'credit_note') $credits++;
            $party = ($d->customer_type ?? '') === 'individual' ? 'B2C' : (($d->customer_type ?? '') === 'b2b' ? 'B2B' : 'Not set');
            $supply = $d->supply === 'export_lut' ? 'LUT export' : ($d->supply === 'no_gst' ? 'No GST' : 'Domestic');
            $g1rows[] = [
                $d->doc_type === 'credit_note' ? 'Credit note' : 'Invoice',
                $d->number, $d->doc_date, $party, $d->contact_name, $d->contact_gstin, $d->sac ?? '',
                $this->money($sign*$d->subtotal), $this->money($sign*$d->cgst), $this->money($sign*$d->sgst), $this->money($sign*$d->igst), $supply,
            ];
            if ($d->supply === 'export_lut') $zero += $sign * (float)$d->subtotal;
            elseif ($d->supply === 'no_gst' || !empty($d->gst_exception)) $exceptions[] = $d;
            else {
                $out += $sign * (float)$d->subtotal;
                if ($party === 'B2C') $b2c++; else $b2b++;
            }
            $cgst += $sign * (float)$d->cgst; $sgst += $sign * (float)$d->sgst; $igst += $sign * (float)$d->igst;
        }
        $exp = $wpdb->get_results("SELECT * FROM {$this->t('expenses')} WHERE itc=1 AND vendor_gstin<>''");
        $itc = 0;
        $g2rows = [];
        foreach ($exp as $e) {
            $gst = $this->expense_gst($e);
            if (empty($e->matched_2b)) $itc += $gst;
            $g2rows[] = [$e->vendor_gstin, $e->title, $e->currency.' '.$this->money($this->expense_taxable($e)), $this->money($gst), $e->tax_rate, empty($e->matched_2b) ? 'Not matched' : 'Matched'];
        }
        $g3rows = [
            ['B2B invoices in the taxable total', (string)$b2b],
            ['B2C invoices in the taxable total', (string)$b2c],
            ['Outward taxable value', $this->money($out)],
            ['Zero-rated exports under LUT', $this->money($zero)],
            ['CGST', $this->money($cgst)],
            ['SGST', $this->money($sgst)],
            ['IGST', $this->money($igst)],
            ['Input GST still unmatched to GSTR-2B', $this->money($itc)],
        ];
        $next = $this->next_due_label();
        $html = '<div class="tax-grid">';
        $html .= $this->tax_card('Outward supplies', $b2b.' B2B - '.$b2c.' B2C', 'Taxable value '.$this->money($out), '#gstr1', 'Open sheet');
        $html .= $this->tax_card('LUT exports', $this->money($zero), 'Zero-rated. GST is not charged on these.', '#gstr1', 'Open sheet');
        $html .= $this->tax_card('Credit notes', (string)$credits, 'Credit notes reduce the outward sheet.', '#gstr1', 'Open sheet');
        $html .= $this->tax_card('Input GST', $this->money($itc), 'Claimable and not yet matched to GSTR-2B.', '#gstr2b', 'Match list');
        $html .= $this->tax_card('Due dates', $next, 'Quarterly QRMP', '#dues', 'Email reminder');
        $html .= $this->tax_card('Exceptions', (string)count($exceptions), 'Indian supplies marked with no GST.', '#exceptions', 'Review');
        $html .= '</div>';
        $html .= '<section class="ub-card ub-tax-due-row" id="dues"><strong>'.esc_html($next).'</strong>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.'<input type="hidden" name="action" value="ub_report"><input type="hidden" name="kind" value="digest">'.wp_nonce_field('ub_report','_wpnonce', true, false);
        $html .= '<button class="btn primary sm" type="submit">Email reminder</button></form></section>';
        if ($exceptions) {
            $html .= '<section class="ub-card" id="exceptions"><strong>Exceptions to review</strong><ul>';
            foreach ($exceptions as $d) $html .= '<li><a href="'.esc_url($this->url(['ub'=>'doc','id'=>(int)$d->id,'mode'=>'view'])).'">'.esc_html($d->number ?: 'Invoice').'</a> - '.esc_html($this->nice_name($d->contact_name)).' - '.esc_html($d->supply_reason ?: 'Reason not typed').'</li>';
            $html .= '</ul></section>';
        } else {
            $html .= '<section class="ub-card" id="exceptions"><strong>Exceptions to review</strong><p class="empty">No Indian supply is marked with GST not applicable.</p></section>';
        }
        $html .= $this->data_table('gstr1', 'GSTR-1', 'Quotes and proforma are not in this sheet. Copy the table, then paste it yourself.', $heads, $g1rows);
        $html .= $this->data_table('gstr3b', 'GSTR-3B', 'Summary for review. Books does not file.', ['Line','Amount'], $g3rows);
        $html .= $this->data_table('gstr2b', 'GSTR-2B match', 'GSTR-2 is not a return you file. Claimable rows use the supplier GSTIN, taxable value, and GST amount you confirmed. Mark a row matched from Expenses.', ['Supplier GSTIN','Title','Taxable','GST','GST %','2B'], $g2rows);
        $html .= '<section class="ub-card" id="tds"><strong>TDS</strong><p>Receivable on a sales invoice is tracked and does not reduce the GST total. Tax the firm deducts is a separate quarterly return.</p>'.$this->tds_block().'</section>';
        return $html;
    }

    private function tax_card($title, $figure, $line, $href, $action) {
        return '<article class="tax-card"><h3>'.esc_html($title).'</h3><strong>'.esc_html($figure).'</strong><p>'.esc_html($line).'</p><a class="btn sm" href="'.esc_url($href).'">'.esc_html($action).'</a></article>';
    }

    private function data_table($id, $title, $status, $heads, $rows) {
        $html = '<section class="ub-card" id="'.esc_attr($id).'"><div class="card-head"><div><strong>'.esc_html($title).'</strong><p>'.esc_html($status).'</p></div><button class="btn sm" type="button" data-copy="#'.esc_attr($id).'">Copy</button></div>';
        $cls = count($heads) <= 2 ? 'ub-table pair' : 'ub-table';
        $html .= '<div class="table-wrap"><table class="'.$cls.'"><thead><tr>';
        foreach ($heads as $h) $html .= '<th>'.esc_html($h).'</th>';
        $html .= '</tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="'.count($heads).'"><p class="empty">Nothing here yet. Issue a tax invoice and it will appear in this step.</p></td></tr>';
        foreach ($rows as $row) {
            $html .= '<tr>';
            foreach ($row as $i => $cell) $html .= '<td data-l="'.esc_attr($heads[$i] ?? '').'">'.esc_html((string)$cell).'</td>';
            $html .= '</tr>';
        }
        return $html.'</tbody></table></div></section>';
    }

    private function tds_block() {
        $c = $this->company();
        $on = array_filter(array_map('trim', explode(',', (string)($c['tds_sections'] ?? ''))));
        if (!$on) return '<p>No section is switched on for tax the firm itself deducts. Add 194J or 194I in Settings only when the LLP actually deducts. Sales-invoice TDS receivable is tracked on each invoice and is not entered here.</p>';
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('tds')} ORDER BY id DESC");
        $html = '<p>Sections in use: '.esc_html(implode(', ', $on)).'. Quarterly due reminders: 31 July, 31 October, 31 January, 31 May.</p>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="ub-form">';
        $html .= '<input type="hidden" name="action" value="ub_tds">'.wp_nonce_field('ub_tds','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Section<select name="section">';
        foreach ($on as $s) $html .= '<option>'.esc_html($s).'</option>';
        $html .= '</select></label><label>Deductee<input name="deductee" required></label></div>';
        $html .= '<div class="ub-2"><label>Base<input type="number" step="0.01" name="base" required></label><label>Rate %<input type="number" step="0.01" name="rate" value="10"></label></div>';
        $html .= '<button class="btn" type="submit">Add TDS line</button></form><table class="ub-table"><tbody>';
        foreach ($rows as $r) $html .= '<tr><td>'.esc_html($r->section.' '.$r->deductee).'</td><td>'.$this->money($r->tax).'</td></tr>';
        return $html.'</tbody></table>';
    }

    public function tds() {
        $this->guard('ub_tds', 'tax');
        global $wpdb;
        $base = (float) ($_POST['base'] ?? 0);
        $rate = (float) ($_POST['rate'] ?? 0);
        $wpdb->insert($this->t('tds'), [
            'section'=>sanitize_text_field($_POST['section'] ?? ''),
            'deductee'=>sanitize_text_field(wp_unslash($_POST['deductee'] ?? '')),
            'base'=>$base,'rate'=>$rate,'tax'=>round($base*$rate/100,2),
            'quarter'=>current_time('Y').'-Q'.ceil(current_time('n')/3),
        ]);
        wp_safe_redirect($this->url(['ub'=>'tax']));
        exit;
    }

    private function view_settings() {
        $c = $this->company();
        $html = '<div class="settings-links"><a class="btn" href="'.esc_url($this->url(['ub'=>'vat'])).'">Botswana and Gulf VAT</a><a class="btn" href="'.esc_url($this->url(['ub'=>'migrate'])).'">Copy LMS finance</a><a class="btn" href="'.esc_url($this->url(['ub'=>'reports'])).'">Reports</a></div>';
        $html .= '<form class="ub-card ub-form settings-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<input type="hidden" name="action" value="ub_settings">'.wp_nonce_field('ub_settings','_wpnonce', true, false);
        $html .= '<details class="ub-settings-section"><summary><span><strong>Firm Details</strong><small>Legal identity, registrations, contact and tax preferences</small></span><em>Edit</em></summary><div class="ub-settings-body">';
        $html .= '<div class="field-grid">';
        foreach ([
            'legal_name'=>'Legal name','nature'=>'Constitution','llpin'=>'LLPIN','incorporated'=>'Incorporated',
            'address'=>'Invoice address (IEC)','mca_address'=>'MCA mailing address','city'=>'City','state'=>'State',
            'gstin'=>'GSTIN','pan'=>'PAN','iec'=>'IEC','iec_issued'=>'IEC issued','iec_file'=>'IEC file',
            'lut_number'=>'LUT acknowledgement ARN','lut_filed'=>'LUT filed on','lut_fy_inferred'=>'Financial year inferred from the filing date',
            'udyam_number'=>'Udyam number','phone'=>'Phone','email'=>'Email','signatory'=>'Signatory','designation'=>'Designation',
            'tds_sections'=>'TDS sections the firm deducts (comma, for example 194J)',
        ] as $k=>$label) {
            $wide = in_array($k, ['address','mca_address','lut_fy_inferred','tds_sections'], true) ? ' wide' : '';
            $html .= '<label class="'.$wide.'">'.esc_html($label).'<input name="'.esc_attr($k).'" value="'.esc_attr($c[$k] ?? '').'"></label>';
        }
        $html .= '</div>';
        $html .= '<label>GST return period<select name="gst_period">';
        foreach (['quarterly'=>'Quarterly QRMP','monthly'=>'Monthly'] as $k=>$l) $html .= '<option value="'.$k.'"'.selected($c['gst_period'] ?? 'quarterly',$k,false).'>'.$l.'</option>';
        $html .= '</select></label>';
        $html .= '<div class="check-list">';
        $html .= '<label><input type="checkbox" name="digest_cron" value="1"'.checked(($c['digest_cron'] ?? '1'), '1', false).'> <span>Email one filing-date digest to rafi@unicybers.com. On by default. It sends only when a GSTR-1, GSTR-3B, PMT-06, or LUT renewal date is within 7 days, and only once that day. It does not email each invoice.</span></label>';
        $html .= '<label><input type="checkbox" name="weekly_cron" value="1"'.checked(($c['weekly_cron'] ?? '1'), '1', false).'> <span>Email the weekly money report to rafi@unicybers.com every Monday. Switch off to stop it.</span></label>';
        $html .= '<label><input type="checkbox" name="monthly_cron" value="1"'.checked(($c['monthly_cron'] ?? '1'), '1', false).'> <span>Email the monthly money report to rafi@unicybers.com on the first of the month. Switch off to stop it.</span></label>';
        $html .= '</div></div></details>';
        $html .= '<details class="ub-settings-section"><summary><span><strong>Bank Accounts</strong><small>'.count($c['banks'] ?? []).' account(s) configured · manage invoice payment details</small></span><em>Edit</em></summary><div class="ub-settings-body">';
        $html .= '<p class="ub-settings-help">The invoice prints the account you pick. The branch address stays in settings and is not printed.</p>';
        foreach (($c['banks'] ?? []) as $i=>$b) {
            $bankTitle = trim(($b['name'] ?? '') . ' · ' . ($b['bank'] ?? ''));
            $html .= '<details class="ub-bank-item"><summary><span><strong>'.esc_html($bankTitle ?: 'Bank account '.($i+1)).'</strong><small>'.esc_html(($b['holder'] ?? 'firm') === 'personal' ? 'Personal account' : 'Firm account').(!empty($b['default']) ? ' · Default' : '').'</small></span><em>Edit</em></summary><fieldset class="ub-card ub-bank-fields"><input type="hidden" name="bank_key[]" value="'.esc_attr($b['key'] ?? '').'">';
            $html .= '<div class="ub-2"><label>Account name<input name="bank_name[]" value="'.esc_attr($b['name'] ?? '').'"></label><label>Bank<input name="bank_bank[]" value="'.esc_attr($b['bank'] ?? '').'"></label></div>';
            $html .= '<div class="ub-2"><label>Number<input name="bank_number[]" value="'.esc_attr($b['number'] ?? '').'"></label><label>IFSC<input name="bank_ifsc[]" value="'.esc_attr($b['ifsc'] ?? '').'"></label></div>';
            $html .= '<label>Branch<input name="bank_branch[]" value="'.esc_attr($b['branch'] ?? '').'"></label>';
            $html .= '<div class="ub-2"><label>Type<select name="bank_type[]"><option value="current"'.selected(($b['type'] ?? ''),'current',false).'>Current</option><option value="savings"'.selected(($b['type'] ?? ''),'savings',false).'>Savings</option></select></label>';
            $html .= '<label>Whose<select name="bank_holder[]"><option value="firm"'.selected(($b['holder'] ?? ''),'firm',false).'>Firm</option><option value="personal"'.selected(($b['holder'] ?? ''),'personal',false).'>Personal</option></select></label></div>';
            $html .= '<label>Note<input name="bank_label[]" value="'.esc_attr($b['label'] ?? '').'"></label>';
            $html .= '<label><input type="checkbox" name="bank_default['.$i.']" value="1"'.checked(!empty($b['default']), true, false).'> Default account</label></fieldset></details>';
        }
        $html .= '<details class="ub-bank-item ub-add-bank"><summary><span><strong>Add another account</strong><small>Configure an additional bank or payment account</small></span><em>Add</em></summary><div class="ub-settings-body"><div class="ub-2"><label>Account name<input name="new_name"></label><label>Bank<input name="new_bank"></label></div>';
        $html .= '<div class="ub-2"><label>Number<input name="new_number"></label><label>IFSC<input name="new_ifsc"></label></div>';
        $html .= '<label>Branch<input name="new_branch"></label>';
        $html .= '<div class="ub-2"><label>Type<select name="new_type"><option value="current">Current</option><option value="savings">Savings</option></select></label>';
        $html .= '<label>Whose<select name="new_holder"><option value="firm">Firm</option><option value="personal">Personal</option></select></label></div>';
        $html .= '<label><input type="checkbox" name="new_default" value="1"> Make this the default</label></div></details>';
        $html .= '</div></details>';
        $html .= '<div class="form-actions"><button class="btn primary" type="submit">Save Settings</button></div></form>';
        if ($this->access() === 'owner') $html .= '<details class="ub-settings-section ub-audit-section"><summary><span><strong>Audit Log</strong><small>Administrative activity and change history</small></span><em>View log</em></summary><div class="ub-settings-body">'.$this->audit_panel().'</div></details>';
        return $html;
    }

    public function settings() {
        $this->guard('ub_settings', 'settings');
        $c = $this->company();
        foreach (['legal_name','nature','llpin','incorporated','address','mca_address','city','state','gstin','pan','iec','iec_issued','iec_file','lut_number','lut_filed','lut_fy_inferred','udyam_number','phone','email','signatory','designation','tds_sections','gst_period'] as $k) {
            $c[$k] = sanitize_text_field(wp_unslash($_POST[$k] ?? ''));
        }
        $c['gstin'] = strtoupper($c['gstin']);
        $c['lut_arn'] = $c['lut_number'];
        if (!in_array($c['gst_period'], ['monthly','quarterly'], true)) $c['gst_period'] = 'quarterly';
        $c['digest_cron'] = empty($_POST['digest_cron']) ? '0' : '1';
        $c['weekly_cron'] = empty($_POST['weekly_cron']) ? '0' : '1';
        $c['monthly_cron'] = empty($_POST['monthly_cron']) ? '0' : '1';
        $keys = (array) ($_POST['bank_key'] ?? []);
        $banks = [];
        $defaultAt = -1;
        foreach ($keys as $i => $key) {
            $name = sanitize_text_field(wp_unslash($_POST['bank_name'][$i] ?? ''));
            if ($name === '' && sanitize_text_field(wp_unslash($_POST['bank_number'][$i] ?? '')) === '') continue;
            $isDefault = !empty($_POST['bank_default'][$i]);
            if ($isDefault) $defaultAt = count($banks);
            $banks[] = [
                'key'=>sanitize_key($key) ?: ('bank'.(count($banks)+1)),
                'name'=>$name,
                'bank'=>sanitize_text_field(wp_unslash($_POST['bank_bank'][$i] ?? '')),
                'number'=>sanitize_text_field(wp_unslash($_POST['bank_number'][$i] ?? '')),
                'ifsc'=>strtoupper(sanitize_text_field(wp_unslash($_POST['bank_ifsc'][$i] ?? ''))),
                'branch'=>sanitize_text_field(wp_unslash($_POST['bank_branch'][$i] ?? '')),
                'type'=>sanitize_key($_POST['bank_type'][$i] ?? '') === 'savings' ? 'savings' : 'current',
                'holder'=>sanitize_key($_POST['bank_holder'][$i] ?? '') === 'personal' ? 'personal' : 'firm',
                'label'=>sanitize_text_field(wp_unslash($_POST['bank_label'][$i] ?? '')),
                'default'=>0,
            ];
        }
        $newName = sanitize_text_field(wp_unslash($_POST['new_name'] ?? ''));
        $newNumber = sanitize_text_field(wp_unslash($_POST['new_number'] ?? ''));
        if ($newName !== '' || $newNumber !== '') {
            if (!empty($_POST['new_default'])) $defaultAt = count($banks);
            $banks[] = [
                'key'=>'bank'.(count($banks)+1).substr(md5($newNumber.$newName), 0, 4),
                'name'=>$newName,'bank'=>sanitize_text_field(wp_unslash($_POST['new_bank'] ?? '')),
                'number'=>$newNumber,'ifsc'=>strtoupper(sanitize_text_field(wp_unslash($_POST['new_ifsc'] ?? ''))),
                'branch'=>sanitize_text_field(wp_unslash($_POST['new_branch'] ?? '')),
                'type'=>sanitize_key($_POST['new_type'] ?? '') === 'savings' ? 'savings' : 'current',
                'holder'=>sanitize_key($_POST['new_holder'] ?? '') === 'personal' ? 'personal' : 'firm',
                'label'=>'','default'=>0,
            ];
        }
        if (!$banks) $banks = $this->default_banks();
        if ($defaultAt < 0) {
            foreach ($banks as $i=>$b) if (($b['holder'] ?? '') === 'firm') { $defaultAt = $i; break; }
        }
        if ($defaultAt < 0) $defaultAt = 0;
        foreach ($banks as $i=>$b) $banks[$i]['default'] = ($i === $defaultAt) ? 1 : 0;
        $c['banks'] = $banks;
        update_option('ub_company', $c, false);
        $this->maybe_schedule();
        wp_safe_redirect($this->url(['ub'=>'settings']));
        exit;
    }

    private function view_vat() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('profiles')} WHERE code<>'india'");
        $html = '<div class="note">These profiles stay locked until a registration number is saved. Invoices continue from the India firm.</div>';
        foreach ($rows as $r) {
            $locked = $r->reg_number === '' || $r->reg_number === null;
            $html .= '<form class="ub-card ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-bottom:12px">';
            $html .= '<input type="hidden" name="action" value="ub_profile"><input type="hidden" name="id" value="'.(int)$r->id.'">'.wp_nonce_field('ub_profile','_wpnonce', true, false);
            $html .= '<strong>'.esc_html($r->label).'</strong> <span class="pill '.($locked?'draft':'paid').'">'.($locked?'Not registered yet':'Number saved').'</span>';
            $html .= '<label>Registration number<input name="reg_number" value="'.esc_attr($r->reg_number).'"></label>';
            $html .= '<label>Legal name<input name="legal_name" value="'.esc_attr($r->legal_name).'"></label>';
            $html .= '<label>Address<textarea name="address" rows="2">'.esc_textarea($r->address).'</textarea></label>';
            $html .= '<label>Return period<input name="period" value="'.esc_attr($r->period).'" placeholder="Monthly or quarterly"></label>';
            $html .= '<button class="btn" type="submit">Save profile</button></form>';
        }
        return $html;
    }

    public function profile() {
        $this->guard('ub_profile', 'settings');
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        $num = strtoupper(sanitize_text_field(wp_unslash($_POST['reg_number'] ?? '')));
        $wpdb->update($this->t('profiles'), [
            'reg_number'=>$num,
            'legal_name'=>sanitize_text_field(wp_unslash($_POST['legal_name'] ?? '')),
            'address'=>sanitize_textarea_field(wp_unslash($_POST['address'] ?? '')),
            'period'=>sanitize_text_field(wp_unslash($_POST['period'] ?? '')),
            'active'=>$num !== '' ? 1 : 0,
        ], ['id'=>$id]);
        wp_safe_redirect($this->url(['ub'=>'vat']));
        exit;
    }

    private function books_role_of($u) {
        $meta = (string) get_user_meta($u->ID, 'ub_role', true);
        if (in_array($meta, ['owner','accountant','coordinator','trainer'], true)) return $meta;
        return '';
    }

    private function role_options($current) {
        $html = '';
        foreach (['coordinator'=>'Coordinator','trainer'=>'Trainer','accountant'=>'Admin','owner'=>'Super Admin'] as $k=>$l) {
            $html .= '<option value="'.$k.'"'.selected($current, $k, false).'>'.$l.'</option>';
        }
        return $html;
    }

    private function view_people() {
        $edit_id = absint($_GET['edit'] ?? 0);
        $editing = $edit_id ? get_user_by('id', $edit_id) : null;
        if ($editing && $this->books_role_of($editing) === '' && (int)$editing->ID !== get_current_user_id()) $editing = null;
        $html = '';
        $issued = get_transient('ub_temp_'.get_current_user_id());
        if (is_array($issued) && !empty($issued['pass'])) {
            delete_transient('ub_temp_'.get_current_user_id());
            $html .= '<div class="note secret-note"><strong>Temporary password for '.esc_html($issued['email']).'</strong><code>'.esc_html($issued['pass']).'</code><p>Copy it now. They must change it after they sign in.</p></div>';
        }
        if ($editing) {
            $role = $this->books_role_of($editing) ?: 'coordinator';
            $html .= '<form class="ub-card ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
            $html .= '<h2>Edit '.esc_html($this->nice_name($editing->display_name)).'</h2>';
            $html .= '<input type="hidden" name="action" value="ub_user"><input type="hidden" name="task" value="edit"><input type="hidden" name="user_id" value="'.(int)$editing->ID.'">'.wp_nonce_field('ub_user','_wpnonce', true, false);
            $html .= '<div class="ub-2"><label>Name<input name="name" required value="'.esc_attr($editing->display_name).'"></label><label>Email<input type="email" name="email" required value="'.esc_attr($editing->user_email).'"></label></div>';
            $html .= '<label>Books Role<select name="role">'.$this->role_options($role).'</select></label>';
            $html .= $this->cap_fields($editing->ID);
            $html .= '<div class="actions"><button class="btn primary" type="submit">Save</button>';
            $html .= '<a class="btn" href="'.esc_url($this->url(['ub'=>'people'])).'">Back</a></div></form>';
            $html .= '<form class="ub-card ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:12px">';
            $html .= '<h2>Temporary password</h2><p>They sign in once with this, then choose their own.</p>';
            $html .= '<input type="hidden" name="action" value="ub_user"><input type="hidden" name="task" value="reset"><input type="hidden" name="user_id" value="'.(int)$editing->ID.'">'.wp_nonce_field('ub_user','_wpnonce', true, false);
            $html .= '<button class="btn" type="submit">Issue temporary password</button></form>';
            if ((int)$editing->ID !== get_current_user_id()) {
                $html .= '<form class="ub-card" method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:12px">';
                $html .= '<input type="hidden" name="action" value="ub_user"><input type="hidden" name="task" value="delete"><input type="hidden" name="user_id" value="'.(int)$editing->ID.'">'.wp_nonce_field('ub_user','_wpnonce', true, false);
                $html .= '<button class="btn danger" type="submit">Remove from Books</button></form>';
            }
            return $html;
        }
        $found = [];
        foreach (get_users(['meta_key'=>'ub_role','number'=>200]) as $u) {
            if (!$this->show_in_people($u)) continue;
            if ($this->books_role_of($u) !== '') $found[$u->ID] = $u;
        }
        $me = wp_get_current_user();
        if ($me && $me->ID && $this->show_in_people($me) && !isset($found[$me->ID])) $found[$me->ID] = $me;
        $html .= '<section class="ub-people-section"><div class="ub-people-head"><div class="ub-people-title"><span class="ub-people-kicker">TEAM DIRECTORY</span><h2>People and access</h2></div><div class="ub-people-head-actions"><div class="ub-people-count"><strong>'.count($found).'</strong><span>Team members</span></div><details class="ub-add-person"><summary><span class="ub-add-person-action">＋ Add person</span></summary><form class="ub-card ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<h2>New team member</h2>';
        $html .= '<input type="hidden" name="action" value="ub_user"><input type="hidden" name="task" value="create">'.wp_nonce_field('ub_user','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label></div>';
        $html .= '<div class="ub-2"><label>Temporary Password<input name="pass" required minlength="8"></label><label>Books Role<select name="role"><option value="coordinator">Coordinator</option><option value="trainer">Trainer</option><option value="accountant">Admin</option><option value="owner">Super Admin</option></select></label></div>';
        $html .= $this->cap_fields(0);
        $html .= '<button class="btn primary" type="submit">Create login</button></form></details></div></div>';
        $html .= '<div class="people-list ub-people-list">';
        if (!$found) $html .= '<div class="ub-card empty">No one is on Books yet.</div>';
        foreach ($found as $u) {
            $role = $this->books_role_of($u);
            if ($role === '' && (int)$u->ID === get_current_user_id()) $role = $this->access();
            if ($role === '') continue;
            $html .= '<article class="person-row"><div><strong>'.esc_html($this->nice_name($u->display_name)).'</strong><span>'.esc_html($u->user_email).'</span></div>';
            $html .= '<span class="pill">'.esc_html($this->role_label($role)).'</span>';
            $html .= '<a class="btn sm" href="'.esc_url($this->url(['ub'=>'people','edit'=>(int)$u->ID])).'">Edit</a></article>';
        }
        return $html.'</div></section>'.$this->leads_panel();
    }

    public function user() {
        $this->guard('ub_user', 'people');
        $task = sanitize_key($_POST['task'] ?? '');
        $role = sanitize_key($_POST['role'] ?? 'coordinator');
        if (!in_array($role, ['owner','accountant','coordinator','trainer','none'], true)) $role = 'coordinator';
        if ($task === 'create' && $role !== 'none') {
            $wp = 'subscriber';
            if ($role === 'accountant') $wp = 'ub_accountant';
            elseif ($role === 'coordinator') $wp = 'uc_coordinator';
            elseif ($role === 'trainer') $wp = 'uc_trainer';
            $id = wp_insert_user([
                'user_login'=>sanitize_email(wp_unslash($_POST['email'] ?? '')),
                'user_email'=>sanitize_email(wp_unslash($_POST['email'] ?? '')),
                'user_pass'=>(string) wp_unslash($_POST['pass'] ?? ''),
                'display_name'=>sanitize_text_field(wp_unslash($_POST['name'] ?? '')),
                'role'=>$wp,
            ]);
            if (!is_wp_error($id)) {
                update_user_meta($id, 'ub_role', $role);
                update_user_meta($id, 'ub_must_change', 1);
                $this->save_caps($id, $role);
                $this->audit('create', 'user', $id, $role);
            }
        }
        if ($task === 'edit') {
            $id = absint($_POST['user_id'] ?? 0);
            $person = $id ? get_user_by('id', $id) : null;
            $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
            if ($person && $email && in_array($role, ['owner','accountant','coordinator','trainer'], true)) {
                wp_update_user([
                    'ID' => $id,
                    'display_name' => sanitize_text_field(wp_unslash($_POST['name'] ?? '')),
                    'user_email' => $email,
                ]);
                update_user_meta($id, 'ub_role', $role);
                $this->save_caps($id, $role);
                $this->audit('edit', 'user', $id, $role);
            }
            wp_safe_redirect($this->url(['ub'=>'people','edit'=>$id]));
            exit;
        }
        if ($task === 'delete') {
            $id = absint($_POST['user_id'] ?? 0);
            if ($id && $id !== get_current_user_id()) delete_user_meta($id, 'ub_role');
            wp_safe_redirect($this->url(['ub'=>'people']));
            exit;
        }
        if ($task === 'reset') {
            $id = absint($_POST['user_id'] ?? 0);
            $person = $id ? get_user_by('id', $id) : null;
            if ($person) {
                $temp = 'UB-'.wp_generate_password(8, false, false);
                wp_set_password($temp, $id);
                update_user_meta($id, 'ub_must_change', 1);
                if ($id === get_current_user_id()) {
                    wp_set_current_user($id);
                    wp_set_auth_cookie($id, true);
                }
                set_transient('ub_temp_'.get_current_user_id(), ['email'=>$person->user_email, 'pass'=>$temp], 2 * MINUTE_IN_SECONDS);
                wp_safe_redirect($this->url($id === get_current_user_id() ? ['ub'=>'account'] : ['ub'=>'people','edit'=>$id]));
                exit;
            }
        }
        if ($task === 'role') {
            $id = absint($_POST['user_id'] ?? 0);
            if ($id && !($role === 'none' && $id === get_current_user_id())) {
                if ($role === 'none') delete_user_meta($id, 'ub_role');
                else update_user_meta($id, 'ub_role', $role);
            }
        }
        wp_safe_redirect($this->url(['ub'=>'people']));
        exit;
    }

    private function view_account() {
        $err = sanitize_key($_GET['pw'] ?? '');
        $msgs = [
            'old'=>'The current password did not match.',
            'match'=>'The new password and the repeat did not match.',
            'short'=>'Use at least 8 characters.',
            'saved'=>'Password saved.',
        ];
        $must = (bool) get_user_meta(get_current_user_id(), 'ub_must_change', true);
        $html = '';
        $issued = get_transient('ub_temp_'.get_current_user_id());
        if (is_array($issued) && !empty($issued['pass'])) {
            delete_transient('ub_temp_'.get_current_user_id());
            $html .= '<div class="note secret-note"><strong>Your temporary password</strong><code>'.esc_html($issued['pass']).'</code><p>Use it as the current password below, then choose a new one.</p></div>';
        }
        $html .= '<section class="ub-card ub-form account-card"><p class="eyebrow">Account</p><h2>Change password</h2>';
        if ($must) $html .= '<p>This login is still on a temporary password. Choose your own before opening the rest of Books.</p>';
        else $html .= '<p>Use the password you sign in with today, then pick a new one.</p>';
        if ($err && isset($msgs[$err])) $html .= '<p class="note">'.esc_html($msgs[$err]).'</p>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<input type="hidden" name="action" value="ub_password">'.wp_nonce_field('ub_password','_wpnonce', true, false);
        $html .= '<label>Current password<input type="password" name="old" autocomplete="current-password" required></label>';
        $html .= '<div class="ub-2"><label>New password<input type="password" name="new" minlength="8" autocomplete="new-password" required></label>';
        $html .= '<label>Repeat new password<input type="password" name="new2" minlength="8" autocomplete="new-password" required></label></div>';
        $html .= '<button class="btn primary" type="submit">Save password</button></form></section>';
        return $html;
    }

    public function password() {
        if (!is_user_logged_in() || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'ub_password')) wp_die('Form expired.', 403);
        $u = wp_get_current_user();
        $old = (string) wp_unslash($_POST['old'] ?? '');
        $new = (string) wp_unslash($_POST['new'] ?? '');
        $new2 = (string) wp_unslash($_POST['new2'] ?? '');
        $back = $this->url(['ub'=>'account']);
        if (!wp_check_password($old, $u->user_pass, $u->ID)) {
            wp_safe_redirect(add_query_arg('pw', 'old', $back));
            exit;
        }
        if (strlen($new) < 8) {
            wp_safe_redirect(add_query_arg('pw', 'short', $back));
            exit;
        }
        if ($new !== $new2) {
            wp_safe_redirect(add_query_arg('pw', 'match', $back));
            exit;
        }
        wp_set_password($new, $u->ID);
        delete_user_meta($u->ID, 'ub_must_change');
        wp_set_current_user($u->ID);
        wp_set_auth_cookie($u->ID, true);
        wp_safe_redirect(add_query_arg('pw', 'saved', $this->url(['ub'=>'account'])));
        exit;
    }

    private function view_migrate() {
        global $wpdb;
        $p = $wpdb->prefix;
        $counts = [];
        foreach (['student_payments','invoices','expenses','trainer_earnings','trainer_payments'] as $name) {
            $table = $p.'uc_'.$name;
            $counts[$name] = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) ? (int)$wpdb->get_var("SELECT COUNT(*) FROM $table") : 0;
        }
        $copied = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->t('docs')} WHERE source='lms'");
        $html = '<div class="ub-card"><strong>Copy the LMS ledger once</strong><p>LMS rows stay where they are. Books stores a copy and becomes the place new invoices are written. Run this, compare the counts, and only then treat the copy as checked.</p><ul>';
        foreach ($counts as $k=>$n) $html .= '<li>'.esc_html($k).': '.$n.'</li>';
        $html .= '</ul><p>Documents already copied: '.$copied.'</p>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_migrate">'.wp_nonce_field('ub_migrate','_wpnonce', true, false);
        $html .= '<button class="btn primary" type="submit">Copy now</button></form></div>';
        return $html;
    }

    public function migrate() {
        $this->guard('ub_migrate', 'settings');
        global $wpdb;
        $p = $wpdb->prefix;
        $payTable = $p.'uc_student_payments';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $payTable)) === $payTable) {
            $rows = $wpdb->get_results("SELECT p.*, u.display_name, u.user_email, i.invoice_number FROM $payTable p LEFT JOIN {$wpdb->users} u ON u.ID=p.user_id LEFT JOIN {$p}uc_invoices i ON i.id=p.invoice_id");
            foreach ($rows as $r) {
                $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->t('docs')} WHERE source='lms' AND source_id=%d", $r->id));
                if ($exists) continue;
                $tax = (float)($r->tax_amount ?? 0);
                $total = (float)$r->amount;
                $base = $tax ? $total - $tax : $total;
                $wpdb->insert($this->t('docs'), [
                    'doc_type'=>'invoice','number'=>$r->invoice_number ?: ('UC-INV-'.$r->id),'status'=>'paid',
                    'contact_name'=>$r->display_name,'contact_email'=>$r->user_email,'contact_country'=>'India',
                    'currency'=>$r->currency ?: 'INR','supply'=>'domestic','price_mode'=>'excl','tax_rate'=>(float)($r->tax_percent ?? 0),
                    'subtotal'=>$base,'igst'=>$tax,'total'=>$total,'paid'=>$total,
                    'doc_date'=>$r->payment_date,'notes'=>'Copied from LMS. Place of supply was not stored. Review before a GST paste sheet.',
                    'source'=>'lms','source_id'=>$r->id,'created_at'=>current_time('mysql'),
                ]);
                $id = (int)$wpdb->insert_id;
                $wpdb->insert($this->t('lines'), ['doc_id'=>$id,'component'=>'Academy programme fee','basis'=>'One time','scope'=>(string)$r->reference,'amount'=>$base]);
            }
        }
        $ex = $p.'uc_expenses';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $ex)) === $ex) {
            foreach ($wpdb->get_results("SELECT * FROM $ex") as $r) {
                if ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->t('expenses')} WHERE source='lms' AND source_id=%d", $r->id))) continue;
                $wpdb->insert($this->t('expenses'), [
                    'title'=>$r->title,'category'=>sanitize_title($r->category ?: 'other'),'amount'=>$r->amount,'currency'=>$r->currency,
                    'spent_on'=>$r->expense_date,'notes'=>$r->notes,'source'=>'lms','source_id'=>$r->id,'created_at'=>current_time('mysql'),
                ]);
            }
        }
        $sh = $p.'uc_trainer_earnings';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $sh)) === $sh) {
            foreach ($wpdb->get_results("SELECT e.*, u.display_name FROM $sh e LEFT JOIN {$wpdb->users} u ON u.ID=e.trainer_user_id") as $r) {
                if ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->t('shares')} WHERE source_id=%d", $r->id))) continue;
                $wpdb->insert($this->t('shares'), [
                    'trainer_name'=>$r->display_name,
                    'trainer_user_id'=>isset($r->trainer_user_id) ? (int)$r->trainer_user_id : null,
                    'currency'=>$r->currency ?: 'INR',
                    'earned'=>$r->trainer_earning ?: $r->amount,
                    'fee_received'=>$r->student_payment ?? 0,
                    'fee_base'=>$r->student_payment ?? 0,
                    'share_percent'=>$r->share_percent ?? 0,
                    'source_id'=>$r->id,
                ]);
            }
        }
        $po = $p.'uc_trainer_payments';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $po)) === $po) {
            foreach ($wpdb->get_results("SELECT p.*, u.display_name FROM $po p LEFT JOIN {$wpdb->users} u ON u.ID=p.trainer_user_id") as $r) {
                if ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->t('payouts')} WHERE source_id=%d", $r->id))) continue;
                $wpdb->insert($this->t('payouts'), [
                    'trainer_name'=>$r->display_name,
                    'trainer_user_id'=>isset($r->trainer_user_id) ? (int)$r->trainer_user_id : null,
                    'currency'=>$r->currency ?: 'INR',
                    'amount'=>$r->amount,
                    'source_id'=>$r->id,
                ]);
            }
        }
        update_option('ub_copy_ran', current_time('mysql'), false);
        wp_safe_redirect($this->url(['ub'=>'migrate']));
        exit;
    }

    private function view_reports() {
        $html = '<div class="ub-card report-actions-card"><div class="report-actions-head"><div><span class="report-kicker">FINANCIAL REPORTING</span><h2>Reports and summaries</h2><p>Generate a weekly summary, monthly summary or tax reminder.</p></div></div>'; 
        $html .= '<form class="form-actions" method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.'<input type="hidden" name="action" value="ub_report">'.wp_nonce_field('ub_report','_wpnonce', true, false);
        $html .= '<button class="btn primary" name="kind" value="weekly" type="submit">Email the weekly report</button>';
        $html .= '<button class="btn" name="kind" value="monthly" type="submit">Email the monthly report</button>';
        $html .= '<button class="btn" name="kind" value="digest" type="submit">Email the tax reminder</button></form></div>';
        $html .= $this->report_view('weekly');
        return $html;
    }

    private function report_view($kind) {
        $pack = $this->report_pack($kind);
        $html = '<section class="ub-card report-sheet"><div class="report-sheet-head"><span class="report-kicker">REPORT PREVIEW</span><h2>'.esc_html($pack['title']).'</h2><p class="report-period">'.esc_html($pack['period']).'</p></div><div class="report-block-grid">';
        foreach ($pack['sections'] as $sec) {
            $html .= '<div class="report-block"><h3>'.esc_html($sec['title']).'</h3><ul>';
            foreach ($sec['lines'] as $line) $html .= '<li>'.esc_html($line).'</li>';
            $html .= '</ul></div>';
        }
        return $html.'</div></section>';
    }

    public function report() {
        $this->guard('ub_report', 'sales');
        $kind = sanitize_key($_POST['kind'] ?? '');
        if (in_array($kind, ['digest','weekly','monthly'], true)) {
            if (!$this->can('owner')) wp_die('Not allowed.', 403);
            if ($kind === 'digest') wp_mail('rafi@unicybers.com', 'UniCybers Books - filing reminder', $this->reminder_text(), ['From: UniCybers Books <info@unicybers.com>']);
            else $this->send_money_report($kind);
            wp_safe_redirect($this->url(['ub'=>'reports']));
            exit;
        }
            global $wpdb;
            $id = absint($_POST['id'] ?? 0);
            $doc = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('docs')} WHERE id=%d", $id));
            if ($doc && $doc->contact_email) {
                $body = ($doc->number ?: 'Document')."\n".$doc->contact_name."\n".$doc->currency.' '.$this->money($doc->total)."\n".$doc->terms."\n\nOpen Books to print the PDF.";
                wp_mail($doc->contact_email, 'UniCybers - '.$doc->number, $body, ['Cc: rafi@unicybers.com', 'From: UniCybers Books <info@unicybers.com>']);
            }
            wp_safe_redirect($this->url(['ub'=>'doc','id'=>$id]));
            exit;
    }

    public function weekly_report() {
        $c = $this->company();
        if (isset($c['weekly_cron']) && (string)$c['weekly_cron'] !== '1') return;
        $key = gmdate('o-\WW');
        if (get_option('ub_weekly_last') === $key) return;
        if ((int) gmdate('N') !== 1) return;
        $this->send_money_report('weekly');
        update_option('ub_weekly_last', $key, false);
    }

    public function monthly_report() {
        $c = $this->company();
        if (isset($c['monthly_cron']) && (string)$c['monthly_cron'] !== '1') return;
        if ((int) current_time('j') !== 1) return;
        $key = current_time('Y-m');
        if (get_option('ub_monthly_last') === $key) return;
        $this->send_money_report('monthly');
        update_option('ub_monthly_last', $key, false);
    }

    private function send_money_report($kind) {
        $title = $kind === 'monthly' ? 'monthly report' : 'weekly report';
        wp_mail('rafi@unicybers.com', 'UniCybers Books - '.$title, $this->money_report($kind), ['From: UniCybers Books <info@unicybers.com>']);
    }

    private function nice_day($ymd) {
        $t = strtotime((string) $ymd);
        return $t ? date('j M Y', $t) : (string) $ymd;
    }

    private function report_pack($kind) {
        global $wpdb;
        $since = $kind === 'monthly' ? gmdate('Y-m-01', strtotime('first day of last month')) : gmdate('Y-m-d', strtotime('-7 days'));
        $until = $kind === 'monthly' ? gmdate('Y-m-01') : current_time('Y-m-d');
        $docs = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->t('docs')} WHERE doc_type='invoice' AND doc_date>=%s AND doc_date<%s", $since, $until)) ?: [];
        $issued = [];
        foreach ($docs as $d) $issued[] = ($d->number ?: 'Draft').' - '.$this->nice_name($d->contact_name).' - '.$d->currency.' '.$this->money($d->total);
        if (!$issued) $issued[] = '0 invoices issued';
        $pays = $wpdb->get_results($wpdb->prepare("SELECT currency, SUM(amount) total FROM {$this->t('pays')} WHERE paid_on>=%s AND paid_on<%s GROUP BY currency", $since, $until)) ?: [];
        $payLines = [];
        foreach ($pays as $p) $payLines[] = $p->currency.' '.$this->money($p->total);
        if (!$payLines) $payLines[] = 'None in this period';
        $over = [];
        foreach ($this->docs("WHERE doc_type='invoice'") as $d) {
            if ($this->derived_status($d) !== 'overdue') continue;
            $over[] = ($d->number ?: 'Invoice').' - '.$d->currency.' '.$this->money((float)$d->total - (float)$d->paid);
        }
        if (!$over) $over[] = 'None';
        $ex = $wpdb->get_results($wpdb->prepare("SELECT currency, SUM(amount) total FROM {$this->t('expenses')} WHERE spent_on>=%s AND spent_on<%s GROUP BY currency", $since, $until)) ?: [];
        $exLines = [];
        foreach ($ex as $e) $exLines[] = $e->currency.' '.$this->money($e->total);
        if (!$exLines) $exLines[] = 'None in this period';
        $trainers = [];
        foreach ($this->trainer_balances() as $b) {
            $trainers[] = $this->nice_name($b['name']).' - '.$b['cur'].' owed '.$this->money($b['owed']).' (share '.$this->money($b['earned']).', expenses '.$this->money($b['expenses']).', paid '.$this->money($b['paid']).')';
        }
        if (!$trainers) $trainers[] = 'None recorded';
        $rems = [];
        foreach ($wpdb->get_results("SELECT * FROM {$this->t('reminders')} WHERE done=0 ORDER BY due_on ASC LIMIT 20") ?: [] as $r) {
            $rems[] = ($r->due_on ?: 'Open').' - '.$r->title.($r->contact_name ? ' - '.$r->contact_name : '');
        }
        if (!$rems) $rems[] = 'None open';
        return [
            'title' => ($kind === 'monthly' ? 'Monthly' : 'Weekly').' report',
            'period' => $this->nice_day($since).' - '.$this->nice_day($until),
            'sections' => [
                ['title'=>'Invoices issued', 'lines'=>$issued],
                ['title'=>'Payments received', 'lines'=>$payLines],
                ['title'=>'Overdue now', 'lines'=>$over],
                ['title'=>'Expenses', 'lines'=>$exLines],
                ['title'=>'Trainer balances', 'lines'=>$trainers],
                ['title'=>'Reminders', 'lines'=>$rems],
                ['title'=>'Next tax date', 'lines'=>[$this->next_due_label()]],
            ],
        ];
    }

    private function money_report($kind) {
        $pack = $this->report_pack($kind);
        $lines = ['UniCybers Books', $pack['title'].' · '.$pack['period'], ''];
        foreach ($pack['sections'] as $sec) {
            $lines[] = $sec['title'];
            if (!$sec['lines']) $lines[] = '- None';
            foreach ($sec['lines'] as $line) $lines[] = '- '.$line;
            $lines[] = '';
        }
        return trim(implode("\n", $lines));
    }

    private function trainer_people() {
        $found = [];
        foreach (get_users(['meta_key'=>'ub_role','meta_value'=>'trainer','number'=>200]) as $u) $found[$u->ID] = $u;
        foreach (get_users(['role'=>'uc_trainer','number'=>200]) as $u) $found[$u->ID] = $u;
        return $found;
    }

    private function share_base($fee, $mode, $custom, $doc, $rate) {
        $fee = (float) $fee;
        if ($mode === 'custom') return max(0, (float)$custom);
        if ($mode === 'inclusive') return $fee;
        if ($doc && (float)$doc->total > 0 && (float)$doc->subtotal > 0 && (float)$doc->subtotal + 0.001 < (float)$doc->total) {
            return round($fee * ((float)$doc->subtotal / (float)$doc->total), 2);
        }
        $rate = (float) $rate;
        if ($rate > 0) return round($fee / (1 + $rate / 100), 2);
        return $fee;
    }

    private function view_trainers() {
        global $wpdb;
        $people = $this->trainer_people();
        $docs = $wpdb->get_results("SELECT id, number, contact_name, currency, total, subtotal, tax_rate FROM {$this->t('docs')} WHERE doc_type='invoice' ORDER BY id DESC LIMIT 80");
        $html = '<form class="ub-card ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<h2>Record a trainer share</h2>';
        $html .= '<input type="hidden" name="action" value="ub_share">'.wp_nonce_field('ub_share','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Trainer<select name="trainer_user_id" required><option value="">Choose</option>';
        if (!$people) $html .= '<option value="" disabled>Add a trainer on People first</option>';
        foreach ($people as $u) $html .= '<option value="'.(int)$u->ID.'">'.esc_html($this->nice_name($u->display_name).' - '.$u->user_email).'</option>';
        $html .= '</select></label><label>Batch<input name="batch_name" required placeholder="October SOC batch"></label></div>';
        $html .= '<div class="ub-2"><label>Fee received<input name="fee_received" type="number" min="0" step="0.01" required></label>';
        $html .= '<label>Linked invoice<select name="doc_id"><option value="0">No invoice</option>';
        foreach ($docs as $d) $html .= '<option value="'.(int)$d->id.'">'.esc_html(($d->number ?: 'Invoice').' - '.$this->nice_name($d->contact_name)).'</option>';
        $html .= '</select></label></div>';
        $html .= '<div class="ub-2"><label>Share base<select name="base_mode"><option value="pre_gst">Before GST (default)</option><option value="inclusive">Amount received, GST included</option><option value="custom">A base I type</option></select></label>';
        $html .= '<label>Custom base<input name="custom_base" type="number" min="0" step="0.01" placeholder="Only if you picked a base you type"></label></div>';
        $html .= '<div class="ub-2"><label>GST rate if there is no invoice<input name="tax_rate" type="number" min="0" step="0.01" value="18"></label>';
        $html .= '<label>Trainer percent<input name="share_percent" type="number" min="0" max="100" step="0.01" value="30" required></label></div>';
        $html .= '<label>Expenses to deduct from this share<input name="expenses" type="number" min="0" step="0.01" value="0"></label>';
        $html .= '<button class="btn primary" type="submit">Save share and email the trainer</button></form>';
        $html .= '<form class="ub-card ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:12px">';
        $html .= '<h2>Record a payout</h2>';
        $html .= '<input type="hidden" name="action" value="ub_payout">'.wp_nonce_field('ub_payout','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Trainer<select name="trainer_user_id" required><option value="">Choose</option>';
        foreach ($people as $u) $html .= '<option value="'.(int)$u->ID.'">'.esc_html($u->display_name).'</option>';
        $html .= '</select></label><label>Amount paid<input name="amount" type="number" min="0" step="0.01" required></label></div>';
        $html .= '<div class="ub-2"><label>Currency<input name="currency" value="INR"></label><label>Note<input name="note" placeholder="UPI on 28 Oct"></label></div>';
        $html .= '<button class="btn primary" type="submit">Save payout and email the trainer</button></form>';
        $html .= '<div class="ub-card" style="margin-top:12px"><h2>Balances</h2>'.$this->trainer_ledger_table(0).'</div>';
        $html .= '<div class="ub-card" style="margin-top:12px"><h2>Shares</h2>'.$this->share_rows(0).'</div>';
        return $html;
    }

    private function view_my_share() {
        $id = get_current_user_id();
        return '<div class="ub-card"><h2>Your batches</h2><p>You see your own share, the expenses deducted from it, and what has been paid to you.</p>'.$this->trainer_ledger_table($id).'</div><div class="ub-card" style="margin-top:12px"><h2>Payments on your batches</h2>'.$this->share_rows($id).'</div>';
    }

    private function trainer_balances() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT trainer_user_id, trainer_name, currency, SUM(earned) earned, SUM(expenses) expenses FROM {$this->t('shares')} GROUP BY trainer_user_id, trainer_name, currency") ?: [];
        $paid = $wpdb->get_results("SELECT trainer_user_id, trainer_name, currency, SUM(amount) paid FROM {$this->t('payouts')} GROUP BY trainer_user_id, trainer_name, currency") ?: [];
        $map = [];
        foreach ($rows as $r) {
            $k = (int)$r->trainer_user_id.'|'.$r->trainer_name.'|'.$r->currency;
            $map[$k] = ['id'=>(int)$r->trainer_user_id,'name'=>$r->trainer_name,'cur'=>$r->currency,'earned'=>(float)$r->earned,'expenses'=>(float)$r->expenses,'paid'=>0];
        }
        foreach ($paid as $r) {
            $k = (int)$r->trainer_user_id.'|'.$r->trainer_name.'|'.$r->currency;
            if (!isset($map[$k])) $map[$k] = ['id'=>(int)$r->trainer_user_id,'name'=>$r->trainer_name,'cur'=>$r->currency,'earned'=>0,'expenses'=>0,'paid'=>0];
            $map[$k]['paid'] = (float)$r->paid;
        }
        foreach ($map as &$b) $b['owed'] = $b['earned'] - $b['expenses'] - $b['paid'];
        return array_values($map);
    }

    private function trainer_ledger_table($only) {
        $rows = [];
        foreach ($this->trainer_balances() as $b) {
            if ($only && (int)$b['id'] !== (int)$only) continue;
            $rows[] = $b;
        }
        if (!$rows) return '<p class="empty">No share is recorded yet. The owner records a percent when a student fee is received.</p>';
        $html = '<table class="ub-table"><thead><tr><th>Trainer</th><th>Currency</th><th>Share</th><th>Expenses</th><th>Paid</th><th>Owed</th></tr></thead><tbody>';
        foreach ($rows as $b) {
            $html .= '<tr><td data-l="Trainer">'.esc_html($this->nice_name($b['name'])).'</td><td data-l="Currency">'.esc_html($b['cur']).'</td>';
            $html .= '<td data-l="Share">'.$this->money($b['earned']).'</td><td data-l="Expenses">'.$this->money($b['expenses']).'</td>';
            $html .= '<td data-l="Paid">'.$this->money($b['paid']).'</td><td data-l="Owed"><strong>'.$this->money($b['owed']).'</strong></td></tr>';
        }
        return $html.'</tbody></table>';
    }

    private function share_rows($only) {
        global $wpdb;
        $sql = "SELECT * FROM {$this->t('shares')}";
        if ($only) $sql = $wpdb->prepare("SELECT * FROM {$this->t('shares')} WHERE trainer_user_id=%d", $only);
        $rows = $wpdb->get_results($sql." ORDER BY id DESC LIMIT 80");
        if (!$rows) return '<p class="empty">Nothing on this ledger yet.</p>';
        $html = '<table class="ub-table"><thead><tr><th>Batch</th><th>Fee received</th><th>Base</th><th>%</th><th>Share</th><th>Expenses</th><th>Net</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $net = (float)$r->earned - (float)$r->expenses;
            $html .= '<tr><td data-l="Batch">'.esc_html($r->batch_name ?: $r->trainer_name).'</td>';
            $html .= '<td data-l="Fee received">'.esc_html($r->currency).' '.$this->money($r->fee_received).'</td>';
            $html .= '<td data-l="Base">'.$this->money($r->fee_base).'</td><td data-l="%">'.esc_html($r->share_percent).'</td>';
            $html .= '<td data-l="Share">'.$this->money($r->earned).'</td><td data-l="Expenses">'.$this->money($r->expenses).'</td>';
            $html .= '<td data-l="Net"><strong>'.$this->money($net).'</strong></td></tr>';
        }
        return $html.'</tbody></table>';
    }

    public function share() {
        $this->guard('ub_share', 'trainer_pay');
        global $wpdb;
        $uid = absint($_POST['trainer_user_id'] ?? 0);
        $user = get_userdata($uid);
        if (!$user) wp_die('Choose a trainer.');
        $fee = (float)($_POST['fee_received'] ?? 0);
        $percent = (float)($_POST['share_percent'] ?? 0);
        $expenses = max(0, (float)($_POST['expenses'] ?? 0));
        $mode = sanitize_key($_POST['base_mode'] ?? 'pre_gst');
        if (!in_array($mode, ['pre_gst','inclusive','custom'], true)) $mode = 'pre_gst';
        $doc_id = absint($_POST['doc_id'] ?? 0);
        $doc = $doc_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('docs')} WHERE id=%d", $doc_id)) : null;
        $rate = $doc ? (float)$doc->tax_rate : (float)($_POST['tax_rate'] ?? 0);
        $base = $this->share_base($fee, $mode, $_POST['custom_base'] ?? 0, $doc, $rate);
        $earned = round($base * $percent / 100, 2);
        $currency = $doc ? $doc->currency : 'INR';
        $batch = sanitize_text_field(wp_unslash($_POST['batch_name'] ?? ''));
        $wpdb->insert($this->t('shares'), [
            'trainer_name'=>$user->display_name,
            'trainer_user_id'=>$uid,
            'batch_name'=>$batch,
            'doc_id'=>$doc_id ?: null,
            'currency'=>$currency,
            'fee_received'=>$fee,
            'fee_base'=>$base,
            'share_percent'=>$percent,
            'earned'=>$earned,
            'expenses'=>$expenses,
            'note'=>$mode,
        ]);
        $net = $earned - $expenses;
        $body = "Batch: {$batch}\nAmount received: {$currency} ".$this->money($fee)."\nShare base: {$currency} ".$this->money($base)."\nPercent: {$percent}\nExpenses deducted: {$currency} ".$this->money($expenses)."\nNet share: {$currency} ".$this->money($net)."\n";
        wp_mail($user->user_email, 'UniCybers Books - trainer share', $body, ['Cc: rafi@unicybers.com', 'From: UniCybers Books <info@unicybers.com>']);
        wp_safe_redirect($this->url(['ub'=>'trainers']));
        exit;
    }

    public function payout() {
        $this->guard('ub_payout', 'trainer_pay');
        global $wpdb;
        $uid = absint($_POST['trainer_user_id'] ?? 0);
        $user = get_userdata($uid);
        if (!$user) wp_die('Choose a trainer.');
        $amount = (float)($_POST['amount'] ?? 0);
        $currency = sanitize_text_field($_POST['currency'] ?? 'INR') ?: 'INR';
        $note = sanitize_text_field(wp_unslash($_POST['note'] ?? ''));
        $method = sanitize_text_field(wp_unslash($_POST['method'] ?? ''));
        $ref = sanitize_text_field(wp_unslash($_POST['reference'] ?? ''));
        $bits = array_filter([$method, $ref, $note]);
        $note = implode(' - ', $bits);
        $wpdb->insert($this->t('payouts'), [
            'trainer_name'=>$user->display_name,
            'trainer_user_id'=>$uid,
            'currency'=>$currency,
            'amount'=>$amount,
            'paid_on'=>current_time('Y-m-d'),
            'note'=>$note,
        ]);
        $body = "A payout was recorded.\nAmount: {$currency} ".$this->money($amount)."\nNote: {$note}\n";
        wp_mail($user->user_email, 'UniCybers Books - trainer payout', $body, ['Cc: rafi@unicybers.com', 'From: UniCybers Books <info@unicybers.com>']);
        $back = sanitize_key($_POST['back'] ?? '') === 'finance' ? 'finance' : 'trainers';
        wp_safe_redirect($this->url(['ub'=>$back]));
        exit;
    }

    private function recurring_panel() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('recurring')} ORDER BY id DESC");
        $html = '<form class="ub-card ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<h2>Monthly recurring expenses</h2>';
        $html .= '<input type="hidden" name="action" value="ub_recur"><input type="hidden" name="task" value="save">'.wp_nonce_field('ub_recur','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Name<input name="title" required placeholder="Office rent"></label><label>Category<select name="category">';
        foreach (['rent'=>'Rent','salary'=>'Salary','internet'=>'Internet','power'=>'Power','other'=>'Custom'] as $k=>$l) $html .= '<option value="'.$k.'">'.$l.'</option>';
        $html .= '</select></label></div>';
        $html .= '<div class="ub-2"><label>Amount<input name="amount" type="number" min="0" step="0.01" required></label><label>Currency<input name="currency" value="INR"></label></div>';
        $html .= '<div class="ub-2"><label>Day of month<input name="day_of_month" type="number" min="1" max="28" value="1"></label><label>On<select name="active"><option value="1">On</option><option value="0">Off</option></select></label></div>';
        $html .= '<button class="btn primary" type="submit">Save series</button></form>';
        $html .= '<div class="ub-card" style="margin-top:12px"><table class="ub-table"><thead><tr><th>Series</th><th>Amount</th><th>Day</th><th>Status</th><th></th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="5"><p class="empty">No repeating expense yet. Add rent or salary above. This month posts when the day arrives.</p></td></tr>';
        foreach ($rows as $r) {
            $html .= '<tr><td data-l="Series"><strong>'.esc_html($r->title).'</strong><br>'.esc_html($r->category).'</td>';
            $html .= '<td data-l="Amount">'.esc_html($r->currency).' '.$this->money($r->amount).'</td><td data-l="Day">'.(int)$r->day_of_month.'</td>';
            $html .= '<td data-l="Status">'.($r->active ? 'On' : 'Stopped').($r->last_ym ? ' · last '.$r->last_ym : '').'</td><td data-l="Actions">';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline">';
            $html .= '<input type="hidden" name="action" value="ub_recur"><input type="hidden" name="task" value="save"><input type="hidden" name="id" value="'.(int)$r->id.'">'.wp_nonce_field('ub_recur','_wpnonce', true, false);
            $html .= '<input name="title" value="'.esc_attr($r->title).'" style="width:120px"> <input name="amount" type="number" step="0.01" value="'.esc_attr($r->amount).'" style="width:90px"> ';
            $html .= '<input type="hidden" name="category" value="'.esc_attr($r->category).'"><input type="hidden" name="currency" value="'.esc_attr($r->currency).'">';
            $html .= '<input name="day_of_month" type="number" min="1" max="28" value="'.(int)$r->day_of_month.'" style="width:60px"> ';
            $html .= '<input type="hidden" name="active" value="'.(int)$r->active.'"><button class="btn sm" type="submit">Save</button></form> ';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline"><input type="hidden" name="action" value="ub_recur"><input type="hidden" name="id" value="'.(int)$r->id.'">'.wp_nonce_field('ub_recur','_wpnonce', true, false);
            $html .= '<input type="hidden" name="task" value="skip"><button class="btn sm" type="submit">Skip this month</button></form> ';
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline"><input type="hidden" name="action" value="ub_recur"><input type="hidden" name="id" value="'.(int)$r->id.'">'.wp_nonce_field('ub_recur','_wpnonce', true, false);
            $html .= '<input type="hidden" name="task" value="stop"><button class="btn sm" type="submit">Stop</button></form></td></tr>';
        }
        return $html.'</tbody></table></div>';
    }

    public function recur() {
        $this->guard('ub_recur', 'expenses');
        global $wpdb;
        $task = sanitize_key($_POST['task'] ?? 'save');
        $id = absint($_POST['id'] ?? 0);
        $table = $this->t('recurring');
        if ($task === 'skip' && $id) {
            $wpdb->update($table, ['last_ym'=>current_time('Y-m')], ['id'=>$id]);
        } elseif ($task === 'stop' && $id) {
            $wpdb->update($table, ['active'=>0], ['id'=>$id]);
        } else {
            $row = [
                'title'=>sanitize_text_field(wp_unslash($_POST['title'] ?? '')),
                'category'=>sanitize_key($_POST['category'] ?? 'other'),
                'amount'=>(float)($_POST['amount'] ?? 0),
                'currency'=>sanitize_text_field($_POST['currency'] ?? 'INR') ?: 'INR',
                'day_of_month'=>max(1, min(28, (int)($_POST['day_of_month'] ?? 1))),
                'active'=>empty($_POST['active']) ? 0 : 1,
            ];
            if ($id) $wpdb->update($table, $row, ['id'=>$id]);
            elseif ($row['title'] !== '') $wpdb->insert($table, $row);
        }
        wp_safe_redirect($this->url(['ub'=>'expenses']));
        exit;
    }

    public function recurring_tick() {
        $this->post_due_recurring();
        $this->tick_subs();
    }

    private function post_due_recurring() {
        global $wpdb;
        $table = $this->t('recurring');
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) return;
        $ym = current_time('Y-m');
        $day = (int) current_time('j');
        $rows = $wpdb->get_results("SELECT * FROM $table WHERE active=1");
        foreach ($rows as $r) {
            if ((string)$r->last_ym === $ym) continue;
            if ($day < (int)$r->day_of_month) continue;
            $wpdb->insert($this->t('expenses'), [
                'title'=>$r->title,
                'category'=>$r->category ?: 'other',
                'amount'=>$r->amount,
                'currency'=>$r->currency ?: 'INR',
                'spent_on'=>current_time('Y-m-').str_pad((string)$r->day_of_month, 2, '0', STR_PAD_LEFT),
                'notes'=>'Recurring series',
                'created_by'=>get_current_user_id(),
                'created_at'=>current_time('mysql'),
            ]);
            $wpdb->update($table, ['last_ym'=>$ym], ['id'=>(int)$r->id]);
        }
    }

    private function view_guide() {
        return $this->view_home($this->access());
    }

    private function audit($action, $type, $id, $detail) {
        global $wpdb;
        $wpdb->insert($this->t('audit'), [
            'user_id'=>get_current_user_id(),
            'action'=>$action,
            'object_type'=>$type,
            'object_id'=>(int)$id,
            'detail'=>sanitize_text_field($detail),
            'created_at'=>current_time('mysql'),
        ]);
    }

    private function audit_panel() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('audit')} ORDER BY id DESC LIMIT 40") ?: [];
        $html = '<article class="ub-card" style="margin-top:12px"><h2>Audit Log</h2>';
        if (!$rows) return $html.'<p class="empty">No changes recorded yet.</p></article>';
        $html .= '<table class="ub-table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $who = $r->user_id ? get_userdata((int)$r->user_id) : null;
            $html .= '<tr><td>'.esc_html($r->created_at).'</td><td>'.esc_html($who ? $this->nice_name($who->display_name) : 'System').'</td><td>'.esc_html(ucfirst($r->action).' '.$r->object_type).'</td><td>'.esc_html($r->detail).'</td></tr>';
        }
        return $html.'</tbody></table></article>';
    }

    private function cap_fields($user_id) {
        $saved = $user_id ? get_user_meta($user_id, 'ub_caps', true) : ['sales'=>1,'finance'=>1,'expenses'=>1,'bank'=>1,'reports'=>1];
        if (!is_array($saved)) $saved = [];
        $html = '<details class="ub-permissions"><summary><strong>Admin access permissions</strong><span>Optional. Only applies to Admin.</span></summary><div class="ub-permission-grid">';
        foreach (['sales'=>'Sales','finance'=>'Finance','expenses'=>'Expenses','bank'=>'Banking','trainer_pay'=>'Trainer pay','tax'=>'Tax desk','reports'=>'Reports','people'=>'People','settings'=>'Settings'] as $k=>$l) {
            $html .= '<label class="ub-permission"><input type="checkbox" name="cap_'.$k.'" value="1"'.checked(!empty($saved[$k]), true, false).'><span>'.esc_html($l).'</span></label>';
        }
        return $html.'</div></details>';
    }

    private function save_caps($id, $role) {
        if ($role !== 'accountant') return;
        $caps = [];
        foreach (['sales','finance','expenses','bank','trainer_pay','tax','reports','people','settings'] as $k) {
            if (!empty($_POST['cap_'.$k])) $caps[$k] = 1;
        }
        if (!$caps) $caps = ['sales'=>1,'finance'=>1,'expenses'=>1,'bank'=>1,'reports'=>1];
        update_user_meta($id, 'ub_caps', $caps);
    }

    private function home_attention() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('reminders')} WHERE done=0 ORDER BY due_on ASC LIMIT 12") ?: [];
        $html = '<div class="ub-row"><article class="ub-card"><h2>Attention</h2>';
        if (!$rows) $html .= '<p class="empty">Nothing is waiting. Add a reminder when a quote or invoice must go out.</p>';
        else {
            $html .= '<table class="ub-table"><tbody>';
            foreach ($rows as $r) {
                $html .= '<tr><td>'.esc_html($r->due_on ?: 'Open').'</td><td><strong>'.esc_html($r->title).'</strong><span class="sub">'.esc_html($r->contact_name).'</span></td></tr>';
            }
            $html .= '</tbody></table>';
        }
        $html .= '<form class="ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:10px">';
        $html .= '<input type="hidden" name="action" value="ub_reminder">'.wp_nonce_field('ub_reminder','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Reminder<input name="title" required placeholder="Send the quotation next week"></label><label>Date<input type="date" name="due_on"></label></div>';
        $html .= '<div class="ub-2"><label>Company<input name="contact_name" placeholder="Company name"></label><label>Note<input name="note"></label></div>';
        $html .= '<button class="btn primary" type="submit">Add Reminder</button></form>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:8px">';
        $html .= '<input type="hidden" name="action" value="ub_chase">'.wp_nonce_field('ub_chase','_wpnonce', true, false);
        $html .= '<button class="btn" type="submit">Email Pending Invoices To Clients</button></form>';
        $html .= '<p class="hint">The client mail goes with a copy to rafi@unicybers.com. Fluent SMTP sends it.</p></article></div>';
        return $html;
    }

    private function view_loans() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('loans')} ORDER BY id DESC LIMIT 100") ?: [];
        $html = '<div class="ub-card"><h2>Loans overview</h2><p>Loan principal is tracked separately from sales and operating expenses. New loans require administrator approval before disbursement.</p>';
        $html .= '<form class="ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_loan_create">'.wp_nonce_field('ub_loan_create','_wpnonce',true,false);
        $html .= '<div class="ub-2"><label>Direction<select name="loan_type"><option value="in">Loan In · Borrowed by UniCybers</option><option value="out">Loan Out · Advanced to staff/trainer</option></select></label><label>Borrower / Lender name<input name="borrower_name" required></label></div>';
        $html .= '<div class="ub-2"><label>Borrower type<select name="borrower_type"><option value="external">External</option><option value="staff">Staff</option><option value="trainer">Trainer</option></select></label><label>Principal<input type="number" name="principal" min="0.01" step="0.01" required></label></div>';
        $html .= '<div class="ub-2"><label>Currency<select name="currency">'.$this->money_options().'</select></label><label>Instalment amount<input type="number" name="repayment_amount" min="0" step="0.01"></label></div>';
        $html .= '<div class="ub-2"><label>Frequency<select name="frequency"><option value="monthly">Monthly</option><option value="weekly">Weekly</option><option value="quarterly">Quarterly</option><option value="yearly">Yearly</option></select></label><label>Issue date<input type="date" name="issue_date" value="'.esc_attr(current_time('Y-m-d')).'"></label></div>';
        $html .= '<div class="ub-2"><label>First due date<input type="date" name="first_due"></label><label>Reason<input name="reason"></label></div><button class="btn primary" type="submit">Submit for approval</button></form></div>';
        $html .= '<div class="ub-card" style="margin-top:12px"><h2>Loan register</h2><table class="ub-table"><thead><tr><th>Reference</th><th>Type / Person</th><th>Principal</th><th>Outstanding</th><th>Status / Actions</th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="5">No loans recorded.</td></tr>';
        foreach ($rows as $r) {
            $html .= '<tr><td>'.esc_html($r->loan_number).'</td><td>'.esc_html(strtoupper($r->loan_type).' · '.$r->borrower_name).'</td><td>'.esc_html($r->currency).' '.$this->money($r->principal).'</td><td>'.esc_html($r->currency).' '.$this->money($r->outstanding).'</td><td>'.esc_html(ucfirst($r->status));
            if ($r->status === 'pending' && $this->can('owner')) $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:6px"><input type="hidden" name="action" value="ub_loan_approve"><input type="hidden" name="loan_id" value="'.(int)$r->id.'">'.wp_nonce_field('ub_loan_approve','_wpnonce',true,false).'<button class="btn sm primary">Approve</button></form>';
            if ($r->status === 'active' && $this->cap('finance')) $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:6px"><input type="hidden" name="action" value="ub_loan_repay"><input type="hidden" name="loan_id" value="'.(int)$r->id.'">'.wp_nonce_field('ub_loan_repay','_wpnonce',true,false).'<input type="number" name="amount" min="0.01" max="'.esc_attr($r->outstanding).'" step="0.01" placeholder="Repayment" required style="width:110px"><button class="btn sm">Record repayment</button></form>';
            $html .= '</td></tr>';
        }
        return $html.'</tbody></table></div>';
    }

    public function loan_create() {
        $this->guard('ub_loan_create','money'); global $wpdb;
        $type = sanitize_key($_POST['loan_type'] ?? ''); if (!in_array($type,['in','out'],true)) wp_die('Invalid loan type.');
        $principal = (float)($_POST['principal'] ?? 0); $name = sanitize_text_field(wp_unslash($_POST['borrower_name'] ?? ''));
        if ($principal <= 0 || !$name) wp_die('Enter a valid person and principal amount.');
        $number = 'UCL-'.current_time('Ymd').'-'.wp_generate_password(5,false,false);
        $wpdb->insert($this->t('loans'), ['loan_number'=>$number,'loan_type'=>$type,'borrower_type'=>sanitize_key($_POST['borrower_type'] ?? 'external'),'borrower_name'=>$name,'principal'=>$principal,'currency'=>sanitize_text_field($_POST['currency'] ?? 'INR'),'repayment_amount'=>max(0,(float)($_POST['repayment_amount'] ?? 0)),'frequency'=>sanitize_key($_POST['frequency'] ?? 'monthly'),'issue_date'=>sanitize_text_field($_POST['issue_date'] ?? '') ?: null,'first_due'=>sanitize_text_field($_POST['first_due'] ?? '') ?: null,'reason'=>sanitize_textarea_field(wp_unslash($_POST['reason'] ?? '')),'status'=>'pending','outstanding'=>$principal,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        $id=(int)$wpdb->insert_id; $this->audit('create','loan',$id,$number.' pending approval'); wp_safe_redirect($this->url(['ub'=>'finance','tab'=>'loans'])); exit;
    }

    public function loan_approve() {
        $this->guard('ub_loan_approve','owner'); global $wpdb; $id=absint($_POST['loan_id'] ?? 0);
        $loan=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('loans')} WHERE id=%d",$id)); if (!$loan || $loan->status!=='pending') wp_die('Loan is not awaiting approval.');
        $wpdb->update($this->t('loans'),['status'=>'active','approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql')],['id'=>$id]);
        $this->audit('approve','loan',$id,$loan->loan_number.' approved. Record actual disbursement separately in the cash/bank ledger.'); wp_safe_redirect($this->url(['ub'=>'finance','tab'=>'loans'])); exit;
    }

    public function loan_repay() {
        $this->guard('ub_loan_repay','money'); global $wpdb; $id=absint($_POST['loan_id'] ?? 0); $amount=(float)($_POST['amount'] ?? 0);
        $loan=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->t('loans')} WHERE id=%d",$id));
        if (!$loan || $loan->status!=='active' || $amount<=0 || $amount>(float)$loan->outstanding) wp_die('Invalid repayment amount or loan status.');
        $wpdb->insert($this->t('loan_txns'),['loan_id'=>$id,'txn_type'=>'repayment','amount'=>$amount,'txn_date'=>current_time('Y-m-d'),'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        $new=max(0,(float)$loan->outstanding-$amount); $wpdb->update($this->t('loans'),['outstanding'=>$new,'status'=>$new<=0?'closed':'active'],['id'=>$id]);
        $this->audit('repay','loan',$id,$loan->loan_number.' repayment '.$amount); wp_safe_redirect($this->url(['ub'=>'finance','tab'=>'loans'])); exit;
    }

    private function view_finance_reminders() {
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->t('reminders')} ORDER BY due_on ASC LIMIT 100") ?: [];
        $html='<div class="ub-card"><h2>Financial reminders</h2><p>Track tax deadlines, payouts, renewals, loan instalments and compliance dates. Recurrence is stored per reminder for scheduled follow-up.</p>';
        $html.='<form class="ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ub_reminder_manage">'.wp_nonce_field('ub_reminder_manage','_wpnonce',true,false);
        $html.='<div class="ub-2"><label>Title<input name="title" required></label><label>Category<select name="kind"><option value="tax">Taxes</option><option value="payout">Payouts</option><option value="renewal">Renewals</option><option value="loan">Loans</option><option value="invoice">Invoices</option><option value="compliance">Compliance</option><option value="other">Custom</option></select></label></div>';
        $html.='<div class="ub-2"><label>Due date<input type="date" name="due_on" required></label><label>Repeat<select name="recurrence"><option value="none">Does not repeat</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="quarterly">Quarterly</option><option value="halfyearly">Half-yearly</option><option value="yearly">Yearly</option></select></label></div>';
        $html.='<div class="ub-2"><label>Notify before<select name="advance_days"><option value="0">On due date</option><option value="1">1 day</option><option value="3">3 days</option><option value="7" selected>7 days</option><option value="14">14 days</option><option value="30">30 days</option></select></label><label>Assigned to<input name="assignee" placeholder="Administrator"></label></div><label>Notes<input name="note"></label><button class="btn primary">Add reminder</button></form></div>';
        $html.='<div class="ub-card" style="margin-top:12px"><h2>Reminder register</h2><table class="ub-table"><thead><tr><th>Reminder</th><th>Category</th><th>Due</th><th>Repeat</th><th>Status</th></tr></thead><tbody>';
        if (!$rows) $html.='<tr><td colspan="5">No reminders yet.</td></tr>';
        foreach($rows as $r) $html.='<tr><td>'.esc_html($r->title).'<br><small>'.esc_html($r->contact_name).'</small></td><td>'.esc_html(ucfirst($r->kind)).'</td><td>'.esc_html($r->due_on).'</td><td>'.esc_html($r->recurrence ?? 'none').'</td><td>'.($r->done?'Completed':'Open').'</td></tr>';
        return $html.'</tbody></table></div>';
    }

    public function reminder_manage() {
        $this->guard('ub_reminder_manage','money'); global $wpdb; $title=sanitize_text_field(wp_unslash($_POST['title'] ?? '')); if (!$title) wp_die('Enter a reminder title.');
        $wpdb->insert($this->t('reminders'),['title'=>$title,'due_on'=>sanitize_text_field($_POST['due_on'] ?? '') ?: null,'kind'=>sanitize_key($_POST['kind'] ?? 'other'),'contact_name'=>sanitize_text_field(wp_unslash($_POST['assignee'] ?? '')),'note'=>sanitize_textarea_field(wp_unslash($_POST['note'] ?? '')),'recurrence'=>sanitize_key($_POST['recurrence'] ?? 'none'),'advance_days'=>absint($_POST['advance_days'] ?? 7),'assignee'=>sanitize_text_field(wp_unslash($_POST['assignee'] ?? '')),'next_due_on'=>sanitize_text_field($_POST['due_on'] ?? '') ?: null,'done'=>0,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        $this->audit('create','reminder',(int)$wpdb->insert_id,$title); wp_safe_redirect($this->url(['ub'=>'finance','tab'=>'reminders'])); exit;
    }

    public function reminder() {
        $this->guard('ub_reminder', 'sales');
        global $wpdb;
        $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        if ($title === '') wp_die('Type the reminder.');
        $wpdb->insert($this->t('reminders'), [
            'title'=>$title,
            'due_on'=>sanitize_text_field($_POST['due_on'] ?? '') ?: null,
            'kind'=>'followup',
            'contact_name'=>sanitize_text_field(wp_unslash($_POST['contact_name'] ?? '')),
            'note'=>sanitize_text_field(wp_unslash($_POST['note'] ?? '')),
            'done'=>0,
            'created_by'=>get_current_user_id(),
            'created_at'=>current_time('mysql'),
        ]);
        $this->audit('add', 'reminder', (int)$wpdb->insert_id, $title);
        wp_safe_redirect($this->url(['ub'=>'home']));
        exit;
    }

    public function chase() {
        $this->guard('ub_chase', 'sales');
        $n = 0;
        foreach ($this->docs("WHERE doc_type='invoice'") as $d) {
            if (!$d->contact_email) continue;
            if (!in_array($this->derived_status($d), ['sent','part_paid','overdue'], true)) continue;
            $due = (float)$d->total - (float)$d->paid;
            wp_mail($d->contact_email, 'UniCybers - pending invoice '.($d->number ?: ''), "Hello,\n\nA payment of ".$d->currency.' '.$this->money($due)." is still open on ".($d->number ?: 'your invoice').".\n\nUniCybers VTZ LLP\nsupport@unicybers.com", ['Cc: rafi@unicybers.com', 'From: '.$this->mail_from()]);
            $n++;
        }
        $this->audit('email', 'chase', 0, $n.' clients');
        wp_safe_redirect($this->url(['ub'=>'home']));
        exit;
    }

    private function subs_panel() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('subs')} ORDER BY id DESC LIMIT 30") ?: [];
        $html = '<article class="ub-card"><h2>Subscriptions</h2>';
        $html .= '<form class="ub-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<input type="hidden" name="action" value="ub_sub">'.wp_nonce_field('ub_sub','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Kind<select name="kind"><option value="training">Training</option><option value="labs">Labs</option><option value="lms">LMS</option></select></label>';
        $html .= '<label>Company<input name="contact_name" required></label></div>';
        $html .= '<div class="ub-2"><label>Email<input type="email" name="contact_email"></label><label>Batch<input name="batch_name"></label></div>';
        $html .= '<div class="ub-2"><label>Monthly Amount<input type="number" step="0.01" min="0" name="amount" required></label><label>Next Invoice<input type="date" name="next_on" value="'.esc_attr(current_time('Y-m-d')).'"></label></div>';
        $html .= '<label class="check"><input type="checkbox" name="charge_monthly" value="1" checked> Charge every month</label>';
        $html .= '<button class="btn primary" type="submit">Save Subscription</button></form>';
        if ($rows) {
            $html .= '<table class="ub-table"><thead><tr><th>Kind</th><th>Company</th><th>Amount</th><th>Next</th><th>Monthly</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                $html .= '<tr><td>'.esc_html(ucfirst($r->kind)).'</td><td>'.esc_html($r->contact_name).'</td><td>'.esc_html($r->currency).' '.$this->money($r->amount).'</td><td>'.esc_html($r->next_on).'</td><td>'.($r->charge_monthly && $r->active ? 'Yes' : 'Off').'</td></tr>';
            }
            $html .= '</tbody></table>';
        }
        return $html.'</article>';
    }

    public function sub() {
        $this->guard('ub_sub', 'sales');
        global $wpdb;
        $kind = sanitize_key($_POST['kind'] ?? 'labs');
        if (!in_array($kind, ['training','labs','lms'], true)) $kind = 'labs';
        $wpdb->insert($this->t('subs'), [
            'kind'=>$kind,
            'contact_name'=>sanitize_text_field(wp_unslash($_POST['contact_name'] ?? '')),
            'contact_email'=>sanitize_email(wp_unslash($_POST['contact_email'] ?? '')),
            'batch_name'=>sanitize_text_field(wp_unslash($_POST['batch_name'] ?? '')),
            'amount'=>round((float)($_POST['amount'] ?? 0), 2),
            'currency'=>'INR',
            'course_days'=>45,
            'lab_free_days'=>30,
            'charge_monthly'=>empty($_POST['charge_monthly']) ? 0 : 1,
            'next_on'=>sanitize_text_field($_POST['next_on'] ?? '') ?: current_time('Y-m-d'),
            'active'=>1,
            'created_by'=>get_current_user_id(),
            'created_at'=>current_time('mysql'),
        ]);
        $this->audit('add', 'subscription', (int)$wpdb->insert_id, $kind);
        wp_safe_redirect($this->url(['ub'=>'subs']));
        exit;
    }

    private function follow_on_subs($doc_id, $data) {
        if (($data['doc_type'] ?? '') !== 'invoice') return;
        global $wpdb;
        $days = (int)($data['course_days'] ?? 0);
        $lab = (float)($data['lab_fee'] ?? 0);
        if (!empty($_POST['lab_follow']) && $lab > 0 && $days >= 30) {
            $exists = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->t('subs')} WHERE doc_id=%d AND kind='labs'", $doc_id));
            if (!$exists) {
                $wpdb->insert($this->t('subs'), [
                    'kind'=>'labs','contact_name'=>$data['contact_name'],'contact_email'=>$data['contact_email'],
                    'batch_name'=>$data['batch_label'],'amount'=>$lab,'currency'=>$data['currency'],
                    'course_days'=>$days,'lab_free_days'=>30,'charge_monthly'=>1,
                    'next_on'=>gmdate('Y-m-d', strtotime($data['doc_date'].' +30 days')),
                    'active'=>1,'doc_id'=>$doc_id,'note'=>'First 30 days free, then monthly labs.',
                    'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),
                ]);
            }
        }
        $lms = (float)($data['lms_fee'] ?? 0);
        if (!empty($_POST['lms_monthly']) && $lms > 0) {
            $exists = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->t('subs')} WHERE doc_id=%d AND kind='lms'", $doc_id));
            if (!$exists) {
                $wpdb->insert($this->t('subs'), [
                    'kind'=>'lms','contact_name'=>$data['contact_name'],'contact_email'=>$data['contact_email'],
                    'batch_name'=>$data['batch_label'],'amount'=>$lms,'currency'=>$data['currency'],
                    'course_days'=>0,'lab_free_days'=>0,'charge_monthly'=>1,
                    'next_on'=>gmdate('Y-m-d', strtotime($data['doc_date'].' +1 month')),
                    'active'=>1,'doc_id'=>$doc_id,'note'=>'Monthly LMS hosting.',
                    'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),
                ]);
            }
        }
    }

    private function tick_subs() {
        global $wpdb;
        $table = $this->t('subs');
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) return;
        $today = current_time('Y-m-d');
        $ym = current_time('Y-m');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE active=1 AND charge_monthly=1 AND next_on IS NOT NULL AND next_on<=%s", $today)) ?: [];
        foreach ($rows as $r) {
            if ((string)$r->last_ym === $ym) continue;
            $names = ['training'=>'Training','labs'=>'Labs','lms'=>'LMS Hosting'];
            $sacs = ['training'=>'999293','labs'=>'998316','lms'=>'998315'];
            $base = round(((float)$r->amount) / 1.18, 2);
            $tax = round((float)$r->amount - $base, 2);
            $half = round($tax / 2, 2);
            $wpdb->insert($this->t('docs'), [
                'doc_type'=>'invoice','number'=>$this->next_number('invoice'),'status'=>'sent',
                'contact_name'=>$r->contact_name,'contact_email'=>$r->contact_email,'contact_country'=>'India',
                'currency'=>$r->currency ?: 'INR','supply'=>'domestic','price_mode'=>'incl','tax_rate'=>18,
                'subtotal'=>$base,'cgst'=>$half,'sgst'=>$half,'igst'=>0,'total'=>$r->amount,'doc_date'=>$today,'terms'=>$this->default_terms('invoice'),
                'product_line'=>$r->kind,'batch_label'=>$r->batch_name,'sac'=>$sacs[$r->kind] ?? '999293',
                'source'=>'subscription','source_id'=>(int)$r->id,'created_by'=>(int)$r->created_by,'created_at'=>current_time('mysql'),
            ]);
            $id = (int)$wpdb->insert_id;
            $wpdb->insert($this->t('lines'), [
                'doc_id'=>$id,'component'=>$names[$r->kind] ?? 'Service','basis'=>'Monthly','scope'=>(string)$r->batch_name,'amount'=>$r->amount,'sac'=>$sacs[$r->kind] ?? '999293',
            ]);
            if ($r->contact_email) {
                wp_mail($r->contact_email, 'UniCybers - '.$names[$r->kind].' invoice', "A new ".$names[$r->kind]." invoice is ready.\n".$r->currency.' '.$this->money($r->amount), ['Cc: rafi@unicybers.com', 'From: '.$this->mail_from()]);
            } else {
                wp_mail('rafi@unicybers.com', 'UniCybers - subscription invoice', $names[$r->kind].' for '.$r->contact_name.' '.$r->currency.' '.$this->money($r->amount), ['From: '.$this->mail_from()]);
            }
            $wpdb->update($table, ['last_ym'=>$ym, 'next_on'=>gmdate('Y-m-d', strtotime($today.' +1 month'))], ['id'=>(int)$r->id]);
            $this->audit('raise', 'subscription', (int)$r->id, $r->kind.' '.$r->contact_name);
        }
    }

    private function leads_panel() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->t('leads')} ORDER BY name ASC LIMIT 300") ?: [];
        $html = '<div class="ub-lms-people people-list" style="margin-top:14px"><div class="list-head"><h2>LMS People</h2>';
        $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<input type="hidden" name="action" value="ub_lead_sync">'.wp_nonce_field('ub_lead_sync','_wpnonce', true, false);
        $html .= '<button class="btn primary" type="submit">Sync People From LMS</button></form></div>';
        if (!$rows) return $html.'<p class="empty">No LMS people copied yet.</p></div>';
        foreach ($rows as $r) {
            $bits = array_filter([
                $r->email ?? '',
                !empty($r->phone) ? $r->phone : '',
                !empty($r->country) ? $r->country : '',
                !empty($r->currency) ? $r->currency : '',
                !empty($r->batch_name) ? $r->batch_name : '',
                !empty($r->status) ? ucfirst($r->status) : '',
            ]);
            $html .= '<article class="person-row"><div><strong>'.esc_html($this->nice_name($r->name)).'</strong><span>'.esc_html(implode(' · ', $bits)).'</span></div>';
            $html .= '<span class="pill">'.esc_html(ucwords(str_replace('_', ' ', (string)($r->lms_role ?: $r->kind)))).'</span></article>';
        }
        return $html.'</div>';
    }

    public function lead_sync() {
        $this->guard('ub_lead_sync', 'people');
        global $wpdb;
        $map = ['uc_student'=>'student','uc_trainer'=>'trainer','uc_coordinator'=>'coordinator','administrator'=>'super admin'];
        $seen = [];
        $n = 0;
        foreach ($map as $role=>$kind) {
            foreach (get_users(['role'=>$role, 'number'=>500]) as $u) {
                if (!$u->user_email || isset($seen[$u->ID])) continue;
                if ($role === 'administrator' && get_user_meta($u->ID, 'ub_role', true) === '' && !get_user_meta($u->ID, 'uc_phone', true)) continue;
                $seen[$u->ID] = 1;
                $this->save_lead($u, $kind);
                $n++;
            }
        }
        $this->audit('sync', 'lead', 0, $n.' people');
        wp_safe_redirect($this->url(['ub'=>'people']));
        exit;
    }

    private function save_lead($u, $kind) {
        global $wpdb;
        $phone = (string) get_user_meta($u->ID, 'uc_phone', true);
        $country = (string) get_user_meta($u->ID, 'uc_country', true);
        $currency = (string) get_user_meta($u->ID, 'uc_currency', true);
        $disabled = get_user_meta($u->ID, 'uc_disabled', true) || get_user_meta($u->ID, 'uc_archived', true);
        $status = $disabled ? 'disabled' : 'active';
        $last = (string) get_user_meta($u->ID, 'uc_last_login', true);
        $batch = '';
        $enrol = $wpdb->prefix.'uc_enrolments';
        $batches = $wpdb->prefix.'uc_batches';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $enrol)) === $enrol) {
            $batch = (string) $wpdb->get_var($wpdb->prepare("SELECT b.name FROM $enrol e LEFT JOIN $batches b ON b.id=e.batch_id WHERE e.user_id=%d AND e.status='active' ORDER BY e.id DESC LIMIT 1", $u->ID));
        }
        $wpdb->query($wpdb->prepare(
            "INSERT INTO {$this->t('leads')} (lms_user_id, name, email, kind, phone, country, currency, lms_role, status, batch_name, last_login, synced_at) VALUES (%d, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
             ON DUPLICATE KEY UPDATE name=VALUES(name), email=VALUES(email), kind=VALUES(kind), phone=VALUES(phone), country=VALUES(country), currency=VALUES(currency), lms_role=VALUES(lms_role), status=VALUES(status), batch_name=VALUES(batch_name), last_login=VALUES(last_login), synced_at=VALUES(synced_at)",
            $u->ID, $u->display_name, $u->user_email, $kind, $phone, $country, $currency, $kind, $status, $batch, $last, current_time('mysql')
        ));
    }

}

UC_Books::boot();
