# UniCybers Placement Desk

How the desk works for students and for staff. Matching is a rule, not an AI score. This is a candidate table, not a hiring pipeline.

Career IDs look like `UC-CR-#####` and do not change.

## What it is

Placement Desk is the academy’s candidate file. A learner fills a career profile, uploads a CV, and is matched against Job DNA that coordinators save. Match is **present / partial / missing**, including SIEM aliases (SIEM ↔ Splunk / QRadar / Microsoft Sentinel). Eligibility is years, education, certificates and required skills.

It is **not**:

- A Kanban pipeline
- An employer portal
- A college portal
- A live Naukri / LinkedIn / OpenAI product

## The five steps

1. **Profile** — contact, city, skills, preferred role, summary.
2. **CV** — resume, ID, degree or cyber certificate. Coordinators verify.
3. **Job DNA** — every opening is a structured record (role, company, location, required skills, min years, education, CTC).
4. **Match** — each required skill is present, partial or missing. Coverage % is explained. Ineligible means a rule failed, not a hidden model.
5. **Apply** — student saves / prepares / applies. Coordinator recommends and tracks interview → offer → joined.

## Student side

Sign in as the learner. Open **Placement Desk**.

- The Career ID in the header is permanent. Quote it to the coordinator.
- **Profile & CV** — save the career file, then upload resume, ID and a degree or certificate. Pending files wait for coordinator verify. A rejection includes a reason.
- Readiness chips show what is present, partial or missing (phone, city, skills, CV, and so on).
- **Jobs & match** — each open Job DNA shows eligibility, skill-by-skill coverage, and skill gaps mapped to a UniCybers course where one exists. Ineligible roles stay visible so the learner can close the gap.
- **My applications** — saved, preparing, applied, interview, offer, joined. Students do not invent a status; the desk records the move.

Students never see a pipeline board. They see their file and why a job does or does not fit.

## Staff side (Coordinator and Super Admin)

Open **Placement Desk**. Trainers do not run this desk.

KPI row: Career IDs, placement ready, CVs to review, open jobs.

The **Coordinator desk** table is the working surface:

| Column | Meaning |
| --- | --- |
| Career ID | Permanent `UC-CR-#####` |
| Candidate | Name and email |
| Readiness | Profile completeness |
| Best match | Top open Job DNA, eligibility, coverage |
| Stage | registered → profile incomplete → documents pending → ready → interviewing → offered → placed |

Open a row to verify a CV, read the match, recommend a job, or schedule an interview.

**Jobs & Job DNA** — add an opening as fields, not a pasted paragraph. Matching uses those fields.

**Applications** — recommended → saved → preparing → ready to apply → applied → interview → offer → joined / closed. Eligibility stays a rule when the status moves.

## Super Admin: Career Proxy

Rafi pastes the Apps Script web-app `/exec` URL and SHARED_TOKEN on Placement Desk. RapidAPI, Claude and Jooble keys stay in Google Script Properties. **Pull jobs (India cyber)** asks Career Proxy to discover openings. Board listings stay REVIEW until a coordinator saves Job DNA.

Client mandates and referrals are typed as Job DNA on this page and skip the board filter.

See `docs/placement-command-center.md` for the search → intelligence → Job DNA → evidence → match → apply → join pipeline.

Do not let a model hide why a candidate was ineligible. Do not send learners straight to an external board without the Career ID file.

## Roles

| Role | Placement Desk |
| --- | --- |
| Student | Own Career ID, profile, documents, jobs, applications |
| Coordinator | Candidate table, Job DNA, verify CVs, applications |
| Super Admin | All of the above, plus Career Proxy /exec URL and job-board pull |
| Trainer | Not available — training stays on Classes |

## Skill aliases (examples)

SIEM covers Splunk, QRadar, Microsoft Sentinel and “SIEM”. Ticketing covers ServiceNow, Jira and “ticketing”. Networking covers TCP/IP, OSI and “networking”. The full map lives in the placement matcher. Add aliases there; do not invent a second scoring system.
