<?php
/**
 * UniCybers Academy LMS: Zoom Meeting Provisioning & Settings Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Zoom_Meeting {
    const LICENSE_EMAIL = 'training@unicybers.com';

    public static function create_batch_meeting($batch) {
        $days = array_filter(explode(',', (string)$batch->recurrence_days));
        if (!$days || !$batch->class_start_time || !$batch->start_date || !$batch->end_date) {
            return new WP_Error('zoom_schedule', 'Complete batch dates, class days and class time first.');
        }

        $tz = $batch->timezone ?: 'Asia/Kolkata';
        try { $dtz = new DateTimeZone($tz); }
        catch (Exception $e) { return new WP_Error('timezone', 'Invalid batch timezone.'); }

        $start = new DateTime($batch->start_date . ' ' . $batch->class_start_time, $dtz);
        $end   = new DateTime($batch->end_date . ' ' . $batch->class_start_time, $dtz);
        $end->modify('+' . max(15, (int)$batch->class_duration) . ' minutes');

        $body = [
            'topic'      => $batch->name,
            'type'       => 8,
            'start_time' => $start->format('Y-m-d\TH:i:s'),
            'duration'   => max(15, (int)$batch->class_duration),
            'timezone'   => $tz,
            'agenda'     => 'UniCybers Academy live training',
            'recurrence' => [
                'type'             => 2,
                'repeat_interval'  => 1,
                'weekly_days'      => implode(',', array_map('absint', $days)),
                'end_date_time'    => $end->format('Y-m-d\TH:i:s\Z')
            ],
            'settings'   => UC_LMS_Zoom_Client::classroom_settings()
        ];

        return UC_LMS_Zoom_Client::request('POST', '/users/me/meetings', $body);
    }

    public static function update_batch_meeting($batch) {
        if (!$batch->zoom_meeting_id) {
            return new WP_Error('zoom_missing', 'No existing Zoom meeting is connected.');
        }
        $days = array_filter(explode(',', (string)$batch->recurrence_days));
        if (!$days || !$batch->class_start_time || !$batch->start_date || !$batch->end_date) {
            return new WP_Error('zoom_schedule', 'Complete batch dates, class days and class time first.');
        }

        $tz = $batch->timezone ?: 'Asia/Kolkata';
        try { $dtz = new DateTimeZone($tz); }
        catch (Exception $e) { return new WP_Error('timezone', 'Invalid batch timezone.'); }

        $start = new DateTime($batch->start_date . ' ' . $batch->class_start_time, $dtz);
        $end   = new DateTime($batch->end_date . ' ' . $batch->class_start_time, $dtz);
        $end->modify('+' . max(15, (int)$batch->class_duration) . ' minutes');

        $body = [
            'topic'      => $batch->name,
            'type'       => 8,
            'start_time' => $start->format('Y-m-d\TH:i:s'),
            'duration'   => max(15, (int)$batch->class_duration),
            'timezone'   => $tz,
            'agenda'     => 'UniCybers Academy live training',
            'recurrence' => [
                'type'             => 2,
                'repeat_interval'  => 1,
                'weekly_days'      => implode(',', array_map('absint', $days)),
                'end_date_time'    => $end->format('Y-m-d\TH:i:s\Z')
            ],
            'settings'   => UC_LMS_Zoom_Client::classroom_settings()
        ];

        return UC_LMS_Zoom_Client::request('PATCH', '/meetings/' . rawurlencode($batch->zoom_meeting_id), $body);
    }

    public static function provision_batch_zoom($batch_id) {
        global $wpdb;
        $t = UC_LMS_Database::table('batches');
        $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM `$t` WHERE id=%d", $batch_id));
        if (!$b) return ['status' => 'error', 'message' => 'Batch not found.'];

        $account = trim((string)get_option('uc_zoom_account_id', ''));
        $client  = trim((string)get_option('uc_zoom_client_id', ''));
        $secret  = trim((string)get_option('uc_zoom_client_secret', ''));

        if (!$account || !$client || !$secret) {
            $wpdb->update($t, ['zoom_status' => 'not_configured', 'zoom_error' => null], ['id' => $batch_id]);
            return ['status' => 'not_configured', 'message' => 'Zoom credentials are not configured.'];
        }

        $result = $b->zoom_meeting_id ? self::update_batch_meeting($b) : self::create_batch_meeting($b);
        if (is_wp_error($result)) {
            $wpdb->update($t, [
                'zoom_status' => 'error',
                'zoom_error'  => $result->get_error_message(),
                'updated_at'  => current_time('mysql')
            ], ['id' => $batch_id]);
            return ['status' => 'error', 'message' => $result->get_error_message()];
        }

        $data = [
            'zoom_status' => 'ready',
            'zoom_error'  => null,
            'updated_at'  => current_time('mysql')
        ];
        if (!$b->zoom_meeting_id && !empty($result['id'])) $data['zoom_meeting_id'] = (string)$result['id'];
        if (isset($result['join_url'])) $data['zoom_join_url'] = esc_url_raw($result['join_url']);
        if (isset($result['start_url'])) $data['zoom_start_url'] = esc_url_raw($result['start_url']);
        if (isset($result['password'])) $data['zoom_passcode'] = sanitize_text_field($result['password']);

        $wpdb->update($t, $data, ['id' => $batch_id]);
        return ['status' => 'ready', 'message' => 'Zoom meeting connected.'];
    }

    public static function portal_start_class_zoom($session, $alternative_hosts = '') {
        $mid = trim((string)($session->zoom_meeting_id ?? ''));
        if ($mid === '' && !empty($session->batch_id)) {
            global $wpdb;
            $mid = (string) $wpdb->get_var($wpdb->prepare("SELECT zoom_meeting_id FROM " . UC_LMS_Database::table('batches') . " WHERE id=%d", (int)$session->batch_id));
        }
        if ($mid === '') return '';
        UC_LMS_Zoom_Client::request('PATCH', '/meetings/' . rawurlencode($mid), [
            'settings' => UC_LMS_Zoom_Client::classroom_settings($alternative_hosts),
        ]);
        $got = UC_LMS_Zoom_Client::request('GET', '/meetings/' . rawurlencode($mid));
        if (is_wp_error($got) || empty($got['start_url'])) return '';
        $url = esc_url_raw($got['start_url']);
        global $wpdb;
        if (!empty($session->id) && $url) {
            $wpdb->update(UC_LMS_Database::table('sessions'), ['zoom_start_url' => $url], ['id' => (int)$session->id]);
        }
        return $url;
    }

    public static function portal_class_zoom($args) {
        $account = trim((string)get_option('uc_zoom_account_id', ''));
        $client  = trim((string)get_option('uc_zoom_client_id', ''));
        $secret  = trim((string)get_option('uc_zoom_client_secret', ''));
        if (!$account || !$client || !$secret) return new WP_Error('zoom_config', 'Zoom is not connected.');
        $existing = trim((string)($args['zoom_meeting_id'] ?? ''));
        $tz = $args['timezone'] ?: 'Asia/Kolkata';
        if ($existing) {
            try { $existing_zone = new DateTimeZone($tz); } catch (Exception $e) { $tz = 'Asia/Kolkata'; $existing_zone = new DateTimeZone($tz); }
            try { $existing_start = new DateTime(trim($args['session_date'].' '.$args['start_time']), $existing_zone); } catch (Exception $e) { return new WP_Error('zoom_schedule', 'Class date or time is not valid.'); }
            $existing_duration = 60;
            if (!empty($args['end_time'])) {
                try { $existing_end = new DateTime(trim($args['session_date'].' '.$args['end_time']), $existing_zone); $diff=(int)round(($existing_end->getTimestamp()-$existing_start->getTimestamp())/60); if ($diff>=15 && $diff<=300) $existing_duration=$diff; } catch (Exception $e) {}
            }
            $patched = UC_LMS_Zoom_Client::request('PATCH', '/meetings/'.rawurlencode($existing), [
                'topic'=>$args['title'] ?: 'UniCybers class',
                'start_time'=>$existing_start->format('Y-m-d\TH:i:s'),
                'duration'=>$existing_duration,
                'timezone'=>$tz,
                'agenda'=>'UniCybers Academy live class',
                'settings'=>UC_LMS_Zoom_Client::classroom_settings($args['alternative_hosts'] ?? ''),
            ]);
            if (is_wp_error($patched)) return $patched;
            $got = UC_LMS_Zoom_Client::request('GET', '/meetings/'.rawurlencode($existing));
            if (!is_wp_error($got) && !empty($got['join_url'])) return ['join_url'=>$got['join_url'],'passcode'=>$got['password'] ?? '','zoom_meeting_id'=>(string)($got['id'] ?? $existing),'start_url'=>$got['start_url'] ?? ''];
        }
        try { $dtz = new DateTimeZone($tz); } catch (Exception $e) { $tz = 'Asia/Kolkata'; $dtz = new DateTimeZone($tz); }
        try { $start = new DateTime(trim($args['session_date'] . ' ' . $args['start_time']), $dtz); } catch (Exception $e) { return new WP_Error('zoom_schedule', 'Class date or time is not valid.'); }
        $mins = 60;
        if (!empty($args['end_time'])) {
            try {
                $end = new DateTime(trim($args['session_date'] . ' ' . $args['end_time']), $dtz);
                $diff = (int)round(($end->getTimestamp() - $start->getTimestamp()) / 60);
                if ($diff >= 15 && $diff <= 300) $mins = $diff;
            } catch (Exception $e) {}
        }
        $body = [
            'topic'      => $args['title'] ?: 'UniCybers class',
            'type'       => 2,
            'start_time' => $start->format('Y-m-d\TH:i:s'),
            'duration'   => $mins,
            'timezone'   => $tz,
            'agenda'     => 'UniCybers Academy live class',
            'settings'   => UC_LMS_Zoom_Client::classroom_settings($args['alternative_hosts'] ?? ''),
        ];
        $hosts = trim((string)($args['alternative_hosts'] ?? ''));
        $host = rawurlencode(self::LICENSE_EMAIL);
        $result = UC_LMS_Zoom_Client::request('POST', '/users/' . $host . '/meetings', $body);
        $hosts_note = '';
        if (is_wp_error($result) && $hosts !== '') {
            unset($body['settings']['alternative_hosts']);
            $result = UC_LMS_Zoom_Client::request('POST', '/users/' . $host . '/meetings', $body);
            $hosts_note = ' The trainer and support host were not added. Each email must already be a user on the UniCybers Zoom account.';
        }
        if (is_wp_error($result)) $result = UC_LMS_Zoom_Client::request('POST', '/users/me/meetings', $body);
        if (is_wp_error($result)) return $result;
        if (empty($result['join_url'])) return new WP_Error('zoom_api', 'Zoom did not return a join link.');
        return ['join_url' => $result['join_url'], 'passcode' => $result['password'] ?? '', 'zoom_meeting_id' => isset($result['id']) ? (string)$result['id'] : '', 'start_url' => $result['start_url'] ?? '', 'hosts_note' => $hosts_note];
    }

    public static function portal_ensure_meeting_id($session) {
        if (!empty($session->zoom_meeting_id)) return $session;
        $blob = (string)($session->join_url ?? '') . ' ' . (string)($session->start_url ?? '') . ' ' . (string)($session->recording_url ?? '');
        $id = '';
        if (preg_match('~(?:zoom\.us|zoom\.com)/(?:j|s|w)/(\d{8,})~i', $blob, $m)) $id = $m[1];
        if ($id === '') return $session;
        global $wpdb;
        $wpdb->update(UC_LMS_Database::table('sessions'), ['zoom_meeting_id' => $id, 'updated_at' => current_time('mysql')], ['id' => $session->id]);
        $session->zoom_meeting_id = $id;
        return $session;
    }
}
