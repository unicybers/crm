<?php
/**
 * UniCybers Academy LMS: Zoom API Client & OAuth Token Manager.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Zoom_Client {

    public static function token() {
        $account = trim((string)get_option('uc_zoom_account_id', ''));
        $client  = trim((string)get_option('uc_zoom_client_id', ''));
        $secret  = trim((string)get_option('uc_zoom_client_secret', ''));

        if (!$account || !$client || !$secret) {
            return new WP_Error('zoom_config', 'Zoom Account ID, Client ID and Client Secret are required.');
        }

        // Cache token in transient for 55 minutes
        $cache_key = 'uc_zoom_access_token_' . md5($account . $client);
        $cached = get_transient($cache_key);
        if ($cached) return $cached;

        $response = wp_remote_post('https://zoom.us/oauth/token', [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($client . ':' . $secret),
                'Content-Type'  => 'application/x-www-form-urlencoded'
            ],
            'body' => [
                'grant_type' => 'account_credentials',
                'account_id' => $account
            ]
        ]);

        if (is_wp_error($response)) return $response;
        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($code < 200 || $code >= 300 || empty($data['access_token'])) {
            return new WP_Error('zoom_auth', $data['reason'] ?? $data['message'] ?? 'Zoom authentication failed.');
        }

        $token = $data['access_token'];
        $expires = max(60, (int)($data['expires_in'] ?? 3600) - 300);
        set_transient($cache_key, $token, $expires);
        return $token;
    }

    public static function request($method, $path, $body = null) {
        $token = self::token();
        if (is_wp_error($token)) return $token;

        $args = [
            'timeout' => 30,
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ]
        ];
        if ($body !== null) {
            $args['body'] = wp_json_encode($body);
        }

        $r = wp_remote_request('https://api.zoom.us/v2' . $path, $args);
        if (is_wp_error($r)) return $r;

        $code = wp_remote_retrieve_response_code($r);
        $data = json_decode(wp_remote_retrieve_body($r), true);

        if ($code < 200 || $code >= 300) {
            $msg = trim((string)($data['message'] ?? 'Zoom API request failed.'));
            return new WP_Error('zoom_api', $msg);
        }
        return $data ?: [];
    }

    public static function classroom_settings($alternative_hosts = '') {
        $settings = [
            'host_video'             => true,
            'participant_video'      => true,
            'join_before_host'       => true,
            'jbh_time'               => 0,
            'waiting_room'           => false,
            'mute_upon_entry'        => false,
            'approval_type'          => 2,
            'auto_recording'         => 'cloud',
            'meeting_authentication' => false,
            'allow_multiple_devices' => true,
        ];
        $hosts = trim((string) $alternative_hosts);
        if ($hosts !== '') $settings['alternative_hosts'] = $hosts;
        return $settings;
    }
}
