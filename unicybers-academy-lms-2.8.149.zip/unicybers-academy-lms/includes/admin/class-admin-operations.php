<?php
/**
 * UniCybers Academy LMS: Admin Operations (Attendance and Materials).
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Admin_Operations extends UC_LMS_Admin_Base {
    public static function instance() {
        static $i = null;
        if (!$i) $i = new self();
        return $i;
    }

    public function attendance_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $rows = $wpdb->get_results("SELECT a.*, u.display_name, s.title session_title, s.session_date FROM {$this->table('attendance')} a LEFT JOIN {$wpdb->users} u ON u.ID=a.user_id LEFT JOIN {$this->table('sessions')} s ON s.id=a.session_id ORDER BY a.id DESC LIMIT 100");
        echo '<div class="wrap"><h1>Attendance Records</h1>';
        $this->render_notice();
        echo '<table class="widefat striped"><thead><tr><th>Student</th><th>Class</th><th>Date</th><th>Joined At</th><th>Minutes</th><th>Status</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr><td>' . esc_html($r->display_name) . '</td><td>' . esc_html($r->session_title) . '</td><td>' . esc_html($r->session_date) . '</td><td>' . esc_html($r->joined_at) . '</td><td>' . (int)$r->minutes . '</td><td>' . esc_html($r->status) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function save_attendance() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_attendance')) wp_die('Not allowed');
        global $wpdb;
        $wpdb->insert($this->table('attendance'), [
            'session_id' => absint($_POST['session_id'] ?? 0),
            'user_id'    => absint($_POST['user_id'] ?? 0),
            'status'     => sanitize_key($_POST['status'] ?? 'present'),
            'minutes'    => absint($_POST['minutes'] ?? 0),
            'joined_at'  => $this->now()
        ]);
        $this->redirect('uc-attendance', $this->notice('success', 'Attendance recorded.'));
    }

    public function materials_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $batches = $wpdb->get_results("SELECT id, name FROM {$this->table('batches')} ORDER BY name");
        $rows = $wpdb->get_results("SELECT m.*, b.name batch_name FROM {$this->table('materials')} m LEFT JOIN {$this->table('batches')} b ON b.id=m.batch_id ORDER BY m.id DESC LIMIT 100");
        echo '<div class="wrap"><h1>Course Materials</h1>';
        $this->render_notice();
        echo '<div class="uc-panel"><h2>Add Material</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('uc_save_material');
        echo '<input type="hidden" name="action" value="uc_save_material"><select name="batch_id" required><option value="">Batch</option>';
        foreach ($batches as $b) echo '<option value="' . absint($b->id) . '">' . esc_html($b->name) . '</option>';
        echo '</select> <input class="regular-text" name="title" required placeholder="Title"> <input class="regular-text" name="url" required placeholder="URL"> <input name="type" placeholder="Type (PDF, Link, Lab)" style="width:140px"> ';
        submit_button('Add Material', 'primary', 'submit', false);
        echo '</form></div>';
        echo '<table class="widefat striped"><thead><tr><th>Batch</th><th>Title</th><th>Type</th><th>URL</th><th>Action</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $del = wp_nonce_url(admin_url('admin-post.php?action=uc_delete_material&id=' . $r->id), 'uc_delete_material_' . $r->id);
            echo '<tr><td>' . esc_html($r->batch_name) . '</td><td>' . esc_html($r->title) . '</td><td>' . esc_html($r->type) . '</td><td><a href="' . esc_url($r->url) . '" target="_blank">' . esc_html($r->url) . '</a></td><td><a href="' . esc_url($del) . '" onclick="return confirm(\'Delete?\')">Delete</a></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function save_material() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_material')) wp_die('Not allowed');
        global $wpdb;
        $wpdb->insert($this->table('materials'), [
            'batch_id'   => absint($_POST['batch_id'] ?? 0),
            'title'      => sanitize_text_field($_POST['title'] ?? ''),
            'type'       => sanitize_text_field($_POST['type'] ?? ''),
            'url'        => esc_url_raw($_POST['url'] ?? ''),
            'added_by'   => get_current_user_id(),
            'visible'    => 1,
            'created_at' => $this->now()
        ]);
        $this->redirect('uc-materials', $this->notice('success', 'Material added.'));
    }

    public function delete_material() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_GET['id'] ?? 0);
        check_admin_referer('uc_delete_material_' . $id);
        global $wpdb;
        $wpdb->delete($this->table('materials'), ['id' => $id]);
        $this->redirect('uc-materials', $this->notice('success', 'Material deleted.'));
    }

    public function announcements_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $batches = $wpdb->get_results("SELECT id, name FROM {$this->table('batches')} ORDER BY name");
        $rows = $wpdb->get_results("SELECT a.*, b.name batch_name, u.display_name FROM {$this->table('announcements')} a LEFT JOIN {$this->table('batches')} b ON b.id=a.batch_id LEFT JOIN {$wpdb->users} u ON u.ID=a.by_user_id ORDER BY a.id DESC LIMIT 100");
        echo '<div class="wrap"><h1>Announcements</h1>';
        $this->render_notice();
        echo '<div class="uc-panel"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('uc_save_announcement');
        echo '<input type="hidden" name="action" value="uc_save_announcement"><select name="audience"><option value="all">All learners</option><option value="batch">Batch</option></select> <select name="batch_id"><option value="">Batch</option>';
        foreach ($batches as $b) echo '<option value="' . absint($b->id) . '">' . esc_html($b->name) . '</option>';
        echo '</select><br><input class="regular-text" name="title" required placeholder="Title"><br><textarea class="large-text" name="body" required rows="4" placeholder="Announcement"></textarea>';
        submit_button('Publish Announcement');
        echo '</form></div><table class="widefat striped"><thead><tr><th>Title</th><th>Audience</th><th>Batch</th><th>By</th><th>Date</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr><td>' . esc_html($r->title) . '</td><td>' . esc_html($r->audience) . '</td><td>' . esc_html($r->batch_name ?: 'All') . '</td><td>' . esc_html($r->display_name) . '</td><td>' . esc_html($r->created_at) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function save_announcement() {
        if (!$this->can_manage() || !check_admin_referer('uc_save_announcement')) wp_die('Not allowed');
        global $wpdb;
        $wpdb->insert($this->table('announcements'), [
            'audience'   => sanitize_key($_POST['audience'] ?? 'all'),
            'batch_id'   => absint($_POST['batch_id'] ?? 0) ?: null,
            'title'      => sanitize_text_field($_POST['title'] ?? ''),
            'body'       => wp_kses_post($_POST['body'] ?? ''),
            'by_user_id' => get_current_user_id(),
            'created_at' => $this->now()
        ]);
        $this->redirect('uc-announcements', $this->notice('success', 'Announcement published.'));
    }



}
