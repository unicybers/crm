<?php
/**
 * UniCybers Academy LMS: Academic Form Handlers (Courses, Batches, Notices, Enquiries).
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Handler_Academic {

    public static function course_save($portal){
        $portal->guard('uc_portal_course_save',['super_admin','coordinator']);
        global $wpdb;
        $id = absint($_POST['id'] ?? 0); $do = sanitize_key($_POST['do'] ?? 'save');
        if ($do==='delete' && $id) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT name FROM {$portal->t('courses')} WHERE id=%d", $id));
            $wpdb->query($wpdb->prepare("UPDATE {$portal->t('batches')} SET course_id=0 WHERE course_id=%d", $id));
            $ok = $wpdb->delete($portal->t('courses'), ['id'=>$id]);
            if ($ok === false) $portal->db_fail('courses');
            $portal->log_audit('course',$id,'delete','Deleted course '.($row->name ?? $id).'. Linked batches set to Unassigned.');
            $portal->set_flash('Course deleted. Batches that used it now show Unassigned. Edit each batch to pick another course.');
            $portal->back('courses');
        }
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        if (!$name) { $portal->set_flash('Enter a course name.','warn'); $portal->back('courses'); }
        $data = [
            'name'=>$name, 'description'=>wp_kses_post(wp_unslash($_POST['description'] ?? '')),
            'category'=>sanitize_text_field(wp_unslash($_POST['category'] ?? '')), 'level'=>sanitize_text_field(wp_unslash($_POST['level'] ?? '')),
            'duration'=>sanitize_text_field(wp_unslash($_POST['duration'] ?? '')), 'mode'=>sanitize_key($_POST['mode'] ?? 'live'),
            'status'=>sanitize_key($_POST['status'] ?? 'active'), 'enrolment_open'=>!empty($_POST['enrolment_open'])?1:0,
            'outline'=>wp_kses_post(wp_unslash($_POST['outline'] ?? '')), 'updated_at'=>current_time('mysql'),
        ];
        if ($id) {
            $ok = $portal->update_row('courses', $data, ['id'=>$id]);
            if ($ok === false) $portal->db_fail('courses');
            $portal->log_audit('course',$id,'update','Updated course '.$name);
            $portal->set_flash('Course updated.');
        } else {
            $base = sanitize_title($name) ?: 'course';
            $data['slug'] = $base.'-'.wp_rand(100,999);
            $tries = 0;
            while ($tries < 6 && $wpdb->get_var($wpdb->prepare("SELECT id FROM {$portal->t('courses')} WHERE slug=%s", $data['slug']))) {
                $data['slug'] = $base.'-'.wp_rand(1000,9999); $tries++;
            }
            $data['created_at'] = current_time('mysql');
            $ok = $portal->insert_row('courses', $data);
            if (!$ok) $portal->db_fail('courses');
            $newId = (int)$wpdb->insert_id;
            $portal->log_audit('course',$newId,'create','Created course '.$name);
            $portal->set_flash('Course created.');
        }
        $portal->back('courses');
    }

    public static function batch_save($portal){
        $portal->guard('uc_portal_batch_save',['super_admin','coordinator']);
        global $wpdb;
        $id = absint($_POST['id'] ?? 0); $do = sanitize_key($_POST['do'] ?? 'save');
        if ($do==='delete' && $id) {
            if ($portal->role()!=='super_admin' && $portal->role()!=='coordinator') wp_die('Only Super Admin or a Coordinator can delete a batch.',403);
            $name = (string)$wpdb->get_var($wpdb->prepare("SELECT name FROM {$portal->t('batches')} WHERE id=%d",$id));
            $wpdb->delete($portal->t('attendance'),['batch_id'=>$id]); $wpdb->delete($portal->t('sessions'),['batch_id'=>$id]);
            if ($portal->has_table('batch_schedule')) $wpdb->delete($portal->t('batch_schedule'),['batch_id'=>$id]);
            $wpdb->delete($portal->t('enrolments'),['batch_id'=>$id]); $wpdb->delete($portal->t('materials'),['batch_id'=>$id]);
            $ok = $wpdb->delete($portal->t('batches'),['id'=>$id]);
            if ($ok === false) $portal->db_fail('batches');
            $portal->log_audit('batch',$id,'delete','Deleted batch '.$name);
            $portal->set_flash('Batch deleted.'); $portal->back('batches');
        }
        if (($do==='generate_schedule' || $do==='provision_zoom') && $id) {
            $portal->set_flash('Classes are scheduled on Classes → Add class. Create the batch here, then pick the batch, day and time there.','warn');
            $portal->back('batches');
        }
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? '')); $course_id = absint($_POST['course_id'] ?? 0);
        if (!$name || !$course_id) { $portal->set_flash('Enter a batch name and choose a course.','warn'); $portal->back('batches'); }
        $start = $portal->ymd($_POST['start_date'] ?? ''); $end = $portal->ymd($_POST['end_date'] ?? '');
        if ($start === null || $end === null) { $portal->set_flash('Choose a real start and end date.','warn'); $portal->back('batches'); }
        if ($start && $end && $start > $end) { $portal->set_flash('The start date must be before the end date.','warn'); $portal->back('batches'); }
        $tz = sanitize_text_field($_POST['timezone'] ?? 'Asia/Kolkata') ?: 'Asia/Kolkata';
        $days = array_values(array_intersect(array_map('sanitize_text_field', (array)($_POST['recurrence_days'] ?? [])), ['1','2','3','4','5','6','7']));
        $data = [
            'course_id'=>$course_id, 'name'=>$name, 'mode'=>sanitize_key($_POST['mode'] ?? 'online'),
            'default_meeting_provider'=>in_array(sanitize_key($_POST['default_meeting_provider'] ?? 'zoom'), ['zoom','google_meet','teams','zoho'], true) ? sanitize_key($_POST['default_meeting_provider']) : 'zoom',
            'trainer_user_id'=>absint($_POST['trainer_user_id'] ?? 0) ?: null,
            'coordinator_user_id'=>absint($_POST['coordinator_user_id'] ?? 0) ?: null,
            'start_date'=>$start ?: null, 'end_date'=>$end ?: null,
            'status'=>sanitize_key($_POST['status'] ?? 'active'), 'country'=>sanitize_text_field(wp_unslash($_POST['country'] ?? '')),
            'location'=>sanitize_text_field(wp_unslash($_POST['location'] ?? '')),
            'timezone'=>$tz, 'recurrence_days'=>implode(',', $days),
            'whatsapp_url'=>esc_url_raw(wp_unslash($_POST['whatsapp_url'] ?? '')),
            'telegram_url'=>esc_url_raw(wp_unslash($_POST['telegram_url'] ?? '')), 'discord_url'=>esc_url_raw(wp_unslash($_POST['discord_url'] ?? '')),
            'group_type'=>sanitize_text_field(wp_unslash($_POST['group_type'] ?? '')),
            'group_url'=>esc_url_raw(wp_unslash($_POST['group_url'] ?? '')),
            'updated_at'=>current_time('mysql'),
        ];
        if ($id) {
            $ok = $portal->update_row('batches', $data, ['id'=>$id]);
            if ($ok === false) $portal->db_fail('batches');
            $portal->log_audit('batch',$id,'update','Updated batch '.$name);
            $portal->set_flash('Batch saved. Open Classes to schedule days and times.');
        } else {
            $data['created_at'] = current_time('mysql');
            $ok = $portal->insert_row('batches', $data);
            if (!$ok) $portal->db_fail('batches');
            $newId = (int)$wpdb->insert_id;
            $portal->log_audit('batch',$newId,'create','Created batch '.$name.' on course '.$course_id);
            $portal->set_flash('Batch created. Open Classes → Add class to schedule it.');
        }
        $portal->back('batches');
    }

    public static function batch_links($portal){
        $portal->guard('uc_portal_batch_links',['super_admin']);
        global $wpdb;
        $id = absint($_POST['batch_id'] ?? 0);
        if (!$id || !in_array($id, $portal->batch_ids(), true)) { $portal->set_flash('Choose a batch.','warn'); $portal->back('messages'); }
        $name = sanitize_text_field(wp_unslash($_POST['group_type'] ?? ''));
        $data = [
            'whatsapp_url'=>esc_url_raw(wp_unslash($_POST['whatsapp_url'] ?? '')),
            'telegram_url'=>esc_url_raw(wp_unslash($_POST['telegram_url'] ?? '')),
            'discord_url'=>esc_url_raw(wp_unslash($_POST['discord_url'] ?? '')),
            'group_type'=>$name,
            'group_url'=>esc_url_raw(wp_unslash($_POST['group_url'] ?? '')),
            'updated_at'=>current_time('mysql'),
        ];
        $ok = $portal->update_row('batches', $data, ['id'=>$id]);
        if ($ok === false) $portal->db_fail('messages');
        $portal->log_audit('batch',$id,'links','Updated class chat links');
        $portal->set_flash('Chat links saved.');
        $portal->back('messages', ['batch'=>$id,'room'=>'class']);
    }

    public static function notice($portal){
        $portal->guard('uc_portal_notice',['super_admin','coordinator','trainer']);
        global $wpdb;
        $aud = sanitize_text_field($_POST['audience'] ?? 'all'); $batch = null;
        if (strpos($aud,'b')===0) { $batch = absint(substr($aud,1)); if (!in_array($batch,$portal->batch_ids(),true)) wp_die('Not your batch',403); $aud = 'batch'; }
        elseif (!$portal->ops() || !in_array($aud,['all','students','staff'],true)) $aud = 'students';
        $wpdb->insert($portal->t('announcements'),['audience'=>$aud,'batch_id'=>$batch,'title'=>sanitize_text_field(wp_unslash($_POST['title'] ?? '')),'body'=>sanitize_textarea_field(wp_unslash($_POST['body'] ?? '')),'by_user_id'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        $portal->set_flash('Announcement posted.'); $portal->back('announcements');
    }

    public static function notice_delete($portal){
        $portal->guard('uc_portal_notice_delete', ['super_admin','coordinator']);
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        if (!$id) { $portal->set_flash('Choose an announcement.','warn'); $portal->back('announcements'); }
        $wpdb->delete($portal->t('announcements'), ['id'=>$id]);
        $portal->log_audit('announcement', $id, 'delete', 'Deleted announcement');
        $portal->set_flash('Announcement deleted.');
        $portal->back('announcements');
    }

    public static function course_interest($portal){
        $nonce = isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '';
        $back = home_url('/programme/'.absint($_POST['course_id'] ?? 0).'/');
        if ($nonce === '' || !wp_verify_nonce($nonce, 'uc_portal_course_interest')) { wp_safe_redirect(add_query_arg('err','1',$back)); exit; }
        if (trim((string)wp_unslash($_POST['website'] ?? '')) !== '') { wp_safe_redirect(add_query_arg('sent','1',$back)); exit; }
        $ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '0');
        $bucket = 'uc_interest_'.md5($ip);
        $n = (int)get_transient($bucket);
        if ($n > 12) { wp_safe_redirect(add_query_arg('err','1',$back)); exit; }
        set_transient($bucket, $n + 1, HOUR_IN_SECONDS);
        global $wpdb;
        $cid = absint($_POST['course_id'] ?? 0);
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
        $phone = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
        $note = sanitize_textarea_field(wp_unslash($_POST['note'] ?? ''));
        $course = $cid ? (string)$wpdb->get_var($wpdb->prepare("SELECT name FROM {$portal->t('courses')} WHERE id=%d", $cid)) : '';
        if (!$cid || $course === '' || !$name || !is_email($email) || !$phone) { wp_safe_redirect(add_query_arg('err','1',$back)); exit; }
        $row = ['id'=>wp_generate_password(12,false,false),'at'=>current_time('mysql'),'course'=>$course,'course_id'=>$cid,'name'=>$name,'email'=>$email,'phone'=>$phone,'note'=>$note,'status'=>'open','by'=>get_current_user_id()];
        $all = get_option('uc_course_enquiries');
        if (!is_array($all)) $all = [];
        $all[] = $row;
        if (count($all) > 200) $all = array_slice($all, -200);
        update_option('uc_course_enquiries', $all, false);
        $body = "Course interest\n\nCourse: {$course}\nName: {$name}\nEmail: {$email}\nPhone: {$phone}\nNote: {$note}\n\nA coordinator chooses the batch. This is not an enrolment.\n";
        wp_mail(['coordinator@unicybers.com','rafi@unicybers.com'], 'UniCybers Academy · Course interest: '.$course, $body, ['Content-Type: text/plain; charset=UTF-8']);
        wp_safe_redirect(add_query_arg('sent','1',$back));
        exit;
    }

    public static function enquiry_status($portal){
        $portal->guard('uc_portal_enquiry_status', ['super_admin','coordinator']);
        $id = sanitize_text_field(wp_unslash($_POST['id'] ?? ''));
        $status = sanitize_key($_POST['status'] ?? '');
        if (!in_array($status, ['open','archived','not_interested'], true)) $status = 'archived';
        $all = get_option('uc_course_enquiries');
        if (!is_array($all)) $all = [];
        foreach ($all as $i => $r) {
            $rid = $r['id'] ?? ('e'.$i);
            if ((string)$rid === $id) { $all[$i]['status'] = $status; $all[$i]['id'] = $rid; }
        }
        update_option('uc_course_enquiries', $all, false);
        $portal->set_flash($status === 'open' ? 'Interest restored.' : ($status === 'archived' ? 'Interest archived.' : 'Marked not interested.'));
        $portal->back('courses');
    }

    public static function training_interest($portal){
        $portal->guard('uc_portal_training_interest', ['student']);
        $item = sanitize_text_field(wp_unslash($_POST['item'] ?? ''));
        $note = sanitize_textarea_field(wp_unslash($_POST['note'] ?? ''));
        $cat = class_exists('UC_LMS_Module_Support') ? UC_LMS_Module_Support::training_catalog() : [];
        $kind = '';
        foreach ($cat as $key => $items) {
            if (in_array($item, $items, true)) $kind = $key;
        }
        if ($kind === '') {
            $portal->set_flash('Choose a certification or a lab from the list.','warn');
            $portal->back('dashboard');
        }
        $u = wp_get_current_user();
        $all = get_option('uc_training_interest', []);
        if (!is_array($all)) $all = [];
        $found = false;
        foreach ($all as $i => $r) {
            if ((int)($r['user_id'] ?? 0) === (int)$u->ID && ($r['kind'] ?? '') === $kind && ($r['item'] ?? '') === $item) {
                $all[$i]['note'] = $note;
                $all[$i]['status'] = 'open';
                $all[$i]['at'] = current_time('mysql');
                $all[$i]['name'] = $u->display_name;
                $all[$i]['email'] = $u->user_email;
                $found = true;
            }
        }
        if (!$found) {
            $all[] = [
                'id' => wp_generate_password(12, false, false),
                'user_id' => (int)$u->ID,
                'name' => $u->display_name,
                'email' => $u->user_email,
                'kind' => $kind,
                'item' => $item,
                'note' => $note,
                'status' => 'open',
                'at' => current_time('mysql'),
            ];
        }
        if (count($all) > 400) $all = array_slice($all, -400);
        update_option('uc_training_interest', $all, false);
        $portal->set_flash('Interest sent. The academy will talk to you about it.');
        $portal->back('dashboard');
    }

    public static function training_interest_status($portal){
        $portal->guard('uc_portal_training_interest_status', ['super_admin','coordinator']);
        $id = sanitize_text_field(wp_unslash($_POST['id'] ?? ''));
        $status = sanitize_key(wp_unslash($_POST['status'] ?? ''));
        $back = sanitize_key(wp_unslash($_POST['back'] ?? 'dashboard'));
        if (!in_array($back, ['dashboard','settings'], true)) $back = 'dashboard';
        if ($status === 'delete' && $portal->role() !== 'super_admin') {
            $portal->set_flash('Only Super Admin can delete an interest.','warn');
            $portal->back($back, $back === 'settings' ? ['_hash'=>'exam-choices'] : []);
        }
        if (strpos($id, 'legacy-') === 0) {
            $uid = absint(substr($id, 7));
            if ($status === 'delete') delete_user_meta($uid, 'uc_exam_choice');
            elseif ($status === 'open') delete_user_meta($uid, 'uc_interest_state');
            else update_user_meta($uid, 'uc_interest_state', 'archived');
        } else {
            $all = get_option('uc_training_interest', []);
            if (!is_array($all)) $all = [];
            foreach ($all as $i => $r) {
                if ((string)($r['id'] ?? '') !== $id) continue;
                if ($status === 'delete') unset($all[$i]);
                else $all[$i]['status'] = $status === 'open' ? 'open' : 'archived';
            }
            update_option('uc_training_interest', array_values($all), false);
        }
        $portal->set_flash($status === 'delete' ? 'Interest deleted.' : ($status === 'open' ? 'Interest restored.' : 'Interest archived.'));
        $portal->back($back, $back === 'settings' ? ['_hash'=>'exam-choices'] : []);
    }
}
