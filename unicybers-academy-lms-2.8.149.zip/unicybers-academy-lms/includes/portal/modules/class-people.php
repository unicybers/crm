<?php
/**
 * UniCybers Academy LMS: People & Directory Module.
 *
 * Manages students, trainers, staff rosters, device management,
 * access request resolution, and demo visitor triage.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_People {
    public static function render($portal) {
        global $wpdb;
        if (!UC_LMS_Portal_Context::ops()) {
            return $portal->empty_state('Not available', 'People is available to the academy team.', 'people');
        }

        $admin = UC_LMS_Portal_Context::role() === 'super_admin';
        $users = get_users([
            'role__in' => ['administrator', 'uc_student', 'uc_trainer', 'uc_coordinator', 'uc_hr'],
            'orderby'  => 'display_name',
            'order'    => 'ASC',
            'number'   => 2000
        ]);

        $tb_devices = UC_LMS_Database::table('devices');
        $tb_reqs    = UC_LMS_Database::table('access_requests');
        $tb_batches = UC_LMS_Database::table('batches');
        $tb_leads   = UC_LMS_Database::table('demo_leads');

        $dev = [];
        if (UC_LMS_Database::has_table('devices')) {
            foreach ($wpdb->get_results("SELECT user_id, COUNT(*) n FROM `$tb_devices` GROUP BY user_id") as $r) {
                $dev[(int)$r->user_id] = (int)$r->n;
            }
        }

        $req = UC_LMS_Database::has_table('access_requests') 
            ? $wpdb->get_results("SELECT * FROM `$tb_reqs` ORDER BY status='open' DESC, id DESC LIMIT 60") 
            : [];

        $open = 0;
        foreach ($req as $r) {
            if ($r->status === 'open') $open++;
        }

        $batches = $wpdb->get_results("SELECT id, name FROM `$tb_batches` WHERE status='active' ORDER BY name");

        $c = ['demo' => 0, 'staff' => 0, 'students' => 0, 'disabled' => 0, 'archived' => 0, 'preview' => 0, 'all' => 0];
        $pending_ids = [];
        $rows = '';

        foreach ($users as $u) {
            if (UC_LMS_Security::is_shared_demo($u) || UC_LMS_Security::is_demo($u)) continue;
            $demo      = false;
            $r         = $portal->lms_role_of($u);
            $isSa      = $r === 'super admin';
            $protected = $portal->is_protected_sa($u);
            $archived  = (bool)get_user_meta($u->ID, 'uc_archived', true);
            $disabled  = (bool)get_user_meta($u->ID, 'uc_disabled', true);
            $last      = get_user_meta($u->ID, 'uc_last_login', true);
            $preview = get_user_meta($u->ID, 'uc_client_preview', true) === '1';
            $is_student = ($r === 'student' && !$demo && !$preview);

            if ($demo) $seg = 'demo';
            elseif ($preview) $seg = 'preview';
            elseif ($archived) $seg = 'archived';
            elseif ($disabled && $is_student) $seg = 'disabled';
            elseif ($is_student) $seg = 'students';
            else $seg = 'staff';

            $c[$seg]++;
            if ($seg !== 'demo' && $seg !== 'preview') $c['all']++;

            $status = $archived ? 'archived' : ($disabled ? 'disabled' : ($last ? 'active' : 'new'));
            if ($seg === 'students' && $status === 'new') $pending_ids[] = (int)$u->ID;

            $pill = $archived ? $portal->pill('Archived', 'mut') : ($disabled ? $portal->pill('Disabled', 'live') : ($last ? $portal->pill('Active', 'ok') : $portal->pill('Not activated', 'warn')));
            $lim  = UC_LMS_Security::device_limit($u->ID);
            $n    = $dev[$u->ID] ?? 0;
            $phone = get_user_meta($u->ID, 'uc_phone', true);

            $data = [
                'id'          => $u->ID,
                'name'        => $u->display_name,
                'email'       => $u->user_email,
                'phone'       => $phone,
                'country'     => get_user_meta($u->ID, 'uc_country', true),
                'role'        => $r,
                'disabled'    => $disabled,
                'archived'    => $archived,
                'limit'       => $lim,
                'admin'       => $isSa,
                'demo'        => $demo,
                'protected'   => $protected,
                'internal'    => (bool)get_user_meta($u->ID, 'uc_internal_test', true) || $portal->is_internal_tester($u)
            ];

            $can_edit = $admin && (!$protected || (int)$u->ID === get_current_user_id());
            $rows .= '<tr data-seg="' . $seg . '" data-st="' . $status . '" data-q="' . esc_attr(strtolower($u->display_name . ' ' . $u->user_email . ' ' . $r . ' ' . $phone)) . '">';
            $tone = $demo ? 'demo' : str_replace(' ', '', $r);
            $rows .= '<td><span class="who"><i class="pip r-' . esc_attr($tone) . '"></i><strong>' . $portal->e($u->display_name) . '</strong></span></td><td>' . $portal->e($u->user_email) . '</td>';
            $role_name = ['hr'=>'Placement HR','super admin'=>'Super Admin','coordinator'=>'Coordinator','trainer'=>'Trainer','student'=>'Student'][$r] ?? $r;
            $rows .= '<td><span class="role r-' . esc_attr($tone) . '">' . $portal->e($demo ? 'Demo guest' : $role_name) . '</span></td><td>' . $portal->e($data['country'] ?: 'Not set') . '</td><td>' . $pill . '</td>';
            $rows .= '<td><span class="devs' . ($n >= $lim && !$isSa && !$demo ? ' full' : '') . '">' . ($isSa || $demo ? '<em>exempt</em>' : $n . ' / ' . $lim) . '</span></td><td class="nowrap">' . $portal->e($last ? $portal->fdate($last, 'j M Y, g:i A') : 'Never') . '</td>';
            
            $acts = '';
            $post = esc_url(admin_url('admin-post.php'));
            $arch_n = wp_nonce_field('uc_portal_person_archive', '_wpnonce', true, false);
            $rem_n  = wp_nonce_field('uc_portal_person_remind', '_wpnonce', true, false);

            if ($admin && !$protected && !$demo && !$isSa && !$archived) {
                $acts .= '<form method="post" action="' . $post . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_person_archive">' . $arch_n . '<input type="hidden" name="id" value="' . (int)$u->ID . '"><input type="hidden" name="do" value="archive"><button class="btn ghost sm" type="submit">Archive</button></form>';
            }
            if ($admin && !$protected && !$demo && ($archived || $disabled)) {
                $acts .= '<form method="post" action="' . $post . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_person_archive">' . $arch_n . '<input type="hidden" name="id" value="' . (int)$u->ID . '"><input type="hidden" name="do" value="restore"><button class="btn ghost sm" type="submit">Restore</button></form>';
            }
            if ($can_edit) {
                $acts .= '<button type="button" class="btn ghost sm" data-edit=\'' . esc_attr(wp_json_encode($data)) . '\'>Edit</button>';
            }
            if (!$isSa && !$demo) {
                $acts .= '<button type="button" class="btn ghost sm" data-devices="' . $u->ID . '" data-name="' . esc_attr($u->display_name) . '" data-limit="' . $lim . '">Devices</button>';
            }
            if ($admin && $is_student && !$archived && !$disabled && $status === 'new') {
                $acts .= '<form method="post" action="' . $post . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_person_remind">' . $rem_n . '<input type="hidden" name="id" value="' . (int)$u->ID . '"><button class="btn ghost sm" type="submit">Remind</button></form>';
            }

            $rows .= '<td class="acts">' . $acts . '</td></tr>';
        }

        $o = '<section class="panel flush people-panel"><div class="toolbar">';
        if (UC_LMS_Portal_Context::role() === 'super_admin') {
            $o .= '<button type="button" class="btn primary" data-edit=\'{"id":0,"role":"student","limit":3}\'>' . $portal->icon('plus') . 'Add Person</button>';
        }
        $o .= '<button type="button" class="btn ghost" data-open="#addToBatch">Add to batch</button>';
        $o .= '<button type="button" class="btn ghost" data-open="#requests">' . $portal->icon('alert') . 'Requests' . ($open ? '<b class="badge">' . $open . '</b>' : '') . '</button>';
        if ($admin && $pending_ids) {
            $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline-form"><input type="hidden" name="action" value="uc_portal_person_remind">' . wp_nonce_field('uc_portal_person_remind', '_wpnonce', true, false) . '<input type="hidden" name="pending" value="1"><button class="btn ghost sm remind-btn" type="submit" title="Email credentials from academy@unicybers.com">Remind ' . count($pending_ids) . '</button></form>';
        }
        $o .= '<div class="seg" role="tablist">';
        $hash = sanitize_key($_GET['seg'] ?? '');
        $default_seg = in_array($hash, ['demo', 'staff', 'students', 'disabled', 'archived', 'preview', 'all'], true) ? $hash : 'students';
        $segs = ['students' => 'Students', 'disabled' => 'Disabled', 'archived' => 'Archived', 'staff' => 'Staff', 'all' => 'All'];
        if ($c['preview'] > 0) $segs = ['students' => 'Students', 'disabled' => 'Disabled', 'archived' => 'Archived', 'staff' => 'Staff', 'preview' => 'Preview', 'all' => 'All'];
        if ($default_seg === 'demo' && $c['demo'] < 1) $default_seg = 'students';
        foreach ($segs as $k => $v) {
            $o .= '<button type="button" class="' . ($k === $default_seg ? 'on' : '') . '" data-seg="' . $k . '">' . $v . ' <b>' . $c[$k] . '</b></button>';
        }
        $o .= '</div><select id="stFilter" aria-label="Status"><option value="">Any status</option><option value="active">Active</option><option value="new">Not activated</option></select><span class="count-shown" id="shown"></span></div>';
        $o .= '<div class="tablewrap people-scroll"><table id="peopleTable"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Country</th><th>Status</th><th>Devices</th><th>Last sign in</th><th></th></tr></thead><tbody>' . $rows . '</tbody></table></div></section>';

        // Add to batch drawer
        $o .= '<details class="panel" id="addToBatch"><summary><span class="eyebrow">STUDENTS</span><h3>Add to batch</h3></summary>';
        $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="uc_portal_student_add">' . wp_nonce_field('uc_portal_student_add', '_wpnonce', true, false) . '<input type="hidden" name="from" value="people">';
        $o .= '<label>Batch<select name="batch_id" required>';
        foreach ($batches as $b) {
            $o .= '<option value="' . (int)$b->id . '">' . $portal->e($b->name) . '</option>';
        }
        $o .= '</select></label><div class="pick-list">';
        $any = false;
        foreach ($users as $u) {
            if ($portal->lms_role_of($u) !== 'student') continue;
            if (UC_LMS_Security::is_demo($u)) continue;
            if (get_user_meta($u->ID, 'uc_client_preview', true) === '1') continue;
            $any = true;
            $o .= '<label class="pick-row"><input type="checkbox" name="user_ids[]" value="' . (int)$u->ID . '"><span><strong>' . $portal->e($u->display_name) . '</strong><small>' . $portal->e($u->user_email) . '</small></span></label>';
        }
        if (!$any) $o .= '<p class="pick-empty">No students on the academy yet.</p>';
        $o .= '</div><div class="right" style="margin-top:10px"><button class="btn primary">Add selected</button></div></form></details>';

        // Modal templates
        $o .= '<template id="tplPerson"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="form"><input type="hidden" name="action" value="uc_portal_person_save">' . wp_nonce_field('uc_portal_person_save', '_wpnonce', true, false) . '<input type="hidden" name="id">';
        $o .= $portal->mhead('ACCOUNT', 'Add Person', true) . '<div class="fgrid">';
        $o .= '<label>Full name<input name="name" required></label><label>Email<input name="email" type="email" required></label><label>Phone<input name="phone"></label><label>Country<input name="country" placeholder="India, Botswana…"></label>';
        $o .= '<label>Role<select name="role"><option value="student">Student</option><option value="trainer">Trainer</option><option value="coordinator">Coordinator</option><option value="hr">Placement HR</option>' . ($admin ? '<option value="super_admin">Super Admin</option>' : '') . '</select></label>';
        $o .= '<label>Enrol in batch<select name="batch"><option value="">No change</option>';
        foreach ($batches as $b) {
            $o .= '<option value="' . (int)$b->id . '">' . $portal->e($b->name) . '</option>';
        }
        $o .= '</select></label>';
        $o .= '<label>Device limit<select name="limit"><option value="3">3 devices (standard)</option><option value="5">5 devices (override)</option></select></label></div>';
        $o .= '<label class="check"><input type="checkbox" name="disabled" value="1"> Disable this account (blocks sign in)</label><label class="check"><input type="checkbox" name="internal_test" value="1"> Internal test account (hidden from attendance and reports unless included)</label><label class="check" data-newonly><input type="checkbox" name="send" value="1" checked> Email sign in details with a temporary password</label>';
        $o .= '<div class="mfoot"><div class="mfoot-l" data-editonly><button type="submit" class="btn ghost sm" name="do" value="reset" formnovalidate>Issue new password</button><button type="submit" class="btn danger sm" name="do" value="delete" formnovalidate data-confirm="Delete this account permanently? Their attendance history is kept.">Delete</button></div><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary" name="do" value="save">Save</button></div></form></template>';

        $o .= '<template id="tplDevices">' . $portal->mhead('SECURITY', 'Devices') . '<p class="hint">Devices · <span data-name></span></p><div data-list class="devlist"></div>';
        $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="inline"><input type="hidden" name="action" value="uc_portal_device_limit">' . wp_nonce_field('uc_portal_device_limit', '_wpnonce', true, false) . '<input type="hidden" name="user"><label>Limit <select name="limit"><option value="3">3 devices</option><option value="5">5 devices</option></select></label><button class="btn ghost sm">Save limit</button></form>';
        $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="uc_portal_device_reset">' . wp_nonce_field('uc_portal_device_reset', '_wpnonce', true, false) . '<input type="hidden" name="user"><div class="mfoot"><button type="button" class="btn ghost" data-close>Close</button><button class="btn danger" data-confirm="Reset all devices? They will sign in again on each device.">Reset all devices</button></div></form></template>';
        $o .= '<script>window.UC_DEVICES=' . wp_json_encode(self::device_map()) . ';window.UC_NONCE_RM="' . esc_js(wp_create_nonce('uc_portal_device_remove')) . '";window.UC_POST="' . esc_js(admin_url('admin-post.php')) . '";</script>';

        // Access requests inbox
        $o .= '<details class="panel access-requests" id="requests"' . ($open ? ' open' : '') . '><summary><span class="eyebrow">ACCESS REQUESTS</span><h3>Access requests ' . ($open ? '<span class="count warn">' . $open . ' open</span>' : '<span class="count">' . count($req) . '</span>') . '</h3><span class="chev">' . $portal->icon('chev') . '</span></summary>';
        if (!$req) {
            $o .= $portal->empty_state('No requests', 'People raise an Access request from the sign in page.', 'shield');
        } else {
            $o .= '<div class="reqs">';
            foreach ($req as $r) {
                $isOpen = $r->status === 'open';
                $o .= '<div class="req' . ($isOpen ? '' : ' done') . '"><div><strong>' . $portal->e($r->email) . '</strong><small>' . $portal->e($r->reason) . ' · ' . $portal->e($portal->fdate($r->raised_at, 'j M, g:i A')) . ($r->device ? ' · ' . $portal->e($r->device) : '') . '</small>' . ($r->detail ? '<p>' . $portal->e($r->detail) . '</p>' : '') . '</div>';
                $o .= $isOpen ? '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="req-act"><input type="hidden" name="action" value="uc_portal_request_resolve">' . wp_nonce_field('uc_portal_request_resolve', '_wpnonce', true, false) . '<input type="hidden" name="id" value="' . (int)$r->id . '"><button class="btn primary sm" name="reset" value="1">Reset devices &amp; close</button><button class="btn ghost sm" name="reset" value="0">Close only</button></form>' : $portal->pill('Resolved', 'ok');
                $o .= '</div>';
            }
            $o .= '</div>';
        }

        $visits = class_exists('UC_LMS_Module_Support') ? UC_LMS_Module_Support::demo_rows() : [];
        $o .= '</details>';
        if ($visits) {
            $o .= '<section class="panel flush" id="demo-leads"><div class="ph" style="padding:16px 18px 0"><div><span class="eyebrow">DEMO LEADS</span><h3>People who attended</h3></div><span class="count">'.count($visits).'</span></div>';
            $o .= '<p class="hint" style="padding:0 18px">These are leads from the demo. Follow them up and enrol the ones who join. This list has no edit, role, or delete.</p>';
            $o .= '<div class="tablewrap"><table class="data equal-cols"><thead><tr><th>Demo</th><th>Name</th><th>Phone</th><th>Course</th><th>Place</th><th>Join date</th><th>Purpose</th><th></th></tr></thead><tbody>';
            foreach (array_reverse($visits) as $row) {
                $o .= '<tr><td>Demo '.(int)($row['slot'] ?? 0).'</td><td><strong>'.$portal->e($row['name'] ?? '').'</strong><small class="sub">'.$portal->e($row['email'] ?? '').'</small></td>';
                $o .= '<td>'.$portal->e($row['phone'] ?? '').'</td><td>'.$portal->e($row['course'] ?? '').'</td><td>'.$portal->e($row['place'] ?? '').'</td><td>'.$portal->e($row['join_date'] ?? '').'</td><td>'.$portal->e((($row['purpose'] ?? '')==='look')?'Looking':'Joining').(!empty($row['archived'])?' · Archived':'').(!empty($row['verified'])?' · Verified':'').'</td><td class="acts">'.UC_LMS_Module_Support::demo_lead_actions($portal, $row, 'people').'</td></tr>';
            }
            $o .= '</tbody></table></div></section>';
        }
        $leads = UC_LMS_Database::has_table('demo_leads') ? $wpdb->get_results("SELECT * FROM `$tb_leads` ORDER BY id DESC LIMIT 40") : [];
        if ($leads) {
            $o .= '<details class="panel" id="demo"><summary><span class="eyebrow">DEMO</span><h3>Demo Leads <span class="count">' . count($leads) . '</span></h3></summary>';
            foreach ($leads as $d) {
                $o .= '<div class="req"><div><strong>' . $portal->e($d->name ?: $d->email) . '</strong><small>' . $portal->e($d->email) . ' · ' . $portal->e($d->interest) . ' · ' . $portal->e($d->seat) . '</small></div></div>';
            }
            $o .= '</details>';
        }
        return $o;
    }

    public static function device_map() {
        global $wpdb;
        if (!UC_LMS_Database::has_table('devices')) return [];
        $tb_devices = UC_LMS_Database::table('devices');
        $m = [];
        foreach ($wpdb->get_results("SELECT id, user_id, label, first_seen, last_seen FROM `$tb_devices` ORDER BY last_seen DESC") as $d) {
            $m[(int)$d->user_id][] = [
                'id'    => (int)$d->id,
                'label' => $d->label ?: 'Device',
                'last'  => $d->last_seen ? date_i18n('j M Y, g:i A', strtotime($d->last_seen)) : 'Never'
            ];
        }
        return $m;
    }
}
