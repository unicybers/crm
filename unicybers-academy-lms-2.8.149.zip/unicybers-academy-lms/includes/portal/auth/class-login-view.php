<?php
/**
 * UniCybers Academy LMS: Portal Login UI Templates & Shortcodes.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Login_View {

    public static function standalone_login_document() {
        $brand = class_exists('UC_Academy_LMS') 
            ? UC_Academy_LMS::instance()->brand_pack(is_user_logged_in() ? get_current_user_id() : 0)
            : (object)['name'=>'UniCybers','legal_name'=>'UniCybers Academy','product_label'=>'ACADEMY','logo_url'=>'','accent'=>'#FF6B1A','accent2'=>'#FF8A3D','support_email'=>'support@unicybers.com'];
        $plugin_file = defined('UC_LMS_FILE') ? UC_LMS_FILE : __DIR__ . '/../../unicybers-academy-lms.php';
        $logo = esc_url($brand->logo_url ?: plugins_url('assets/unicybers-emblem.svg', $plugin_file));
        $legal = esc_html($brand->legal_name ?: $brand->name ?: 'UniCybers Academy');
        $product = esc_html($brand->product_label ?: 'ACADEMY');
        $support = esc_attr($brand->support_email ?: 'support@unicybers.com');
        $brand_css = class_exists('UC_Academy_LMS') ? UC_Academy_LMS::instance()->brand_css($brand) : '';
        $scene = esc_url(plugins_url('assets/login-scene.png', $plugin_file));
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            $target = esc_url(UC_LMS_Login_Handler::role_dashboard_url($user));
            $name = esc_html($user->display_name ?: $user->user_login);
            return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$legal.'</title>'.self::site_icon_html().'<script>try{document.documentElement.setAttribute("data-theme",localStorage.getItem("uc_lms_theme")||"dark")}catch(e){}</script><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Sora:wght@600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@600;700&family=Figtree:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet"><style>' . UC_LMS_Login_Assets::standalone_login_css($scene) . $brand_css . '</style></head><body data-theme="light"><main class="uc-standalone"><header class="login-nav"><a class="login-brand" href="'.esc_url(home_url('/')).'"><img src="'.$logo.'" alt="'.$legal.'"><span>'.$legal.'</span></a><div class="login-nav-right"><nav>Cybersecurity <i>|</i> Careers <i>|</i> Real Skills <i>|</i> Brighter Futures</nav><button class="login-theme" id="loginTheme" type="button"><span>☼</span> <b class="theme-text">Light</b></button></div></header><section class="signed-card"><img class="signed-logo" src="'.$logo.'" alt="'.$legal.'"><span class="login-eyebrow">'.$product.'</span><h1>You are already signed in</h1><p>Your session is active, '.$name.'.</p><a class="login-primary" href="'.$target.'">Continue to Academy <span>→</span></a><a class="signed-out" href="'.esc_url(wp_logout_url(home_url('/login/'))).'">Sign out</a></section></main><script>(function(){var b=document.body,t=document.getElementById("loginTheme"),saved=localStorage.getItem("uc_lms_theme")||"dark";b.setAttribute("data-theme",saved);document.documentElement.setAttribute("data-theme",saved);function p(){var d=b.getAttribute("data-theme")==="dark";t.querySelector("span").textContent=d?"☾":"☼";t.querySelector("b").textContent=d?"Dark":"Light";}p();t.onclick=function(){var n=b.getAttribute("data-theme")==="dark"?"light":"dark";b.setAttribute("data-theme",n);document.documentElement.setAttribute("data-theme",n);localStorage.setItem("uc_lms_theme",n);p();};})();</script></body></html>';
        }
        $error = self::login_error_message();
        $error_html = $error ? '<div class="login-error" role="alert">'.esc_html($error).'</div>' : '';
        $nonce = wp_create_nonce('uc_front_login');
        $action = esc_url(UC_LMS_Login::instance()->login_page_url());
        $forgot = esc_url(wp_lostpassword_url(home_url('/')));
        $redirect = esc_url(home_url('/'));
        return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#f6f8fb"><title>'.$legal.' | Login</title>'.self::site_icon_html().'<script>try{document.documentElement.setAttribute("data-theme",localStorage.getItem("uc_lms_theme")||"dark")}catch(e){}</script><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Sora:wght@600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@600;700&family=Figtree:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet"><style>'.UC_LMS_Login_Assets::standalone_login_css($scene).$brand_css.'</style></head><body data-theme="light"><main class="uc-standalone"><header class="login-nav"><a class="login-brand" href="'.esc_url(home_url('/')).'"><img src="'.$logo.'" alt="'.$legal.'"><span>'.$legal.'</span></a><div class="login-nav-right"><nav>Cybersecurity <i>|</i> Careers <i>|</i> Real Skills <i>|</i> Brighter Futures</nav><button class="login-theme" id="loginTheme" type="button"><span>☼</span> <b class="theme-text">Light</b></button></div></header><div class="login-layout"><section class="login-hero"><div class="hero-scene hero-bright" aria-hidden="true"></div><div class="hero-scene hero-dark" aria-hidden="true"></div><div class="login-kicker">YOUR CYBER LEARNING PARTNER</div><h1 class="h-bright">Learn.<br>Practice.<br><em>Grow.</em></h1><h1 class="h-dark">Build Skills.<br>Build Your<br><em>Career.</em></h1><p>Industry focused courses, hands on labs and real world skills for a safer digital future.</p><div class="login-features"><article><span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h11a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"/><path d="M8 8h7"/></svg></span><div><strong>Expert Courses</strong><small>Structured learning paths</small></div></article><article><span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.7 3h10.6a2 2 0 0 0 1.7-3l-5-9V3"/></svg></span><div><strong>Hands on Labs</strong><small>Real environments. Real skills.</small></div></article><article><span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/></svg></span><div><strong>Career Support</strong><small>Guidance and placements</small></div></article><article><span><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M16 4a4 4 0 0 1 0 8M22 21a7 7 0 0 0-4-6.3"/></svg></span><div><strong>Global Community</strong><small>Learn with professionals</small></div></article></div><div class="login-quote"><b></b>Skills today. Opportunities tomorrow.</div></section><section class="login-card" aria-label="'.$legal.' sign in"><div class="card-logo"><img src="'.$logo.'" alt="'.$legal.'"></div><span class="login-eyebrow">'.$product.'</span><h2>Welcome back</h2><p class="login-description">Sign in to access your classes, labs, recordings, materials and career profile.</p>'.$error_html.'<form method="post" action="'.$action.'" class="login-form"><input type="hidden" name="action" value="uc_lms_login"><input type="hidden" name="uc_login_nonce" value="'.esc_attr($nonce).'"><input type="hidden" name="uc_redirect" value="'.esc_attr($redirect).'"> <label>Email address</label><div class="login-field"><span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18v14H3z"/><path d="m3 6 9 7 9-7"/></svg></span><input name="uc_email" type="email" autocomplete="username" placeholder="Enter your email address" required autofocus></div><label>Password</label><div class="login-field"><span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 11h14v10H5z"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg></span><input id="ucPassword" name="uc_password" type="password" autocomplete="current-password" placeholder="Enter your password" required><button type="button" id="ucEye" aria-label="Show password"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></button></div><div class="login-options"><label><input name="uc_remember" type="checkbox" value="1" checked> Remember me</label><a href="'.$forgot.'">Forgot password?</a></div><button class="login-primary" type="submit">Sign In <span>→</span></button><p class="login-coordinator">If a browser check appears, it is the server in front of the academy. This form is the sign-in.</p></form><div class="login-or"><span></span>OR<span></span></div><div class="login-support"><a href="mailto:'.$support.'?subject='.rawurlencode($legal.' Login Support').'"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18v14H3z"/><path d="m3 6 9 7 9-7"/></svg>Email support</a><button type="button" id="ucHelpBtn"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7M12 17h.01"/></svg>Access request</button></div>'.self::access_help_html().'<div class="login-secure"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/></svg>Secure and encrypted sign in</div><p class="login-coordinator">Need an account? Contact your training coordinator.</p></section></div><footer class="login-footer"><span>© '.esc_html(date('Y')).' '.$legal.'</span><span><a href="'.esc_url(home_url('/legal/#privacy')).'">Privacy</a> · <a href="'.esc_url(home_url('/legal/#terms')).'">Terms</a></span><span>Skills today. Opportunities tomorrow.</span></footer></main><script>(function(){var b=document.body,t=document.getElementById("loginTheme"),saved=localStorage.getItem("uc_lms_theme")||"dark";b.setAttribute("data-theme",saved);document.documentElement.setAttribute("data-theme",saved);function paint(){var d=b.getAttribute("data-theme")==="dark";t.querySelector("span").textContent=d?"☾":"☼";t.querySelector("b").textContent=d?"Dark":"Light";}paint();t.onclick=function(){var n=b.getAttribute("data-theme")==="dark"?"light":"dark";b.setAttribute("data-theme",n);document.documentElement.setAttribute("data-theme",n);localStorage.setItem("uc_lms_theme",n);paint();};var p=document.getElementById("ucPassword"),e=document.getElementById("ucEye");if(e&&p)e.onclick=function(){p.type=p.type==="password"?"text":"password";e.classList.toggle("on",p.type!=="password");e.setAttribute("aria-label",p.type==="password"?"Show password":"Hide password")};})();</script></body></html>';
    }

    public static function site_icon_html() {
        return class_exists('UC_LMS_Portal_Layout') ? UC_LMS_Portal_Layout::favicon_html() : '';
    }

    public static function access_help_html() {
        $state = sanitize_key($_GET['uc_help'] ?? '');
        $msgs = ['sent'=>'Request received. If that address has an account, the Academy team will reset access, usually within the hour.','email'=>'Enter the email you sign in with.','expired'=>'That form expired. Please try again.'];
        $msg = isset($msgs[$state]) ? '<div class="login-help-msg'.($state==='sent'?' ok':'').'" role="status">'.esc_html($msgs[$state]).'</div>' : '';
        return $msg.'<form class="login-help" id="ucHelpForm" method="post" action="'.esc_url(admin_url('admin-post.php')).'" hidden><input type="hidden" name="action" value="uc_access_request"><input type="hidden" name="uc_ar_nonce" value="'.esc_attr(wp_create_nonce('uc_access_request')).'"><strong>Ask the Academy for help</strong><label>Your email<input name="ar_email" type="email" required></label><label>What is wrong?<select name="ar_reason"><option>Too many devices, need a reset</option><option>Forgotten password</option><option>Account not activated</option><option>Something else</option></select></label><label>Anything else (optional)<textarea name="ar_detail" rows="2" maxlength="400"></textarea></label><button class="login-primary" type="submit">Send request</button></form><script>(function(){var b=document.getElementById("ucHelpBtn"),f=document.getElementById("ucHelpForm");if(b&&f)b.addEventListener("click",function(){f.hidden=!f.hidden;if(!f.hidden)f.querySelector("input[name=ar_email]").focus();});})();</script>';
    }

    public static function login_error_message() {
        $code = sanitize_key($_GET['uc_login_error'] ?? '');
        if ($code === 'missing') return 'Enter your email and password.';
        if ($code === 'invalid') return 'Invalid email or password.';
        if ($code === 'invalid_request') return 'Your sign in request expired. Please try again.';
        if ($code === 'locked') return 'Too many attempts. Try again in about ten minutes.';
        if ($code === 'devices') return 'You have reached your device limit. Use "Access request" below and the Academy will reset it.';
        if ($code === 'disabled') return 'This account is disabled. Contact support.';
        if ($code === 'closed') return 'Demo access is closed.';
        if ($code === 'retired') return 'The old shared demo seats are retired. Use the public demo link from the trainer.';
        return '';
    }

    public static function login_css_payload() {
        return UC_LMS_Login_Assets::login_css_payload();
    }

    public static function login_page_shortcode() {
        $plugin_file = defined('UC_LMS_FILE') ? UC_LMS_FILE : __DIR__ . '/../../unicybers-academy-lms.php';
        $brand = class_exists('UC_Academy_LMS') 
            ? UC_Academy_LMS::instance()->brand_pack(is_user_logged_in() ? get_current_user_id() : 0)
            : (object)['name'=>'UniCybers','legal_name'=>'UniCybers Academy','product_label'=>'ACADEMY','logo_url'=>''];
        $logo = esc_url($brand->logo_url ?: plugins_url('assets/unicybers-emblem.svg', $plugin_file));
        $name = esc_html($brand->name ?: 'UniCybers');
        $portal_label = strtoupper(esc_html(($brand->name ?: 'UniCybers') . ' PORTAL'));

        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            $who = 'your account';
            if (class_exists('UC_LMS_Portal')) {
                $role = UC_LMS_Portal::instance()->lms_role_of($user);
                $names = ['super admin'=>'Super Admin','coordinator'=>'Coordinator','trainer'=>'Trainer','hr'=>'Placement HR','student'=>'Student'];
                if (isset($names[$role])) $who = $names[$role];
            }
            return '<div class="uc-login-page-shell"><div class="uc-login-card uc-login-already"><div class="uc-login-logo"><img src="' . $logo . '" alt="' . $name . '"></div><h1>You are already signed in</h1><p>Your session is active, '.esc_html($who).'.</p><a class="uc-login-submit" href="'.esc_url(UC_LMS_Login_Handler::role_dashboard_url($user)).'">Continue to Academy</a><a class="uc-login-signout" style="display:block;margin-top:14px;text-align:center;color:#ffb089;font:600 14px/1.4 sans-serif" href="'.esc_url(home_url('/logout/')).'">Sign out</a></div></div>';
        }
        $error = self::login_error_message();
        $redirect = wp_get_referer();
        if (!$redirect || strpos($redirect, '/wp-login.php') !== false) $redirect = home_url('/');
        ob_start();
        ?>
        <style id="uc-login-inline-css"><?php echo UC_LMS_Login_Assets::login_css_payload(); ?></style>
        <div class="uc-login-page-shell">
          <div class="uc-login-atmosphere" aria-hidden="true"></div>
          <div class="uc-login-nav">CYBERSECURITY <span>|</span> CAREERS <span>|</span> REAL SKILLS <span>|</span> BRIGHTER FUTURES</div>
          <div class="uc-login-layout">
          <div class="uc-login-pitch">
            <div class="uc-login-kicker">YOUR CYBER LEARNING PARTNER</div>
            <h2>Build Skills.<br>Build Your <em>Career.</em></h2>
            <p>Your trusted platform for cybersecurity learning, practice and career growth.</p>
            <div class="uc-login-pillars">
              <div><b>Learn</b><span>Gain in demand skills</span></div>
              <div><b>Practice</b><span>Hands on labs and real scenarios</span></div>
              <div><b>Certify</b><span>Get career ready</span></div>
            </div>
            <div class="uc-login-quote">Skills today. Opportunities tomorrow.</div>
          </div>
          <section class="uc-login-card" aria-label="<?php echo $name; ?> sign in">
            <div class="uc-login-logo"><img src="<?php echo $logo; ?>" alt="<?php echo $name; ?>"></div>
            <div class="uc-login-portal-label"><?php echo $portal_label; ?></div>
            <h1>Welcome back</h1>
            <div class="uc-login-rule"></div>
            <p class="uc-login-description">Sign in to access your classes, labs, recordings, materials and career profile.</p>
            <?php if ($error): ?><div class="uc-login-error" role="alert"><?php echo esc_html($error); ?></div><?php endif; ?>
            <form method="post" action="<?php echo esc_url(UC_LMS_Login::instance()->login_page_url()); ?>" class="uc-login-form">
              <input type="hidden" name="action" value="uc_lms_login">
              <input type="hidden" name="uc_login_nonce" value="<?php echo esc_attr(wp_create_nonce('uc_front_login')); ?>">
              <input type="hidden" name="uc_redirect" value="<?php echo esc_attr($redirect); ?>">
              <label>Email</label>
              <div class="uc-login-input"><span>✉</span><input name="uc_email" type="email" autocomplete="username" inputmode="email" placeholder="Enter your email" required autofocus></div>
              <label>Password</label>
              <div class="uc-login-input"><span>▣</span><input id="ucLoginPassword" name="uc_password" type="password" autocomplete="current-password" placeholder="Enter your password" required><button type="button" id="ucLoginEye" aria-label="Show password"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="1.6"/></svg></button></div>
              <div class="uc-login-options"><label class="uc-login-remember"><input name="uc_remember" type="checkbox" value="1" checked> <span>Remember me on this device</span></label><a href="<?php echo esc_url(wp_lostpassword_url(UC_LMS_Login::instance()->login_page_url())); ?>">Forgot password?</a></div>
              <button class="uc-login-submit" type="submit">Sign in <span>→</span></button>
              <p class="uc-login-description">If a browser check appears, it is the server in front of the academy. This form is the sign-in.</p>
            </form>
            <button type="button" class="uc-login-help" id="ucLoginHelp">Access request</button>
            <div class="uc-login-or"><span></span><b>OR</b><span></span></div>
            <div class="uc-login-support"><a href="mailto:support@unicybers.com?subject=UniCybers%20LMS%20Login%20Support">Email support</a><a href="mailto:support@unicybers.com?subject=UniCybers%20LMS%20Cannot%20Sign%20In">Access request</a></div>
            <div class="uc-login-secure"><span>◇</span> Secure UniCybers account access.</div>
          </section>
          </div>
        </div>
        <script>
        (function(){
          var shell=document.querySelector('.uc-login-page-shell');
          if(shell && shell.parentNode !== document.body){
            document.body.appendChild(shell);
          }
          document.body.classList.add('uc-login-mode-active');
          var p=document.getElementById('ucLoginPassword'), e=document.getElementById('ucLoginEye');
          if(e&&p)e.addEventListener('click',function(){var on=p.type==='password';p.type=on?'text':'password';e.classList.toggle('is-open',on);e.setAttribute('aria-label',on?'Hide password':'Show password');});
          var h=document.getElementById('ucLoginHelp');
          if(h)h.addEventListener('click',function(){window.location.href='mailto:support@unicybers.com?subject=UniCybers%20LMS%20Cannot%20Sign%20In';});
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    public static function serve_standalone_login() {
        if (!UC_LMS_Login::is_standalone_login_request()) return;
        status_header(200);
        nocache_headers();
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));
        echo self::standalone_login_document();
        exit;
    }

    public static function serve_shortcode_login_standalone() {
        if (is_admin() || is_user_logged_in()) return;
        if (UC_LMS_Login::is_standalone_login_request()) return;
        $path = trailingslashit((string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH));
        $root = trailingslashit((string) wp_parse_url(home_url('/'), PHP_URL_PATH));
        if ($path === $root || (function_exists('is_front_page') && is_front_page())) return;
        global $post;
        if (!$post || (strpos((string)$post->post_content, 'uc_login') === false && strpos((string)$post->post_content, 'uc_lms_dashboard') === false)) return;
        if (function_exists('do_action')) do_action('litespeed_control_set_nocache');
        status_header(200);
        nocache_headers();
        header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));
        echo self::standalone_login_document();
        exit;
    }
}
