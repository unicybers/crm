<?php
/**
 * UniCybers Academy LMS: Messages & Announcements Module.
 *
 * Manages class chat rooms, direct "Ask Trainer" student-trainer discussions,
 * batch social community links (WhatsApp, Telegram, Discord), and broadcast notices.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Messages {
    public static function render_notices($portal) {
        global $wpdb;
        $o = '';
        if (UC_LMS_Portal_Context::staff()) {
            $ids = UC_LMS_Portal_Context::batch_ids();
            $tb_batches = UC_LMS_Database::table('batches');
            $in_ids = UC_LMS_Portal_Context::in_ids($ids);
            $bs = $ids ? $wpdb->get_results("SELECT id, name FROM `$tb_batches` WHERE id IN ({$in_ids}) ORDER BY name") : [];

            $o .= '<section class="panel compose"><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="compose-split"><input type="hidden" name="action" value="uc_portal_notice">' . wp_nonce_field('uc_portal_notice', '_wpnonce', true, false);
            $o .= '<div class="compose-meta"><label>Announcement title<input name="title" required maxlength="160" placeholder="Class cancelled, lab window, exam…"></label><label>Audience<select name="audience">' . (UC_LMS_Portal_Context::ops() ? '<option value="all">Everyone</option><option value="students">All students</option><option value="staff">Staff only</option>' : '');
            foreach ($bs as $b) {
                $o .= '<option value="b' . (int)$b->id . '">' . $portal->e($b->name) . '</option>';
            }
            $o .= '</select></label><button class="btn primary">' . $portal->icon('plus') . 'Post</button></div>';
            $o .= '<label class="compose-body">Message<textarea name="body" rows="6" required placeholder="Write the announcement…"></textarea></label></form></section>';
        }
        return $o . '<section class="panel">' . $portal->notice_rows(60, true) . '</section>';
    }

    public static function render($portal) {
        global $wpdb;
        $ids = UC_LMS_Portal_Context::batch_ids();
        if (!$ids) {
            return $portal->empty_state('No batches yet', 'You will see class chat here once you are on a batch.', 'messages');
        }

        $tb_batches  = UC_LMS_Database::table('batches');
        $tb_messages = UC_LMS_Database::table('messages');
        $tb_enrol    = UC_LMS_Database::table('enrolments');

        $in_ids = UC_LMS_Portal_Context::in_ids($ids);
        $batches = $wpdb->get_results("SELECT * FROM `$tb_batches` WHERE id IN ({$in_ids}) ORDER BY name");

        $sel = absint($_GET['batch'] ?? 0);
        if (!$sel || !in_array($sel, $ids, true)) $sel = (int)$batches[0]->id;

        $cur = null;
        foreach ($batches as $b) {
            if ((int)$b->id === $sel) $cur = $b;
        }

        $room = sanitize_key($_GET['room'] ?? 'class');
        if (!in_array($room, ['class', 'trainer'], true)) $room = 'class';

        $with = absint($_GET['with'] ?? 0);
        $me   = UC_LMS_Portal_Context::user_id();
        $trainer_id = $cur ? (int)$cur->trainer_user_id : 0;

        $o = '<div class="lib"><nav class="lib-dir" aria-label="Batches">';
        foreach ($batches as $b) {
            $o .= '<a class="' . ($sel === (int)$b->id ? 'on' : '') . '" href="' . esc_url(add_query_arg(['batch' => (int)$b->id, 'room' => $room], $portal->url('messages'))) . '">' . $portal->e($b->name) . '</a>';
        }
        $o .= '</nav><div class="lib-main"><section class="panel chat-panel">';

        $app_name = ($cur && trim((string)($cur->group_type ?? '')) !== '') ? $cur->group_type : 'App';
        $links = $cur ? [
            ['wa', 'WhatsApp', $cur->whatsapp_url ?? ''],
            ['tg', 'Telegram', $cur->telegram_url ?? ''],
            ['dc', 'Discord', $cur->discord_url ?? ''],
            ['app', $app_name, $cur->group_url ?? ''],
        ] : [];

        $o .= '<div class="room-tabs">';
        $o .= '<a class="' . ($room === 'class' ? 'on' : '') . '" href="' . esc_url(add_query_arg(['batch' => $sel, 'room' => 'class'], $portal->url('messages'))) . '">Class chat</a>';
        $o .= '<a class="' . ($room === 'trainer' ? 'on' : '') . '" href="' . esc_url(add_query_arg(['batch' => $sel, 'room' => 'trainer'], $portal->url('messages'))) . '">Ask trainer</a>';
        foreach ($links as $g) {
            if ($g[2] !== '') {
                $o .= '<a class="gjoin ' . $g[0] . '" href="' . esc_url($g[2]) . '" target="_blank" rel="noopener">Join ' . $portal->e($g[1]) . '</a>';
            } elseif (UC_LMS_Portal_Context::role() === 'super_admin') {
                $o .= '<a class="gjoin add ' . $g[0] . '" href="#chatLinks">Add ' . $portal->e($g[1]) . '</a>';
            }
        }
        $o .= '</div>';

        if (UC_LMS_Portal_Context::role() === 'super_admin' && $cur) {
            $o .= '<form id="chatLinks" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="link-manage"><input type="hidden" name="action" value="uc_portal_batch_links">' . wp_nonce_field('uc_portal_batch_links', '_wpnonce', true, false) . '<input type="hidden" name="batch_id" value="' . (int)$sel . '">';
            $o .= '<div class="link-grid">';
            $o .= '<label class="ch-wa"><span>WhatsApp</span><input name="whatsapp_url" value="' . esc_attr($cur->whatsapp_url ?? '') . '" placeholder="https://chat.whatsapp.com/…"></label>';
            $o .= '<label class="ch-tg"><span>Telegram</span><input name="telegram_url" value="' . esc_attr($cur->telegram_url ?? '') . '" placeholder="https://t.me/…"></label>';
            $o .= '<label class="ch-dc"><span>Discord</span><input name="discord_url" value="' . esc_attr($cur->discord_url ?? '') . '" placeholder="https://discord.gg/…"></label>';
            $o .= '<label class="ch-name"><span>App name</span><input name="group_type" value="' . esc_attr($cur->group_type ?: '') . '" placeholder="D6"></label>';
            $o .= '<label class="ch-app"><span>App link</span><input name="group_url" value="' . esc_attr($cur->group_url ?? '') . '" placeholder="https://…"></label>';
            $o .= '<div class="link-save"><button class="btn primary sm">Save links</button></div></div></form>';
        }

        $to = 0;
        $placeholder = 'Ask this class…';
        if ($room === 'trainer') {
            $placeholder = 'Ask your trainer…';
            if (UC_LMS_Portal_Context::role() === 'student') {
                $to = $trainer_id;
            } else {
                $demo_sql = $portal->demo_sql();
                $roster = $wpdb->get_results($wpdb->prepare("SELECT u.ID, u.display_name FROM `$tb_enrol` e JOIN {$wpdb->users} u ON u.ID=e.user_id WHERE e.batch_id=%d AND e.status='active' AND {$demo_sql} ORDER BY u.display_name", $sel));
                if (!$with && $roster) $with = (int)$roster[0]->ID;
                $to = $with;
                $o .= '<div class="dm-pick">';
                if (!$roster) $o .= '<p class="muted">No learners on this batch yet.</p>';
                foreach ($roster as $st) {
                    $o .= '<a class="' . ($with === (int)$st->ID ? 'on' : '') . '" href="' . esc_url(add_query_arg(['batch' => $sel, 'room' => 'trainer', 'with' => (int)$st->ID], $portal->url('messages'))) . '">' . $portal->e($st->display_name) . '</a>';
                }
                $o .= '</div>';
                $placeholder = 'Reply to this student…';
            }
        }

        $rows = [];
        if (UC_LMS_Database::has_table('messages')) {
            if ($room === 'trainer' && $to) {
                $rows = $wpdb->get_results($wpdb->prepare("SELECT m.*, u.display_name FROM `$tb_messages` m LEFT JOIN {$wpdb->users} u ON u.ID=m.from_user_id WHERE m.scope='dm' AND m.batch_id=%d AND ((m.from_user_id=%d AND m.to_user_id=%d) OR (m.from_user_id=%d AND m.to_user_id=%d)) ORDER BY m.id DESC LIMIT 80", $sel, $me, $to, $to, $me));
            } elseif ($room !== 'trainer') {
                $rows = $wpdb->get_results($wpdb->prepare("SELECT m.*, u.display_name FROM `$tb_messages` m LEFT JOIN {$wpdb->users} u ON u.ID=m.from_user_id WHERE m.scope='batch' AND m.batch_id=%d ORDER BY m.id DESC LIMIT 80", $sel));
            }
        }

        $rows = array_reverse($rows);
        $o .= '<div class="chat-log">';
        if (!$rows) {
            $o .= $portal->empty_state(
                $room === 'trainer' ? 'No doubts yet' : 'No messages yet',
                $room === 'trainer' ? 'Send a question to your trainer. It stays in this portal.' : 'Ask a question for this class below.',
                'messages'
            );
        }

        foreach ($rows as $m) {
            $mine = (int)$m->from_user_id === $me;
            $o .= '<div class="chat-msg' . ($mine ? ' mine' : '') . '"><span class="avatar xs">' . $portal->e($portal->initials($m->display_name ?: '?')) . '</span><div class="chat-bubble"><strong>' . $portal->e($m->display_name ?: 'Deleted user') . '</strong><p>' . nl2br($portal->e($m->body)) . '</p><small>' . $portal->e($portal->fdate($m->created_at, 'j M, g:i A')) . '</small></div></div>';
        }
        $o .= '</div>';

        if ($room !== 'trainer' || $to) {
            $o .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="chat-compose"><input type="hidden" name="action" value="uc_portal_message_send">' . wp_nonce_field('uc_portal_message_send', '_wpnonce', true, false) . '<input type="hidden" name="batch_id" value="' . (int)$sel . '"><input type="hidden" name="scope" value="' . ($room === 'trainer' ? 'dm' : 'batch') . '"><input type="hidden" name="to_user_id" value="' . (int)$to . '"><textarea name="body" rows="2" placeholder="' . $portal->e($placeholder) . '" required></textarea><button class="btn primary">Send</button></form>';
        }

        $o .= '</section></div></div>';
        return $o;
    }
}
