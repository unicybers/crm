<?php
/**
 * UniCybers Academy LMS: Background Cron Engine.
 *
 * Handles automated cloud recording syncs, scheduled report digests,
 * and background cache maintenance tasks.
 */

if (!defined('ABSPATH')) exit;

final class UC_LMS_Cron {
    private static $instance = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public static function init() {
        $inst = self::instance();
        add_filter('cron_schedules', [$inst, 'cron_schedules'], 1);
        add_filter('cron_schedules', [$inst, 'cron_schedules'], 9999);
        add_action('uc_lms_recording_sync', [$inst, 'cron_recording_sync']);
        add_action('uc_lms_pull_session_recording', [$inst, 'cron_pull_single_recording']);
        add_action('init', [$inst, 'ensure_recording_sync_cron'], 19);
        add_action('init', [$inst, 'ensure_weekly_report_cron'], 20);
        add_action('init', [$inst, 'ensure_monthly_report_cron'], 21);
    }

    public function cron_schedules($schedules) {
        if (!is_array($schedules)) $schedules = [];
        $schedules['uc_ten_minutes'] = ['interval' => 600, 'display' => 'Every 10 minutes'];
        $schedules['ten_minutes'] = ['interval' => 600, 'display' => 'Every 10 minutes'];
        if (empty($schedules['monthly'])) {
            $schedules['monthly'] = ['interval' => 30 * DAY_IN_SECONDS, 'display' => 'Once monthly'];
        }
        return $schedules;
    }

    public function ensure_recording_sync_cron() {
        $schedules = function_exists('wp_get_schedules') ? wp_get_schedules() : [];
        $recurrence = isset($schedules['uc_ten_minutes']) ? 'uc_ten_minutes' : (isset($schedules['ten_minutes']) ? 'ten_minutes' : 'hourly');
        $current = function_exists('wp_get_schedule') ? wp_get_schedule('uc_lms_recording_sync') : false;
        if ($current && !empty($schedules) && !isset($schedules[$current])) {
            wp_clear_scheduled_hook('uc_lms_recording_sync');
        }
        if (!wp_next_scheduled('uc_lms_recording_sync')) {
            wp_schedule_event(time() + 600, $recurrence, 'uc_lms_recording_sync');
        }
    }

    public function cron_recording_sync() {
        if (class_exists('UC_LMS_Zoom') && method_exists('UC_LMS_Zoom', 'portal_sync_recordings_now')) {
            UC_LMS_Zoom::portal_sync_recordings_now();
        } elseif (class_exists('UC_Academy_LMS') && method_exists('UC_Academy_LMS', 'instance')) {
            UC_Academy_LMS::instance()->portal_sync_recordings_now();
        }
        // Reuse the existing 10-minute recording job to avoid another cron worker.
        if (get_option('uc_drive_sync_enabled', '1') !== '0' && class_exists('UC_LMS_Drive_Materials')) UC_LMS_Drive_Materials::sync();
        if (get_option('uc_google_refresh_token')) {
            $meet_result = class_exists('UC_LMS_Meeting') ? UC_LMS_Meeting::instance()->portal_sync_meet_folder() : 0;
        }
        if (get_option('uc_zoho_refresh_token')) {
            $zoho_result = class_exists('UC_LMS_Meeting_Zoho') ? UC_LMS_Meeting_Zoho::sync_recordings() : 0;
        }
        if (get_option('uc_ms_client_id') && get_option('uc_ms_client_secret')) {
            $teams_result = class_exists('UC_LMS_Meeting_Teams') ? UC_LMS_Meeting_Teams::sync_recordings() : 0;
        }
    }

    public function cron_pull_single_recording($session_id) {
        $session_id = (int)$session_id;
        if ($session_id <= 0) return;
        global $wpdb;
        $table = class_exists('UC_LMS_Database') ? UC_LMS_Database::table('sessions') : $wpdb->prefix . 'uc_sessions';
        $session = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $session_id));
        if (!$session) return;
        if (class_exists('UC_LMS_Zoom') && method_exists('UC_LMS_Zoom', 'portal_pull_recording')) {
            UC_LMS_Zoom::portal_pull_recording($session);
        } elseif (class_exists('UC_Academy_LMS') && method_exists('UC_Academy_LMS', 'instance')) {
            UC_Academy_LMS::instance()->portal_pull_recording($session);
        }
    }

    public function ensure_weekly_report_cron() {
        if (wp_next_scheduled('uc_lms_weekly_report')) return;
        try {
            $tz = new DateTimeZone('Asia/Kolkata');
        } catch (Exception $e) {
            $tz = new DateTimeZone('UTC');
        }
        $now = new DateTime('now', $tz);
        $next = clone $now;
        if ((int)$now->format('N') === 1 && (int)$now->format('G') < 8) {
            $next->setTime(8, 0, 0);
        } else {
            $next->modify('next monday');
            $next->setTime(8, 0, 0);
        }
        wp_schedule_event($next->getTimestamp(), 'weekly', 'uc_lms_weekly_report');
    }

    public function ensure_monthly_report_cron() {
        if (wp_next_scheduled('uc_lms_monthly_report')) return;
        try {
            $tz = new DateTimeZone('Asia/Kolkata');
        } catch (Exception $e) {
            $tz = new DateTimeZone('UTC');
        }
        $next = new DateTime('first day of next month 08:00:00', $tz);
        wp_schedule_event($next->getTimestamp(), 'monthly', 'uc_lms_monthly_report');
    }

    public static function unschedule_all() {
        foreach (['uc_lms_recording_sync', 'uc_lms_weekly_report', 'uc_lms_monthly_report'] as $hook) {
            wp_clear_scheduled_hook($hook);
        }
    }

    public function cron_cache_one_recording() {
        if (get_transient('uc_lms_rec_cache_lock')) return;
        global $wpdb;
        $table = $wpdb->prefix . 'uc_sessions';
        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE hidden=0 AND session_date >= CURDATE() - INTERVAL 30 DAY AND session_date <= CURDATE() AND LOWER(IFNULL(status,''))<>'cancelled' AND LOWER(IFNULL(recording_status,''))<>'discarded' ORDER BY session_date DESC LIMIT 40");
        $n = 0;
        foreach ((array)$rows as $s) {
            $path = class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::portal_cached_recording_path($s) : (class_exists('UC_Academy_LMS') ? UC_Academy_LMS::instance()->portal_cached_recording_path($s) : '');
            if ($path && is_file($path) && filesize($path) > 50000) continue;
            if ((int)get_transient('uc_lms_rec_fail_'.$s->id) >= 3) continue;
            set_transient('uc_lms_rec_cache_lock', 1, 45 * MINUTE_IN_SECONDS);
            if (function_exists('set_time_limit')) @set_time_limit(0);
            if (function_exists('ignore_user_abort')) ignore_user_abort(true);
            $ok = class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::portal_pull_recording($s) : (class_exists('UC_Academy_LMS') ? UC_Academy_LMS::instance()->portal_pull_recording($s) : false);
            if (is_wp_error($ok) || !$ok) set_transient('uc_lms_rec_fail_'.$s->id, (int)get_transient('uc_lms_rec_fail_'.$s->id) + 1, DAY_IN_SECONDS);
            $n++;
            if ($n >= 3) { delete_transient('uc_lms_rec_cache_lock'); return; }
        }
        delete_transient('uc_lms_rec_cache_lock');
    }

    public function repair_shared_meeting_recordings() {
        global $wpdb;
        $t = $wpdb->prefix . 'uc_sessions';
        $ids = $wpdb->get_col("SELECT s.id FROM {$t} s JOIN (SELECT zoom_meeting_id FROM {$t} WHERE zoom_meeting_id IS NOT NULL AND zoom_meeting_id<>'' GROUP BY zoom_meeting_id HAVING COUNT(*)>1) d ON d.zoom_meeting_id=s.zoom_meeting_id WHERE s.recording_url LIKE '%zoom.us%'");
        if (!$ids) return;
        $uploads = wp_upload_dir();
        $base = empty($uploads['error']) ? rtrim((string)$uploads['basedir'],'/').'/uc-lms-recordings/' : '';
        foreach ($ids as $id) {
            $f = $base ? $base.(int)$id.'.mp4' : '';
            if ($f && is_file($f)) @unlink($f);
        }
        $in = implode(',', array_map('absint', $ids));
        $wpdb->query("UPDATE {$t} SET recording_url=NULL, recording_status=NULL, recording_passcode=NULL, zoom_uuid=NULL, recording_at=NULL WHERE id IN ({$in})");
    }
}
