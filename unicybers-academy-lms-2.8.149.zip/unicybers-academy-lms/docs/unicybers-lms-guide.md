# UniCybers Academy LMS guide

Rida answers only from the sections below. Each section is marked for who may see it.

## Sign in
role: all
Open the academy login and use the email and password you were given. A new academy account asks you to choose your own password. A demo guest keeps the temporary password and is not asked to change it. If a browser check appears before the academy, that check belongs to the server in front of the LMS. The sign-in itself is this email and password form.

## Search
role: all
The search box is on every page, including a phone. Type at least two letters. It lists matching portal records and the guide sections you are allowed to read. Lines marked Guide are Rida. Students see student topics. Staff see staff topics and the student topics. Settings topics appear only for Super Admin.

## Help and support
role: all
Help shows the academy guide, Rida, and a way to reach Super Admin. WhatsApp, Email, and Your reference are three equal buttons. Copy the reference into the message. Demo access, client preview, certification interest, footer links, and the audit log are on Settings. They stay closed until a Super Admin opens them. Your own password and devices are the closed fold named Your sign-in.

## Rida
role: all
Rida is on Help. Ask how to do something in the academy, for example how to schedule a class. Rida replies with the matching guide section and nothing outside this guide. If the guide has no match, Rida says so.

## Password and devices
role: all
Open Help and expand Your sign-in. Change your password there, and remove a device you no longer use. Students and staff have a device limit. Super Admin does not. The account menu also opens that fold.

## Join a class
role: student
Open Dashboard or Classes. Join appears 20 minutes before the start. The meeting address is not printed on the page. Keep the class tab open so your minutes are recorded. The room may be Zoom, Google Meet, Microsoft Teams, Zoho Meeting, or a classroom.

## Your attendance
role: student
Attendance comes from the minutes you stay in a live class. A class that nobody has marked yet is Not marked. Not marked is not the same as Absent.

## Your materials and recordings
role: student
Open Materials. A recording moves from Processing to Available after it is ready. Watch it inside the portal. Download and copy are blocked, and a blocked attempt is written to the audit log. Opening materials from a class shows that batch only.

## Practice
role: student
Open Practice for the mock or assignment your trainer assigned. An aptitude paper appears only during the date and time the trainer scheduled. It is not on the page before that window, and it closes when the window ends. A trainer can set a mock to repeat. The add form scrolls when the paper is long, so every question, Cancel, and Save stay reachable.

## Your profile and documents
role: student
Open Profile. Fill the contact, study, and work fields. Upload the documents the academy asks for. An incomplete profile stays off the placement ready list until the required fields and documents are in. You can keep adding documents while you are looking for a role. On the dashboard and on Profile, send interest for a certification or an extra lab pack and add a note such as pricing or dates. The labs in your course stay included. No price is stored. Super Admin and Coordinator see the ask, can archive it, and Super Admin can delete it.

## Announcements and messages
role: student
Announcements are notes for the academy. Messages are notes sent to you. Both are in the sidebar.

## Courses
role: staff
Courses is the catalogue. Add course, name it, set the category, level, and Active, then Save. A course is not a live class. Deleting a course removes it from the catalogue. Its batches keep running and show Unassigned until you attach another course.

## Batches
role: staff
Open Batches and Add batch. Choose the course, name the intake, assign a trainer, set the dates, and Save. Open a batch to enrol students. A new student receives a one-time password. Copy it, or tick Email so it is sent once. The first sign-in asks them to choose their own password. Deleting a batch removes its classes, attendance, and materials.

## Schedule a class
role: staff
Open Classes and choose Schedule Class. Pick the batch, date, time, and platform: Zoom, Meet, Teams, Zoho, or Room. Repeat through copies that class on the weekdays you tick. The edit window stays open until you use its close control. Clicking the dimmed page does not close it. Delete with This and future, or Entire series, removes that series, not only one row. Students see Join 20 minutes before the start.

## Class room and recordings
role: staff
Open a class to reach Class Room. Sync recording checks Zoom, Google Meet, Zoho, and Teams for that class. If an AI key is saved in Settings, a draft recap is written from the class title and the notes you add. It does not invent a spoken transcript. The batch overview starts collapsed. Finished classes can be limited to one batch, then sorted newest to oldest, oldest to newest, or by name and batch.

## Materials for staff
role: staff
Add files in the Google Drive folders by category, then press Sync Drive. Add Material is for a link. A pasted link is not uploaded again. Choosing a file in Add Material stores that file in the batch Drive folder only when Google is allowed to create files. If Drive refuses, the LMS says so and does not keep the file. Students watch and read inside the portal. There is no Open button that sends them to Drive, and students do not see Remove. Coordinators and Super Admin can still remove a recording from the library list. Class recordings come from the class, with Sync recording or the recording link, not from Add Material. The player stays up while the tab is open. It pauses only when the tab is hidden. Filter the library by batch. The category buttons sit on the same line as Sort: All, Notes, Slides, Labs, Assignments, Recordings, Links and Other. Sort is newest to oldest, oldest to newest, or A to Z by name, type, or batch. Column headings do not open another sort or a search box. A recording is labelled with its platform. The class room names that platform. A Meet or classroom session does not say Zoom. The portal footer shows Legal and Support.

## People
role: staff
People lists students, trainers, coordinators, and Placement HR. Last sign-in is the date and time on one line. Super Admin creates people and can reset a password. Coordinators and trainers do not reset another person's password from this page. The old shared seats demo01 through demo20 are not listed here. People who attended a demo are listed under Demo leads, with their course, place, phone, and purpose. Super Admin can archive a lead who is not interested, or delete a test lead and that demo sign-in. Restore brings an archived lead back. Follow the active leads and enrol the ones who join. They cannot sign in after the demo window ends. The status menu on this page opens above the toolbar.

## Reports and marking attendance
role: staff
Reports count Present and Absent from marks. Unmarked stays Not marked. In a classroom session, mark attendance on the attendance grid. The class-end list shows Present, Absent, or Not marked.

## Placement desk
role: staff
Placement Desk is a separate add-on. The menu appears only while that plugin is installed and active. It lists candidates on one card each. Career IDs counts the candidates on the desk, not every old profile. Each candidate is one card. Filter by batch, lane, and pack. The lane Not applicable or Archived takes that person off the active desk. Change the lane again to bring them back. Ask and Remind sit on the card: pick the document, type what to send, and send the note. Incomplete means required profile fields are still empty. Remind emails that person. Remove takes them off the desk and keeps the student account. A complete profile can copy a client link. Screen CVs sends the saved profile fields when an AI key is set. If the model fails, no score is invented. Jobs appear only when you save a Job DNA opening or a job API is configured. This desk tracks the academy pack, the client ask list, aptitude, and the lane through placed. It does not send offer letters or run a separate recruiting inbox.

## Demo access
role: staff
Open Settings and expand Demo access. It stays closed until you open it. Turn demo on and choose 1, 2, or 3 hours. The clock starts then and the portal closes itself when that time ends. Guests are signed out. It does not stay open for the day. You can turn it off earlier. Then copy the public link. Paste the trainer's own Google Meet address and save it. After a guest signs in, the dashboard shows that demo session. If the Meet address is still empty, the page says the trainer has not posted it. Academy classes and announcements stay off that login. The temporary password is not changed. Guests use the link, enter name, email, phone, course, place, expected join date, and whether they are joining or only looking. Each new guest is numbered from Demo 1 onward, up to 500, and gets their own sign-in. The list in that fold is the record to check after the session. Mark a row verified when you have seen that person. Turn demo off to stop new sign-ups and to block those guest sign-ins. The old shared addresses demo01@unicybers.com through demo20@unicybers.com are not listed on People and cannot sign in. A buyer preview is the Client preview fold on Settings. Super Admin sets a name, logo and colour and issues preview1 through preview5. Those five seats see sample classes and sample placement only.

## Client preview
role: super
Open Settings and expand Client preview. Enter the buyer’s academy name, pick a colour from the chips, the logo, or the screen, and upload their logo. The colour is a hex code such as #FF6B1A. Save brand keeps the look. Save and issue 5 passwords creates preview1@unicybers.com through preview5@unicybers.com. Each of preview1 through preview5 can switch Student, Trainer, Coordinator, Placement HR, and Super Admin from View as. The passwords stay on this fold so they can be shared again. They walk the sample academy only. They cannot see UniCybers students or change live records.

## Placement HR
role: hr
Super Admin creates a Placement HR person on People. That login opens Placement Desk only, and Help if the add-on is not active. It does not open classes, People, or Settings. On the desk, each candidate shows their Career ID, batch, documents already uploaded, pack, and the latest aptitude score when a scheduled paper was submitted. Ask for a document sends the student an email and shows the request on their profile. Move the lane from Pack open, Asked for documents, Ready for a role, Sent to a role, In interview, Offer, Placed, Paused, Not applicable, or Archived. Not applicable and Archived leave the active list. Save a Job DNA opening on the Cybersecurity, IT, or Non-IT track, and tick only what that client asks. The student sees that list on the role. Then track the application. The batch sheet counts who is on the desk, whose pack is complete, who was asked for a document, and who is placed, by batch, for a college HOD or a client. Screen CVs uses the saved profile when an AI key is set. If the model fails, no score is invented.

## Settings
role: super
Settings is Super Admin only. Each block stays closed until you open it. Brand sets the watermark. The default is UNICYBERS. Type a client name when this academy is sold under another company. AI credits stores the provider, the keys, the call counts, and the balance you type in. The provider does not send a live balance. Job APIs is a list. Career sync uses each row you save. Menus by role hides pages. Super Admin always keeps Settings. Zoom, Google Drive, Teams, and Zoho each have their own fold. Drive upload needs permission to create files. A read-only Drive connection cannot upload. Below those, Demo access, Client preview, Certification interest, Footer links, and the Audit log are closed until you open them. Help is the guide, Rida, and the WhatsApp or email path to the academy.
