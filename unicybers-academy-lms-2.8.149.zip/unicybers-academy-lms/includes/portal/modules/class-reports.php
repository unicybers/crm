<?php
/**
 * UniCybers Academy LMS: Reports & Attendance Analytics Module.
 *
 * Manages student attendance KPIs, class end summaries, weekly/monthly ops reports,
 * attendance grids with quick toggle actions, trainer teaching hours.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Reports {
    public static function render($portal) {
        global $wpdb;
        $uid = UC_LMS_Portal_Context::user_id();

        $tb_sessions   = UC_LMS_Database::table('sessions');
        $tb_enrolments = UC_LMS_Database::table('enrolments');
        $tb_attendance = UC_LMS_Database::table('attendance');
        $tb_batches    = UC_LMS_Database::table('batches');

        if (UC_LMS_Portal_Context::role() === 'student') {
            $rows = UC_LMS_Database::has_table('attendance') 
                ? $wpdb->get_results($wpdb->prepare(
                    "SELECT s.title, s.session_date, s.start_time, s.end_time, a.minutes, a.status 
                    FROM `$tb_sessions` s 
                    JOIN `$tb_enrolments` e ON e.batch_id=s.batch_id AND e.user_id=%d AND e.status='active' 
                    LEFT JOIN `$tb_attendance` a ON a.session_id=s.id AND a.user_id=%d 
                    WHERE s.hidden=0 AND LOWER(s.status)<>'cancelled' AND " . $portal->class_finished_sql('s') . "
                    ORDER BY s.session_date DESC", $uid, $uid)) 
                : [];

            $p = 0; $missed = 0; $open = 0; $mins = 0; $del = 0;
            foreach ($rows as $r) {
                if (in_array($r->status, ['present','partial'], true)) $p++;
                elseif ($r->status === 'absent') $missed++;
                else $open++;
                $mins += (int)$r->minutes;
                $del  += $r->end_time ? max(0, (strtotime($r->end_time) - strtotime($r->start_time)) / 60) : 0;
            }

            $o = '<div class="kpis">'
                . $portal->kpi('Present', $p, 'Classes attended', 'reports', 'green')
                . $portal->kpi('Absent', $missed, 'Marked absent', 'alert', 'rose')
                . $portal->kpi('Not marked', $open, 'No join log yet', 'classes', 'amber')
                . $portal->kpi('Hours attended', round($mins / 60, 1), 'From join to last activity', 'classes', 'violet')
                . $portal->kpi('Hours delivered', round($del / 60, 1), 'Completed classes', 'batches', 'teal')
                . '</div>';

            $o .= '<section class="panel flush"><div class="tablewrap"><table><thead><tr><th>Date</th><th>Class</th><th>Minutes</th><th>Status</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                $st = in_array($r->status, ['present','partial'], true) ? $portal->pill('Present', 'ok') : ($r->status === 'absent' ? $portal->pill('Absent', 'mut') : $portal->pill('Not marked', 'warn'));
                $o .= '<tr data-q="' . esc_attr(strtolower($r->title)) . '"><td class="mono-s">' . $portal->e($portal->fdate($r->session_date, 'j M Y')) . '</td><td><strong>' . $portal->e($r->title) . '</strong></td><td>' . (int)$r->minutes . '</td><td>' . $st . '</td></tr>';
            }
            if (!$rows) {
                $o .= '<tr><td colspan="4">' . $portal->empty_state('Nothing recorded yet', 'Attendance appears after your first class.', 'reports') . '</td></tr>';
            }
            return $o . '</tbody></table></div></section>';
        }

        // Staff / Admin Reporting Dashboard
        $ids = UC_LMS_Portal_Context::batch_ids();
        $in_ids = UC_LMS_Portal_Context::in_ids($ids);
        $bs = $ids ? $wpdb->get_results("SELECT id, name FROM `$tb_batches` WHERE id IN ({$in_ids}) ORDER BY status='active' DESC, name") : [];

        $view_in = sanitize_key($_GET['view'] ?? 'class');
        $view = in_array($view_in, ['class', 'cards', 'weekly', 'monthly', 'attendance', 'hours'], true) ? $view_in : 'class';
        $student_only = UC_LMS_Portal_Context::role() === 'coordinator';

        if ($student_only && !in_array($view, ['class', 'cards', 'weekly', 'monthly', 'attendance'], true)) $view = 'class';

        $tabs = $student_only
            ? ['class' => 'Student Report', 'cards' => 'Report cards', 'weekly' => 'Weekly Ops', 'monthly' => 'Monthly Ops', 'attendance' => 'Attendance']
            : ['class' => 'Class Report', 'cards' => 'Report cards', 'weekly' => 'Weekly Ops', 'monthly' => 'Monthly Ops', 'attendance' => 'Attendance Grid', 'hours' => 'Trainer Hours'];


        $o = '<div class="tabs">';
        foreach ($tabs as $k => $label) {
            $o .= '<a class="tab' . ($view === $k ? ' on' : '') . '" href="' . esc_url(add_query_arg('view', $k, $portal->url('reports'))) . '">' . $portal->icon($k === 'hours' ? 'classes' : 'reports') . $label . '</a>';
        }
        $o .= '</div>';

        if ($view === 'class')    return $o . $portal->class_end_report();
        if ($view === 'cards')    return $o . $portal->report_cards();
        if ($view === 'weekly')   return $o . $portal->report_cards() . $portal->weekly_ops_report();
        if ($view === 'monthly')  return $o . $portal->monthly_ops_report();
        if ($view === 'hours')    return $o . $portal->trainer_hours_report();

        // Attendance Grid View
        $sel = absint($_GET['batch'] ?? 0);
        if (!$sel && $bs) $sel = (int)$bs[0]->id;
        if ($sel && !in_array($sel, $ids, true)) $sel = 0;

        $o .= '<section class="panel"><form method="get" class="inline"><input type="hidden" name="view" value="attendance"><label>Batch <select name="batch" onchange="this.form.submit()">';
        foreach ($bs as $b) {
            $o .= '<option value="' . (int)$b->id . '"' . selected($sel, (int)$b->id, false) . '>' . $portal->e($b->name) . '</option>';
        }
        $o .= '</select></label>';
        $o .= $portal->include_testers_toggle('attendance');
        if ($sel) {
            $o .= '<a class="btn ghost sm" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=uc_portal_att_csv&batch=' . $sel . ($portal->want_internal() ? '&internal=1' : '')), 'uc_portal_att_csv')) . '">Export CSV</a>';
        }
        $o .= '</form><p class="hint">Online classes record a join. Classroom classes stay Not marked until you click the dot for that student.</p>';

        if (!$sel) {
            return $o . $portal->empty_state('No batches', 'Create a batch to see attendance.', 'reports') . '</section>';
        }

        list($sess, $roster, $map) = $portal->att_data($sel);
        if (!$sess || !$roster) {
            return $o . $portal->empty_state('Nothing to report yet', 'Attendance appears after the first completed class with enrolled students.', 'reports') . '</section>';
        }

        $nonce = wp_create_nonce('uc_portal_attendance_toggle');
        $post_url = esc_url(admin_url('admin-post.php'));

        $o .= '<div class="tablewrap grid-wrap"><table class="attgrid"><thead><tr><th class="sticky">Student</th>';
        foreach ($sess as $s) {
            $o .= '<th title="' . esc_attr($s->title) . '">' . $portal->e(date('j M', strtotime($s->session_date))) . '</th>';
        }
        $o .= '<th>Present</th><th>%</th></tr></thead><tbody>';

        foreach ($roster as $st) {
            $p = 0;
            $cells = '';
            foreach ($sess as $s) {
                $a = $map[$st->ID][$s->id] ?? null;
                $ok = $a && $a->status === 'present';
                if ($ok) $p++;
                $cells .= '<td class="att-cell"><form method="post" action="' . $post_url . '"><input type="hidden" name="action" value="uc_portal_attendance_toggle"><input type="hidden" name="_wpnonce" value="' . $nonce . '"><input type="hidden" name="session_id" value="' . (int)$s->id . '"><input type="hidden" name="user_id" value="' . (int)$st->ID . '"><input type="hidden" name="batch" value="' . $sel . '">' . ($portal->want_internal() ? '<input type="hidden" name="internal" value="1">' : '') . '<button type="submit" class="dot-btn ' . ($ok ? 'yes' : 'no') . '" title="' . ($a ? (int)$a->minutes . ' min · click to mark absent' : 'Absent · click to mark present') . '">' . ($ok ? '●' : '·') . '</button></form></td>';
            }
            $pct = round($p * 100 / count($sess));
            $o .= '<tr data-q="' . esc_attr(strtolower($st->display_name)) . '"><td class="sticky"><strong>' . $portal->e($st->display_name) . '</strong></td>' . $cells . '<td><b>' . $p . '</b></td><td><span class="pct ' . ($pct >= 75 ? 'good' : ($pct >= 50 ? 'mid' : 'low')) . '">' . $pct . '%</span></td></tr>';
        }

        return $o . '</tbody></table></div></section>';
    }
}
