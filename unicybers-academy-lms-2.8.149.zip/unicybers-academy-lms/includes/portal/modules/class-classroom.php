<?php
/**
 * UniCybers Academy LMS: Classroom & Live Session Module.
 *
 * Handles the live class room interface, attendance logging upon entry,
 * video player embedding, intelligence tabs, and secure Zoom/Meet redirection.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Classroom {
    public static function render($id = 0, $portal = null) {
        if ($id instanceof UC_LMS_Portal) {
            $temp = $portal;
            $portal = $id;
            $id = is_numeric($temp) ? (int)$temp : 0;
        }
        if (!$portal && class_exists('UC_LMS_Portal')) {
            $portal = UC_LMS_Portal::instance();
        }
        global $wpdb;
        $from_path = $portal ? $portal->force_portal_request([]) : [];
        if (!$id) $id = (int)($from_path['uc_id'] ?? 0);
        $s = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.name batch_name, b.zoom_passcode, c.name course_name, u.display_name trainer_name FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$portal->t('courses')} c ON c.id=b.course_id LEFT JOIN {$wpdb->users} u ON u.ID=s.trainer_user_id WHERE s.id=%d AND s.hidden=0", $id));
        if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) return $portal->empty_state('Not available','This class is not in your batches.','classes');
        $intel = class_exists('UC_LMS_Intelligence') ? UC_LMS_Intelligence::instance() : null;
        $staff = $portal->staff();
        $uid = get_current_user_id();
        if ($intel && $portal->role()==='student') $intel->mark_view($id, $uid);
        $pack = $intel ? $intel->pack($s, $staff, $uid) : ['status'=>(object)[],'summary'=>null,'topics'=>[],'steps'=>[],'chapters'=>[],'transcript'=>[],'tasks'=>[],'polls'=>[],'participants'=>[],'mine'=>null,'sched'=>7200,'stats'=>['total'=>0,'present'=>0,'partial'=>0,'absent'=>0,'avg_min'=>0]];
        $st = $pack['status'];
        $w = $portal->window($s);
        $mins = 0;
        if ($s->start_time && $s->end_time) {
            $mins = max(1, (int)round((strtotime($s->session_date.' '.$s->end_time) - strtotime($s->session_date.' '.$s->start_time)) / 60));
        }
        $dur = $s->end_time ? $portal->t12($s->start_time).' to '.$portal->t12($s->end_time).($mins ? ' ('.$mins.' mins)' : '') : $portal->t12($s->start_time);
        $heading = $portal->recording_heading($s);
        $notes = trim((string)($s->recording_notes ?? ''));
        $o = '<div class="cr">';
        $o .= '<nav class="cr-bc"><a href="'.esc_url($portal->url('materials')).'">Materials</a><span>›</span><a href="'.esc_url($portal->url('courses')).'">My Courses</a><span>›</span><span>'.$portal->e($s->course_name ?: 'Programme').'</span><span>›</span><span>'.$portal->e($s->batch_name).'</span><span>›</span><strong>'.$portal->e($heading).'</strong></nav>';
        $o .= '<header class="cr-hero"><div class="cr-hero-title"><span class="cr-flag" aria-hidden="true"></span><h2>'.$portal->e($heading).'</h2>';
        $o .= $portal->pill($w['done'] ? 'Class Completed' : ($w['live'] ? 'Live' : 'Scheduled'), $w['done']?'ok':($w['live']?'live':'mut'));
        $o .= '</div><div class="cr-meta"><span>'.$portal->e($s->batch_name).'</span><span>'.$portal->e($portal->fdate($s->session_date,'j M Y')).'</span><span>'.$portal->e($dur).'</span><span>Trainer: '.$portal->e($s->trainer_name ?: 'Trainer').'</span>';
        if (strcasecmp($heading, (string)$s->title) !== 0) $o .= '<span>'.$portal->e($portal->platform_label($s)).': '.$portal->e($s->title).'</span>';
        $o .= '</div>';
        if ($notes !== '') $o .= '<p class="cr-rec-notes">'.$portal->e($notes).'</p>';
        $o .= '</header>';
        if ($staff) {
            $o .= '<div class="cr-staff-acts"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form"><input type="hidden" name="action" value="uc_portal_intel_sync"><input type="hidden" name="session_id" value="'.$id.'">'.wp_nonce_field('uc_portal_intel_sync','_wpnonce',true,false).'<button class="btn ghost sm" type="submit">Sync recording</button></form>';
            $o .= $portal->recording_details_button($s, 'classroom').'</div>';
            $o .= $portal->recording_modal_tpl();
        }
        $o .= '<nav class="cr-tabs" data-cr-tabs>';
        foreach (['room'=>'Class Room','summary'=>'Summary','transcript'=>'Transcript','tasks'=>'Tasks','polls'=>'Polls & Quiz','materials'=>'Materials'] as $k=>$lab) {
            $o .= '<button type="button" class="'.($k==='room'?'on':'').'" data-cr="'.$k.'">'.$portal->e($lab).'</button>';
        }
        $o .= '</nav>';
        $o .= '<div class="cr-grid" data-cr-panel="room">';
        $ch = '';
        if ($pack['chapters']) {
            $ch = '<aside class="cr-ch"><h3>Chapters (AI Generated)</h3><ol>';
            foreach ($pack['chapters'] as $i => $row) {
                $ch .= '<li class="'.($i===0?'on':'').'"><button type="button" class="cr-seek" data-t="'.(int)$row->t_seconds.'"><em>'.$portal->e($intel->clock($row->t_seconds)).'</em><span>'.$portal->e($row->heading).'</span></button></li>';
            }
            $ch .= '</ol></aside>';
        }
        $o .= '<div class="cr-stage">'.$portal->classroom_player($s, $ch).'</div>';
        $o .= $portal->cr_summary_card($pack, $staff, $s, $intel);
        $o .= '<aside class="cr-rail">';
        $o .= $portal->cr_tasks_card($pack, $staff, $s);
        $o .= $portal->cr_polls_card($pack, $staff, $s);
        $o .= '</aside></div>';
        $o .= '<div class="cr-block" data-cr-panel="summary" hidden>'.$portal->cr_summary_full($pack, $staff, $s).'</div>';
        $o .= '<div class="cr-block" data-cr-panel="transcript" hidden>'.$portal->cr_transcript($pack, $intel).'</div>';
        $o .= '<div class="cr-block" data-cr-panel="tasks" hidden>'.$portal->cr_tasks_card($pack, $staff, $s, true).'</div>';
        $o .= '<div class="cr-block" data-cr-panel="polls" hidden>'.$portal->cr_polls_card($pack, $staff, $s, true).'</div>';
        $o .= '<div class="cr-block" data-cr-panel="materials" hidden>'.$portal->cr_materials((int)$s->batch_id, $id).'</div>';
        $o .= '<div class="cr-bottom" data-cr-panel="room">'.$portal->cr_attendance($pack, $staff, $s, $intel);
        $o .= $portal->cr_participants($pack, $s, $staff);
        $o .= $portal->cr_transcript($pack, $intel, true);
        $o .= $portal->cr_materials((int)$s->batch_id, $id);
        $o .= '</div>';
        $o .= '<div class="cr-views">';
        if ($staff) {
            $o .= $portal->cr_trainer_strip($pack, $st, $s);
        }
        if ($portal->ops()) $o .= $portal->batch_class_history(true);
        if (!$staff) $o .= $portal->student_progress_panel($uid, $portal->in_ids($portal->batch_ids()));
        $o .= '</div>';
        return $o.'</div>';
    }

    public static function window($s) {
        $tz    = UC_LMS_Portal_Context::valid_tz((string)($s->batch_timezone ?? ''));
        $start = self::ts($s->session_date, $s->start_time, $tz);
        $end   = $s->end_time ? self::ts($s->session_date, $s->end_time, $tz) : $start + 7200;
        $early = UC_LMS_Portal_Context::staff() ? 180 * 60 : 20 * 60;
        $now   = time();

        return [
            'start' => $start,
            'end'   => $end,
            'open'  => ($now >= $start - $early && $now <= $end + 1200),
            'done'  => ($now > $end + 1200),
            'live'  => ($now >= $start && $now <= $end)
        ];
    }

    private static function ts($date, $time, $tz = '') {
        $tz = UC_LMS_Portal_Context::valid_tz($tz);
        try {
            return (new DateTime(trim($date . ' ' . ($time ?: '00:00:00')), new DateTimeZone($tz)))->getTimestamp();
        } catch (Exception $e) {
            return 0;
        }
    }

    public static function classroom_player($portal, $s, $chapters='') {
        $id = (int)$s->id;
        $url = $s->recording_url;
        $pass = trim((string)($s->passcode ?: $s->zoom_passcode ?: ''));
        if (!$portal->recording_playable($s)) {
            $portal->maybe_auto_pull_recording($s);
            global $wpdb;
            $fresh = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.zoom_passcode FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.id=%d", $id));
            if ($fresh) { $s = $fresh; $url = $s->recording_url; }
        }
        $src = $portal->embed($url, $pass);
        $direct = $src && (preg_match('~\.(mp4|webm|m4v)(\?|$)~i', $src) || preg_match('~/rec/download/~i', $src));
        $framed = $src && class_exists('UC_LMS_Portal_Stream') && UC_LMS_Portal_Stream::framed_player($src);
        $local = !$framed && $portal->recording_ready($s);
        if ($framed) {
            $direct = false;
        } elseif ($local) {
            $src = home_url('/lms-media/recording/'.$id.'/');
            $direct = true;
        } elseif (!$src && $url) {
            if (stripos($url, 'zoom.us') !== false || $portal->recording_playable($s)) {
                $src = home_url('/lms-media/recording/'.$id.'/');
                $direct = true;
            }
        }
        $o = '<div class="viewer cr-player"><div class="v-frame" oncontextmenu="return false">';
        if ($local || ($src && $direct)) {
            $o .= '<video id="ucClassPlayer" src="'.esc_url($src).'" controls playsinline controlslist="nodownload noplaybackrate" disablepictureinpicture oncontextmenu="return false"></video>';
        } elseif ($src) {
            $o .= '<iframe src="'.esc_url($src).'" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen referrerpolicy="origin" loading="eager" style="width:100%;height:100%;border:none;min-height:480px"></iframe>';
        } else {
            $plat = $portal->recording_platform_label($s);
            $msg = $portal->staff() ? 'No '.$plat.' recording is on this class yet. Sync recording, or paste the file link.' : 'Recording is not available yet.';
            $o .= '<div class="v-overlay"><p>'.$portal->e($msg).'</p><div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><a class="btn ghost sm" href="'.esc_url(home_url('/lms-view/recording/'.$id.'/')).'">Open viewer</a></div></div>';
        }
        $mark = trim((string)get_option('uc_watermark_text', 'UNICYBERS'));
        if ($mark === '') $mark = 'UNICYBERS';
        $o .= '<div class="v-watermark" aria-hidden="true">';
        for ($wi=0; $wi<4; $wi++) $o .= '<span>'.$portal->e($mark).'</span>';
        $o .= '</div>';
        if (!$local && !($src && $direct) && !$src) {
            $o .= '<div class="cr-play-caption" data-cr-poster><strong>'.$portal->e($portal->recording_heading($s)).'</strong></div>';
        }
        $o .= $chapters;
        $o .= '</div></div>';
        return $o;
    }

    public static function cr_summary_card($portal, $pack, $staff, $s, $intel=null, $full=false) {
        return UC_LMS_Classroom_Cards::cr_summary_card($portal, $pack, $staff, $s, $intel, $full);
    }

    public static function cr_summary_full($portal, $pack, $staff, $s) {
        return UC_LMS_Classroom_Cards::cr_summary_full($portal, $pack, $staff, $s);
    }

    public static function cr_tasks_card($portal, $pack, $staff, $s, $full=false) {
        return UC_LMS_Classroom_Cards::cr_tasks_card($portal, $pack, $staff, $s, $full);
    }

    public static function cr_polls_card($portal, $pack, $staff, $s, $full=false) {
        return UC_LMS_Classroom_Cards::cr_polls_card($portal, $pack, $staff, $s, $full);
    }

    public static function cr_transcript($portal, $pack, $intel, $compact=false) {
        return UC_LMS_Classroom_Cards::cr_transcript($portal, $pack, $intel, $compact);
    }

    public static function cr_ring($portal, $pct) {
        return UC_LMS_Classroom_Cards::cr_ring($portal, $pct);
    }

    public static function cr_attendance($portal, $pack, $staff, $s, $intel) {
        return UC_LMS_Classroom_Cards::cr_attendance($portal, $pack, $staff, $s, $intel);
    }

    public static function cr_participants($portal, $pack, $s, $staff=true) {
        return UC_LMS_Classroom_Cards::cr_participants($portal, $pack, $s, $staff);
    }

    public static function cr_materials($portal, $batch_id, $sid) {
        return UC_LMS_Classroom_Cards::cr_materials($portal, $batch_id, $sid);
    }

    public static function cr_trainer_strip($portal, $pack, $st, $s) {
        return UC_LMS_Classroom_Cards::cr_trainer_strip($portal, $pack, $st, $s);
    }

}
