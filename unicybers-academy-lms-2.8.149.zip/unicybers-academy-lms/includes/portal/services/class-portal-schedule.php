<?php
/**
 * UniCybers Academy LMS: Portal Live Schedule, Session Timing & Meeting Join Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Schedule {

    public static function sessions($portal, $where='1=1',$order='s.session_date,s.start_time',$limit=200){
        global $wpdb;
        $ids = $portal->in_ids($portal->batch_ids());
        return $wpdb->get_results("SELECT s.*,b.name batch_name,b.timezone AS batch_timezone,c.name course_name FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$portal->t('courses')} c ON c.id=b.course_id WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND ({$where}) ORDER BY {$order} LIMIT ".(int)$limit);
    }

    public static function window($portal, $s){
        $tz = $portal->session_tz($s);
        $start = $portal->ts($s->session_date,$s->start_time,$tz);
        $end = $s->end_time ? $portal->ts($s->session_date,$s->end_time,$tz) : $start + 7200;
        $early = $portal->staff() ? 180*60 : 20*60;
        $now = time();
        return ['start'=>$start,'end'=>$end,'open'=>($now >= $start-$early && $now <= $end+1200),'done'=>($now > $end+1200),'live'=>($now>=$start && $now<=$end)];
    }

    public static function cancelled($portal, $s){ return strtolower((string)$s->status)==='cancelled'; }

    public static function platform_key($s){
        $p = strtolower(trim((string)($s->platform ?? '')));
        $url = strtolower((string)($s->join_url ?? ''));
        $rec = strtolower((string)($s->recording_url ?? ''));
        if ($p === '' || $p === 'zoom') {
            if (strpos($url, 'meet.google') !== false || ($url === '' && strpos($rec, 'meet.google') !== false)) $p = 'google_meet';
            elseif (strpos($url, 'teams.microsoft') !== false || strpos($url, 'teams.live') !== false) $p = 'teams';
            elseif (strpos($url, 'zoho') !== false) $p = 'zoho';
            elseif ($p === 'zoom' && strpos($url, 'zoom.us') === false && strpos($rec, 'zoom.us') === false && (strpos($rec, 'drive.google') !== false || strpos($rec, 'docs.google') !== false)) $p = 'google_meet';
            elseif ($p === '') $p = 'zoom';
        }
        return $p;
    }

    public static function platform_chip($portal, $s){
        $p = self::platform_key($s);
        if ($p==='google_meet'||$p==='meet'||$p==='google meet') return '<span class="plat meet">Meet</span>';
        if ($p==='teams'||$p==='microsoft_teams'||$p==='ms_teams') return '<span class="plat teams">Teams</span>';
        if ($p==='zoho'||$p==='zoho_meeting'||$p==='zoho meeting') return '<span class="plat zoho">Zoho</span>';
        if ($p==='offline'||$p==='classroom') return '<span class="plat">Room</span>';
        return '<span class="plat zoom">Zoom</span>';
    }

    public static function tz_options($portal, $selected='Asia/Kolkata'){
        $zones = [
            'Asia/Kolkata'=>'India IST (Asia/Kolkata)',
            'Africa/Gaborone'=>'Botswana (Africa/Gaborone)',
            'Asia/Dubai'=>'UAE (Asia/Dubai)',
            'Africa/Johannesburg'=>'South Africa (Africa/Johannesburg)',
            'UTC'=>'UTC',
        ];
        if ($selected && !isset($zones[$selected])) $zones[$selected] = $selected;
        $o = '';
        foreach ($zones as $id=>$label) $o .= '<option value="'.esc_attr($id).'"'.selected($selected,$id,false).'>'.$portal->e($label).'</option>';
        return $o;
    }

    public static function batch_trainers($portal){
        $seen = [];
        $out = [];
        foreach (get_users(['role__in'=>['administrator','uc_trainer','uc_coordinator'],'orderby'=>'display_name','number'=>200]) as $u) {
            $seen[(int)$u->ID] = true;
            $out[] = $u;
        }
        foreach (['rafi@unicybers.com','coordinator@unicybers.com','sofia@unicybers.com'] as $email) {
            $u = get_user_by('email', $email);
            if ($u && empty($seen[(int)$u->ID])) { $seen[(int)$u->ID] = true; $out[] = $u; }
        }
        usort($out, function($a,$b){ return strcasecmp($a->display_name, $b->display_name); });
        return $out;
    }

    public static function with_pwd($portal, $url, $passcode=''){
        $u = trim((string)$url);
        if ($u==='') return '';
        $pwd = $passcode;
        if (preg_match('/[?&]pwd=([^&]+)/', $u, $m)) $pwd = rawurldecode(str_replace('+',' ',$m[1]));
        $base = preg_replace('/([?&])pwd=[^&]*/', '$1', $u);
        $base = rtrim($base, "?&");
        if ($pwd!=='') $base .= (strpos($base,'?')===false?'?':'&').'pwd='.rawurlencode($pwd);
        return $base;
    }

    public static function session_host_url($portal, $s){
        if (!empty($s->zoom_start_url)) return $s->zoom_start_url;
        if (!empty($s->start_url)) return $s->start_url;
        global $wpdb;
        return (string)$wpdb->get_var($wpdb->prepare("SELECT zoom_start_url FROM {$portal->t('batches')} WHERE id=%d", (int)$s->batch_id));
    }

    public static function join_button($portal, $s,$w){
        if ($portal->cancelled($s)) return $portal->pill('Cancelled','live');
        $class = '<a class="btn primary sm" href="'.esc_url(home_url('/lms-class/'.(int)$s->id.'/')).'">'.$portal->icon('play').'Open Class Room</a>';
        if (time() > (int)$w['end']) {
            $o = $class;
            if ($w['open'] && (!empty($s->join_url) || ($portal->staff() && $portal->session_host_url($s)))) {
                $o .= '<a class="btn ghost sm" target="_blank" rel="noopener" data-join="'.(int)$s->id.'" href="'.esc_url(home_url('/lms-join/'.(int)$s->id.'/')).'">'.($portal->staff()?'Start Class':'Join Class').'</a>';
            }
            return $o;
        }
        if ($w['open']) {
            $has = !empty($s->join_url) || ($portal->staff() && $portal->session_host_url($s));
            if (!$has) return $portal->pill('Link pending','warn');
            $label = $portal->staff() ? 'Start Class' : 'Join Class';
            return '<a class="btn primary sm" target="_blank" rel="noopener" data-join="'.(int)$s->id.'" href="'.esc_url(home_url('/lms-join/'.(int)$s->id.'/')).'">'.$portal->e($label).'</a>';
        }
        return $portal->pill($portal->staff() ? 'Opens 3 hours before' : 'Opens 20 min before','mut');
    }

    public static function join($portal, $id){
        global $wpdb;
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d AND hidden=0", $id));
        $fail = function($m){ $portal->set_flash($m,'warn'); wp_safe_redirect($portal->url('classes')); exit; };
        if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) $fail('That class is not in your batches.');
        if ($portal->cancelled($s)) $fail('That class was cancelled.');
        $w = $portal->window($s);
        if (!$w['open']) $fail($w['done'] ? 'This class has ended.' : 'The join button opens 20 minutes before the class starts.');
        $url = $s->join_url;
        if ($portal->staff() && class_exists('UC_Academy_LMS')) {
            $fresh = UC_Academy_LMS::instance()->portal_start_class_zoom($s, $portal->zoom_alt_hosts((int)$s->batch_id));
            if (!empty($fresh)) $url = $fresh;
            else {
                $host = $portal->session_host_url($s);
                if ($host) $url = $host;
            }
        }
        if (empty($url)) $fail('The trainer has not added the meeting link yet.');
        if ($portal->role()==='student' && $portal->has_table('attendance')) {
            $now = current_time('mysql'); $uid = get_current_user_id();
            $ex = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$portal->t('attendance')} WHERE session_id=%d AND user_id=%d", $s->id, $uid));
            if ($ex) $wpdb->update($portal->t('attendance'), ['last_seen_at'=>$now,'status'=>'present'], ['id'=>$ex]);
            else $wpdb->insert($portal->t('attendance'), ['session_id'=>$s->id,'batch_id'=>$s->batch_id,'user_id'=>$uid,'joined_at'=>$now,'last_seen_at'=>$now,'minutes'=>0,'status'=>'present','source'=>'portal']);
        }
        wp_redirect(esc_url_raw($url)); exit;
    }

    public static function greeting($portal){ $h=(int)$portal->now_in_tz()->format('G'); return $h<12?'Good morning':($h<17?'Good afternoon':'Good evening'); }

    public static function ops_junk($portal, $text){
        return (bool)preg_match('/test\s*delet/i', (string)$text);
    }

    public static function upcoming_rows($portal, $limit=16){
        $from = $portal->now_in_tz(); $from->modify('-1 day');
        $rows = $portal->sessions("LOWER(s.status)<>'cancelled' AND s.session_date>='".esc_sql($from->format('Y-m-d'))."'", 's.session_date,s.start_time', 60);
        $out = [];
        foreach ($rows as $s) {
            if ($portal->window($s)['done']) continue;
            if ($portal->ops_junk($s->title.' '.$s->batch_name)) continue;
            $out[] = $s;
            if (count($out) >= $limit) break;
        }
        return $out;
    }

    public static function next_session($portal){
        $from = $portal->now_in_tz(); $from->modify('-1 day');
        $rows = $portal->sessions("s.session_date>='".esc_sql($from->format('Y-m-d'))."' AND LOWER(s.status)<>'cancelled'", 's.session_date,s.start_time', 40);
        foreach ($rows as $s) {
            if ($portal->ops_junk($s->title.' '.$s->batch_name)) continue;
            $w=$portal->window($s); if (!$w['done']) return [$s,$w];
        }
        return [null,null];
    }

    public static function hero($portal, $name){
        list($s,$w) = $portal->next_session();
        $date = $portal->now_in_tz()->format('l, j F Y');
        $desk = esc_url(plugins_url('assets/hero-desk.webp', UC_LMS_FILE));
        $h = '<div class="hero-row"><section class="hero" style="--hero-desk:url(\''.esc_attr($desk).'\')"><div class="hero-main"><span class="eyebrow on-dark">'.$portal->e(strtoupper($date)).'</span><h2>'.$portal->e($portal->greeting()).', '.$portal->e(strtok($name,' ')).'.</h2>';
        $h .= '<p>'.($portal->role()==='student' ? 'Your classes, materials and attendance.' : 'Here\'s what needs your attention today.').'</p></div></section>';
        if ($s) {
            $h .= '<div class="next"><div class="next-top"><span class="next-ico">'.$portal->icon('classes').'</span><span class="eyebrow">'.($w['live']?'<i class="dot live"></i>LIVE NOW':'NEXT CLASS').'</span><a class="next-go" href="'.esc_url($portal->url('classes')).'" aria-label="Open classes">›</a></div>';
            $h .= '<strong>'.$portal->e($s->title).'</strong><small>'.$portal->e($s->batch_name).' · '.$portal->e($portal->t12($s->start_time)).($s->end_time?' to '.$portal->e($portal->t12($s->end_time)):'').' IST</small>';
            $h .= '<div class="cd" data-start="'.($w['start']*1000).'" data-end="'.($w['end']*1000).'"><span><b data-u="d">0</b>d</span><span><b data-u="h">00</b>h</span><span><b data-u="m">00</b>m</span><span><b data-u="s">00</b>s</span></div>';
            $h .= '<div class="next-act">'.$portal->join_button($s,$w).'</div></div>';
        } else {
            $h .= '<div class="next idle"><div class="next-top"><span class="next-ico">'.$portal->icon('classes').'</span><span class="eyebrow">NEXT CLASS</span></div><strong>Nothing scheduled</strong><small>The countdown appears here as soon as a class is added.</small></div>';
        }
        return $h.'</div>';
    }

    public static function kpi($portal, $label,$value,$sub,$icon,$tone='flat',$href=''){
        $tag = $href ? 'a href="'.esc_url($href).'"' : 'div';
        return '<'.$tag.' class="kpi k-'.$tone.'"><span class="kpi-ico">'.$portal->icon($icon).'</span><div><small>'.$portal->e($label).'</small><strong>'.$portal->e($value).'</strong><em>'.$portal->e($sub).'</em></div></'.($href?'a':'div').'>';
    }

    public static function attention($portal){
        global $wpdb; $items = [];
        $ids = $portal->in_ids($portal->batch_ids());
        if ($portal->ops() && $portal->has_table('access_requests')) {
            $n = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('access_requests')} WHERE status='open'");
            if ($n) $items[] = ['alert','live',$n.' sign in request'.($n>1?'s':'').' waiting','People › Access requests',$portal->url('people').'#requests'];
        }
        $nolink = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('sessions')} WHERE batch_id IN ({$ids}) AND hidden=0 AND LOWER(status)<>'cancelled' AND session_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 2 DAY AND (join_url IS NULL OR join_url='')");
        if ($nolink) $items[] = ['classes','warn',$nolink.' class'.($nolink>1?'es':'').' in the next 48 h without a meeting link','Add the link before students arrive',$portal->url('classes')];
        if ($portal->ops() && $portal->has_table('devices')) {
            $full = UC_LMS_Security::accounts_at_device_limit_count();
            if ($full) $items[] = ['device','warn',$full.' account'.($full>1?'s':'').' at the device limit','They cannot sign in on a new device',$portal->url('people')];
        }
        $unassigned = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('batches')} WHERE id IN ({$ids}) AND status='active' AND (trainer_user_id IS NULL OR trainer_user_id=0)");
        if ($unassigned) $items[] = ['batches','info',$unassigned.' active batch'.($unassigned>1?'es have':' has').' no trainer','Assign one in wp-admin until phase 2',$portal->url('batches')];
        $recent = $wpdb->get_results("SELECT id, recording_url, recording_status FROM {$portal->t('sessions')} WHERE batch_id IN ({$ids}) AND hidden=0 AND session_date BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE() - INTERVAL 1 DAY AND LOWER(status)<>'cancelled' AND LOWER(IFNULL(recording_status,''))<>'discarded'");
        $pending = 0;
        foreach ($recent as $r) if (!$portal->recording_playable_fast($r)) $pending++;
        if ($pending) $items[] = ['play','info',$pending.' recent class'.($pending>1?'es':'').' without a recording','Press Sync Zoom. Nights Zoom did not record stay hidden.',$portal->url('materials')];
        if (!$items) return $portal->empty_state('All clear','Nothing needs your attention right now.','shield');
        $o = '<div class="att">';
        foreach (array_slice($items,0,12) as $i) $o .= '<a class="att-row" href="'.esc_url($i[4]).'"><span class="att-ico t-'.$i[1].'">'.$portal->icon($i[0]).'</span><span><strong>'.$portal->e($i[2]).'</strong><small>'.$portal->e($i[3]).'</small></span><i>›</i></a>';
        return $o.'</div>';
    }

    public static function class_rows($portal, $rows,$editable=false,$list=false){
        if (!$rows) return $portal->empty_state('No upcoming classes','New classes appear here as soon as they are scheduled.','classes');
        if ($list) {
            $o = '<div class="att">';
            foreach ($rows as $s) {
                $w = $portal->window($s);
                $ts = strtotime($s->session_date);
                $tone = $w['live'] ? 'live' : 'info';
                $heading = $portal->recording_heading($s);
                $dest = $w['done'] ? home_url('/lms-class/'.(int)$s->id.'/') : $portal->url('classes');
                $o .= '<div class="att-row" data-q="'.esc_attr(strtolower($heading.' '.$s->title.' '.$s->batch_name)).'"><span class="att-ico t-'.$tone.'">'.$portal->icon('classes').'</span>';
                $o .= '<span><a href="'.esc_url($dest).'"><strong>'.$portal->e($heading).'</strong></a><small>'.$portal->e(date('D j M',$ts)).' · '.$portal->e($s->batch_name).' · '.$portal->e($portal->t12($s->start_time)).($s->end_time?' to '.$portal->e($portal->t12($s->end_time)):'').' IST</small></span>';
                $o .= $portal->join_button($s,$w).'</div>';
            }
            return $o.'</div>';
        }
        $o = '<div class="crows">';
        foreach ($rows as $s) {
            $w = $portal->window($s);
            $ts = strtotime($s->session_date);
            $heading = $portal->recording_heading($s);
            $dest = $w['done'] ? home_url('/lms-class/'.(int)$s->id.'/') : $portal->url('classes');
            $o .= '<article class="crow'.($w['live']?' is-live':'').'" data-q="'.esc_attr(strtolower($heading.' '.$s->title.' '.$s->batch_name)).'" data-batch="'.esc_attr((string)$s->batch_id).'" data-name="'.esc_attr(strtolower($heading)).'" data-date="'.esc_attr((string)$s->session_date).'"><div class="crow-top"><div class="dtile"><b>'.$portal->e(date('d',$ts)).'</b><span>'.$portal->e(strtoupper(date('M',$ts))).'</span></div>'.$portal->platform_chip($s).'</div>';
            $o .= '<div class="cmain"><a href="'.esc_url($dest).'"><strong>'.$portal->e($heading).'</strong></a><small>'.$portal->e(date('D',$ts)).' · '.$portal->e($s->batch_name).' · '.$portal->e($portal->t12($s->start_time)).($s->end_time?' to '.$portal->e($portal->t12($s->end_time)):'').' IST</small></div><div class="cact">'.$portal->join_button($s,$w);
            if ($editable) {
                $recurrence_days = !empty($s->recurring_days) ? array_values(array_filter(explode(',', (string)$s->recurring_days))) : [];
                $data = ['id'=>(int)$s->id,'batch_id'=>(int)$s->batch_id,'title'=>$s->title,'session_date'=>$s->session_date,'start_time'=>substr($s->start_time,0,5),'end_time'=>$s->end_time?substr($s->end_time,0,5):'','platform'=>$s->platform?:'zoom','join_url'=>$s->join_url,'passcode'=>$s->passcode,'status'=>$s->status,'recording_url'=>$s->recording_url,'cancelled'=>$portal->cancelled($s)?1:0,'recurring_group'=>(string)($s->recurring_group ?? ''),'recurring_days'=>$recurrence_days,'recurring_until'=>(string)($s->recurring_until ?? '')];
                $o .= '<button type="button" class="btn ghost sm" data-edit-class=\''.esc_attr(wp_json_encode($data)).'\'>Edit</button>';
                $o .= $portal->generate_link_button($s);
            }
            $o .= '</div></article>';
        }
        return $o.'</div>';
    }

    public static function session_has_join($portal, $s){
            if (!empty($s->join_url)) return true;
            $p = strtolower((string)($s->platform ?: 'zoom'));
            if ($p !== 'zoom') return false;
            return $portal->staff() && (bool)$portal->session_host_url($s);
        }

    public static function generate_link_button($portal, $s){
            $p = strtolower((string)($s->platform ?: ''));
            if (!empty($s->join_url) || !$portal->staff()) return '';
            if (!in_array($p, ['google_meet','meet','google meet','teams','microsoft_teams','ms_teams','zoho','zoho_meeting'], true)) return '';
            return '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form"><input type="hidden" name="action" value="uc_portal_generate_link">'.wp_nonce_field('uc_portal_generate_link','_wpnonce',true,false).'<input type="hidden" name="session_id" value="'.(int)$s->id.'"><button class="btn ghost sm" type="submit">Generate link</button></form>';
        }

    public static function platform_label($portal, $s){
            $p = self::platform_key($s);
            if ($p==='google_meet'||$p==='meet'||$p==='google meet') return 'Meet';
            if ($p==='teams'||$p==='microsoft_teams'||$p==='ms_teams') return 'Teams';
            if ($p==='zoho'||$p==='zoho_meeting') return 'Zoho';
            if ($p==='offline'||$p==='classroom') return 'Classroom';
            return 'Zoom';
        }

    public static function is_meet_platform($portal, $s){
            $p = strtolower((string)($s->platform ?? ''));
            return $p==='google_meet'||$p==='meet'||$p==='google meet';
        }

    public static function recording_platform_label($portal, $r){
            if (trim((string)($r->platform ?? '')) !== '') return self::platform_label($portal, $r);
            $url = (string)($r->recording_url ?? '');
            if (stripos($url, 'teams.microsoft.com') !== false) return 'Teams';
            if (stripos($url, 'zoom.us') !== false) return 'Zoom';
            if ($portal->drive_file_id($url)) return 'Meet';
            return 'Zoom';
        }
}
