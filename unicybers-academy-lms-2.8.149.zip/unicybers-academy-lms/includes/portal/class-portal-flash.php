<?php
/**
 * UniCybers Academy LMS: Portal Flash Messaging & HTTP Cache Controller.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Flash {
    public static function e($s) { return esc_html((string)$s); }

    public static function forbid_cache(){
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        nocache_headers();
        if (!headers_sent()) {
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: Wed, 11 Jan 1984 05:00:00 GMT');
            header('X-LiteSpeed-Cache-Control: no-cache');
        }
        if (function_exists('do_action')) do_action('litespeed_control_set_nocache');
    }

    public static function purge_portal_cache($portal){
        if (function_exists('do_action')) {
            do_action('litespeed_purge_all', 'unicybers-lms');
            foreach ($portal->nav_pages() as $p) do_action('litespeed_purge_url', $portal->url($p));
        }
        if (function_exists('wp_cache_flush')) wp_cache_flush();
        if (function_exists('rocket_clean_domain')) rocket_clean_domain();
        if (function_exists('w3tc_flush_all')) w3tc_flush_all();
    }

    public static function flash($portal){
        $token = sanitize_text_field(wp_unslash($_GET['ucn'] ?? ''));
        if ($token === '') return '';
        $k = 'uc_flash_'.get_current_user_id(); $f = get_transient($k);
        if (!$f || (string)($f['token'] ?? '') !== $token) return '';
        delete_transient($k);
        $extra = !empty($f['secret']) ? '<div class="secret"><code id="flashSecret">'.UC_LMS_Portal_Helpers::e($f['secret']).'</code><button type="button" class="btn sm" data-copy="#flashSecret">Copy</button></div>' : '';
        if (!empty($f['wa'])) $extra .= ' <a class="btn sm" href="'.esc_url($f['wa']).'" target="_blank" rel="noopener">Open WhatsApp</a>';
        return '<div class="flash '.esc_attr($f['type']??'ok').'" role="status"><div>'.UC_LMS_Portal_Helpers::e($f['msg']??'').$extra.'</div><button type="button" class="flash-x" aria-label="Dismiss">×</button></div>';
    }

    public static function set_flash($portal, $msg,$type='ok',$secret='',$wa=''){
        $portal->last_flash_msg = (string)$msg;
        $portal->last_flash_type = $type;
        $portal->flash_token = wp_generate_password(8, false, false);
        set_transient('uc_flash_'.get_current_user_id(), ['msg'=>$msg,'type'=>$type,'secret'=>$secret,'wa'=>$wa,'token'=>$portal->flash_token], 90);
    }

    public static function wants_ajax(){
        if ((string)($_POST['uc_ajax'] ?? '') === '1') return true;
        return (string)($_SERVER['HTTP_X_UC_AJAX'] ?? '') === '1';
    }

    public static function back($portal, $page,$args=[]){
        self::purge_portal_cache($portal);
        self::forbid_cache();
        if ($portal->flash_token) $args['ucn'] = $portal->flash_token;
        $args['uc_t'] = (string) time();
        $hash = '';
        if (!empty($args['_hash'])) { $hash = '#'.preg_replace('/[^a-z0-9_-]/i','', (string)$args['_hash']); unset($args['_hash']); }
        $url = add_query_arg($args, $portal->url($page)).$hash;
        if (self::wants_ajax()) {
            if (!headers_sent()) {
                nocache_headers();
                header('Content-Type: application/json; charset=utf-8');
            }
            echo wp_json_encode([
                'ok' => ($portal->last_flash_type !== 'warn' && $portal->last_flash_type !== 'error'),
                'url' => $url,
                'msg' => $portal->last_flash_msg,
                'type' => $portal->last_flash_type,
            ]);
            exit;
        }
        wp_safe_redirect($url, 303);
        exit;
    }
}
