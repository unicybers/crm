# UniCybers LMS: Drive and Meeting Integration Setup

## Google Drive folder structure

Use the existing shared folder as the configured root (folder ID: `1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi`). Create one folder per batch using the exact LMS batch name. Inside each batch folder create `Notes`, `Slides`, `Labs`, `Assignments`, `Recordings`, `Links`, and `Other`. Example:

```text
Google Meet (configured LMS root)
  EH SOC 1026
    Notes
    Slides
    Labs
    Assignments
    Recordings
    Links
    Other
  SOC R030926
    Notes
    Slides
    Labs
    Assignments
    Recordings
    Links
    Other
  Meet Recordings
```

The existing root-level `Meet Recordings` folder is left to the Google Meet recording importer. That importer now scans this dedicated folder only when it exists and only matches Google Meet sessions, so videos in each batch’s `Recordings` category are not mistaken for class meeting recordings. Do not place general learning files at the root level. Root-level loose files do not have a reliable batch/category and are therefore not imported. A batch folder must match an existing LMS batch name. Files are indexed by permanent Drive file ID; the LMS stores metadata and the Drive viewer URL, not a second copy of the file.

The first sync scans the configured folder. Later syncs use the Drive Changes API cursor. The existing 10-minute recording cron is reused. Manual Sync Drive is available to staff with access to Materials. Changing the root folder hides old Drive-sourced rows and rebuilds the index from the new root. The LMS stores metadata and links only. It does not copy the source files into WordPress uploads.

## Google Drive sharing

Share the root folder with the Google Workspace account connected in LMS Settings. Viewer permission is sufficient to index file metadata. To let the LMS apply Google's reader download/print/copy restriction, that connected account must own the files or have the relevant restriction-management capability; the plugin requests the Google Drive `drive` OAuth scope for this optional setting. Use a dedicated Workspace integration account and understand that this is a broad Drive scope. After upgrading, reconnect Google and approve the expanded permissions.

For native Google Drive preview to render inside the LMS, students' Google accounts also need Viewer access to the relevant batch folders. Prefer a Google Group per batch (for example, `eh-soc-1026-students@yourdomain`) and share that batch folder with its group as Viewer. Do not share with `Anyone with the link`. If your students do not have Google accounts, a separate authenticated media proxy/storage provider is required; native Drive preview cannot display private files to users who have no Drive permission. Drive's restriction prevents standard download/print/copy for supported readers but cannot block external screen recording or a phone camera.

## Zoom

Keep the existing Zoom connection. Enable Cloud Recording on the Zoom host account and allow the host/meeting policy to record. The existing Zoom meeting and recording integration is retained. Enable Cloud Recording on the licensed host, check the recording policy and ensure the host owns the recording. Existing recording synchronization remains active; the shared 10-minute job is the fallback. No new Zoom app setup is required if the current account connection remains valid.

## Google Meet

Connect the Google Workspace organizer account in LMS Settings. The account needs Google Calendar event creation, Meet space access and Drive access. Reconnect Google after installing the updated plugin because the requested scopes include Drive management for optional download restriction. Meet recording availability depends on the Workspace edition, organizer licence and administrator recording policy. Google saves completed recordings to the organizer's Drive, typically in `Meet Recordings`. Share that folder with the connected LMS account. The existing importer matches recordings to scheduled sessions. If your Workspace plan or policy does not permit automatic recording, the class link can still be created but the LMS cannot force recording.

## Zoho Meeting

Create a Zoho OAuth client in the correct Zoho data centre, enter Client ID and Secret, ZSOID and presenter user ID in LMS Settings, then use Connect Zoho Meeting. The integration requests `ZohoMeeting.meeting.CREATE`, `ZohoMeeting.meeting.UPDATE`, and `ZohoMeeting.recording.READ`. Zoho Meeting plan and presenter permissions must allow scheduling and recording. The connector uses `ZohoMeeting.meeting.UPDATE` when an existing recurring meeting is edited. After the meeting finishes, wait for the recording state to reach `UPLOADED`; the LMS checks for recordings during the existing scheduled sync. Do not enable public recording links as a default. Test whether the selected Zoho account permits the LMS protected viewer to play the returned recording URL.

## Microsoft Teams

Register a Microsoft Entra ID application and configure the tenant ID, client ID, client secret and licensed organizer UPN in LMS Settings. Grant Microsoft Graph Application permissions `Calendars.ReadWrite`, `OnlineMeetings.Read.All` and `OnlineMeetingRecording.Read.All`, then grant tenant admin consent. An administrator must create and assign an application access policy for the app to the organizer. The LMS creates calendar-backed Teams meetings, looks up the resulting onlineMeeting ID and checks for recordings. Available Teams recordings stream on demand from Microsoft 365 through the authenticated LMS viewer. The LMS does not store a second video copy. The stream consumes your web host's outbound bandwidth while students watch. Teams recording availability still depends on organizer licensing, recording policy and Microsoft tenant permissions.

## Meeting provider defaults

Select the default provider in each batch. New class sessions inherit the batch default. A class can override the provider. Zoom retains the existing batch room behavior. Google Meet, Teams and Zoho create a meeting for each session. Classroom/offline sessions do not create meeting links.

## Batch scheduling and recurring edits

Choose the default meeting provider when creating or editing a batch. New classes inherit that provider. In the class editor, a recurring series can be changed as `This class only`, `This and future classes`, or `Entire series`. A date shift moves selected session dates by the same number of days; time, title and provider changes are applied to the selected sessions. Schedule conflicts with sessions outside the selected edit scope are skipped and reported. Zoom keeps its existing batch-room model; Google Meet, Teams and Zoho generate a meeting per session.

## Lightweight operation

No meeting video or general Drive materials are copied into the LMS by the new connectors. Provider code is loaded on demand. The existing recording cron is reused for 10-minute incremental checks. WordPress cron runs when the site receives traffic; for reliable timing on a low-traffic site, configure a cPanel cron to call WordPress cron every few minutes and disable the default page-load trigger only after verifying your hosting setup.
