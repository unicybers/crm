<?php
/**
 * UniCybers Academy LMS: Zoom Operations Facade & Coordinator.
 *
 * Provides complete backward compatibility by delegating to
 * specialized client, meeting, recordings, and storage engines.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Zoom {
    const LICENSE_EMAIL = 'training@unicybers.com';

    // Secret fields stay blank in settings HTML; an empty save preserves the existing values.
    public static function keep_client_secret($value) { $value = is_string($value) ? trim($value) : ''; return $value !== '' ? $value : (string)get_option('uc_zoom_client_secret',''); }
    public static function keep_webhook_secret($value) { $value = is_string($value) ? trim($value) : ''; return $value !== '' ? $value : (string)get_option('uc_zoom_webhook_secret',''); }

    // Client & API
    public static function token() { return UC_LMS_Zoom_Client::token(); }
    public static function request($method, $path, $body = null) { return UC_LMS_Zoom_Client::request($method, $path, $body); }
    public static function classroom_settings($title, $start_iso, $duration_minutes, $timezone, $alternative_hosts = []) {
        return UC_LMS_Zoom_Client::classroom_settings($title, $start_iso, $duration_minutes, $timezone, $alternative_hosts);
    }

    // Meeting Management
    public static function create_batch_meeting($data) { return UC_LMS_Zoom_Meeting::create_batch_meeting($data); }
    public static function update_batch_meeting($meeting_id, $data) { return UC_LMS_Zoom_Meeting::update_batch_meeting($meeting_id, $data); }
    public static function provision_batch_zoom($batch_id) { return UC_LMS_Zoom_Meeting::provision_batch_zoom($batch_id); }
    public static function portal_start_class_zoom($session_id) { return UC_LMS_Zoom_Meeting::portal_start_class_zoom($session_id); }
    public static function portal_class_zoom($params) { return UC_LMS_Zoom_Meeting::portal_class_zoom($params); }
    public static function portal_ensure_meeting_id($session_id) { return UC_LMS_Zoom_Meeting::portal_ensure_meeting_id($session_id); }

    // Recording Sync & Ingestion
    public static function sync_one_recording_safe($session) { return UC_LMS_Zoom_Recordings::sync_one_recording_safe($session); }
    public static function sync_one_recording($session) { return UC_LMS_Zoom_Recordings::sync_one_recording($session); }
    public static function portal_sync_recordings_now() { return UC_LMS_Zoom_Recordings::portal_sync_recordings_now(); }
    public static function recording_matches($r, $s) { return UC_LMS_Zoom_Recordings::recording_matches($r, $s); }
    public static function zoom_topic_matches($topic, $s) { return UC_LMS_Zoom_Recordings::zoom_topic_matches($topic, $s); }
    public static function zoom_row_seconds($r, $s) { return UC_LMS_Zoom_Recordings::zoom_row_seconds($r, $s); }
    public static function zoom_recording_usable($file) { return UC_LMS_Zoom_Recordings::zoom_recording_usable($file); }
    public static function zoom_recording_for_session($rec_data, $session) { return UC_LMS_Zoom_Recordings::zoom_recording_for_session($rec_data, $session); }
    public static function store_session_recording($session, $rec, $source = 'zoom') { return UC_LMS_Zoom_Recordings::store_session_recording($session, $rec, $source); }
    public static function session_tz_name($s) { return UC_LMS_Zoom_Recordings::session_tz_name($s); }
    public static function session_start_ts($s) { return UC_LMS_Zoom_Recordings::session_start_ts($s); }
    public static function session_labels($s) { return UC_LMS_Zoom_Recordings::session_labels($s); }

    // Storage, Cache & Streaming
    public static function cached_recording_path($session_id, $file_id = '', $ensure_dir = false) { return UC_LMS_Zoom_Storage::cached_recording_path($session_id, $file_id, $ensure_dir); }
    public static function portal_cached_recording_path($session_id, $file_id = '', $ensure_dir = false) { return UC_LMS_Zoom_Storage::cached_recording_path($session_id, $file_id, $ensure_dir); }
    public static function uuid_path($uuid) { return UC_LMS_Zoom_Storage::uuid_path($uuid); }
    public static function portal_zoom_uuid_path($uuid) { return UC_LMS_Zoom_Storage::uuid_path($uuid); }
    public static function portal_zoom_request($method, $path, $body = null) { return self::request($method, $path, $body); }
    public static function portal_recording_fetch_url($session, $file_id = '') { return UC_LMS_Zoom_Storage::portal_recording_fetch_url($session, $file_id); }
    public static function portal_discard_recording($session_id) { return UC_LMS_Zoom_Storage::portal_discard_recording($session_id); }
    public static function portal_pull_recording($session_id, $file_id = '') { return UC_LMS_Zoom_Storage::portal_pull_recording($session_id, $file_id); }
    public static function portal_cache_recording($session_id, $file_id = '') { return UC_LMS_Zoom_Storage::portal_cache_recording($session_id, $file_id); }
    public static function portal_store_uploaded_recording($session_id, $file_array) { return UC_LMS_Zoom_Storage::portal_store_uploaded_recording($session_id, $file_array); }
    public static function stream_local_mp4($file_path, $file_name = '') { return UC_LMS_Zoom_Storage::stream_local_mp4($file_path, $file_name); }
    public static function portal_stream_recording($session_id, $file_id = '') { return UC_LMS_Zoom_Storage::portal_stream_recording($session_id, $file_id); }
}
