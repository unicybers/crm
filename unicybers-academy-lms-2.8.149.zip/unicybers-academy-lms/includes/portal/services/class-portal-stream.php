<?php
/**
 * UniCybers Academy LMS: Portal Video & Media Streaming Service.
 *
 * Handles chunked byte-range HTTP 206 streaming for local uploads,
 * reverse proxy streaming for Google Drive video files, and remote MP4s.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Stream {

    /**
     * Map a WordPress upload URL back to its safe local file path.
     *
     * @param string $url
     * @return string
     */
    public static function local_upload_path($url) {
        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) return '';
        $baseurl = rtrim((string)$uploads['baseurl'], '/');
        $basedir = rtrim((string)$uploads['basedir'], '/');
        $u = strtok((string)$url, '?');
        if ($baseurl === '' || $u === '' || strpos($u, $baseurl) !== 0) return '';
        $rel = rawurldecode(substr($u, strlen($baseurl)));
        $path = $basedir . $rel;
        $root = realpath($basedir);
        $real = realpath($path);
        if (!$root || !$real || strpos($real, $root) !== 0) return '';
        return is_file($real) ? $real : '';
    }

    /**
     * Extract Google Drive file ID from URL.
     *
     * @param string $url
     * @return string
     */
    public static function drive_file_id($url) {
        $u = (string)$url;
        if (preg_match('~drive\.google\.com/file/d/([A-Za-z0-9_-]{10,})~', $u, $m)) return $m[1];
        if (preg_match('~[?&]id=([A-Za-z0-9_-]{10,})~', $u, $m)) return $m[1];
        return '';
    }

    /**
     * Get Google Drive direct view URL.
     *
     * @param string $url
     * @return string
     */
    public static function drive_open_url($url) {
        $id = self::drive_file_id($url);
        return $id ? 'https://drive.google.com/file/d/' . $id . '/view' : '';
    }

    /**
     * Temporary cookie jar path for Google Drive downloads.
     *
     * @param string $file_id
     * @return string
     */
    public static function drive_cookie_jar($file_id = '') {
        return sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'ucdrv-' . md5((string)$file_id) . '.txt';
    }

    /**
     * Detect if media source can be embedded in an iframe.
     *
     * @param string $src
     * @return bool
     */
    public static function framed_player($src) {
        return (bool)preg_match('~drive\.google\.com|docs\.google\.com|youtube\.com|youtube-nocookie\.com|view\.officeapps\.live\.com~i', (string)$src);
    }

    /**
     * Resolve Google Drive direct video streaming URL.
     *
     * @param string $file_id
     * @return string
     */
    public static function drive_stream_url($file_id) {
        $key = 'uc_drv_' . substr(md5($file_id), 0, 16);
        $cached = get_transient($key);
        if (is_string($cached) && $cached !== '') return $cached;
        if (!function_exists('curl_init')) return '';
        $jar = self::drive_cookie_jar($file_id);
        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';
        $pages = [
            'https://drive.google.com/uc?export=download&id=' . rawurlencode($file_id),
            'https://drive.usercontent.google.com/download?id=' . rawurlencode($file_id) . '&export=download',
        ];
        $candidates = [];
        foreach ($pages as $page) {
            $raw = '';
            $ch = curl_init($page);
            curl_setopt_array($ch, [
                CURLOPT_HEADER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_USERAGENT => $ua,
                CURLOPT_COOKIEJAR => $jar,
                CURLOPT_COOKIEFILE => $jar,
            ]);
            $resp = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $hdr_size = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            curl_close($ch);
            if (!is_string($resp) || $resp === '') continue;
            $head = substr($resp, 0, $hdr_size);
            $body = substr($resp, $hdr_size);
            if (preg_match('~^Location:\s*(\S+)~mi', $head, $m)) {
                $loc = trim($m[1]);
                if (preg_match('~^https://~i', $loc)) return $loc;
            }
            if (preg_match('~action="([^"]*download[^"]*)"~i', $body, $m)) {
                $act = html_entity_decode($m[1], ENT_QUOTES);
                if (preg_match('~^https://~i', $act)) $candidates[] = $act;
            }
            if (preg_match('~href="(/uc\?[^"]+confirm=[^"&]+[^"]*)"~i', $body, $m)) {
                $candidates[] = 'https://drive.google.com' . html_entity_decode($m[1], ENT_QUOTES);
            }
        }
        foreach ($candidates as $cand) {
            $ch = curl_init($cand);
            curl_setopt_array($ch, [
                CURLOPT_HEADER => true,
                CURLOPT_NOBODY => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_USERAGENT => $ua,
                CURLOPT_COOKIEFILE => $jar,
            ]);
            $resp = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if (is_string($resp) && preg_match('~^Location:\s*(\S+)~mi', $resp, $m)) {
                $loc = trim($m[1]);
                if (preg_match('~^https://~i', $loc)) {
                    set_transient($key, $loc, 4 * HOUR_IN_SECONDS);
                    return $loc;
                }
            }
        }
        $fallback = 'https://drive.usercontent.google.com/download?id=' . rawurlencode($file_id) . '&export=download&authuser=0';
        set_transient($key, $fallback, 30 * MINUTE_IN_SECONDS);
        return $fallback;
    }

    /**
     * Stream a Google Drive video file via direct API bearer token or signed URL.
     *
     * @param UC_LMS_Portal $portal
     * @param string $file_id
     */
    public static function stream_drive_file($portal, $file_id) {
        if (class_exists('UC_Academy_LMS')) {
            $token = UC_Academy_LMS::instance()->portal_google_token();
            if ($token !== '') {
                $api = 'https://www.googleapis.com/drive/v3/files/' . rawurlencode($file_id) . '?alt=media&supportsAllDrives=true';
                if (self::stream_remote_video($api, ['Authorization: Bearer ' . $token], true) !== false) return;
            }
        }
        $url = self::drive_stream_url($file_id);
        if ($url === '') {
            status_header(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'This recording cannot play in the academy player.';
            exit;
        }
        self::stream_remote_video($url, [], false, self::drive_cookie_jar($file_id));
    }

    /**
     * Chunked HTTP range proxy for remote videos.
     *
     * @param string $url
     * @param array $headers
     * @param bool $soft
     * @param string $cookie
     * @return bool|void
     */
    public static function stream_remote_video($url, $headers = [], $soft = false, $cookie = '') {
        if (!function_exists('curl_init') || !preg_match('~^https://~i', (string)$url)) {
            if ($soft) return false;
            status_header(404);
            header('Content-Type: text/plain; charset=utf-8');
            echo 'Recording file is not available.';
            exit;
        }
        @set_time_limit(0);
        if (function_exists('ignore_user_abort')) ignore_user_abort(true);
        while (ob_get_level() > 0) @ob_end_clean();
        $range = isset($_SERVER['HTTP_RANGE']) ? (string)$_SERVER['HTTP_RANGE'] : '';
        $req = array_merge(['User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'], $headers);
        if ($range !== '') $req[] = 'Range: ' . $range;
        $ch = curl_init($url);
        $meta = ['code' => 200, 'type' => 'video/mp4', 'len' => '', 'crange' => '', 'html' => false, 'started' => false];
        $opts = [
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 6,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_HTTPHEADER => $req,
            CURLOPT_HEADERFUNCTION => function ($ch, $h) use (&$meta) {
                $trim = trim($h);
                if (preg_match('#^HTTP/\S+\s+(\d+)#', $trim, $m)) {
                    $meta['code'] = (int)$m[1];
                    $meta['type'] = '';
                    $meta['len'] = '';
                    $meta['crange'] = '';
                    return strlen($h);
                }
                $p = strpos($h, ':');
                if ($p) {
                    $k = strtolower(trim(substr($h, 0, $p)));
                    $v = trim(substr($h, $p + 1));
                    if ($k === 'content-type') $meta['type'] = $v;
                    if ($k === 'content-length') $meta['len'] = $v;
                    if ($k === 'content-range') $meta['crange'] = $v;
                }
                if ($trim === '' && !$meta['started']) {
                    if ($meta['code'] >= 300 && $meta['code'] < 400) return strlen($h);
                    $meta['started'] = true;
                    $type = strtolower($meta['type']);
                    $meta['html'] = (strpos($type, 'text/html') !== false) || (strpos($type, 'json') !== false) || ($meta['code'] >= 400);
                    if ($meta['html']) return -1;
                    if (!headers_sent()) {
                        http_response_code($meta['code'] === 206 ? 206 : 200);
                        $send = (strpos($type, 'video') !== false || strpos($type, 'mp4') !== false || strpos($type, 'octet-stream') !== false) ? $meta['type'] : 'video/mp4';
                        header('Content-Type: ' . $send);
                        header('Content-Disposition: inline');
                        if ($meta['len'] !== '') header('Content-Length: ' . $meta['len']);
                        if ($meta['crange'] !== '') header('Content-Range: ' . $meta['crange']);
                        header('Accept-Ranges: bytes');
                        header('Cache-Control: private, no-store');
                        header('X-Content-Type-Options: nosniff');
                    }
                }
                return strlen($h);
            },
            CURLOPT_WRITEFUNCTION => function ($ch, $data) use (&$meta) {
                if (!empty($meta['html'])) return 0;
                echo $data;
                if (function_exists('flush')) flush();
                return strlen($data);
            },
        ];
        if ($cookie !== '' && is_file($cookie)) {
            $opts[CURLOPT_COOKIEFILE] = $cookie;
            $opts[CURLOPT_COOKIEJAR] = $cookie;
        }
        curl_setopt_array($ch, $opts);
        curl_exec($ch);
        curl_close($ch);
        if (!empty($meta['html']) || empty($meta['started'])) {
            if ($soft && !headers_sent()) return false;
            if (!headers_sent()) {
                status_header(404);
                header('Content-Type: text/plain; charset=utf-8');
                echo 'Recording file is not available.';
            }
        }
        exit;
    }

    /**
     * Stream a course material file (PDF, slide, MP4) with access check.
     *
     * @param UC_LMS_Portal $portal
     * @param int $id
     */
    public static function stream_material($portal, $id) {
        global $wpdb;
        $x = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('materials')} WHERE id=%d", $id));
        if (!$x || !in_array((int)$x->batch_id, $portal->batch_ids(), true) || (empty($x->visible) && !$portal->staff()) || (!empty($x->student_locked) && !$portal->staff())) {
            status_header(404); header('Content-Type: text/plain; charset=utf-8'); echo 'This material is not available.'; exit;
        }
        $url = trim((string)($x->url ?? ''));
        $path = self::local_upload_path($url);
        if ($path) {
            $mime = function_exists('mime_content_type') ? (mime_content_type($path) ?: '') : '';
            if ($mime === '') $mime = 'application/octet-stream';
            nocache_headers();
            header('Content-Type: ' . $mime);
            header('Content-Length: ' . filesize($path));
            header('Content-Disposition: inline; filename="' . basename($path) . '"');
            readfile($path);
            exit;
        }
        if ($url && preg_match('~^https?://~i', $url)) { wp_redirect($url); exit; }
        status_header(404); header('Content-Type: text/plain; charset=utf-8'); echo 'This material is not available.'; exit;
    }

    /**
     * Stream a class recording with access verification.
     *
     * @param UC_LMS_Portal $portal
     * @param int $id
     */
    public static function stream_recording($portal, $id) {
        global $wpdb;
        $x = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.zoom_passcode FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.id=%d AND s.hidden=0", $id));
        $fail = function(){ status_header(404); header('Content-Type: text/plain; charset=utf-8'); echo 'Recording file is not available.'; exit; };
        if (!$x || !in_array((int)$x->batch_id, $portal->batch_ids(), true)) $fail();
        if (strtolower((string)$x->platform) === 'teams' && strtolower((string)$x->recording_status) === 'available') {
            UC_LMS_Meeting_Teams::stream_recording($x);
        }
        if (empty($x->recording_url)) $fail();
        $fid = self::drive_file_id((string)$x->recording_url);
        if ($fid) self::stream_drive_file($portal, $fid);
        $ru = (string)$x->recording_url;
        if (preg_match('~\.(mp4|webm|m4v)(\?|$)~i', $ru) && stripos($ru, 'zoom.us') === false) self::stream_remote_video($ru);
        if (!class_exists('UC_Academy_LMS')) $fail();
        UC_Academy_LMS::instance()->portal_stream_recording($x);
    }
}
