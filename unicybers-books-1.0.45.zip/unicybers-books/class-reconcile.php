<?php
if (!defined('ABSPATH')) exit;

/**
 * Bank reconciliation for UniCybers Books.
 * Statement import and matching only. No bank password, PIN, OTP, or live feed.
 */
final class UC_Books_Reconcile {
    public static function install() {
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        $stmt = $wpdb->prefix.'ub_bank_stmt';
        $txn = $wpdb->prefix.'ub_bank_txn';
        $link = $wpdb->prefix.'ub_bank_link';
        $audit = $wpdb->prefix.'ub_bank_audit';
        dbDelta("CREATE TABLE $stmt (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            bank_key varchar(40) NOT NULL,
            country varchar(20) NOT NULL DEFAULT 'india',
            currency varchar(10) NOT NULL DEFAULT 'INR',
            file_name varchar(191) NULL,
            opening decimal(14,2) NULL,
            closing decimal(14,2) NULL,
            period_start date NULL,
            period_end date NULL,
            status varchar(20) NOT NULL DEFAULT 'open',
            source_hash char(64) NOT NULL,
            row_count int unsigned NOT NULL DEFAULT 0,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY source_hash (bank_key, source_hash)
        ) $c;");
        dbDelta("CREATE TABLE $txn (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            stmt_id bigint unsigned NOT NULL,
            bank_key varchar(40) NOT NULL,
            txn_date date NOT NULL,
            amount decimal(14,2) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'INR',
            direction varchar(10) NOT NULL DEFAULT 'credit',
            description text NULL,
            reference varchar(191) NULL,
            fingerprint char(64) NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'unmatched',
            confidence smallint unsigned NOT NULL DEFAULT 0,
            match_note text NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY fingerprint (bank_key, fingerprint),
            KEY stmt_id (stmt_id),
            KEY status (status)
        ) $c;");
        dbDelta("CREATE TABLE $link (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            txn_id bigint unsigned NOT NULL,
            ledger_type varchar(20) NOT NULL,
            ledger_id bigint unsigned NOT NULL DEFAULT 0,
            amount decimal(14,2) NOT NULL DEFAULT 0,
            confidence smallint unsigned NOT NULL DEFAULT 0,
            state varchar(20) NOT NULL DEFAULT 'suggested',
            reason text NULL,
            approved_by bigint unsigned NULL,
            approved_at datetime NULL,
            PRIMARY KEY  (id),
            KEY txn_id (txn_id),
            KEY ledger (ledger_type, ledger_id, state)
        ) $c;");
        dbDelta("CREATE TABLE $audit (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            created_at datetime NOT NULL,
            user_id bigint unsigned NULL,
            action varchar(40) NOT NULL,
            stmt_id bigint unsigned NULL,
            txn_id bigint unsigned NULL,
            detail text NULL,
            PRIMARY KEY  (id),
            KEY stmt_id (stmt_id)
        ) $c;");
    }

    public static function page($app) {
        if (!$app->can('money')) return $app->deny();
        self::install();
        $stmt = isset($_GET['stmt']) ? absint($_GET['stmt']) : 0;
        if ($stmt) return self::statement($app, $stmt);
        return self::home($app);
    }

    private static function home($app) {
        global $wpdb;
        $banks = self::banks($app);
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ub_bank_stmt ORDER BY id DESC LIMIT 30") ?: [];
        $note = sanitize_text_field(wp_unslash($_GET['note'] ?? ''));
        $html = '';
        if ($note !== '') $html .= '<div class="note">'.esc_html($note).'</div>';
        $html .= '<div class="kpis">';
        $html .= self::count_card($app, 'Open lines', (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ub_bank_txn WHERE status IN ('unmatched','suggested','exception')"), 'Still to clear', '#E69A0B');
        $html .= self::count_card($app, 'Matched', (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ub_bank_txn WHERE status='matched'"), 'Confirmed links', '#22C55E');
        $html .= self::count_card($app, 'Needs review', (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ub_bank_txn WHERE status='suggested'"), 'Not auto-confirmed', '#5B93F5');
        $html .= self::count_card($app, 'Exceptions', (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ub_bank_txn WHERE status='exception'"), 'Charges, transfers, gaps', '#C81E1E');
        $html .= '</div>';
        $html .= '<section class="panel"><h3 class="fin-h">Import a statement</h3>';
        $html .= '<p>Use a CSV, OFX, QIF, or CAMT.053 file from the bank. Books does not store a banking password, PIN, or OTP, and it does not call a bank API.</p>';
        $html .= '<form class="ub-form" method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';
        $html .= '<input type="hidden" name="action" value="ub_recon_import">'.wp_nonce_field('ub_recon_import','_wpnonce', true, false);
        $html .= '<div class="ub-2"><label>Account<select name="bank_key" required>';
        foreach ($banks as $b) $html .= '<option value="'.esc_attr($b['key']).'">'.esc_html($b['label']).'</option>';
        $html .= '</select></label><label>Country<select name="country"><option value="india">India</option><option value="botswana">Botswana</option></select></label></div>';
        $html .= '<div class="ub-2"><label>Currency<select name="currency"><option>INR</option><option>BWP</option><option>USD</option><option>AED</option><option>ZAR</option></select></label>';
        $html .= '<label>Statement file<input type="file" name="statement" accept=".csv,.ofx,.qif,.xml,.txt" required></label></div>';
        $html .= '<div class="ub-2"><label>Opening balance<input type="number" step="0.01" name="opening" placeholder="Optional"></label><label>Closing balance<input type="number" step="0.01" name="closing" placeholder="Optional"></label></div>';
        $html .= '<button class="btn primary" type="submit">Import and match</button></form></section>';
        $html .= '<section class="panel flush"><h3 class="fin-h fin-h-pad">Statements</h3><div class="table-wrap"><table class="ub-table"><thead><tr><th>When</th><th>Account</th><th>Currency</th><th>Lines</th><th>Status</th><th></th></tr></thead><tbody>';
        if (!$rows) $html .= '<tr><td colspan="6"><p class="empty">No statement imported yet.</p></td></tr>';
        $names = [];
        foreach ($banks as $b) $names[$b['key']] = $b['label'];
        foreach ($rows as $r) {
            $html .= '<tr><td>'.esc_html(mysql2date('j M Y', $r->created_at)).'</td><td>'.esc_html($names[$r->bank_key] ?? $r->bank_key).'</td>';
            $html .= '<td>'.esc_html($r->currency).'</td><td>'.(int)$r->row_count.'</td><td>'.esc_html(ucfirst($r->status)).'</td>';
            $html .= '<td><a class="btn sm" href="'.esc_url($app->url(['ub'=>'reconcile','stmt'=>(int)$r->id])).'">Open</a></td></tr>';
        }
        $html .= '</tbody></table></div></section>';
        $html .= '<section class="panel"><h3 class="fin-h">Engine check</h3><ul class="recon-check">';
        foreach (self::self_check() as $line) $html .= '<li>'.esc_html($line).'</li>';
        $html .= '</ul><p>Direct bank feeds are not connected. India Account Aggregator and Botswana bank APIs need a licensed provider, a consent journey, and credentials that are not in this plugin.</p></section>';
        return $html;
    }

    private static function statement($app, $id) {
        global $wpdb;
        $stmt = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ub_bank_stmt WHERE id=%d", $id));
        if (!$stmt) return '<div class="note">That statement was not found.</div>';
        $txns = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ub_bank_txn WHERE stmt_id=%d ORDER BY txn_date, id", $id)) ?: [];
        $sum = 0;
        $matched = 0;
        foreach ($txns as $t) {
            $sum += (float)$t->amount;
            if ($t->status === 'matched') $matched++;
        }
        $pct = $txns ? (int) round($matched * 100 / count($txns)) : 0;
        $ledger = self::ledger_balance($stmt->currency, $stmt->bank_key);
        $html = '<p><a class="btn sm" href="'.esc_url($app->url(['ub'=>'reconcile'])).'">All statements</a></p>';
        $html .= '<div class="kpis">';
        $html .= self::count_card($app, 'Cleared', $pct.'%', $matched.' of '.count($txns).' lines', '#22C55E', '');
        $html .= self::count_card($app, 'Statement movement', self::money($sum), $stmt->currency, '#2CC4D9', '');
        $html .= self::count_card($app, 'Books receipts minus payments', self::money($ledger), 'Same currency, not a bank balance', '#A78BFA', '');
        $close = $stmt->closing === null ? 'Not typed' : self::money($stmt->closing);
        $html .= self::count_card($app, 'Closing on the file', $close, $stmt->opening === null ? 'Opening not typed' : 'Opening '.self::money($stmt->opening), '#E69A0B', '');
        $html .= '</div>';
        if ($stmt->opening !== null && $stmt->closing !== null) {
            $move = round((float)$stmt->closing - (float)$stmt->opening, 2);
            $gap = round($move - $sum, 2);
            $html .= '<div class="note">Opening to closing movement is '.esc_html(self::money($move)).'. Imported lines sum to '.esc_html(self::money($sum)).'. Difference '.esc_html(self::money($gap)).'.</div>';
        }
        $html .= '<section class="panel flush"><h3 class="fin-h fin-h-pad">Lines</h3><div class="table-wrap"><table class="ub-table"><thead><tr><th>Date</th><th>Narration</th><th>Amount</th><th>Match</th><th></th></tr></thead><tbody>';
        if (!$txns) $html .= '<tr><td colspan="5"><p class="empty">This file had no usable lines.</p></td></tr>';
        foreach ($txns as $t) {
            $links = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ub_bank_link WHERE txn_id=%d ORDER BY confidence DESC", $t->id)) ?: [];
            $html .= '<tr><td>'.esc_html(mysql2date('j M Y', $t->txn_date)).'</td><td><strong>'.esc_html(wp_html_excerpt((string)$t->description, 90, '…')).'</strong>';
            if ($t->reference) $html .= '<span class="sub">'.esc_html($t->reference).'</span>';
            $html .= '</td><td>'.esc_html(($t->direction === 'debit' ? '-' : '').self::money(abs($t->amount))).'</td><td>';
            if (!$links) $html .= esc_html($t->match_note ?: 'No candidate');
            foreach ($links as $l) {
                $html .= '<div class="recon-hit"><span class="pill '.($l->state === 'confirmed' ? 'paid' : 'sent').'">'.esc_html(ucfirst($l->state)).' '.(int)$l->confidence.'</span> ';
                $html .= esc_html(self::ledger_label($l).' - '.$l->reason).'</div>';
            }
            $html .= '</td><td class="recon-acts">';
            if ($stmt->status !== 'locked' && $t->status !== 'matched') {
                foreach ($links as $l) {
                    if ($l->state !== 'suggested') continue;
                    $html .= self::post_button('ub_recon_confirm', ['txn'=>(int)$t->id,'link'=>(int)$l->id], 'Confirm');
                }
                if ($t->direction === 'debit') $html .= self::post_button('ub_recon_adjust', ['txn'=>(int)$t->id], 'Post as expense');
                $html .= self::post_button('ub_recon_reject', ['txn'=>(int)$t->id], 'Leave open');
            } else {
                $html .= esc_html(ucfirst($t->status));
            }
            $html .= '</td></tr>';
        }
        $html .= '</tbody></table></div></section>';
        if ($app->can('owner') && $stmt->status !== 'locked') {
            $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field('ub_recon_lock','_wpnonce', true, false);
            $html .= '<input type="hidden" name="action" value="ub_recon_lock"><input type="hidden" name="stmt" value="'.(int)$stmt->id.'">';
            $html .= '<button class="btn" type="submit">Lock this statement</button></form>';
        }
        return $html;
    }

    public static function import() {
        $app = self::app();
        $app->guard('ub_recon_import', 'money');
        self::install();
        if (empty($_FILES['statement']['tmp_name'])) wp_die('Choose a statement file.');
        $name = sanitize_file_name($_FILES['statement']['name'] ?? 'statement.csv');
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($ext === 'pdf' || $ext === 'xlsx' || $ext === 'xls') {
            wp_safe_redirect($app->url(['ub'=>'reconcile','note'=>'PDF and Excel files are not read here. Export CSV, OFX, QIF, or CAMT.053 from the bank.']));
            exit;
        }
        $raw = file_get_contents($_FILES['statement']['tmp_name']);
        if ($raw === false || $raw === '') wp_die('The file was empty.');
        $currency = strtoupper(sanitize_text_field(wp_unslash($_POST['currency'] ?? 'INR')));
        if (!in_array($currency, ['INR','BWP','USD','AED','ZAR'], true)) $currency = 'INR';
        $country = sanitize_key($_POST['country'] ?? 'india') === 'botswana' ? 'botswana' : 'india';
        $bank = sanitize_key($_POST['bank_key'] ?? '');
        $parsed = self::parse($raw, $ext);
        if (!$parsed) {
            wp_safe_redirect($app->url(['ub'=>'reconcile','note'=>'No transactions were found. Check that the file has a date and an amount.']));
            exit;
        }
        global $wpdb;
        $hash = hash('sha256', $bank.'|'.$currency.'|'.self::canonical($parsed));
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ub_bank_stmt WHERE bank_key=%s AND source_hash=%s", $bank, $hash));
        if ($existing) {
            wp_safe_redirect($app->url(['ub'=>'reconcile','stmt'=>(int)$existing,'note'=>'This file was already imported.']));
            exit;
        }
        $dates = array_column($parsed, 'date');
        sort($dates);
        $wpdb->insert($wpdb->prefix.'ub_bank_stmt', [
            'bank_key'=>$bank,'country'=>$country,'currency'=>$currency,'file_name'=>$name,
            'opening'=>self::nullable_amount($_POST['opening'] ?? ''),
            'closing'=>self::nullable_amount($_POST['closing'] ?? ''),
            'period_start'=>$dates[0] ?? null,'period_end'=>$dates[count($dates)-1] ?? null,
            'status'=>'open','source_hash'=>$hash,'row_count'=>0,
            'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),
        ]);
        $sid = (int)$wpdb->insert_id;
        $kept = 0; $dup = 0;
        foreach ($parsed as $row) {
            $fp = hash('sha256', $bank.'|'.$row['date'].'|'.$row['amount'].'|'.strtolower($row['reference'].'|'.$row['description']));
            $ok = $wpdb->insert($wpdb->prefix.'ub_bank_txn', [
                'stmt_id'=>$sid,'bank_key'=>$bank,'txn_date'=>$row['date'],'amount'=>$row['amount'],'currency'=>$currency,
                'direction'=>$row['amount'] < 0 ? 'debit' : 'credit','description'=>$row['description'],'reference'=>$row['reference'],
                'fingerprint'=>$fp,'status'=>'unmatched',
            ]);
            if (!$ok) { $dup++; continue; }
            $kept++;
            self::match_txn($wpdb->insert_id, $bank, $currency);
        }
        $wpdb->update($wpdb->prefix.'ub_bank_stmt', ['row_count'=>$kept], ['id'=>$sid]);
        self::audit('import', $sid, 0, 'Imported '.$kept.' lines. Skipped '.$dup.' duplicates. File name only, not the file body.');
        wp_safe_redirect($app->url(['ub'=>'reconcile','stmt'=>$sid,'note'=>$kept.' lines imported. '.$dup.' duplicates skipped.']));
        exit;
    }

    public static function confirm() {
        $app = self::app();
        $app->guard('ub_recon_confirm', 'money');
        global $wpdb;
        $txn = self::txn(absint($_POST['txn'] ?? 0));
        $link = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ub_bank_link WHERE id=%d AND txn_id=%d", absint($_POST['link'] ?? 0), $txn->id));
        if (!$txn || !$link) wp_die('That match was not found.');
        if (self::locked($txn->stmt_id)) wp_die('This statement is locked.');
        if ((int)$link->confidence < 65) wp_die('This suggestion is below the review line and cannot be confirmed.');
        $already = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ub_bank_link WHERE ledger_type=%s AND ledger_id=%d AND state='confirmed' AND id<>%d", $link->ledger_type, $link->ledger_id, $link->id));
        if ($already) wp_die('That Books row is already linked to another bank line.');
        $wpdb->update($wpdb->prefix.'ub_bank_link', [
            'state'=>'confirmed','approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql'),
        ], ['id'=>$link->id]);
        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}ub_bank_link SET state='rejected' WHERE txn_id=%d AND id<>%d AND state='suggested'", $txn->id, $link->id));
        $wpdb->update($wpdb->prefix.'ub_bank_txn', ['status'=>'matched','confidence'=>(int)$link->confidence], ['id'=>$txn->id]);
        self::audit('confirm', (int)$txn->stmt_id, (int)$txn->id, $link->ledger_type.' #'.$link->ledger_id);
        wp_safe_redirect($app->url(['ub'=>'reconcile','stmt'=>(int)$txn->stmt_id]));
        exit;
    }

    public static function reject() {
        $app = self::app();
        $app->guard('ub_recon_reject', 'money');
        $txn = self::txn(absint($_POST['txn'] ?? 0));
        if (!$txn) wp_die('That line was not found.');
        if (self::locked($txn->stmt_id)) wp_die('This statement is locked.');
        global $wpdb;
        $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}ub_bank_link SET state='rejected' WHERE txn_id=%d AND state='suggested'", $txn->id));
        $wpdb->update($wpdb->prefix.'ub_bank_txn', ['status'=>'unmatched','match_note'=>'Left open by a reviewer.'], ['id'=>$txn->id]);
        self::audit('reject', (int)$txn->stmt_id, (int)$txn->id, 'Suggestions cleared');
        wp_safe_redirect($app->url(['ub'=>'reconcile','stmt'=>(int)$txn->stmt_id]));
        exit;
    }

    public static function adjust() {
        $app = self::app();
        $app->guard('ub_recon_adjust', 'owner');
        global $wpdb;
        $txn = self::txn(absint($_POST['txn'] ?? 0));
        if (!$txn || $txn->direction !== 'debit') wp_die('Only a debit can be posted as an expense.');
        if (self::locked($txn->stmt_id)) wp_die('This statement is locked.');
        $have = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ub_expenses WHERE source='reconcile' AND source_id=%d", $txn->id));
        if ($have) wp_die('An expense was already posted for this line.');
        $title = trim(wp_strip_all_tags((string)$txn->description));
        if ($title === '') $title = 'Bank charge';
        $wpdb->insert($wpdb->prefix.'ub_expenses', [
            'title'=>$title,'category'=>'bank-charge','amount'=>abs((float)$txn->amount),'currency'=>$txn->currency,
            'spent_on'=>$txn->txn_date,'notes'=>'Posted from bank reconcile. GST or VAT was not taken from the narration. Review before a tax claim.','source'=>'reconcile','source_id'=>$txn->id,
            'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),
        ]);
        $eid = (int)$wpdb->insert_id;
        $wpdb->insert($wpdb->prefix.'ub_bank_link', [
            'txn_id'=>$txn->id,'ledger_type'=>'expense','ledger_id'=>$eid,'amount'=>abs((float)$txn->amount),
            'confidence'=>100,'state'=>'confirmed','reason'=>'Approved expense from this bank line. Tax treatment was not inferred.','approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql'),
        ]);
        $wpdb->update($wpdb->prefix.'ub_bank_txn', ['status'=>'matched','confidence'=>100,'match_note'=>'Posted as an expense after approval.'], ['id'=>$txn->id]);
        self::audit('adjust', (int)$txn->stmt_id, (int)$txn->id, 'Expense #'.$eid);
        wp_safe_redirect($app->url(['ub'=>'reconcile','stmt'=>(int)$txn->stmt_id]));
        exit;
    }

    public static function lock() {
        $app = self::app();
        $app->guard('ub_recon_lock', 'owner');
        global $wpdb;
        $id = absint($_POST['stmt'] ?? 0);
        $wpdb->update($wpdb->prefix.'ub_bank_stmt', ['status'=>'locked'], ['id'=>$id]);
        self::audit('lock', $id, 0, 'Statement locked');
        wp_safe_redirect($app->url(['ub'=>'reconcile','stmt'=>$id]));
        exit;
    }

    private static function match_txn($id, $bank, $currency) {
        global $wpdb;
        $txn = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ub_bank_txn WHERE id=%d", $id));
        if (!$txn) return;
        $cands = self::candidates($txn, $currency);
        $best = 0;
        $top = [];
        foreach ($cands as $c) {
            if ($c['score'] < 65) continue;
            $top[] = $c;
            if ($c['score'] > $best) $best = $c['score'];
        }
        $auto = 0;
        foreach ($top as $c) {
            if ($c['auto']) $auto++;
        }
        $status = 'unmatched';
        $note = self::exception_note($txn);
        if ($top) {
            $status = ($auto === 1 && count($top) === 1) ? 'matched' : 'suggested';
            if ($note && $status !== 'matched') $status = 'exception';
        } elseif ($note) {
            $status = 'exception';
        }
        foreach ($top as $c) {
            $state = ($status === 'matched' && $c['auto']) ? 'confirmed' : 'suggested';
            $wpdb->insert($wpdb->prefix.'ub_bank_link', [
                'txn_id'=>$txn->id,'ledger_type'=>$c['type'],'ledger_id'=>$c['id'],'amount'=>$c['amount'],
                'confidence'=>$c['score'],'state'=>$state,'reason'=>$c['why'],
                'approved_by'=>$state === 'confirmed' ? 0 : null,
                'approved_at'=>$state === 'confirmed' ? current_time('mysql') : null,
            ]);
        }
        $wpdb->update($wpdb->prefix.'ub_bank_txn', [
            'status'=>$status,'confidence'=>$best,'match_note'=>$note,
        ], ['id'=>$txn->id]);
    }

    private static function candidates($txn, $currency) {
        global $wpdb;
        $p = $wpdb->prefix;
        $rows = [];
        if ($txn->direction === 'credit') {
            $pays = $wpdb->get_results($wpdb->prepare("SELECT p.id, p.amount, p.currency, p.paid_on, p.reference, d.number, d.contact_name FROM {$p}ub_pays p LEFT JOIN {$p}ub_docs d ON d.id=p.doc_id WHERE p.currency=%s", $currency)) ?: [];
            foreach ($pays as $r) $rows[] = self::pair($txn, 'pay', (int)$r->id, (float)$r->amount, $r->currency, $r->paid_on, trim($r->reference.' '.$r->number), $r->contact_name);
            $docs = $wpdb->get_results($wpdb->prepare("SELECT id, total, paid, currency, doc_date, number, contact_name FROM {$p}ub_docs WHERE doc_type='invoice' AND currency=%s AND status<>'draft'", $currency)) ?: [];
            foreach ($docs as $r) {
                $open = round((float)$r->total - (float)$r->paid, 2);
                if ($open <= 0.009) continue;
                $rows[] = self::pair($txn, 'doc', (int)$r->id, $open, $r->currency, $r->doc_date, $r->number, $r->contact_name);
            }
        } else {
            $ex = $wpdb->get_results($wpdb->prepare("SELECT id, amount, currency, spent_on, title, vendor FROM {$p}ub_expenses WHERE currency=%s", $currency)) ?: [];
            foreach ($ex as $r) $rows[] = self::pair($txn, 'expense', (int)$r->id, (float)$r->amount, $r->currency, $r->spent_on, $r->title, $r->vendor);
            $po = $wpdb->get_results($wpdb->prepare("SELECT id, amount, currency, paid_on, trainer_name, note FROM {$p}ub_payouts WHERE currency=%s", $currency)) ?: [];
            foreach ($po as $r) $rows[] = self::pair($txn, 'payout', (int)$r->id, (float)$r->amount, $r->currency, $r->paid_on ?: $txn->txn_date, $r->note, $r->trainer_name);
        }
        usort($rows, function ($a, $b) { return $b['score'] <=> $a['score']; });
        return array_slice($rows, 0, 3);
    }

    public static function pair($txn, $type, $id, $amount, $currency, $date, $ref, $name) {
        $scored = self::score([
            'amount'=>abs((float)$txn->amount),'date'=>$txn->txn_date,'text'=>strtolower($txn->description.' '.$txn->reference),
        ], [
            'amount'=>abs((float)$amount),'currency'=>$currency,'date'=>$date ?: $txn->txn_date,'ref'=>(string)$ref,'name'=>(string)$name,'txn_currency'=>$txn->currency,
        ]);
        return ['type'=>$type,'id'=>$id,'amount'=>abs((float)$amount),'score'=>$scored['score'],'why'=>$scored['why'],'auto'=>$scored['auto']];
    }

    public static function score($txn, $row) {
        $left = strtoupper((string)($row['txn_currency'] ?? ''));
        $right = strtoupper((string)($row['currency'] ?? ''));
        if ($left !== '' && $right !== '' && $left !== $right) return ['score'=>0,'why'=>'Currency differs','auto'=>false];
        $diff = abs($txn['amount'] - $row['amount']);
        $exact = $diff <= 0.02;
        $partial = !$exact && $row['amount'] > 0 && $txn['amount'] < $row['amount'] && $txn['amount'] > 0;
        if (!$exact && !$partial) return ['score'=>0,'why'=>'Amount does not match','auto'=>false];
        $score = $exact ? 45 : 18;
        $why = [$exact ? 'Amount matches' : 'Partial amount'];
        $days = abs((strtotime($txn['date']) - strtotime($row['date'])) / 86400);
        $close = $days <= 2;
        if ($close) { $score += 25; $why[] = 'Date within 2 days'; }
        elseif ($days <= 7) { $score += 12; $why[] = 'Date within 7 days'; }
        $hit = false;
        $hay = preg_replace('/[^a-z0-9]/', '', $txn['text']);
        foreach ([$row['ref'], $row['name']] as $n) {
            $needle = preg_replace('/[^a-z0-9]/', '', strtolower((string)$n));
            if (strlen($needle) >= 4 && strpos($hay, $needle) !== false) { $hit = true; break; }
        }
        if ($hit) { $score += 30; $why[] = 'Reference found in the narration'; }
        $score = min(100, $score);
        $auto = $exact && $hit && $close && $score >= 92;
        return ['score'=>$score,'why'=>implode('. ', $why),'auto'=>$auto];
    }

    private static function exception_note($txn) {
        $text = strtolower($txn->description.' '.$txn->reference);
        if (preg_match('/\b(charge|charges|chgs|fee|fees)\b/', $text)) return 'Possible bank charge. GST or VAT is not taken from this narration.';
        if (preg_match('/\binterest\b/', $text)) return 'Possible interest. It is not posted until someone approves an entry.';
        if (preg_match('/\b(reversal|refund)\b/', $text)) return 'Possible reversal or refund. Review before linking.';
        if (preg_match('/\b(self|own account|trf|transfer)\b/', $text)) return 'Possible transfer. No ledger entry was created.';
        return '';
    }

    public static function parse($raw, $ext) {
        $raw = ltrim($raw, "\xEF\xBB\xBF");
        if ($ext === 'ofx' || stripos($raw, '<STMTTRN>') !== false) return self::parse_ofx($raw);
        if ($ext === 'qif' || strncmp(ltrim($raw), '!Type:', 6) === 0) return self::parse_qif($raw);
        if ($ext === 'xml' || stripos($raw, 'BkToCstmrStmt') !== false || stripos($raw, '<Ntry>') !== false) return self::parse_camt($raw);
        return self::parse_csv($raw);
    }

    public static function parse_csv($raw) {
        $lines = preg_split('/\r\n|\n|\r/', $raw);
        $header = null; $start = 0;
        foreach ($lines as $i => $line) {
            if (stripos($line, 'date') !== false && (stripos($line, 'debit') !== false || stripos($line, 'credit') !== false || stripos($line, 'amount') !== false)) {
                $header = array_map('strtolower', str_getcsv($line));
                $start = $i + 1;
                break;
            }
        }
        $out = [];
        for ($i = $start; $i < count($lines); $i++) {
            if (trim($lines[$i]) === '') continue;
            $cols = str_getcsv($lines[$i]);
            if (!$header) {
                $date = self::date($cols[0] ?? '');
                $amount = self::signed($cols[2] ?? '', $cols[3] ?? '', $cols[1] ?? '');
                if (!$date || $amount === null) continue;
                $out[] = ['date'=>$date,'amount'=>$amount,'description'=>sanitize_text_field($cols[1] ?? ''),'reference'=>sanitize_text_field($cols[4] ?? '')];
                continue;
            }
            $map = [];
            foreach ($header as $n => $h) $map[trim($h)] = $cols[$n] ?? '';
            $date = self::date($map['date'] ?? $map['txn date'] ?? $map['value date'] ?? $map['transaction date'] ?? '');
            $debit = $map['debit'] ?? $map['withdrawal'] ?? $map['dr'] ?? '';
            $credit = $map['credit'] ?? $map['deposit'] ?? $map['cr'] ?? '';
            $amount = self::signed($debit, $credit, $map['amount'] ?? '');
            if (!$date || $amount === null || abs($amount) < 0.001) continue;
            $desc = $map['description'] ?? $map['narration'] ?? $map['particulars'] ?? $map['details'] ?? '';
            $ref = $map['reference'] ?? $map['ref'] ?? $map['cheque'] ?? $map['utr'] ?? $map['chq no'] ?? '';
            $out[] = ['date'=>$date,'amount'=>$amount,'description'=>sanitize_text_field($desc),'reference'=>sanitize_text_field($ref)];
        }
        return $out;
    }

    private static function parse_ofx($raw) {
        $out = [];
        $blocks = preg_split('/<STMTTRN>/i', $raw);
        array_shift($blocks);
        if (!$blocks) return $out;
        foreach ($blocks as $b) {
            $date = self::date(self::tag($b, 'DTPOSTED'));
            $amount = self::num(self::tag($b, 'TRNAMT'));
            if (!$date || $amount === null) continue;
            $out[] = ['date'=>$date,'amount'=>$amount,'description'=>sanitize_text_field(self::tag($b, 'NAME').' '.self::tag($b, 'MEMO')),'reference'=>sanitize_text_field(self::tag($b, 'FITID').' '.self::tag($b, 'CHECKNUM'))];
        }
        return $out;
    }

    private static function parse_qif($raw) {
        $out = [];
        $cur = ['date'=>'','amount'=>null,'description'=>'','reference'=>''];
        foreach (preg_split('/\r\n|\n|\r/', $raw) as $line) {
            $k = substr($line, 0, 1); $v = trim(substr($line, 1));
            if ($line === '^') {
                if ($cur['date'] && $cur['amount'] !== null) $out[] = ['date'=>$cur['date'],'amount'=>$cur['amount'],'description'=>sanitize_text_field($cur['description']),'reference'=>sanitize_text_field($cur['reference'])];
                $cur = ['date'=>'','amount'=>null,'description'=>'','reference'=>''];
                continue;
            }
            if ($k === 'D') $cur['date'] = self::date($v) ?: '';
            if ($k === 'T' || $k === 'U') $cur['amount'] = self::num($v);
            if ($k === 'P' || $k === 'M') $cur['description'] .= ' '.$v;
            if ($k === 'N') $cur['reference'] = $v;
        }
        if ($cur['date'] && $cur['amount'] !== null) $out[] = ['date'=>$cur['date'],'amount'=>$cur['amount'],'description'=>sanitize_text_field($cur['description']),'reference'=>sanitize_text_field($cur['reference'])];
        return $out;
    }

    private static function parse_camt($raw) {
        $out = [];
        if (!function_exists('simplexml_load_string')) return $out;
        $xml = @simplexml_load_string($raw);
        if (!$xml) return $out;
        $xml->registerXPathNamespace('c', 'urn:iso:std:iso:20022:tech:xsd:camt.053.001.02');
        $nodes = $xml->xpath('//*[local-name()="Ntry"]') ?: [];
        foreach ($nodes as $n) {
            $amt = (string)($n->Amt ?? '');
            $ind = strtoupper((string)($n->CdtDbtInd ?? 'CRDT'));
            $date = self::date((string)($n->BookgDt->Dt ?? $n->ValDt->Dt ?? ''));
            $amount = self::num($amt);
            if (!$date || $amount === null) continue;
            if ($ind === 'DBIT') $amount = -abs($amount);
            else $amount = abs($amount);
            $ref = (string)($n->AcctSvcrRef ?? $n->NtryRef ?? '');
            $desc = (string)($n->AddtlNtryInf ?? '');
            $out[] = ['date'=>$date,'amount'=>$amount,'description'=>sanitize_text_field($desc),'reference'=>sanitize_text_field($ref)];
        }
        return $out;
    }

    public static function self_check() {
        $exact = self::score(
            ['amount'=>35000,'date'=>'2026-10-26','text'=>'neft uc/inv/2026/003 qlick'],
            ['amount'=>35000,'currency'=>'INR','txn_currency'=>'INR','date'=>'2026-10-26','ref'=>'UC/INV/2026/003','name'=>'Qlick']
        );
        $weak = self::score(
            ['amount'=>1000,'date'=>'2026-10-01','text'=>'upi payment'],
            ['amount'=>1000,'currency'=>'INR','txn_currency'=>'INR','date'=>'2026-09-01','ref'=>'','name'=>'']
        );
        $fx = self::score(
            ['amount'=>100,'date'=>'2026-10-01','text'=>'payment'],
            ['amount'=>100,'currency'=>'BWP','txn_currency'=>'INR','date'=>'2026-10-01','ref'=>'PAY1','name'=>'']
        );
        $partial = self::score(
            ['amount'=>5000,'date'=>'2026-10-02','text'=>'part uc/inv/2026/009'],
            ['amount'=>20000,'currency'=>'INR','txn_currency'=>'INR','date'=>'2026-10-02','ref'=>'UC/INV/2026/009','name'=>'']
        );
        $lines = [];
        $lines[] = ($exact['auto'] && $exact['score'] >= 92) ? 'Pass - exact amount, date, and invoice reference can confirm.' : 'Fail - exact match';
        $lines[] = (!$weak['auto'] && $weak['score'] < 92) ? 'Pass - amount alone is not confirmed.' : 'Fail - weak match was confirmed';
        $lines[] = ($fx['score'] === 0) ? 'Pass - a different currency is not matched.' : 'Fail - currency';
        $lines[] = (!$partial['auto'] && $partial['score'] >= 18) ? 'Pass - a partial receipt is suggested, not confirmed.' : 'Fail - partial';
        return $lines;
    }

    private static function date($v) {
        $v = trim((string)$v);
        if ($v === '') return '';
        if (preg_match('/^\d{8}/', $v)) $v = substr($v, 0, 8);
        foreach (['Y-m-d','d/m/Y','d-m-Y','d/m/y','d-m-y','m/d/Y','Ymd','j M Y','d M Y'] as $fmt) {
            $dt = DateTime::createFromFormat($fmt, $v);
            if ($dt && $dt->format($fmt) === $v) return $dt->format('Y-m-d');
        }
        $t = strtotime($v);
        return $t ? date('Y-m-d', $t) : '';
    }

    private static function signed($debit, $credit, $amount) {
        $d = self::num($debit);
        $c = self::num($credit);
        if ($c !== null && abs($c) > 0) return abs($c);
        if ($d !== null && abs($d) > 0) return -abs($d);
        $a = self::num($amount);
        if ($a === null) return null;
        if (preg_match('/dr/i', (string)$amount)) return -abs($a);
        return $a;
    }

    private static function num($v) {
        $v = trim((string)$v);
        if ($v === '') return null;
        $neg = strpos($v, '(') !== false || strncmp($v, '-', 1) === 0;
        $v = preg_replace('/[^0-9.\-]/', '', $v);
        if ($v === '' || $v === '-' || $v === '.') return null;
        $n = (float)$v;
        return $neg ? -abs($n) : $n;
    }

    private static function tag($xml, $tag) {
        if (preg_match('/<'.$tag.'>([^<]*)/i', $xml, $m)) return trim($m[1]);
        return '';
    }

    private static function nullable_amount($v) {
        $n = self::num($v);
        return $n === null ? null : $n;
    }

    private static function canonical($rows) {
        $bits = [];
        foreach ($rows as $r) $bits[] = $r['date'].'|'.$r['amount'].'|'.$r['reference'].'|'.$r['description'];
        sort($bits);
        return implode("\n", $bits);
    }

    private static function banks($app) {
        $c = $app->company();
        $out = [];
        foreach (($c['banks'] ?? []) as $b) {
            if (($b['holder'] ?? '') === 'personal') continue;
            $out[] = ['key'=>$b['key'] ?? 'bank','label'=>trim(($b['bank'] ?? 'Bank').' '.substr((string)($b['number'] ?? ''), -4))];
        }
        if (!$out) $out[] = ['key'=>'firm','label'=>'Firm account'];
        return $out;
    }

    private static function ledger_balance($currency, $bank) {
        global $wpdb;
        $p = $wpdb->prefix;
        $in = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$p}ub_pays WHERE currency=%s", $currency));
        $ex = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$p}ub_expenses WHERE currency=%s", $currency));
        $po = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$p}ub_payouts WHERE currency=%s", $currency));
        unset($bank);
        return round($in - $ex - $po, 2);
    }

    private static function ledger_label($l) {
        $map = ['pay'=>'Receipt','doc'=>'Open invoice','expense'=>'Expense','payout'=>'Trainer payout'];
        return ($map[$l->ledger_type] ?? $l->ledger_type).' #'.(int)$l->ledger_id;
    }

    private static function count_card($app, $label, $value, $sub, $color, $href = null) {
        unset($app, $href);
        return '<article class="kpi" style="--k:'.esc_attr($color).'"><div><small>'.esc_html($label).'</small><strong>'.esc_html((string)$value).'</strong><em>'.esc_html($sub).'</em></div></article>';
    }

    private static function post_button($action, $fields, $label) {
        $html = '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'.wp_nonce_field($action,'_wpnonce', true, false);
        $html .= '<input type="hidden" name="action" value="'.esc_attr($action).'">';
        foreach ($fields as $k=>$v) $html .= '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr($v).'">';
        $html .= '<button class="btn sm" type="submit">'.esc_html($label).'</button></form>';
        return $html;
    }

    private static function txn($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ub_bank_txn WHERE id=%d", $id));
    }

    private static function locked($stmt) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare("SELECT status FROM {$wpdb->prefix}ub_bank_stmt WHERE id=%d", $stmt)) === 'locked';
    }

    private static function audit($action, $stmt, $txn, $detail) {
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'ub_bank_audit', [
            'created_at'=>current_time('mysql'),'user_id'=>get_current_user_id(),'action'=>$action,
            'stmt_id'=>$stmt ?: null,'txn_id'=>$txn ?: null,'detail'=>wp_strip_all_tags($detail),
        ]);
    }

    private static function money($n) {
        return number_format((float)$n, 2, '.', ',');
    }

    private static function app() {
        return $GLOBALS['uc_books_app'];
    }
}
