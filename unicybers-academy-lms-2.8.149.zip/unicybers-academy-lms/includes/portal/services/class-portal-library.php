<?php
/**
 * UniCybers Academy LMS: Materials Library & Recordings Catalog Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Library {

    public static function is_video_material($portal, $m){
        $url = (string)($m->url ?? '');
        $t = strtolower((string)($m->type ?? '').' '.$url);
        if (preg_match('~\.(mp4|webm|m4v)(\?|$)~i', $url)) return true;
        if (preg_match('~youtube\.com|youtu\.be|vimeo\.com|zoom\.us/(?:[^?#]*/)?(?:rec|recording)/~i', $url)) return true;
        return strpos($t,'recording')!==false || (strpos($t,'video')!==false && strpos($t,'pdf')===false);
    }

    public static function file_category($portal, $m){
        $url = (string)($m->url ?? '');
        $t = strtolower((string)($m->title ?? '').' '.$url.' '.(string)($m->type ?? ''));
        if (preg_match('~\.pdf(\?|$)~i', $url) || strpos($t,'pdf')!==false) return 'pdf';
        if (preg_match('~\.(ppt|pptx)(\?|$)~i', $url) || strpos($t,'slide')!==false || strpos($t,'ppt')!==false || strpos($url,'docs.google.com/presentation')!==false) return 'ppt';
        if (preg_match('~\.(doc|docx)(\?|$)~i', $url) || strpos($t,'docx')!==false || strpos($t,'word')!==false || strpos($url,'docs.google.com/document')!==false) return 'doc';
        if (preg_match('~\.(xls|xlsx|csv)(\?|$)~i', $url) || strpos($t,'excel')!==false || strpos($url,'docs.google.com/spreadsheets')!==false) return 'xls';
        if (preg_match('~\.zip(\?|$)~i', $url)) return 'zip';
        return 'link';
    }

    public static function file_cat_label($portal, $k){
        $map = ['pdf'=>'PDF','ppt'=>'PPT','doc'=>'DOCX','xls'=>'XLS','zip'=>'ZIP','link'=>'Link','zoom'=>'Zoom','video'=>'Video'];
        return $map[$k] ?? strtoupper($k);
    }

    public static function content_cats($portal){
        return ['notes'=>'Notes','slide'=>'Slides','lab'=>'Labs','assignment'=>'Assignments','recording'=>'Recordings','link'=>'Links','other'=>'Other'];
    }

    public static function content_category($portal, $m){
        $type = strtolower((string)($m->type ?? ''));
        $allowed = array_keys($portal->content_cats());
        if (in_array($type, $allowed, true)) return $type;
        if ($portal->is_video_material($m)) return 'recording';
        $t = strtolower((string)($m->title ?? '').' '.(string)($m->url ?? ''));
        if (strpos($t,'assign')!==false || strpos($t,'homework')!==false) return 'assignment';
        if (strpos($t,'lab')!==false) return 'lab';
        if (preg_match('~\.(ppt|pptx)(\?|$)~i', (string)$m->url) || strpos($t,'slide')!==false) return 'slide';
        if (strpos($t,'note')!==false || preg_match('~\.pdf(\?|$)~i', (string)$m->url)) return 'notes';
        if (preg_match('~^https?://~i', (string)$m->url) && !preg_match('~\.(pdf|ppt|pptx|doc|docx)(\?|$)~i', (string)$m->url)) return 'link';
        return 'other';
    }

    public static function sort_pills($portal, $shelf, $cats){
        $o = '<nav class="lib-sort" data-shelf="'.esc_attr($shelf).'" aria-label="Sort"><button type="button" class="on" data-libcat="all">All</button>';
        foreach ($cats as $id) $o .= '<button type="button" data-libcat="'.esc_attr($id).'">'.$portal->e($portal->file_cat_label($id)).'</button>';
        return $o.'</nav>';
    }

    public static function library_desk($portal, $mats, $zoom, $del_nonce, $toolbar = ''){
        $staff = $portal->staff();
        $rows = [];
        foreach ((array)$mats as $m) {
            $cat = $portal->content_category($m);
            $rows[] = [
                'cat' => $cat,
                'title' => (string)$m->title,
                'type' => $portal->file_cat_label($portal->is_video_material($m) ? 'video' : $portal->file_category($m)),
                'batch' => (string)$m->batch_name,
                'date' => $portal->fdate($m->created_at, 'j M Y'),
                'q' => strtolower($m->title.' '.$m->batch_name.' '.$cat),
                'html' => $portal->library_file_row($m, '', $cat, $del_nonce),
            ];
        }
        foreach ((array)$zoom as $r) {
            $play = $portal->recording_playable_fast($r);
            $heading = $portal->recording_heading($r);
            $rows[] = [
                'cat' => 'recording',
                'title' => $heading,
                'type' => $portal->recording_platform_label($r),
                'batch' => (string)$r->batch_name,
                'date' => $portal->fdate($r->session_date, 'j M Y'),
                'q' => strtolower($heading.' '.$r->title.' '.(string)($r->recording_notes ?? '').' '.$r->batch_name.' recording'),
                'html' => $portal->library_zoom_row($r, $play),
            ];
        }
        $sort = '<label>Sort <select data-lib-sort aria-label="Sort"><option value="date-desc">Newest to oldest</option><option value="date-asc">Oldest to newest</option><option value="name-asc">Name, A to Z</option><option value="name-desc">Name, Z to A</option><option value="type-asc">Type, A to Z</option><option value="batch-asc">Batch, A to Z</option></select></label>';
        $tabs = '<nav class="lib-tabs" data-shelf="lib" aria-label="Category"><button type="button" class="on" data-libcat="all">All</button>';
        foreach ($portal->content_cats() as $id=>$label) $tabs .= '<button type="button" data-libcat="'.esc_attr($id).'">'.$portal->e($label).'</button>';
        $tabs .= '</nav>';
        $o = '<div class="lib-desk"><div class="lib-tools">'.$toolbar.$sort.$tabs.'</div>';
        if (!$rows) {
            $o .= '<p class="lib-empty-board">Nothing in this view yet. Put files in the Drive folders and press Sync Drive, or add a link with Add Material.</p></div>';
            return $o;
        }
        $o .= '<div class="lib-tablewrap"><table class="lib-table"><thead><tr><th>Name</th><th>Category</th><th>Type</th><th>Batch</th><th>Added</th><th></th></tr></thead><tbody>';
        foreach ($rows as $row) $o .= $row['html'];
        $o .= '</tbody></table></div></div>';
        return $o;
    }

    public static function library_item_href($portal, $m){
        $url = trim((string)($m->url ?? ''));
        $k = $portal->material_kind($url);
        $fc = $portal->file_category($m);
        $type = strtolower((string)($m->type ?? ''));
        $embeddable = $portal->embed($url) !== '';
        $file = in_array($k, ['pdf','image','video','office','zip'], true)
            || in_array($fc, ['pdf','ppt','doc','xls','zip'], true)
            || in_array($type, ['slide','slides','notes','recording','assignment','lab'], true)
            || $portal->is_video_material($m)
            || $embeddable;
        if (!$file) {
            return ['href' => $url, 'blank' => (bool)$url, 'label' => 'Open'];
        }
        return [
            'href' => home_url('/lms-view/material/'.(int)$m->id.'/'),
            'blank' => false,
            'label' => ($k === 'video' || $portal->is_video_material($m) || $type === 'recording') ? 'Watch' : 'Open',
        ];
    }

    public static function library_name_link($portal, $m, $name){
        $h = $portal->library_item_href($m);
        if (!$h['href']) return '<strong>'.$name.'</strong>';
        $blank = $h['blank'] ? ' target="_blank" rel="noopener"' : '';
        return '<a class="lib-name" href="'.esc_url($h['href']).'"'.$blank.'>'.$name.'</a>';
    }

    public static function library_file_row($portal, $m, $open, $cat, $del_nonce){
        $name = $portal->e($m->title);
        $h = $portal->library_item_href($m);
        $title = $portal->library_name_link($m, $name);
        $cats = $portal->content_cats();
        $o = '<tr class="lib-row" data-shelf="lib" data-libcat="'.esc_attr($cat).'" data-name="'.esc_attr(strtolower((string)$m->title)).'" data-type="'.esc_attr(strtolower($portal->file_cat_label($portal->is_video_material($m) ? 'video' : $portal->file_category($m)))).'" data-batch="'.esc_attr(strtolower((string)$m->batch_name)).'" data-date="'.esc_attr((string)($m->created_at ?? '')).'" data-q="'.esc_attr(strtolower($m->title.' '.$m->batch_name.' '.$cat)).'">';
        $o .= '<td class="lib-td-name">'.$title.'</td>';
        $o .= '<td><span class="lib-chip c-'.esc_attr($cat).'">'.$portal->e($cats[$cat] ?? $cat).'</span></td>';
        $o .= '<td>'.$portal->e($portal->file_cat_label($portal->is_video_material($m) ? 'video' : $portal->file_category($m))).'</td>';
        $o .= '<td>'.$portal->e($m->batch_name).'</td>';
        $o .= '<td>'.$portal->e($portal->fdate($m->created_at,'j M Y')).'</td>';
        $o .= '<td class="lib-td-act">';
        if ($h['href']) {
            $blank = $h['blank'] ? ' target="_blank" rel="noopener"' : '';
            $o .= '<a class="btn ghost sm" href="'.esc_url($h['href']).'"'.$blank.'>'.$portal->e($h['label']).'</a>';
        }
        if ($portal->staff()) {
            $payload = ['id'=>(int)$m->id,'title'=>$m->title,'batch_id'=>(int)$m->batch_id,'type'=>$cat];
            $o .= '<button type="button" class="btn ghost sm" data-edit-material=\''.esc_attr(wp_json_encode($payload)).'\'>Edit name</button>';
        }
        if ($portal->ops() && $del_nonce) $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form"><input type="hidden" name="action" value="uc_portal_material_delete"><input type="hidden" name="_wpnonce" value="'.$del_nonce.'"><input type="hidden" name="id" value="'.(int)$m->id.'"><button type="submit" class="btn ghost sm danger-hover" data-confirm="Delete this material? Students will no longer see it.">Delete</button></form>';
        $o .= '</td></tr>';
        return $o;
    }

    public static function recording_heading($portal, $r){
        $label = trim((string)($r->recording_label ?? ''));
        return $label !== '' ? $label : (string)$r->title;
    }

    public static function recording_name_cell($portal, $r){
        $heading = $portal->recording_heading($r);
        $view_url = home_url('/lms-view/recording/'.(int)$r->id.'/');
        $o = '<a class="lib-name" href="'.esc_url($view_url).'"><strong>'.$portal->e($heading).'</strong></a>';
        $label = trim((string)($r->recording_label ?? ''));
        if ($label !== '' && strcasecmp($label, (string)$r->title) !== 0) {
            $o .= '<small class="lib-zoom-src">'.$portal->e($portal->recording_platform_label($r)).': '.$portal->e($r->title).'</small>';
        }
        $notes = trim((string)($r->recording_notes ?? ''));
        if ($notes !== '') $o .= '<small class="lib-zoom-note">'.$portal->e($notes).'</small>';
        return $o;
    }

    public static function recording_details_button($portal, $r, $back='materials'){
        if (!$portal->staff()) return '';
        $payload = [
            'id'=>(int)$r->id,
            'recording_label'=>trim((string)($r->recording_label ?? '')),
            'recording_notes'=>(string)($r->recording_notes ?? ''),
            'zoom_title'=>(string)$r->title,
            'back'=>$back,
        ];
        return '<button type="button" class="btn ghost sm" data-edit-recording=\''.esc_attr(wp_json_encode($payload)).'\'>Details</button>';
    }

    public static function library_zoom_row($portal, $r, $play){
        $heading = $portal->recording_heading($r);
        $q = strtolower($heading.' '.$r->title.' '.(string)($r->recording_notes ?? '').' '.$r->batch_name.' recording');
        $view_url = home_url('/lms-view/recording/'.(int)$r->id.'/');
        $o = '<tr class="lib-row" data-shelf="lib" data-libcat="recording" data-name="'.esc_attr(strtolower($heading)).'" data-type="'.esc_attr(strtolower($portal->recording_platform_label($r))).'" data-batch="'.esc_attr(strtolower((string)$r->batch_name)).'" data-date="'.esc_attr((string)$r->session_date).'" data-q="'.esc_attr($q).'">';
        $o .= '<td class="lib-td-name">'.$portal->recording_name_cell($r).'</td>';
        $o .= '<td><span class="lib-chip c-recording">Recordings</span></td><td>'.$portal->e($portal->recording_platform_label($r)).'</td>';
        $o .= '<td>'.$portal->e($r->batch_name).'</td><td>'.$portal->e($portal->fdate($r->session_date,'j M Y')).'</td>';
        $o .= '<td class="lib-td-act">';
        $o .= '<a class="btn primary sm" href="'.esc_url($view_url).'">Watch</a>';
        $o .= '<a class="btn ghost sm" href="'.esc_url(home_url('/lms-class/'.(int)$r->id.'/')).'">Class Room</a>';
        $o .= $portal->recording_details_button($r);
        if ($portal->ops()) $o .= $portal->recording_hide_form((int)$r->id);
        $o .= '</td></tr>';
        return $o;
    }

    public static function library_shelf($portal, $docs, $zoom, $video_mats, $del_nonce){
        $staff = $portal->staff();
        $cards = '';
        $nvid = 0;
        $vcats = [];
        foreach ((array)$video_mats as $m) { $nvid++; $vcats['video']=1; $cards .= $portal->video_material_card($m); }
        foreach ((array)$zoom as $r) {
            $play = $portal->recording_playable_fast($r);
            if (!$play && !$staff) continue;
            $nvid++;
            $vcats['zoom']=1;
            $cards .= $portal->zoom_card($r, $play);
        }
        $dcats = [];
        foreach ((array)$docs as $m) $dcats[$portal->file_category($m)] = 1;
        $o = '<section class="lib-shelf">';
        $o .= '<section class="lib-pane"><header class="lib-pane-head"><h2>Documents <em>'.count($docs).'</em></h2>';
        if ($dcats) $o .= $portal->sort_pills('docs', array_keys($dcats));
        $o .= '</header>';
        $o .= $docs ? $portal->document_cards($docs, $del_nonce) : '<p class="lib-empty-board">No documents for this view yet.</p>';
        $o .= '</section>';
        $o .= '<section class="lib-pane lib-pane-vid"><header class="lib-pane-head"><h2>Recordings <em>'.$nvid.'</em></h2>';
        if ($portal->ops() && $nvid) {
            $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="lib-bulk">'.wp_nonce_field('uc_portal_recording_hide_short','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_recording_hide_short"><button type="submit" class="btn ghost sm" data-confirm="Hide every Zoom file under 20 minutes from the library? The class stays on Classes. Sync will not bring these files back.">Hide files under 20 min</button></form>';
        }
        if ($vcats) $o .= $portal->sort_pills('vids', array_keys($vcats));
        $o .= '</header>';
        $o .= $nvid ? '<div class="lib-grid">'.$cards.'</div>' : '<p class="lib-empty-board">No recordings for this view yet. Sync Zoom after class ends.</p>';
        $o .= '</section></section>';
        return $o;
    }

    public static function document_cards($portal, $docs, $del_nonce) {
        return UC_LMS_Portal_Library_Views::document_cards($portal, $docs, $del_nonce);
    }

    public static function video_material_card($portal, $m) {
        return UC_LMS_Portal_Library_Views::video_material_card($portal, $m);
    }

    public static function zoom_card($portal, $r, $play) {
        return UC_LMS_Portal_Library_Views::zoom_card($portal, $r, $play);
    }

    public static function recording_hide_form($portal, $id) {
        return UC_LMS_Portal_Library_Views::recording_hide_form($portal, $id);
    }

    public static function material_modal_tpl($portal, $batches) {
        return UC_LMS_Portal_Library_Views::material_modal_tpl($portal, $batches);
    }

    public static function recording_modal_tpl($portal) {
        return UC_LMS_Portal_Library_Views::recording_modal_tpl($portal);
    }

    public static function mtype($portal, $m){ $t=strtolower($m->type.' '.$m->url); if(strpos($t,'pdf')!==false)return 'pdf'; if(strpos($t,'slide')!==false||strpos($t,'ppt')!==false||strpos($t,'presentation')!==false)return 'ppt'; if(strpos($t,'doc')!==false)return 'doc'; if(strpos($t,'video')!==false||strpos($t,'youtu')!==false)return 'vid'; return 'link'; }

    public static function embed($portal, $url, $passcode=''){
        $u = trim((string)$url);
        $u = preg_replace('/([?&])pwd=[^&]*/', '$1', $u);
        $u = rtrim($u, '?&');
        if (preg_match('~(?:/file/d/|/document/d/|/presentation/d/|/spreadsheets/d/|[?&]id=)([A-Za-z0-9_-]{10,})~', $u, $m)) {
            if (strpos($u,'docs.google.com/presentation')!==false) return 'https://docs.google.com/presentation/d/'.$m[1].'/embed?start=false&loop=false&delayms=3000&rm=minimal';
            if (strpos($u,'docs.google.com/document')!==false) return 'https://docs.google.com/document/d/'.$m[1].'/preview?rm=minimal';
            if (strpos($u,'docs.google.com/spreadsheets')!==false) return 'https://docs.google.com/spreadsheets/d/'.$m[1].'/preview?rm=minimal';
            return 'https://drive.google.com/file/d/'.$m[1].'/preview?rm=minimal';
        }
        if (preg_match('~drive\.google\.com/(?:[^\?#]*/)?folders/([A-Za-z0-9_-]{10,})~i', $u, $m)) {
            return 'https://drive.google.com/embeddedfolderview?id='.$m[1].'#list';
        }
        if (preg_match('~canva\.com/design/([A-Za-z0-9_-]+)/view~i', $u, $m)) {
            return 'https://www.canva.com/design/'.$m[1].'/view?embed';
        }
        if (preg_match('~(?:youtube\.com/watch\?v=|youtu\.be/)([A-Za-z0-9_-]{6,})~', $u, $m)) return 'https://www.youtube-nocookie.com/embed/'.$m[1];
        if (preg_match('~\.(mp4|webm|m4v)(\?|$)~i', $u)) return $u;
        if (preg_match('~\.pdf(\?|$)~i', $u)) return $u;
        if (preg_match('~\.(png|jpe?g|gif|webp)(\?|$)~i', $u)) return $u;
        if (preg_match('~\.(doc|docx|ppt|pptx|xls|xlsx)(\?|$)~i', $u) && preg_match('~^https?://~i', $u)) {
            return 'https://view.officeapps.live.com/op/embed.aspx?src='.rawurlencode($u);
        }
        if (preg_match('~zoom\.us/(?:[^?#]*/)?(?:rec|recording)/~i', $u)) return '';
        if (preg_match('~^https?://~i', $u)) return $u;
        return '';
    }

    public static function material_kind($portal, $url){
        $path = strtolower((string)(wp_parse_url($url, PHP_URL_PATH) ?: $url));
        if (preg_match('~\.pdf$~', $path)) return 'pdf';
        if (preg_match('~\.(png|jpe?g|gif|webp)$~', $path)) return 'image';
        if (preg_match('~\.(doc|docx|ppt|pptx|xls|xlsx)$~', $path)) return 'office';
        if (preg_match('~\.(mp4|webm|m4v)$~', $path)) return 'video';
        if (preg_match('~\.zip$~', $path)) return 'zip';
        if (preg_match('~docs\.google\.com/(?:presentation|document|spreadsheets)|drive\.google\.com/(?:file|.*folders)|canva\.com/design~i', (string)$url)) return 'office';
        if (preg_match('~youtube\.com|youtu\.be|vimeo\.com~i', (string)$url)) return 'video';
        return $url ? 'web' : '';
    }

    public static function material_open_url($portal, $m){
        $url = trim((string)($m->url ?? ''));
        $k = $portal->material_kind($url);
        if (in_array($k, ['pdf','image','video','office','zip'], true) && $portal->local_upload_path($url)) {
            return home_url('/lms-media/material/'.(int)$m->id.'/');
        }
        return $url;
    }

    public static function material_link_label($portal, $url){
        $u = preg_replace('~^https?://~i', '', trim((string)$url));
        if (function_exists('mb_strlen') && mb_strlen($u) > 72) return mb_substr($u, 0, 68).'…';
        if (strlen($u) > 72) return substr($u, 0, 68).'…';
        return $u;
    }

    public static function zoom_open_url($portal, $url, $pass=''){
        $u = trim((string)$url);
        if ($u==='' || stripos($u,'zoom.us')===false) return '';
        $u = preg_replace('~zoom\.us/rec/download/~i', 'zoom.us/rec/share/', $u);
        $u = preg_replace('/([?&])access_token=[^&]*/', '$1', $u);
        $u = preg_replace('/([?&])pwd=[^&]*/', '$1', $u);
        return rtrim($u, '?&');
    }

    public static function recording_ready($portal, $session){
        if (!class_exists('UC_Academy_LMS')) return false;
        $path = UC_Academy_LMS::instance()->portal_cached_recording_path($session);
        return $path && is_file($path) && filesize($path) > 50000;
    }

    public static function recording_playable($portal, $session){
        if (strtolower((string)($session->recording_status ?? '')) === 'discarded') return false;
        if ($portal->recording_ready($session)) return true;
        if (strtolower((string)($session->platform ?? '')) === 'teams' && strtolower((string)($session->recording_status ?? '')) === 'available') return true;
        $url = trim((string)($session->recording_url ?? ''));
        return $url !== '' && $portal->embed($url) !== '';
    }

    public static function recording_playable_fast($portal, $session){
        $st = strtolower((string)($session->recording_status ?? ''));
        if ($st === 'discarded') return false;
        if ($st === 'available') return true;
        $url = trim((string)($session->recording_url ?? ''));
        return $url !== '' && $portal->embed($url) !== '';
    }

    public static function playable_recording_count($portal, $ids){
        global $wpdb;
        return (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('sessions')} WHERE batch_id IN ({$ids}) AND hidden=0 AND LOWER(IFNULL(recording_status,''))<>'discarded' AND (LOWER(IFNULL(recording_status,''))='available' OR (IFNULL(recording_url,'')<>'' AND recording_url NOT LIKE '%zoom.us/rec%'))");
    }

    public static function recording_link_form($portal, $id, $url=''){
        $val = '';
        if ($url && stripos($url,'zoom.us')===false && $portal->embed($url)!=='') $val = $url;
        return '<form class="rec-link" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uc_portal_recording_link"><input type="hidden" name="session_id" value="'.(int)$id.'">'.wp_nonce_field('uc_portal_recording_link','_wpnonce',true,false).'<input name="recording_url" type="url" required placeholder="https://drive.google.com/file/d/…/view" value="'.esc_attr($val).'"><button class="btn primary sm" type="submit">Embed Drive</button></form>';
    }

    public static function maybe_auto_pull_recording($portal, $session){
        if (!class_exists('UC_Academy_LMS')) return;
        if ($portal->recording_ready($session)) return;
        $url = trim((string)($session->recording_url ?? ''));
        if ($url !== '' && $portal->embed($url) !== '') return;
        $id = (int)$session->id;
        $lock = 'uc_lms_view_pull_'.$id;
        if (get_transient($lock)) return;
        set_transient($lock, 1, 15 * MINUTE_IN_SECONDS);

        // Avoid blocking frontend user requests with heavy synchronous video downloads (which cause Cloudflare 520 timeouts)
        if (function_exists('wp_schedule_single_event') && !wp_next_scheduled('uc_lms_pull_session_recording', [$id])) {
            wp_schedule_single_event(time(), 'uc_lms_pull_session_recording', [$id]);
        } elseif (defined('DOING_CRON') && DOING_CRON) {
            if (function_exists('set_time_limit')) @set_time_limit(180);
            $path = UC_Academy_LMS::instance()->portal_pull_recording($session);
            if (is_wp_error($path) || !$path) delete_transient($lock);
        }
    }
}
