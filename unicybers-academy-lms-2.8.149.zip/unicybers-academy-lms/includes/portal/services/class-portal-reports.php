<?php
/**
 * UniCybers Academy LMS: Portal Reporting & Evaluation Engine.
 *
 * Computes student attendance hours, material open rates, recording view telemetry,
 * practice assignment completions, and compiles comprehensive report cards.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Reports_Engine {

    /**
     * Render the student progress panel (used on student dashboard & materials library).
     *
     * @param UC_LMS_Portal $portal
     * @param int $uid
     * @param string $ids In-list of batch IDs
     * @return string
     */
    public static function student_progress_panel($portal, $uid, $ids) {
        global $wpdb;
        $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('sessions')} WHERE batch_id IN ({$ids}) AND hidden=0 AND LOWER(IFNULL(status,''))<>'cancelled'");
        $finished = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('sessions')} s WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(IFNULL(s.status,''))<>'cancelled' AND {$portal->class_finished_sql('s')}");
        $recs = $portal->playable_recording_count($ids);
        $watched = $portal->has_table('intel_views') ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('intel_views')} v JOIN {$portal->t('sessions')} s ON s.id=v.session_id WHERE v.user_id=%d AND s.batch_id IN ({$ids})", $uid)) : 0;
        $att = $portal->has_table('attendance') ? $wpdb->get_row($wpdb->prepare("SELECT COUNT(*) total, SUM(status IN ('present','partial')) present FROM {$portal->t('attendance')} WHERE user_id=%d", $uid)) : null;
        $apct = ($att && $att->total) ? round($att->present * 100 / $att->total) : 0;
        $tasks_p = $portal->has_table('intel_tasks') ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('intel_tasks')} t JOIN {$portal->t('sessions')} s ON s.id=t.session_id WHERE s.batch_id IN ({$ids}) AND t.status='published'") : 0;
        $polls_p = $portal->has_table('intel_polls') ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('intel_polls')} p JOIN {$portal->t('sessions')} s ON s.id=p.session_id WHERE s.batch_id IN ({$ids}) AND p.published=1") : 0;
        $labs = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('materials')} WHERE batch_id IN ({$ids}) AND visible=1 AND (LOWER(type) IN ('lab','assignment') OR title LIKE '%lab%')");
        $bits = [];
        if ($finished) $bits[] = min(100, round($watched * 100 / max(1, $recs ?: $finished)));
        $bits[] = $apct;
        $overall = $bits ? round(array_sum($bits) / count($bits)) : 0;
        $row = function ($l, $v) use ($portal) {
            return '<div class="prog-row"><span>' . $portal->e($l) . '</span><strong>' . $portal->e($v) . '</strong></div>';
        };
        $o = '<section class="panel intel-progress"><div class="ph"><div><span class="eyebrow">PROGRAMME</span><h3>Your progress</h3></div></div>';
        $o .= $row('Classes', $finished . ' / ' . $total);
        $o .= $row('Attendance', $apct . '%');
        $o .= $row('Recordings watched', $watched . ' / ' . $recs);
        $o .= $row('Assignments published', (string)$tasks_p);
        $o .= $row('Quizzes published', (string)$polls_p);
        $o .= $row('Labs', (string)$labs);
        $o .= '<div class="prog-row overall"><span>Overall progress</span><strong>' . $overall . '%</strong></div>';
        $o .= '<div class="prog"><i style="width:' . $overall . '%"></i></div></section>';
        return $o;
    }

    /**
     * Render the report cards gallery for all active learners across accessible batches.
     *
     * @param UC_LMS_Portal $portal
     * @return string
     */
    public static function report_cards($portal) {
        global $wpdb;
        $ids = $portal->batch_ids();
        $in = $portal->in_ids($ids);
        if (!$ids) return $portal->empty_state('No batches', 'Report cards appear once a batch has students.', 'reports');
        $people = $wpdb->get_results("SELECT DISTINCT u.ID, u.display_name, e.batch_id, b.name batch_name FROM {$portal->t('enrolments')} e JOIN {$wpdb->users} u ON u.ID=e.user_id JOIN {$portal->t('batches')} b ON b.id=e.batch_id WHERE e.status='active' AND e.batch_id IN ({$in}) ORDER BY b.name, u.display_name");
        if (!$people) return $portal->empty_state('No students', 'Enrol a student to build a report card.', 'people');
        $o = '<section class="panel"><div class="ph"><div><span class="eyebrow">WEEKLY VIEW</span><h3>Student report cards</h3></div></div><p class="hint">Built from attendance, materials opened, recordings opened and Practice. The note is written from those numbers. It is not a separate AI service.</p><div class="lib-grid">';
        foreach ($people as $p) {
            if (class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo($p->ID)) continue;
            $card = self::one_report_card($portal, (int)$p->ID, (int)$p->batch_id);
            $o .= '<article class="rcard"><h4>' . $portal->e($p->display_name ?: 'Student') . '</h4><small>' . $portal->e($p->batch_name) . '</small><div class="rstats">';
            $o .= '<div><b>' . $card['hours'] . 'h</b><span>Attendance</span></div>';
            $o .= '<div><b>' . $card['mats_open'] . '/' . $card['mats'] . '</b><span>Materials</span></div>';
            $o .= '<div><b>' . $card['recs_open'] . '/' . $card['recs'] . '</b><span>Recordings</span></div>';
            $o .= '<div><b>' . $card['asg_done'] . '/' . $card['asg'] . '</b><span>Practice</span></div>';
            $o .= '</div><p class="rnote">' . $portal->e($card['note']) . '</p></article>';
        }
        $o .= '</div></section>';
        return $o;
    }

    /**
     * Compute analytics metrics and progress notes for a single student in a batch.
     *
     * @param UC_LMS_Portal $portal
     * @param int $uid
     * @param int $batch_id
     * @return array
     */
    public static function one_report_card($portal, $uid, $batch_id) {
        global $wpdb;
        $mins = $portal->has_table('attendance') ? (int)$wpdb->get_var($wpdb->prepare("SELECT SUM(minutes) FROM {$portal->t('attendance')} WHERE user_id=%d AND batch_id=%d AND status IN ('present','partial')", $uid, $batch_id)) : 0;
        if (!$mins && $portal->has_table('attendance')) {
            $mins = (int)$wpdb->get_var($wpdb->prepare("SELECT SUM(a.minutes) FROM {$portal->t('attendance')} a JOIN {$portal->t('sessions')} s ON s.id=a.session_id WHERE a.user_id=%d AND s.batch_id=%d AND a.status IN ('present','partial')", $uid, $batch_id));
        }
        $mats = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('materials')} WHERE batch_id=%d AND visible=1 AND IFNULL(student_locked,0)=0", $batch_id));
        $mats_open = $portal->has_table('opens') ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT o.ref_id) FROM {$portal->t('opens')} o JOIN {$portal->t('materials')} m ON m.id=o.ref_id WHERE o.user_id=%d AND o.kind='material' AND m.batch_id=%d", $uid, $batch_id)) : 0;
        $recs = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('sessions')} WHERE batch_id=%d AND hidden=0 AND recording_url IS NOT NULL AND recording_url<>''", $batch_id));
        $recs_open = $portal->has_table('opens') ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT o.ref_id) FROM {$portal->t('opens')} o JOIN {$portal->t('sessions')} s ON s.id=o.ref_id WHERE o.user_id=%d AND o.kind='recording' AND s.batch_id=%d", $uid, $batch_id)) : 0;
        if ($portal->has_table('intel_views')) {
            $watched = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT v.session_id) FROM {$portal->t('intel_views')} v JOIN {$portal->t('sessions')} s ON s.id=v.session_id WHERE v.user_id=%d AND s.batch_id=%d", $uid, $batch_id));
            if ($watched > $recs_open) $recs_open = $watched;
        }
        $asg = $portal->has_table('practice') ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('practice')} WHERE batch_id=%d AND kind='assignment'", $batch_id)) : 0;
        $asg_done = ($asg && $portal->has_table('practice_done')) ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('practice_done')} d JOIN {$portal->t('practice')} p ON p.id=d.practice_id WHERE d.user_id=%d AND p.batch_id=%d AND p.kind='assignment'", $uid, $batch_id)) : 0;
        $asg_pct = $asg ? (int)round($asg_done * 100 / $asg) : 0;
        $hours = round($mins / 60, 1);
        $note = self::progress_note($hours, $mats, $mats_open, $recs, $recs_open, $asg, $asg_pct);
        return compact('hours', 'mats', 'mats_open', 'recs', 'recs_open', 'asg', 'asg_done', 'asg_pct', 'note');
    }

    /**
     * Generate evaluation progress summary narrative.
     *
     * @param float $hours
     * @param int $mats
     * @param int $mats_open
     * @param int $recs
     * @param int $recs_open
     * @param int $asg
     * @param int $asg_pct
     * @return string
     */
    public static function progress_note($hours = 0, $mats = 0, $mats_open = 0, $recs = 0, $recs_open = 0, $asg = 0, $asg_pct = 0) {
        $bits = [];
        if ($hours >= 8) $bits[] = 'Attendance hours are solid for placement review';
        elseif ($hours > 0) $bits[] = 'Attendance hours are still light';
        else $bits[] = 'No class hours recorded yet';
        if ($mats) $bits[] = $mats_open >= $mats ? 'materials are being opened' : 'some materials have not been opened';
        if ($recs) $bits[] = $recs_open >= $recs ? 'recordings are being opened' : 'some recordings have not been opened';
        if ($asg) $bits[] = $asg_pct >= 80 ? 'assignments are nearly complete' : 'assignment completion is ' . $asg_pct . ' percent';
        return ucfirst(implode('. ', $bits)) . '.';
    }

    public static function class_end_report($portal){
        global $wpdb;
        $ids = $portal->in_ids($portal->batch_ids());
        $sess = $wpdb->get_results("SELECT s.*, b.name batch_name, u.display_name trainer_name FROM {$portal->t('sessions')} s LEFT JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$wpdb->users} u ON u.ID=s.trainer_user_id WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(s.status)<>'cancelled' AND {$portal->class_finished_sql('s')} ORDER BY s.session_date DESC, s.start_time DESC LIMIT 80");
        $sel = absint($_GET['session'] ?? 0);
        if (!$sel && $sess) $sel = (int)$sess[0]->id;
        $cur = null; foreach ($sess as $s) if ((int)$s->id === $sel) $cur = $s;
        $o = '<div class="class-report"><section class="panel"><div class="ph"><div><span class="eyebrow">AFTER CLASS</span><h3>Who Attended</h3></div></div>';
        $o .= '<form method="get" class="inline"><input type="hidden" name="view" value="class"><label>Finished Class <select name="session" onchange="this.form.submit()">';
        if (!$sess) $o .= '<option value="">No finished classes yet</option>';
        foreach ($sess as $s) $o .= '<option value="'.(int)$s->id.'"'.selected($sel,(int)$s->id,false).'>'.$portal->e($portal->fdate($s->session_date,'j M Y')).' · '.$portal->e($s->title).' · '.$portal->e($s->batch_name).'</option>';
        $o .= '</select></label></form>';
        if (!$cur) return $o.$portal->empty_state('No class report yet','When a scheduled class ends, the roster and attendance appear here.','reports').'</section></div>';
        list($ignore,$roster,$map) = $portal->att_data((int)$cur->batch_id);
        $present=0;$absent=0;$unmarked=0;
        foreach ($roster as $st) {
            $a = $map[$st->ID][$cur->id] ?? null;
            if ($a && in_array($a->status, ['present','partial'], true)) $present++;
            elseif ($a && $a->status==='absent') $absent++;
            else $unmarked++;
        }
        $enr = count($roster); $pct = $enr ? round($present*100/$enr) : 0;
        $o .= '<div class="kpis" style="margin-top:12px">'.$portal->kpi('Present',$present,'Joined or marked present','people','green').$portal->kpi('Absent',$absent,'Marked absent','alert','rose').$portal->kpi('Not marked',$unmarked,'No join log yet','classes','amber').$portal->kpi('Attendance',$pct.'%','Present of enrolled','reports','violet').'</div></section>';
        $o .= '<section class="panel flush"><div class="ph" style="padding:14px 18px 0"><div><span class="eyebrow">ROSTER</span><h3>'.$portal->e($cur->title).'</h3><p class="muted">'.$portal->e($cur->batch_name).' · '.$portal->e($portal->t12($cur->start_time)).($cur->end_time?' to '.$portal->e($portal->t12($cur->end_time)):'').' IST · '.$portal->e($cur->trainer_name ?: 'Trainer').' · '.strtoupper($portal->e($cur->platform ?: 'zoom')).'</p></div></div>';
        $nonce = wp_create_nonce('uc_portal_attendance_toggle'); $post_url = esc_url(admin_url('admin-post.php'));
        $o .= '<div class="tablewrap"><table class="fit-cols"><thead><tr><th>Student</th><th>Email</th><th>Status</th><th>Minutes</th></tr></thead><tbody>';
        if (!$roster) $o .= '<tr><td colspan="4">No learners enrolled on this batch.</td></tr>';
        foreach ($roster as $st) {
            $a = $map[$st->ID][$cur->id] ?? null;
            $label = ($a && in_array($a->status, ['present','partial'], true)) ? 'Present' : (($a && $a->status==='absent') ? 'Absent' : 'Not marked');
            $o .= '<tr><td><strong>'.$portal->e($st->display_name).'</strong></td><td>'.$portal->e($st->user_email).'</td><td><form method="post" action="'.$post_url.'" class="inline-form"><input type="hidden" name="action" value="uc_portal_attendance_toggle"><input type="hidden" name="_wpnonce" value="'.$nonce.'"><input type="hidden" name="session_id" value="'.(int)$cur->id.'"><input type="hidden" name="user_id" value="'.(int)$st->ID.'"><input type="hidden" name="batch" value="'.(int)$cur->batch_id.'"><input type="hidden" name="view" value="class"><button class="text-start" type="submit">'.$label.'</button></form></td><td class="mono-s">'.(int)($a->minutes ?? 0).'</td></tr>';
        }
        return $o.'</tbody></table></div></section></div>';
    }

    public static function weekly_ops_report($portal){
        global $wpdb;
        $week = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['week'] ?? '') ? $_GET['week'] : '';
        if (!$week) {
            $n = current_time('timestamp');
            $week = date('Y-m-d', $n - ((int)date('N',$n)-1)*DAY_IN_SECONDS);
        }
        $end = date('Y-m-d', strtotime($week.' +6 days'));
        $ids = $portal->in_ids($portal->batch_ids());
        $held = $wpdb->get_results($wpdb->prepare("SELECT s.*, b.name batch_name, u.display_name trainer_name FROM {$portal->t('sessions')} s LEFT JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$wpdb->users} u ON u.ID=s.trainer_user_id WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND (s.session_date < CURDATE() OR (s.session_date=CURDATE() AND IFNULL(s.end_time,'23:59:00') < CURTIME()) OR LOWER(s.status) IN ('completed','finished')) ORDER BY s.session_date, s.start_time", $week, $end));
        $upcoming = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('sessions')} s WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND NOT (s.session_date < CURDATE() OR (s.session_date=CURDATE() AND IFNULL(s.end_time,'23:59:00') < CURTIME()) OR LOWER(s.status) IN ('completed','finished'))", $week, $end));
        $hours = 0; $present=0; $expected=0;
        $byTrainer=[]; $byBatch=[];
        foreach ($held as $s) {
            $mins = $s->end_time ? max(0,(strtotime($s->end_time)-strtotime($s->start_time))/60) : 60;
            $hours += $mins/60;
            $tid = (int)$s->trainer_user_id; $bid = (int)$s->batch_id;
            if (!isset($byTrainer[$tid])) $byTrainer[$tid] = ['name'=>$s->trainer_name ?: 'Unassigned','classes'=>0,'hours'=>0,'batches'=>[]];
            $byTrainer[$tid]['classes']++; $byTrainer[$tid]['hours'] += $mins/60; $byTrainer[$tid]['batches'][$bid]=1;
            if (!isset($byBatch[$bid])) $byBatch[$bid] = ['name'=>$s->batch_name,'classes'=>0,'hours'=>0,'present'=>0,'expected'=>0];
            $byBatch[$bid]['classes']++; $byBatch[$bid]['hours'] += $mins/60;
            list($ignore,$roster,$map) = $portal->att_data($bid);
            foreach ($roster as $st) {
                $expected++; $byBatch[$bid]['expected']++;
                $a = $map[$st->ID][$s->id] ?? null;
                if ($a && $a->status==='present') { $present++; $byBatch[$bid]['present']++; }
            }
        }
        $pct = $expected ? round($present*100/$expected) : 0;
        $missing = []; $short = [];
        foreach ($held as $s) {
            $kind = $portal->rec_issue($s);
            if ($kind==='missing') $missing[] = $s;
            if ($kind==='short') $short[] = $s;
        }
        $o = '<section class="panel"><div class="ph"><div><span class="eyebrow">THIS WEEK</span><h3>Academy Weekly Report</h3></div>';
        $o .= '<form method="get" class="inline"><input type="hidden" name="view" value="weekly"><label>Week starting <input type="date" name="week" value="'.esc_attr($week).'" onchange="this.form.submit()"></label></form></div>';
        $o .= '<p class="muted">'.$portal->e($portal->fdate($week,'j M Y')).' to '.$portal->e($portal->fdate($end,'j M Y')).'. Monday 8:00 AM IST emails the full week to rafi@unicybers.com. coordinator@unicybers.com receives attendance only.</p>';
        if ($portal->role()==='super_admin') {
            $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline" style="margin-top:8px"><input type="hidden" name="action" value="uc_portal_weekly_email">'.wp_nonce_field('uc_portal_weekly_email','_wpnonce',true,false).'<input type="hidden" name="week" value="'.esc_attr($week).'"><button class="btn ghost sm">Email this week now</button></form>';
        }
        $o .= '<div class="kpis" style="margin-top:12px">'.$portal->kpi('Classes Held',count($held),$upcoming.' still upcoming','classes','violet').$portal->kpi('Missing recordings',count($missing),'No playable file','play','rose').$portal->kpi('Short recordings',count($short),'Under 20 minutes','alert','amber').$portal->kpi('Attendance',$pct.'%','Present of expected','reports','green').'</div></section>';
        $o .= $portal->rec_watch_table($missing, $short);
        if ($portal->role()==='super_admin') {
        $o .= '<section class="panel flush"><h3 class="fin-h fin-h-pad">Trainers</h3><div class="tablewrap"><table class="ops"><thead><tr><th>Trainer</th><th class="num">Classes</th><th class="num">Hours</th><th class="num">Batches</th></tr></thead><tbody>';
        if (!$byTrainer) $o .= '<tr><td colspan="4">No trainer hours this week.</td></tr>';
        foreach ($byTrainer as $r) $o .= '<tr><td><strong>'.$portal->e($r['name']).'</strong></td><td class="num">'.$r['classes'].'</td><td class="num">'.number_format($r['hours'],1).'</td><td class="num">'.count($r['batches']).'</td></tr>';
        $o .= '</tbody></table></div></section>';
        }

        $o .= '<section class="panel flush"><h3 class="fin-h fin-h-pad">Batches</h3><div class="tablewrap"><table class="ops"><thead><tr><th>Batch</th><th class="num">Classes</th><th class="num">Hours</th><th class="num">Attendance</th></tr></thead><tbody>';
        if (!$byBatch) $o .= '<tr><td colspan="4">No batch classes this week.</td></tr>';
        foreach ($byBatch as $r) {
            $bp = $r['expected'] ? round($r['present']*100/$r['expected']) : 0;
            $o .= '<tr><td><strong>'.$portal->e($r['name']).'</strong></td><td class="num">'.$r['classes'].'</td><td class="num">'.number_format($r['hours'],1).'</td><td class="num">'.($r['expected']?$r['present'].'/'.$r['expected'].' ('.$bp.'%)':'No roster').'</td></tr>';
        }
        $o .= '</tbody></table></div></section>';

        $o .= '<section class="panel flush"><h3 class="fin-h fin-h-pad">Classes</h3><div class="tablewrap"><table><thead><tr><th>When</th><th>Class</th><th>Batch</th><th>Trainer</th><th>Status</th><th>Recording</th></tr></thead><tbody>';
        $upcomingRows = $wpdb->get_results($wpdb->prepare("SELECT s.*, b.name batch_name, u.display_name trainer_name FROM {$portal->t('sessions')} s LEFT JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$wpdb->users} u ON u.ID=s.trainer_user_id WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND NOT (s.session_date < CURDATE() OR (s.session_date=CURDATE() AND IFNULL(s.end_time,'23:59:00') < CURTIME()) OR LOWER(s.status) IN ('completed','finished')) ORDER BY s.session_date, s.start_time", $week, $end));
        if (!$held && !$upcomingRows) $o .= '<tr><td colspan="6">No classes this week.</td></tr>';
        foreach ($held as $s) $o .= '<tr><td class="mono-s">'.$portal->e($portal->fdate($s->session_date,'j M Y')).'</td><td><strong>'.$portal->e($s->title).'</strong></td><td>'.$portal->e($s->batch_name).'</td><td>'.$portal->e($s->trainer_name ?: 'Unassigned').'</td><td>Finished</td><td>'.$portal->e($portal->rec_label($s)).'</td></tr>';
        foreach ($upcomingRows as $s) $o .= '<tr><td class="mono-s">'.$portal->e($portal->fdate($s->session_date,'j M Y')).'</td><td><strong>'.$portal->e($s->title).'</strong></td><td>'.$portal->e($s->batch_name).'</td><td>'.$portal->e($s->trainer_name ?: 'Unassigned').'</td><td class="muted">Upcoming</td><td class="muted">—</td></tr>';
        return $o.'</tbody></table></div></section>';
    }

    public static function rec_issue($portal, $s){
        if (!$portal->recording_playable_fast($s)) return 'missing';
        $d = (int)($s->recording_duration ?? 0);
        if ($d > 0 && $d < 20 * 60) return 'short';
        return 'ok';
    }

    public static function rec_label($portal, $s){
        $kind = $portal->rec_issue($s);
        if ($kind === 'missing') return 'Missing recording';
        $d = (int)($s->recording_duration ?? 0);
        if ($kind === 'short') return 'Stopped early ('.round($d/60).' min)';
        return $d ? round($d/60).' min' : 'Playable';
    }

    public static function rec_watch_table($portal, $missing, $short){
        $o = '<section class="panel flush"><h3 class="fin-h fin-h-pad">Recording watch</h3><div class="tablewrap"><table class="ops"><thead><tr><th>When</th><th>Class</th><th>Batch</th><th>Issue</th></tr></thead><tbody>';
        if (!$missing && !$short) $o .= '<tr><td colspan="4">No missing or short recordings in this period.</td></tr>';
        foreach ($missing as $s) $o .= '<tr><td class="mono-s">'.$portal->e($portal->fdate($s->session_date,'j M Y')).'</td><td><strong>'.$portal->e($s->title).'</strong></td><td>'.$portal->e($s->batch_name).'</td><td>No playable file. Zoom did not give a recording, or Sync Zoom has not pulled it.</td></tr>';
        foreach ($short as $s) $o .= '<tr><td class="mono-s">'.$portal->e($portal->fdate($s->session_date,'j M Y')).'</td><td><strong>'.$portal->e($s->title).'</strong></td><td>'.$portal->e($s->batch_name).'</td><td>Under 20 minutes. Recording likely stopped or a false start ('.round(((int)($s->recording_duration ?? 0))/60).' min).</td></tr>';
        return $o.'</tbody></table></div></section>';
    }

    public static function monthly_ops_report($portal){
        global $wpdb;
        $month = preg_match('/^\d{4}-\d{2}$/', $_GET['month'] ?? '') ? $_GET['month'] : current_time('Y-m');
        $start = $month.'-01';
        $end = date('Y-m-t', strtotime($start));
        $ids = $portal->in_ids($portal->batch_ids());
        $held = $wpdb->get_results($wpdb->prepare("SELECT s.*, b.name batch_name, u.display_name trainer_name FROM {$portal->t('sessions')} s LEFT JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$wpdb->users} u ON u.ID=s.trainer_user_id WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND (s.session_date < CURDATE() OR (s.session_date=CURDATE() AND IFNULL(s.end_time,'23:59:00') < CURTIME()) OR LOWER(s.status) IN ('completed','finished')) ORDER BY s.session_date, s.start_time", $start, $end));
        $upcoming = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('sessions')} s WHERE s.batch_id IN ({$ids}) AND s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND NOT (s.session_date < CURDATE() OR (s.session_date=CURDATE() AND IFNULL(s.end_time,'23:59:00') < CURTIME()) OR LOWER(s.status) IN ('completed','finished'))", $start, $end));
        $present=0; $expected=0; $missing=[]; $short=[];
        foreach ($held as $s) {
            list($ignore,$roster,$map) = $portal->att_data((int)$s->batch_id);
            foreach ($roster as $st) {
                $expected++;
                $a = $map[$st->ID][$s->id] ?? null;
                if ($a && $a->status==='present') $present++;
            }
            $kind = $portal->rec_issue($s);
            if ($kind==='missing') $missing[] = $s;
            if ($kind==='short') $short[] = $s;
        }
        $pct = $expected ? round($present*100/$expected) : 0;
        $o = '<section class="panel"><div class="ph"><div><span class="eyebrow">THIS MONTH</span><h3>Academy Monthly Report</h3></div>';
        $o .= '<form method="get" class="inline"><input type="hidden" name="view" value="monthly"><label>Month <input type="month" name="month" value="'.esc_attr($month).'" onchange="this.form.submit()"></label></form></div>';
        $o .= '<p class="muted">'.$portal->e($portal->fdate($start,'j M Y')).' to '.$portal->e($portal->fdate($end,'j M Y')).'. First of the month emails the previous month to rafi@unicybers.com. coordinator@unicybers.com receives attendance only.</p>';
        if ($portal->role()==='super_admin') {
            $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline" style="margin-top:8px"><input type="hidden" name="action" value="uc_portal_monthly_email">'.wp_nonce_field('uc_portal_monthly_email','_wpnonce',true,false).'<input type="hidden" name="month" value="'.esc_attr($month).'"><button class="btn ghost sm">Email this month now</button></form>';
        }
        $o .= '<div class="kpis" style="margin-top:12px">'.$portal->kpi('Classes Held',count($held),$upcoming.' still upcoming','classes','violet').$portal->kpi('Missing recordings',count($missing),'No playable file','play','rose').$portal->kpi('Short recordings',count($short),'Under 20 minutes','alert','amber').$portal->kpi('Attendance',$pct.'%','Present of expected','reports','green').'</div></section>';
        $o .= $portal->rec_watch_table($missing, $short);
        $o .= '<section class="panel flush"><h3 class="fin-h fin-h-pad">Classes</h3><div class="tablewrap"><table><thead><tr><th>When</th><th>Class</th><th>Batch</th><th>Recording</th></tr></thead><tbody>';
        if (!$held) $o .= '<tr><td colspan="4">No finished classes this month.</td></tr>';
        foreach ($held as $s) $o .= '<tr><td class="mono-s">'.$portal->e($portal->fdate($s->session_date,'j M Y')).'</td><td><strong>'.$portal->e($s->title).'</strong></td><td>'.$portal->e($s->batch_name).'</td><td>'.$portal->e($portal->rec_label($s)).'</td></tr>';
        return $o.'</tbody></table></div></section>';
    }

    public static function trainer_hours_report($portal){
        global $wpdb;
        $month = preg_match('/^\d{4}-\d{2}$/', $_GET['month'] ?? '') ? $_GET['month'] : current_time('Y-m');
        $mine = $portal->role()==='trainer';
        $trainer_ids = $mine ? [get_current_user_id()] : array_map(function($u){return (int)$u->ID;}, get_users(['role'=>'uc_trainer']));
        $rows = [];
        foreach ($trainer_ids as $tid) {
            $t = get_user_by('id',$tid); if (!$t) continue;
            $agg = $wpdb->get_row($wpdb->prepare(
                "SELECT COUNT(*) classes, COALESCE(SUM(TIMESTAMPDIFF(MINUTE,CONCAT(session_date,' ',start_time),CONCAT(session_date,' ',IFNULL(end_time,start_time)))),0) minutes
                 FROM {$portal->t('sessions')} WHERE trainer_user_id=%d AND hidden=0 AND LOWER(status)<>'cancelled' AND DATE_FORMAT(session_date,'%%Y-%%m')=%s",
                $tid, $month));
            $rows[] = ['name'=>$t->display_name,'classes'=>(int)($agg->classes ?? 0),'hours'=>round((float)($agg->minutes ?? 0)/60,1)];
        }
        $o = '<section class="panel"><form method="get" class="inline"><input type="hidden" name="view" value="hours"><label>Month <input type="month" name="month" value="'.esc_attr($month).'" onchange="this.form.submit()"></label></form>';
        if (!$rows) return $o.$portal->empty_state('No trainers yet','Trainer hours appear here once classes are scheduled.','classes').'</section>';
        $o .= '<div class="tablewrap"><table class="ops"><thead><tr><th>Trainer</th><th class="num">Classes taught</th><th class="num">Scheduled hours</th></tr></thead><tbody>';
        foreach ($rows as $r) $o .= '<tr><td><strong>'.$portal->e($r['name']).'</strong></td><td class="num">'.$r['classes'].'</td><td class="num">'.$r['hours'].' h</td></tr>';
        return $o.'</tbody></table></div></section>';
    }

}
