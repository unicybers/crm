(function(){
  'use strict';
  function request(url, options){
    return fetch(url, options).then(function(r){
      return r.text().then(function(text){
        var data;
        try { data = JSON.parse(text); }
        catch(e){ throw new Error('The CRM server returned a non-JSON response ('+r.status+').'); }
        if(!r.ok) throw new Error((data && (data.message || data.error)) || ('Server error '+r.status));
        if(!data || typeof data !== 'object') throw new Error('Unexpected CRM server response.');
        if(data.ok === false) throw new Error(data.error || data.message || 'CRM request failed.');
        if(data.success === false) throw new Error((data.data && data.data.message) || 'CRM request failed.');
        return data;
      });
    });
  }
  function ajaxFallback(fn,args){
    if(!window.UC_CRM_AJAX) return Promise.reject(new Error('CRM connection endpoint is not configured.'));
    var body = new URLSearchParams();
    body.set('action','uc_crm_rpc');
    body.set('payload',JSON.stringify({fn:fn,args:args}));
    return request(window.UC_CRM_AJAX,{
      method:'POST',credentials:'same-origin',
      headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
      body:body.toString(),cache:'no-store'
    });
  }
  function call(fn,args){
    var headers={'Content-Type':'application/json','Cache-Control':'no-cache'};
    if(window.UC_CRM_NONCE) headers['X-WP-Nonce']=window.UC_CRM_NONCE;
    var primary = window.UC_CRM_RPC ? request(window.UC_CRM_RPC,{
      method:'POST',credentials:'same-origin',headers:headers,
      body:JSON.stringify({fn:fn,args:args}),cache:'no-store'
    }) : Promise.reject(new Error('CRM REST endpoint is not configured.'));
    return primary.catch(function(err){
      if(!window.UC_CRM_AJAX) return Promise.reject(err);
      return ajaxFallback(fn,args).catch(function(){ return Promise.reject(err); });
    });
  }
  function chain(){
    var ok=function(){},err=function(){};
    var proxy=new Proxy({}, {get:function(_,prop){
      if(prop==='withSuccessHandler') return function(fn){ok=fn||ok;return proxy;};
      if(prop==='withFailureHandler') return function(fn){err=fn||err;return proxy;};
      return function(){
        var args=Array.prototype.slice.call(arguments),done=ok,fail=err;
        call(String(prop),args).then(function(res){
          if(res && res.success===true && Object.prototype.hasOwnProperty.call(res,'data')) done(res.data);
          else done(res && Object.prototype.hasOwnProperty.call(res,'data') ? res.data : res);
        }).catch(function(e){fail({message:(e&&e.message)||String(e)});});
      };
    }});
    return proxy;
  }
  window.ucCRM=window.ucCRM||{};
  window.ucCRM.run=new Proxy({}, {get:function(_,prop){var c=chain();return c[prop];}});
})();
