<?php
/**
 * Registers optional UniCybers add-ons.
 *
 * An add-on calls UC_LMS_Addons::register() on plugins_loaded.
 * Finance and CRM use the same hook later. A page appears in the
 * portal only while that add-on is installed and active.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Addons {
    private static $addons = [];

    public static function register($slug, $args) {
        $slug = sanitize_key($slug);
        if ($slug === '') return;
        self::$addons[$slug] = [
            'label' => (string)($args['label'] ?? $slug),
            'pages' => array_values(array_filter(array_map('sanitize_key', (array)($args['pages'] ?? [$slug])))),
            'roles' => array_values(array_filter(array_map('sanitize_key', (array)($args['roles'] ?? ['super_admin'])))),
        ];
    }

    public static function active($slug) {
        return isset(self::$addons[sanitize_key($slug)]);
    }

    public static function pages_for($role) {
        $pages = [];
        foreach (self::$addons as $addon) {
            if (!in_array($role, $addon['roles'], true)) continue;
            foreach ($addon['pages'] as $page) $pages[] = $page;
        }
        return array_values(array_unique($pages));
    }
}
