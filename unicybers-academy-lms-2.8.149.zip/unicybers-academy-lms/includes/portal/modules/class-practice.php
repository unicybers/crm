<?php
/**
 * UniCybers Academy LMS: Practice, Assignments & Mock Exams Module.
 *
 * Manages cybersecurity assignments, lab tasks, question paper triage
 * (SOC, CEH, Network), submission tracking, answer review, and live mock sessions.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Practice {
    public static function render($portal) {
        global $wpdb;
        if (!$portal->has_table('practice')) {
            return $portal->empty_state('Practice is not ready', 'Reload the portal once so the practice tables can be created.', 'practice');
        }

        $ids = $portal->in_ids($portal->batch_ids());
        $tb_practice = $portal->t('practice');
        $tb_batches  = $portal->t('batches');
        $rows = $wpdb->get_results("SELECT p.*, b.name batch_name FROM {$tb_practice} p JOIN {$tb_batches} b ON b.id=p.batch_id WHERE p.batch_id IN ({$ids}) ORDER BY p.kind, p.due_at, p.starts_at, p.id DESC");
        $uid = get_current_user_id();
        $done = [];
        if ($portal->has_table('practice_done')) {
            $tb_done = $portal->t('practice_done');
            foreach ($wpdb->get_results($wpdb->prepare("SELECT practice_id FROM {$tb_done} WHERE user_id=%d", $uid)) as $d) {
                $done[(int)$d->practice_id] = 1;
            }
        }
        $batches = $wpdb->get_results("SELECT id,name FROM {$tb_batches} WHERE id IN ({$ids}) ORDER BY name");
        $o = '';
        if ($portal->staff()) {
            $o .= '<template id="tplPractice"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form" enctype="multipart/form-data"><input type="hidden" name="action" value="uc_portal_practice_save"><input type="hidden" name="id" value="0"><input type="hidden" name="paper" value="">'.wp_nonce_field('uc_portal_practice_save','_wpnonce',true,false);
            $o .= $portal->mhead('PRACTICE','Add assignment or mock', true).'<div class="fgrid">';
            $o .= '<label>Batch<select name="batch_id" required><option value="">Select a batch</option>';
            foreach ($batches as $b) $o .= '<option value="'.(int)$b->id.'">'.$portal->e($b->name).'</option>';
            $o .= '</select></label><label>Type<select name="kind" data-practice-kind><option value="assignment">Assignment</option><option value="mock">Mock</option><option value="aptitude">Aptitude</option></select></label></div>';
            $o .= '<label>Title<input name="title" required placeholder="SOC alert triage or CEH mock"></label>';
            $o .= '<div data-mock hidden><div class="fgrid">';
            $o .= '<label>Date<input type="date" name="mock_date"></label>';
            $o .= '<label>Start<input type="time" name="mock_start"></label>';
            $o .= '<label>End<input type="time" name="mock_end"></label></div>';
            $o .= '<label>Meeting link<input name="url" placeholder="Paste the Zoom, Meet, Teams or Zoho link for this mock"></label>';
            $o .= '<div class="msub">Recurring mocks</div><div class="check-row weekday-picker">';
            foreach (['2'=>'Mon','3'=>'Tue','4'=>'Wed','5'=>'Thu','6'=>'Fri','7'=>'Sat','1'=>'Sun'] as $k=>$label) $o .= '<label class="daychk"><input type="checkbox" name="mock_days[]" value="'.$k.'"><span class="day-short">'.$label.'</span></label>';
            $o .= '</div><div class="fgrid"><label>Repeat through<input type="date" name="mock_until"></label><label>Custom dates<input name="mock_dates" placeholder="2026-11-03, 2026-11-12"></label></div>';
            $o .= '<label>Notes<textarea name="body" rows="3" placeholder="What the mock covers"></textarea></label></div>';
            $o .= '<div data-apt hidden><div class="fgrid"><label>Date<input type="date" name="apt_date"></label><label>Opens<input type="time" name="apt_start"></label><label>Closes<input type="time" name="apt_end"></label></div>';
            $o .= '<p class="hint">Students see this paper only between open and close. It does not stay on their page.</p></div>';
            $o .= '<div data-asg><div data-asg-only><label>Due date<input type="date" name="due_date"></label>';
            $o .= '<label>Brief<textarea name="body_asg" rows="3" placeholder="What the student should do"></textarea></label>';
            $o .= '<label>Upload a document<span class="file-btn"><input type="file" name="brief" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg"><span class="file-pick">Choose File</span><span class="file-name" data-file-name>No File Chosen</span></span></label></div>';
            $o .= '<div class="paper-tools"><button type="button" class="btn ghost sm" data-preset="apt">First-round aptitude</button><button type="button" class="btn ghost sm" data-preset="soc">SOC paper</button><button type="button" class="btn ghost sm" data-preset="ceh">CEH paper</button><button type="button" class="btn ghost sm" data-preset="net">Network paper</button><button type="button" class="btn ghost sm" data-add-q="mcq">Multiple choice</button><button type="button" class="btn ghost sm" data-add-q="short">Short answer</button><button type="button" class="btn ghost sm" data-add-q="diagram">Network diagram</button></div>';
            $o .= '<div data-questions></div></div>';
            $o .= '<div class="mfoot"><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary">Save</button></div></form></template>';
        }
        $mocks = [];
        $apts = [];
        $works = [];
        $now = current_time('timestamp');
        foreach ($rows as $r) {
            if ($r->kind === 'mock') $mocks[] = $r;
            elseif ($r->kind === 'aptitude') {
                $open = $r->starts_at && $now >= strtotime($r->starts_at) && (!$r->ends_at || $now <= strtotime($r->ends_at));
                if (!$portal->staff() && !$open && empty($done[(int)$r->id])) continue;
                $apts[] = $r;
            } else $works[] = $r;
        }
        if ($mocks) {
            $o .= '<div class="crows">';
            foreach ($mocks as $r) {
                $ts = $r->starts_at ? strtotime($r->starts_at) : 0;
                $plat = 'Meet';
                $u = strtolower((string)$r->url);
                if (strpos($u,'zoom.')!==false) $plat = 'Zoom';
                elseif (strpos($u,'teams')!==false) $plat = 'Teams';
                elseif (strpos($u,'zoho')!==false) $plat = 'Zoho';
                $o .= '<article class="crow"><div class="crow-top"><div class="dtile"><b>'.($ts?$portal->e(date('d',$ts)):'--').'</b><span>'.($ts?$portal->e(strtoupper(date('M',$ts))):'MOCK').'</span></div><span class="plat">'.$portal->e($plat).'</span></div>';
                $o .= '<div class="cmain"><strong>'.$portal->e($r->title).'</strong><small>'.$portal->e($r->batch_name);
                if ($ts) $o .= ' · '.$portal->e(date('D',$ts)).' · '.$portal->e(date('g:i A',$ts));
                if ($r->ends_at && strtotime($r->ends_at)) $o .= ' to '.$portal->e(date('g:i A', strtotime($r->ends_at)));
                $o .= '</small>';
                if (trim((string)$r->body)!=='') $o .= '<small>'.$portal->e($r->body).'</small>';
                $o .= '</div><div class="cact">';
                if ($portal->staff()) {
                    $mock_data = ['id'=>(int)$r->id, 'kind'=>'mock', 'title'=>$r->title, 'batch_id'=>(int)$r->batch_id, 'url'=>$r->url, 'body'=>$r->body, 'mock_date'=>$ts?date('Y-m-d',$ts):'', 'mock_start'=>$ts?date('H:i',$ts):'', 'mock_end'=>$r->ends_at?date('H:i',strtotime($r->ends_at)):''];
                    $o .= '<button type="button" class="btn ghost sm" data-edit-practice=\''.esc_attr(wp_json_encode($mock_data)).'\'>Edit</button>';
                }
                if ($r->url) $o .= '<a class="btn primary sm" target="_blank" rel="noopener" href="'.esc_url($r->url).'">Join mock</a>';
                else $o .= $portal->pill('Link pending','warn');
                $o .= '</div></article>';
            }
            $o .= '</div>';
        }
        if ($apts) {
            $o .= '<section class="panel"><div class="ph"><div><span class="eyebrow">FIRST ROUND</span><h3>Aptitude</h3></div></div>';
            foreach ($apts as $r) {
                $open = $r->starts_at && $now >= strtotime($r->starts_at) && (!$r->ends_at || $now <= strtotime($r->ends_at));
                $paper = json_decode((string)($r->paper ?? ''), true);
                if (!is_array($paper)) $paper = [];
                $when = $r->starts_at ? $portal->fdate($r->starts_at, 'D j M, g:i A') : '';
                if ($r->ends_at) $when .= ' to '.$portal->fdate($r->ends_at, 'g:i A');
                $o .= '<article class="lib-card"><div class="lib-card-copy"><strong>'.$portal->e($r->title).'</strong><small>Aptitude · '.$portal->e($r->batch_name).($when?' · '.$portal->e($when):'').'</small>';
                if ($portal->staff()) {
                    $o .= '<p>'.$portal->pill($open?'Open now':'Scheduled','ok').'</p>';
                } elseif (!empty($done[(int)$r->id])) {
                    $got = $wpdb->get_row($wpdb->prepare("SELECT answers FROM {$portal->t('practice_done')} WHERE practice_id=%d AND user_id=%d", $r->id, $uid));
                    $score = self::score_paper($paper, json_decode((string)($got->answers ?? ''), true));
                    $o .= '<p>'.$portal->pill('Submitted '.$score['correct'].' / '.$score['total'],'ok').'</p>';
                } elseif ($open) {
                    $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form">'.wp_nonce_field('uc_portal_practice_done','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_practice_done"><input type="hidden" name="id" value="'.(int)$r->id.'">';
                    foreach ($paper as $i=>$q) {
                        $o .= '<label>'.($i+1).'. '.$portal->e((string)($q['q'] ?? '')).'</label>';
                        foreach ((array)($q['options'] ?? []) as $opt) {
                            if (trim((string)$opt)==='') continue;
                            $o .= '<label class="check"><input type="radio" name="answer_'.$i.'" value="'.esc_attr($opt).'" required> '.$portal->e($opt).'</label>';
                        }
                    }
                    $o .= '<button class="btn primary sm" type="submit">Submit aptitude</button></form>';
                }
                $o .= '</div></article>';
            }
            $o .= '</section>';
        }
        if (!$rows) return $o.$portal->empty_state('Nothing in Practice yet','Schedule a mock, an aptitude, or add an assignment for a batch.','practice');
        if (!$works) return $o;
        $o .= '<div class="lib-grid">';
        foreach ($works as $r) {
            $enrolled = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('enrolments')} WHERE batch_id=%d AND status='active'", $r->batch_id));
            $finished = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('practice_done')} WHERE practice_id=%d", $r->id));
            $pct = $enrolled ? round($finished * 100 / $enrolled) : 0;
            $paper = json_decode((string)($r->paper ?? ''), true);
            if (!is_array($paper)) $paper = [];
            $when = $r->starts_at ? 'Due '.$portal->fdate($r->starts_at, 'D j M') : '';
            $o .= '<article class="lib-card"><div class="lib-card-copy"><strong>'.$portal->e($r->title).'</strong><small>Assignment · '.$portal->e($r->batch_name).($when?' · '.$portal->e($when):'').'</small>';
            $brief = trim((string)($r->body ?? ''));
            if ($brief !== '') $o .= '<p>'.$portal->e($brief).'</p>';
            if (!empty($r->brief_url)) $o .= '<p><a href="'.esc_url($r->brief_url).'" target="_blank" rel="noopener">Open brief</a></p>';
            if ($portal->staff()) {
                $asg_data = ['id'=>(int)$r->id, 'kind'=>'assignment', 'title'=>$r->title, 'batch_id'=>(int)$r->batch_id, 'body_asg'=>$r->body, 'due_date'=>$r->starts_at?date('Y-m-d',strtotime($r->starts_at)):''];
                $o .= '<p><button type="button" class="btn ghost sm" data-edit-practice=\''.esc_attr(wp_json_encode($asg_data)).'\'>Edit</button></p>';
                $o .= '<p><strong>'.$pct.'%</strong> submitted · '.$finished.' of '.$enrolled.' students</p>';
                $subs = $wpdb->get_results($wpdb->prepare("SELECT d.*, u.display_name FROM {$portal->t('practice_done')} d LEFT JOIN {$wpdb->users} u ON u.ID=d.user_id WHERE d.practice_id=%d ORDER BY d.completed_at DESC", $r->id));
                if ($subs) {
                    $o .= '<details><summary>Answers</summary>';
                    foreach ($subs as $s) {
                        $o .= '<p><strong>'.$portal->e($s->display_name ?: 'Student').'</strong>';
                        $ans = json_decode((string)($s->answers ?? ''), true);
                        if (is_array($ans)) foreach ($ans as $i=>$a) $o .= '<br>'.($i+1).'. '.$portal->e(is_array($a)?implode(', ',$a):(string)$a);
                        if (!empty($s->file_url)) $o .= '<br><a href="'.esc_url($s->file_url).'" target="_blank" rel="noopener">Uploaded file</a>';
                        $o .= '</p>';
                    }
                    $o .= '</details>';
                }
            } elseif (!empty($done[(int)$r->id])) {
                $o .= '<p>'.$portal->pill('Submitted','ok').'</p>';
            } else {
                $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data" class="form">'.wp_nonce_field('uc_portal_practice_done','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_practice_done"><input type="hidden" name="id" value="'.(int)$r->id.'">';
                foreach ($paper as $i=>$q) {
                    $prompt = (string)($q['q'] ?? '');
                    $type = (string)($q['type'] ?? 'short');
                    $o .= '<label>'.($i+1).'. '.$portal->e($prompt);
                    if ($type==='mcq' && !empty($q['options']) && is_array($q['options'])) {
                        $o .= '</label>';
                        foreach ($q['options'] as $k=>$opt) {
                            if (trim((string)$opt)==='') continue;
                            $o .= '<label class="check"><input type="radio" name="answer_'.$i.'" value="'.esc_attr($opt).'" required> '.$portal->e($opt).'</label>';
                        }
                    } else {
                        $ph = $type==='diagram' ? 'Label the path, or describe each box' : 'Your answer';
                        $o .= '<textarea name="answer_'.$i.'" rows="3" required placeholder="'.$portal->e($ph).'"></textarea></label>';
                    }
                }
                $o .= '<label>Upload your work<span class="file-btn"><input type="file" name="work" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.webp"><span class="file-pick">Choose File</span><span class="file-name" data-file-name>No File Chosen</span></span></label>';
                $o .= '<button class="btn primary sm" type="submit">Submit</button></form>';
            }
            $o .= '</div></article>';
        }
        return $o.'</div>';
    }

    public static function score_paper($paper, $answers){
        $correct = 0; $total = 0;
        if (!is_array($paper)) $paper = [];
        if (!is_array($answers)) $answers = [];
        foreach ($paper as $i=>$q) {
            if (($q['type'] ?? '') !== 'mcq' || trim((string)($q['key'] ?? '')) === '') continue;
            $total++;
            if (trim((string)($answers[$i] ?? '')) === trim((string)$q['key'])) $correct++;
        }
        return ['correct'=>$correct,'total'=>$total];
    }
}
