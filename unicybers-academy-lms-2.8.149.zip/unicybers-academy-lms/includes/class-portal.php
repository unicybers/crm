<?php
/**
 * UniCybers Academy LMS Student & Ops Portal Router.
 *
 * Coordinates authentication, routes, URL dispatching, and page rendering.
 * All subsystem methods are delegated via UC_LMS_Portal_Facade and UC_LMS_Portal_Helpers.
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/portal/class-portal-flash.php';
require_once __DIR__ . '/portal/class-portal-helpers.php';
require_once __DIR__ . '/portal/class-portal-dates.php';
require_once __DIR__ . '/portal/class-portal-icons.php';
require_once __DIR__ . '/portal/trait-portal-facade.php';

class UC_LMS_Portal {
    use UC_LMS_Portal_Facade;

    const VERSION = '2.8.149';
    const PROTECTED_SA = ['rafi@unicybers.com','rafi@unicybers.online','academy@unicybers.com'];
    const KNOWN_ROLES = [
        'rafi@unicybers.com'=>'super admin',
        'rafi@unicybers.online'=>'super admin',
        'academy@unicybers.com'=>'super admin',
        'coordinator@unicybers.com'=>'coordinator',
        'coordinator@unicybers.online'=>'coordinator',
        'sofia@unicybers.com'=>'coordinator',
        'sofia@unicybers.online'=>'coordinator',
        'noori@unicybers.com'=>'coordinator',
        'ranjan@unicybers.com'=>'trainer',
        'shoaib@unicybers.com'=>'trainer',
    ];
    const REST_NS = 'uc-portal/v1';
    const WA = '918688022686';
    const SUPPORT_EMAIL = 'support@unicybers.com';
    const LABS = 'https://labs.unicybers.com';

    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public $flash_token = '';
    public $last_flash_msg = '';
    public $last_flash_type = 'ok';

    public $labels = [
        'dashboard'=>'Dashboard','courses'=>'Courses','batches'=>'Batches','classes'=>'Classes','practice'=>'Practice',
        'materials'=>'Materials & Recordings','people'=>'People','announcements'=>'Announcements','messages'=>'Messages','reports'=>'Reports',
        'placement'=>'Placement Desk','settings'=>'Settings','guide'=>'Academy Guide','help'=>'Help & Support','profile'=>'My Profile','audit'=>'Audit Log','inventory'=>'Feature Inventory',
        'join'=>'Joining Class','view'=>'Viewer','classroom'=>'Class Room','setpassword'=>'Set Your Password'
    ];
    public $legacy = ['students'=>'people','trainers'=>'people','attendance'=>'reports','recordings'=>'materials','notices'=>'announcements','tenants'=>'dashboard'];

    public function __construct() {
        add_action('init', [$this,'routes']);
        add_action('init', [$this,'maybe_flush'], 99);
        add_action('init', [$this,'maybe_upgrade_core'], 5);
        add_filter('query_vars', [$this,'query_vars']);
        add_filter('request', [$this,'force_portal_request']);
        add_filter('redirect_canonical', [$this,'disable_canonical'], 10, 2);
        add_action('template_redirect', [$this,'render'], 1);
        add_action('rest_api_init', [$this,'api']);
        foreach (['person_save','person_delete','person_reset','device_remove','device_reset','device_limit','request_resolve','password','notice','notice_delete','att_csv','footer_links','sync_recordings','recording_pull','recording_upload','recording_link','recording_hide','recording_hide_short','recording_details','meet_notes','course_save','batch_save','session_save','drive_materials_sync','generate_link','material_save','material_delete','material_lock','practice_save','practice_done','attendance_toggle','message_send','profile_save','job_save','job_delete','application_save','job_feed','career_proxy','ai_credits','settings_save','ats_run','placement_optout','batch_links','demo_gate','course_interest','training_interest','training_interest_status','student_import','student_add','student_remove','enquiry_status','document_upload','weekly_email','monthly_email','tenant_save','tenant_preview','person_archive','person_remind','placement_remind','placement_stage','placement_doc_ask','client_preview','preview_role'] as $h) {
            add_action('admin_post_uc_portal_'.$h, [$this,'h_'.$h]);
        }
        add_action('admin_post_nopriv_uc_portal_course_interest', [$this,'h_course_interest']);
        add_action('uc_lms_weekly_report', [$this, 'send_weekly_digest']);
        add_action('uc_lms_monthly_report', [$this, 'send_monthly_digest']);
        register_activation_hook(UC_LMS_FILE, [$this,'activate']);
        register_deactivation_hook(UC_LMS_FILE, 'flush_rewrite_rules');
    }

    public function maybe_upgrade_core(){
        if (!is_admin() && (!defined('DOING_CRON') || !DOING_CRON)) {
            return;
        }
        if (class_exists('UC_Academy_LMS') && method_exists('UC_Academy_LMS','instance')) {
            UC_Academy_LMS::instance()->maybe_upgrade();
        }
        if (get_option('uc_portal_extras') !== self::VERSION) {
            $this->ensure_portal_extras();
            update_option('uc_portal_extras', self::VERSION, false);
        }
    }

    public function activate(){
        ob_start();
        $this->routes();
        flush_rewrite_rules(false);
        update_option('uc_portal_rules', self::VERSION, false);
        ob_end_clean();
    }

    public function maybe_flush(){ if (get_option('uc_portal_rules') !== self::VERSION) { flush_rewrite_rules(false); update_option('uc_portal_rules', self::VERSION, false); } }

    public function routes() {
        $pages = array_merge(array_keys(array_diff_key($this->labels, ['join'=>1,'view'=>1])), array_keys($this->legacy));
        foreach ($pages as $p) add_rewrite_rule('^'.preg_quote($p,'/').'/?$', 'index.php?uc_portal=1&uc_portal_page='.$p, 'top');
        add_rewrite_rule('^lms-join/([0-9]+)/?$', 'index.php?uc_portal=1&uc_portal_page=join&uc_id=$matches[1]', 'top');
        add_rewrite_rule('^lms-class/([0-9]+)/?$', 'index.php?uc_portal=1&uc_portal_page=classroom&uc_id=$matches[1]', 'top');
        add_rewrite_rule('^lms-view/(material|recording)/([0-9]+)/?$', 'index.php?uc_portal=1&uc_portal_page=view&uc_kind=$matches[1]&uc_id=$matches[2]', 'top');
        add_rewrite_rule('^lms-media/(recording|material)/([0-9]+)/?$', 'index.php?uc_portal=1&uc_portal_page=media&uc_kind=$matches[1]&uc_id=$matches[2]', 'top');
        add_rewrite_rule('^lms-media/recording/([0-9]+)/?$', 'index.php?uc_portal=1&uc_portal_page=media&uc_kind=recording&uc_id=$matches[1]', 'top');
        add_rewrite_rule('^programme/([0-9]+)/?$', 'index.php?uc_portal=1&uc_portal_page=programme&uc_id=$matches[1]', 'top');
        add_rewrite_rule('^candidate/([A-Za-z0-9]+)/?$', 'index.php?uc_portal=1&uc_portal_page=candidate&uc_kind=$matches[1]', 'top');
        add_rewrite_rule('^try-demo/?$', 'index.php?uc_portal=1&uc_portal_page=trydemo', 'top');
        add_rewrite_rule('^logout/?$', 'index.php?uc_portal=1&uc_portal_page=logout', 'top');
        foreach (['uc_portal','uc_portal_page','uc_id','uc_kind'] as $t) add_rewrite_tag('%'.$t.'%', '([^&]+)');
    }

    public function is_known_staff($u = null){
        $u = $u ?: wp_get_current_user();
        $email = strtolower((string)($u->user_email ?? ''));
        return isset(self::KNOWN_ROLES[$email]);
    }

    public function lift_staff_password_wall(){
        if (!$this->is_known_staff()) return;
        $uid = get_current_user_id();
        if ($uid && get_user_meta($uid, 'uc_must_change', true)) {
            delete_user_meta($uid, 'uc_must_change');
        }
    }

    public function lms_role_of($u){
        $email = strtolower((string)$u->user_email);
        if (isset(self::KNOWN_ROLES[$email])) return self::KNOWN_ROLES[$email];
        $roles = (array)$u->roles;
        if (in_array('uc_coordinator',$roles,true)) return 'coordinator';
        if (in_array('uc_hr',$roles,true)) return 'hr';
        if (in_array('uc_trainer',$roles,true)) return 'trainer';
        if (in_array('uc_student',$roles,true)) return 'student';
        if (user_can($u,'manage_options') || in_array('administrator',$roles,true)) return 'super admin';
        return 'student';
    }

    public function is_protected_sa($u){
        return in_array(strtolower((string)$u->user_email), self::PROTECTED_SA, true);
    }

    public function role() {
        if (!is_user_logged_in()) return 'guest';
        if (get_user_meta(get_current_user_id(), 'uc_client_preview', true) === '1') return self::preview_view_role();
        $map = ['super admin'=>'super_admin','coordinator'=>'coordinator','trainer'=>'trainer','student'=>'student','hr'=>'hr'];
        $r = $this->lms_role_of(wp_get_current_user());
        return $map[$r] ?? 'guest';
    }

    public function staff(){ return in_array($this->role(), ['super_admin','coordinator','trainer'], true); }

    public function ops(){ return in_array($this->role(), ['super_admin','coordinator'], true); }

    public static function preview_view_role() {
        $allowed = ['student','trainer','coordinator','hr','super_admin'];
        $set = sanitize_key((string)get_user_meta(get_current_user_id(), 'uc_preview_role', true));
        if (in_array($set, $allowed, true)) return $set;
        $email = strtolower((string)wp_get_current_user()->user_email);
        $map = [
            'preview1@unicybers.com' => 'student',
            'preview2@unicybers.com' => 'trainer',
            'preview3@unicybers.com' => 'coordinator',
            'preview4@unicybers.com' => 'hr',
            'preview5@unicybers.com' => 'super_admin',
        ];
        return $map[$email] ?? 'student';
    }

    public function nav_pages() {
        switch ($this->role()) {
            case 'super_admin': $pages = ['dashboard','courses','batches','classes','practice','materials','people','announcements','messages','reports','settings']; break;
            case 'coordinator': $pages = ['dashboard','courses','batches','classes','practice','materials','people','announcements','messages','reports']; break;
            case 'trainer':     $pages = ['dashboard','courses','batches','classes','practice','materials','announcements','messages','reports']; break;
            case 'student':     $pages = ['dashboard','courses','classes','practice','materials','profile','announcements','messages','reports']; break;
            case 'hr':          $pages = []; break;
            default: return [];
        }
        $pages = $this->with_addons($pages);
        $preview = is_user_logged_in() && get_user_meta(get_current_user_id(), 'uc_client_preview', true) === '1';
        if ($preview) {
            if ($this->role() === 'hr' && !in_array('placement', $pages, true)) $pages[] = 'placement';
            return array_values($pages);
        }
        if ($this->role() === 'student' && class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo(wp_get_current_user())) {
            $pages = array_values(array_diff($pages, ['announcements','placement']));
        }
        return array_values(array_filter($pages, function ($page) { return $this->feature_allowed($page); }));
    }

    private function with_addons($pages){
        if (!class_exists('UC_LMS_Addons')) return $pages;
        foreach (UC_LMS_Addons::pages_for($this->role()) as $page) {
            if (in_array($page, $pages, true)) continue;
            $at = array_search('announcements', $pages, true);
            if ($at === false) $pages[] = $page;
            else array_splice($pages, $at, 0, [$page]);
        }
        return $pages;
    }

    public function feature_allowed($page){
        $role = $this->role();
        if ($role === 'guest') return true;
        if ($role === 'super_admin' && $page === 'settings') return true;
        $map = get_option('uc_role_features', []);
        if (!is_array($map) || !isset($map[$role]) || !is_array($map[$role])) return true;
        return !isset($map[$role][$page]) || !empty($map[$role][$page]);
    }

    public function nav_label($p){
        $r = $this->role();
        if ($p==='courses' && $r==='student') return 'My Courses';
        if ($p==='classes' && $r==='student') return 'My Classes';
        if ($p==='reports' && $r==='student') return 'My Attendance';
        if ($p==='reports' && $r==='coordinator') return 'Student Report';
        if ($p==='batches' && $r==='trainer') return 'My Batches';
        return $this->labels[$p] ?? ucfirst($p);
    }

    public function allowed() {
        $extra = $this->role() === 'hr' ? ['help','setpassword','guide'] : ['help','join','view','classroom','media','setpassword','profile','audit','inventory','guide'];
        return array_merge($this->nav_pages(), $extra);
    }

    public function query_vars($vars){
        foreach (['uc_portal','uc_portal_page','uc_id','uc_kind'] as $k) if (!in_array($k, $vars, true)) $vars[] = $k;
        return $vars;
    }

    public function request_path(){
        $path = (string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        $home = (string) wp_parse_url(home_url('/'), PHP_URL_PATH);
        $path = '/'.trim(rawurldecode($path), '/');
        $home = '/'.trim($home, '/');
        if ($home !== '/' && strpos($path, $home) === 0) $path = substr($path, strlen($home)) ?: '/';
        return trim($path, '/');
    }

    public function force_portal_request($vars){
        $path = $this->request_path();
        if (preg_match('#^lms-join/(\d+)$#', $path, $m)) {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'join'; $vars['uc_id'] = $m[1];
            return $vars;
        }
        if (preg_match('#^lms-class/(\d+)$#', $path, $m)) {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'classroom'; $vars['uc_id'] = $m[1];
            return $vars;
        }
        if (preg_match('#^lms-view/(material|recording)/(\d+)$#', $path, $m)) {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'view'; $vars['uc_kind'] = $m[1]; $vars['uc_id'] = $m[2];
            return $vars;
        }
        if (preg_match('#^lms-media/(recording|material)/(\d+)$#', $path, $m)) {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'media'; $vars['uc_kind'] = $m[1]; $vars['uc_id'] = $m[2];
            return $vars;
        }
        if (preg_match('#^programme/(\d+)$#', $path, $m)) {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'programme'; $vars['uc_id'] = $m[1];
            return $vars;
        }
        if (preg_match('#^candidate/([A-Za-z0-9]+)$#', $path, $m)) {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'candidate'; $vars['uc_kind'] = $m[1];
            return $vars;
        }
        if ($path === 'try-demo') {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'trydemo';
            return $vars;
        }
        if ($path === 'logout') {
            $vars['uc_portal'] = '1'; $vars['uc_portal_page'] = 'logout';
            return $vars;
        }
        $slug = strtolower(strtok($path, '/'));
        if (isset($this->legacy[$slug])) $slug = $this->legacy[$slug];
        if ($slug && isset($this->labels[$slug]) && !in_array($slug, ['join','view','classroom'], true)) {
            $vars['uc_portal'] = '1';
            $vars['uc_portal_page'] = $slug;
        }
        return $vars;
    }

    public function disable_canonical($redirect, $request){
        if (!empty($this->force_portal_request([])['uc_portal']) || get_query_var('uc_portal')) return false;
        return $redirect;
    }

    public function url($page) { return home_url('/'.trim($page,'/').'/'); }

    public function t($name) { global $wpdb; return $wpdb->prefix.'uc_'.$name; }

    public function has_table($n){ global $wpdb; static $c=[]; if(!isset($c[$n])) $c[$n] = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$this->t($n))) === $this->t($n)); return $c[$n]; }

    public function render() {
        $from_path = $this->force_portal_request([]);
        $is_portal = get_query_var('uc_portal') || !empty($from_path['uc_portal']);
        if (!$is_portal) return;
        $this->forbid_cache();
        $page = sanitize_key(get_query_var('uc_portal_page') ?: ($from_path['uc_portal_page'] ?? 'dashboard'));
        if ($page === 'programme') { $this->public_programme((int)(get_query_var('uc_id') ?: ($from_path['uc_id'] ?? 0))); exit; }
        if ($page === 'candidate') { $this->public_candidate(sanitize_text_field(get_query_var('uc_kind') ?: ($from_path['uc_kind'] ?? ''))); exit; }
        if ($page === 'trydemo') { UC_LMS_Module_Support::public_demo(); exit; }
        if ($page === 'logout') {
            if (is_user_logged_in()) wp_logout();
            wp_safe_redirect(home_url('/login/'));
            exit;
        }
        if (!is_user_logged_in()) { wp_safe_redirect(home_url('/login/')); exit; }
        if (!empty($_POST['action']) && $_POST['action'] === 'uc_portal_password') { $this->h_password(); }
        $this->lift_staff_password_wall();
        if (isset($this->legacy[$page])) { wp_safe_redirect($this->url($this->legacy[$page])); exit; }
        if ($this->role()==='hr' && !in_array($page, $this->allowed(), true)) {
            $home = in_array('placement', $this->nav_pages(), true) ? 'placement' : 'help';
            wp_safe_redirect($this->url($home));
            exit;
        }
        if ($this->role()==='guest' || !in_array($page, $this->allowed(), true)) {
            if ($page !== 'dashboard') {
                wp_safe_redirect($this->url('dashboard'));
                exit;
            }
            wp_safe_redirect(home_url('/login/'));
            exit;
        }
        $demo_guest = class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo(wp_get_current_user());
        if ($demo_guest && UC_LMS_Security::demo_closed()) {
            wp_logout();
            wp_safe_redirect(add_query_arg('uc_login_error', 'closed', home_url('/login/')));
            exit;
        }
        if ($demo_guest) delete_user_meta(get_current_user_id(), 'uc_must_change');
        $must = !$demo_guest && (bool) get_user_meta(get_current_user_id(),'uc_must_change',true);
        if ($must && $page !== 'setpassword' && !$this->is_known_staff()) $page = 'setpassword';
        if ($page === 'join') { $this->join((int)(get_query_var('uc_id') ?: ($from_path['uc_id'] ?? 0))); exit; }
        if ($page === 'media') {
            if (is_user_logged_in() && get_user_meta(get_current_user_id(), 'uc_client_preview', true) === '1') {
                wp_die('This seat only shows sample data.', 'Preview', 403);
            }
            $mk = sanitize_key(get_query_var('uc_kind') ?: ($from_path['uc_kind'] ?? 'recording'));
            $mid = (int)(get_query_var('uc_id') ?: ($from_path['uc_id'] ?? 0));
            if ($mk === 'material') $this->stream_material($mid);
            else $this->stream_recording($mid);
            exit;
        }
        status_header(200);
        $this->document($page);
        exit;
    }

    public function content($page) {
        if (is_user_logged_in() && get_user_meta(get_current_user_id(), 'uc_client_preview', true) === '1') {
            return UC_LMS_Module_Preview::render($this, $page);
        }
        switch ($page) {
            case 'dashboard':     return UC_LMS_Module_Dashboard::render($this);
            case 'courses':       return UC_LMS_Module_Courses::render($this);
            case 'batches':       return UC_LMS_Module_Batches::render($this);
            case 'classes':       return UC_LMS_Module_Classes::render($this);
            case 'practice':      return UC_LMS_Module_Practice::render($this);
            case 'materials':     return UC_LMS_Module_Materials::render($this);
            case 'people':        return UC_LMS_Module_People::render($this);
            case 'announcements':
                if (class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo(wp_get_current_user())) {
                    return $this->empty_state('Not part of the demo', 'Academy announcements stay off a demo login.', 'announcements');
                }
                return UC_LMS_Module_Messages::render_notices($this);
            case 'messages':      return UC_LMS_Module_Messages::render($this);
            case 'reports':       return UC_LMS_Module_Reports::render($this);
            case 'tenants':
                if (function_exists('wp_safe_redirect')) {
                    wp_safe_redirect($this->url('dashboard'));
                    exit;
                }
                return $this->content('dashboard');
            case 'placement':     return class_exists('UC_LMS_Module_Placement') ? UC_LMS_Module_Placement::render($this) : $this->empty_state('Placement Desk is not installed', 'Install and activate the UniCybers Placement Desk add-on to open this page.', 'placement');
            case 'settings':      return UC_LMS_Module_Settings::render($this);
            case 'guide':         return UC_LMS_Module_Support::render_guide($this);
            case 'help':          return UC_LMS_Module_Support::render_help($this);
            case 'profile':       return UC_LMS_Module_Profile::render($this);
            case 'audit':         return UC_LMS_Module_Audit::render_audit($this);
            case 'inventory':     return UC_LMS_Module_Audit::render_inventory($this);
            case 'view':          return UC_LMS_Module_Viewer::render(sanitize_key(get_query_var('uc_kind')), (int)get_query_var('uc_id'), $this);
            case 'classroom':     return UC_LMS_Module_Classroom::render((int)get_query_var('uc_id'), $this);
            case 'setpassword':   return UC_LMS_Module_Auth::render_setpassword($this);
        }
        return '';
    }

}
