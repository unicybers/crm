<?php
/**
 * UniCybers Academy LMS: User Profile & Account Settings Module.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Profile {
    public static function render($portal){
        global $wpdb;
        $uid = get_current_user_id();
        if ($portal->ops() && !empty($_GET['user'])) $uid = absint($_GET['user']);
        if ($portal->role()==='student') $uid = get_current_user_id();
        $u = get_user_by('id',$uid);
        if (!$u) return $portal->empty_state('Not found','Choose a student.','user');
        $row = $portal->has_table('student_profiles') ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('student_profiles')} WHERE user_id=%d",$uid)) : null;
        $cid = class_exists('UC_LMS_Placement') ? UC_LMS_Placement::ensure_career_id($uid) : '';
        $docs = $portal->has_table('student_documents') ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$portal->t('student_documents')} WHERE user_id=%d ORDER BY id DESC",$uid)) : [];
        $g = function($k) use ($row){ return $row && isset($row->$k) ? $row->$k : ''; };
        $o = '<section class="panel profile-desk"><div class="ph"><div><span class="eyebrow">'.($cid?$portal->e($cid):'Student Profile').'</span><h3>'.$portal->e($u->display_name).'</h3></div></div>';
        $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form profile-form"><input type="hidden" name="action" value="uc_portal_profile_save">'.wp_nonce_field('uc_portal_profile_save','_wpnonce',true,false).'<input type="hidden" name="user_id" value="'.$uid.'">';
        $field = function($name, $label) use ($g) {
            return '<label>'.$label.'<input name="'.$name.'" value="'.esc_attr($g($name)).'"></label>';
        };
        $o .= '<div class="profile-blocks">';
        $o .= '<fieldset class="profile-block"><legend>Contact</legend><div class="fgrid">';
        $o .= $field('phone','Phone').$field('whatsapp','WhatsApp').$field('city','City').$field('state','State').$field('postal_code','Postal code').$field('country','Country').$field('nationality','Nationality').$field('linkedin','LinkedIn').$field('github','GitHub').$field('portfolio','Portfolio');
        $o .= '</div></fieldset>';
        $o .= '<fieldset class="profile-block"><legend>Education</legend><div class="fgrid">';
        $o .= $field('highest_qualification','Highest qualification').$field('field_of_study','Field of study').$field('institution','Institution').$field('graduation_year','Graduation year').$field('certifications','Certifications').$field('languages','Languages');
        $o .= '</div></fieldset>';
        $o .= '<fieldset class="profile-block"><legend>Work</legend><div class="fgrid">';
        $o .= $field('headline','Headline').$field('employment_status','Employment status').$field('employer','Employer').$field('current_job_title','Current job title').$field('experience_years','Total experience years').$field('relevant_experience','Relevant experience years').$field('skills','Skills').$field('tools','Tools').$field('current_ctc','Current pay').$field('expected_salary','Expected pay').$field('expected_salary_currency','Pay currency').$field('notice_period','Notice period').$field('work_authorization','Work authorization').$field('willing_to_relocate','Willing to relocate').$field('shift_preference','Shift preference').$field('work_preference','Work preference');
        $o .= '</div></fieldset>';
        $o .= '<fieldset class="profile-block"><legend>Placement</legend><div class="fgrid">';
        $o .= $field('preferred_role','Preferred role').$field('preferred_location','Preferred location').$field('availability','Availability').$field('key_projects','Key projects');
        $o .= '</div></fieldset>';
        $o .= '</div>';
        $o .= '<label class="profile-summary">Professional Summary<textarea name="professional_summary" rows="3" placeholder="A short note on your background and target role.">'.esc_textarea($g('professional_summary')).'</textarea></label>';
        $miss = $portal->pack_missing($row, $uid);
        if ($miss) $o .= '<p class="hint">Still needed: '.$portal->e(implode(', ', array_slice($miss, 0, 8))).(count($miss)>8?'…':'').'.</p>';
        $o .= '<div class="profile-actions"><button class="btn primary" type="submit">Save Profile</button></div></form></section>';
        if ($portal->role()==='student' && (int)$uid === get_current_user_id()) $o .= UC_LMS_Module_Support::training_form($portal);
        $o .= '<section class="panel profile-desk"><div class="ph"><div><span class="eyebrow">Documents</span><h3>'.count($docs).' On File</h3></div></div>';
        $ask = get_user_meta($uid, 'uc_doc_ask', true);
        if (is_array($ask) && !empty($ask['label'])) $o .= '<p class="hint">Placement Desk asked for '.$portal->e($ask['label']).($ask['note'] ? ': '.$portal->e($ask['note']) : '').'.</p>';
        if (!$docs) $o .= '<p class="muted">Add Resume, Government ID, Degree or Marksheet, and a Cybersecurity Certificate.</p>';
        foreach ($docs as $d) $o .= '<div class="req"><div><strong>'.$portal->e($d->document_type).'</strong><small>'.$portal->e($d->file_name).' · '.$portal->e($d->status).'</small></div></div>';
        $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form profile-form" enctype="multipart/form-data" style="margin-top:12px"><input type="hidden" name="action" value="uc_portal_document_upload">'.wp_nonce_field('uc_portal_document_upload','_wpnonce',true,false).'<input type="hidden" name="user_id" value="'.$uid.'">';
        $o .= '<div class="fgrid profile-docs"><label>Document<select name="document_type" required><option value="resume">Resume / CV</option><option value="id_proof">Government ID</option><option value="degree">Degree / Marksheet</option><option value="certificate">Cybersecurity Certificate</option></select></label><label>File'.$portal->file_control('file','.pdf,.png,.jpg,.jpeg,.docx').'</label></div>';
        $o .= '<div class="profile-actions"><button class="btn primary">Add Document</button></div></form>';
        return $o.'</section>';
    }
}
