<?php
/**
 * UniCybers Academy LMS: Intelligence Data Pack & Student Engagement Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Intelligence_Pack {

    public static function scheduled_seconds($session) {
        $start = strtotime($session->session_date.' '.$session->start_time);
        $end = !empty($session->end_time) ? strtotime($session->session_date.' '.$session->end_time) : $start + 7200;
        if ($end <= $start) $end = $start + 7200;
        return max(1, $end - $start);
    }

    public static function mark_view($sid, $uid) {
        if (!$sid || !$uid) return;
        global $wpdb;
        $t_views = self::t('intel_views');
        $wpdb->query($wpdb->prepare(
            "INSERT INTO {$t_views} (session_id,user_id,viewed_at) VALUES (%d,%d,%s)
             ON DUPLICATE KEY UPDATE viewed_at=VALUES(viewed_at)",
            $sid, $uid, current_time('mysql')
        ));
    }

    public static function clock($sec) {
        $sec = max(0, (int)$sec);
        $h = floor($sec / 3600);
        $m = floor(($sec % 3600) / 60);
        $s = $sec % 60;
        if ($h) return sprintf('%d:%02d:%02d', $h, $m, $s);
        return sprintf('%d:%02d', $m, $s);
    }

    public static function state_label($st) {
        $st = strtolower((string)$st);
        if ($st === 'available') return ['ok', 'Available'];
        if ($st === 'processing') return ['warn', 'Processing'];
        if ($st === 'failed') return ['live', 'Failed'];
        return ['mut', 'Not available'];
    }

    public static function status($sid) {
        global $wpdb;
        if (!self::has('intel_status')) {
            return (object) [
                'recording_state' => 'unavailable',
                'transcript_state' => 'unavailable',
                'summary_state' => 'unavailable',
                'attendance_state' => 'unavailable',
                'participants_state' => 'unavailable',
                'tasks_state' => 'unavailable',
                'polls_state' => 'unavailable',
                'chapters_state' => 'unavailable',
            ];
        }
        $t_status = self::t('intel_status');
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t_status} WHERE session_id=%d", $sid));
        return $row ?: (object) [
            'recording_state' => 'unavailable',
            'transcript_state' => 'unavailable',
            'summary_state' => 'unavailable',
            'attendance_state' => 'unavailable',
            'participants_state' => 'unavailable',
            'tasks_state' => 'unavailable',
            'polls_state' => 'unavailable',
            'chapters_state' => 'unavailable',
        ];
    }

    public static function pack($session, $staff, $uid) {
        global $wpdb;
        $sid = (int)$session->id;
        $st = self::status($sid);
        $t_sum = self::t('intel_summaries');
        $t_cues = self::t('intel_cues');
        $t_tasks = self::t('intel_tasks');
        $t_polls = self::t('intel_polls');
        $t_parts = self::t('intel_participants');
        $sum = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t_sum} WHERE session_id=%d", $sid));
        $cues = self::has('intel_cues') ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t_cues} WHERE session_id=%d ORDER BY t_seconds,id", $sid)) : [];
        $tasks = self::has('intel_tasks') ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t_tasks} WHERE session_id=%d ORDER BY id", $sid)) : [];
        $polls = self::has('intel_polls') ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t_polls} WHERE session_id=%d ORDER BY id", $sid)) : [];
        $parts = self::has('intel_participants') ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t_parts} WHERE session_id=%d ORDER BY display_name", $sid)) : [];
        $mine = null;
        foreach ($parts as $p) {
            if ((int)$p->user_id === (int)$uid) { $mine = $p; break; }
        }
        if (!$staff) {
            $tasks = array_values(array_filter($tasks, function ($t) { return $t->status === 'published'; }));
            $polls = array_values(array_filter($polls, function ($p) { return (int)$p->published === 1; }));
            $parts = array_map(function ($p) {
                $row = clone $p;
                $row->email = '';
                $row->user_email = '';
                return $row;
            }, $parts);
            if ($sum && !(int)$sum->published) $sum = null;
        }
        $topics = $sum && $sum->topics ? json_decode($sum->topics, true) : [];
        $steps = $sum && $sum->next_steps ? json_decode($sum->next_steps, true) : [];
        $chapters = array_values(array_filter($cues, function ($c) { return $c->kind === 'chapter'; }));
        $transcript = array_values(array_filter($cues, function ($c) { return $c->kind === 'transcript'; }));
        $sched = self::scheduled_seconds($session);
        $present = $partial = $absent = 0; $avg = 0; $n = 0;
        $all_parts = self::has('intel_participants') ? $wpdb->get_results($wpdb->prepare("SELECT attendance_status,duration_seconds FROM {$t_parts} WHERE session_id=%d", $sid)) : [];
        foreach ($all_parts as $p) {
            $n++;
            $avg += (int)$p->duration_seconds;
            if ($p->attendance_status === 'present') $present++;
            elseif ($p->attendance_status === 'partial') $partial++;
            else $absent++;
        }
        return [
            'status' => $st,
            'summary' => $sum,
            'topics' => is_array($topics) ? $topics : [],
            'steps' => is_array($steps) ? $steps : [],
            'chapters' => $chapters,
            'transcript' => $transcript,
            'tasks' => $tasks,
            'polls' => $polls,
            'participants' => $parts,
            'mine' => $mine,
            'sched' => $sched,
            'stats' => [
                'total' => $n,
                'present' => $present,
                'partial' => $partial,
                'absent' => $absent,
                'avg_min' => $n ? round($avg / $n / 60) : 0,
            ],
        ];
    }

    public static function t($n) {
        global $wpdb;
        return $wpdb->prefix.'uc_'.$n;
    }

    public static function has($n) {
        global $wpdb;
        static $c = [];
        if (!isset($c[$n])) $c[$n] = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', self::t($n))) === self::t($n));
        return $c[$n];
    }
}
