<?php
/**
 * UniCybers Academy LMS: Microsoft Teams Provider.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Meeting_Teams {

    private static function graph_token() {
        $tenant = trim((string)get_option('uc_ms_tenant', ''));
        $client = trim((string)get_option('uc_ms_client_id', ''));
        $secret = trim((string)get_option('uc_ms_client_secret', ''));
        if (!$tenant || !$client || !$secret) return new WP_Error('teams_config', 'Save the Microsoft Teams tenant, application ID and secret in LMS Settings.');
        $response = wp_remote_post('https://login.microsoftonline.com/'.rawurlencode($tenant).'/oauth2/v2.0/token', ['timeout'=>20, 'body'=>[
            'client_id'=>$client, 'client_secret'=>$secret, 'scope'=>'https://graph.microsoft.com/.default', 'grant_type'=>'client_credentials'
        ]]);
        if (is_wp_error($response)) return $response;
        $auth = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($auth['access_token'])) return new WP_Error('teams_token', (string)($auth['error_description'] ?? 'Microsoft 365 did not issue an access token.'));
        return (string)$auth['access_token'];
    }

    private static function date_times($date, $start, $end, $tz) {
        $tz = $tz ?: 'Asia/Kolkata';
        try { $zone = new DateTimeZone($tz); } catch (Exception $e) { $zone = new DateTimeZone('Asia/Kolkata'); $tz = 'Asia/Kolkata'; }
        $start_dt = DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$start, 0, 5), $zone);
        if (!$start_dt) return new WP_Error('teams_date', 'Class date or start time is invalid.');
        $end_dt = $end ? DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$end, 0, 5), $zone) : false;
        if (!$end_dt || $end_dt <= $start_dt) { $end_dt = clone $start_dt; $end_dt->modify('+90 minutes'); }
        return ['start'=>$start_dt, 'end'=>$end_dt, 'timezone'=>$tz];
    }

    public static function teams_create_meeting($title, $date, $start, $end, $tz) {
        $user = trim((string)get_option('uc_ms_user', ''));
        if (!$user) return new WP_Error('teams_config', 'Add the Teams meeting organizer user in LMS Settings.');
        $token = self::graph_token();
        if (is_wp_error($token)) return $token;
        $dt = self::date_times($date, $start, $end, $tz);
        if (is_wp_error($dt)) return $dt;
        // Calendar-backed online meetings are required for the Microsoft Graph recording API.
        $payload = [
            'subject'=>'UniCybers: '.$title,
            'body'=>['contentType'=>'text','content'=>'Scheduled through UniCybers Academy LMS.'],
            'start'=>['dateTime'=>$dt['start']->format('Y-m-d\\TH:i:s'),'timeZone'=>$dt['timezone']],
            'end'=>['dateTime'=>$dt['end']->format('Y-m-d\\TH:i:s'),'timeZone'=>$dt['timezone']],
            'isOnlineMeeting'=>true,
            'onlineMeetingProvider'=>'teamsForBusiness',
        ];
        $url = 'https://graph.microsoft.com/v1.0/users/'.rawurlencode($user).'/events';
        $response = wp_remote_post($url, ['timeout'=>30,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode($payload)]);
        if (is_wp_error($response)) return $response;
        $code = (int)wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        $join = (string)($data['onlineMeeting']['joinUrl'] ?? $data['onlineMeetingUrl'] ?? '');
        if ($code < 200 || $code >= 300 || !$join) {
            $message = (string)($data['error']['message'] ?? 'Microsoft 365 did not create a Teams calendar meeting.');
            return new WP_Error('teams_create', $message.' (HTTP '.$code.'). Check Calendars.ReadWrite admin consent and Teams meeting policy.');
        }
        $meeting_id = '';
        for ($attempt = 0; $attempt < 3 && $meeting_id === ''; $attempt++) {
            if ($attempt) sleep(1);
            $meeting_id = self::lookup_online_meeting_id($token, $user, $join);
        }
        return [
            'join_url'=>esc_url_raw($join),
            'calendar_event_id'=>sanitize_text_field((string)($data['id'] ?? '')),
            'provider_meeting_id'=>$meeting_id,
            'provider_data'=>['provider'=>'teams','organizer'=>$user],
        ];
    }

    private static function lookup_online_meeting_id($token, $user, $join_url) {
        $filter = "JoinWebUrl eq '".str_replace("'", "''", $join_url)."'";
        $url = 'https://graph.microsoft.com/v1.0/users/'.rawurlencode($user).'/onlineMeetings?'.http_build_query(['$filter'=>$filter], '', '&', PHP_QUERY_RFC3986);
        $response = wp_remote_get($url, ['timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$token,'Accept'=>'application/json']]);
        if (is_wp_error($response) || (int)wp_remote_retrieve_response_code($response) >= 300) return '';
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return sanitize_text_field((string)($data['value'][0]['id'] ?? ''));
    }

    public static function teams_update_meeting($event_id, $join_url, $title, $date, $start, $end, $tz) {
        $user = trim((string)get_option('uc_ms_user',''));
        if (!$user || !$event_id) return new WP_Error('teams_config', 'Teams organizer or calendar event ID is missing.');
        $token = self::graph_token();
        if (is_wp_error($token)) return $token;
        $dt = self::date_times($date, $start, $end, $tz);
        if (is_wp_error($dt)) return $dt;
        $url = 'https://graph.microsoft.com/v1.0/users/'.rawurlencode($user).'/events/'.rawurlencode($event_id);
        $body = [
            'subject'=>'UniCybers: '.$title,
            'start'=>['dateTime'=>$dt['start']->format('Y-m-d\\TH:i:s'),'timeZone'=>$dt['timezone']],
            'end'=>['dateTime'=>$dt['end']->format('Y-m-d\\TH:i:s'),'timeZone'=>$dt['timezone']],
        ];
        $response = wp_remote_request($url, ['method'=>'PATCH','timeout'=>25,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode($body)]);
        if (is_wp_error($response)) return $response;
        $code = (int)wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) return new WP_Error('teams_update', 'Microsoft Graph could not update the Teams calendar event (HTTP '.$code.').');
        return ['join_url'=>$join_url,'calendar_event_id'=>$event_id,'provider_data'=>['provider'=>'teams','organizer'=>$user]];
    }

    private static function recording_content_url($token, $user, $meeting_id) {
        $url = 'https://graph.microsoft.com/v1.0/users/'.rawurlencode($user).'/onlineMeetings/'.rawurlencode($meeting_id).'/recordings';
        $response = wp_remote_get($url, ['timeout'=>25,'headers'=>['Authorization'=>'Bearer '.$token,'Accept'=>'application/json']]);
        if (is_wp_error($response)) return $response;
        $code = (int)wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) return new WP_Error('teams_recording', (string)($data['error']['message'] ?? 'Microsoft Graph could not retrieve this meeting recording.').' (HTTP '.$code.')');
        foreach ((array)($data['value'] ?? []) as $recording) {
            if (!empty($recording['recordingContentUrl'])) return [
                'url'=>(string)$recording['recordingContentUrl'],
                'created'=>(string)($recording['createdDateTime'] ?? ''),
                'id'=>(string)($recording['id'] ?? ''),
            ];
        }
        return new WP_Error('teams_recording_pending', 'The Teams recording is not available yet.');
    }

    /**
     * Stream a Teams cloud recording through an authenticated, range-aware proxy.
     * The video remains in Microsoft 365; the LMS does not create a second copy.
     */
    public static function stream_recording($session) {
        if (empty($session->provider_meeting_id) || !function_exists('curl_init')) {
            status_header(404); header('Content-Type: text/plain; charset=utf-8'); echo 'Teams recording is not available.'; exit;
        }
        $user = trim((string)get_option('uc_ms_user',''));
        $token = self::graph_token();
        if (!$user || is_wp_error($token)) {
            status_header(503); header('Content-Type: text/plain; charset=utf-8'); echo 'Teams recording connection needs attention.'; exit;
        }
        $recording = self::recording_content_url($token, $user, (string)$session->provider_meeting_id);
        if (is_wp_error($recording)) {
            status_header(404); header('Content-Type: text/plain; charset=utf-8'); echo esc_html($recording->get_error_message()); exit;
        }
        @set_time_limit(0);
        if (function_exists('ignore_user_abort')) ignore_user_abort(true);
        while (ob_get_level() > 0) @ob_end_clean();
        $headers = ['Authorization: Bearer '.$token, 'Accept: video/mp4'];
        $range = isset($_SERVER['HTTP_RANGE']) ? trim((string)$_SERVER['HTTP_RANGE']) : '';
        if ($range !== '' && preg_match('/^bytes=\d*-\d*$/', $range)) $headers[] = 'Range: '.$range;
        $meta = ['code'=>200,'type'=>'video/mp4','length'=>'','range'=>'','started'=>false,'invalid'=>false];
        $ch = curl_init((string)$recording['url']);
        curl_setopt_array($ch, [
            CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_UNRESTRICTED_AUTH=>false,
            CURLOPT_MAXREDIRS=>5,
            CURLOPT_CONNECTTIMEOUT=>20,
            CURLOPT_TIMEOUT=>0,
            CURLOPT_HTTPHEADER=>$headers,
            CURLOPT_HEADERFUNCTION=>function($curl,$line) use (&$meta) {
                $trim=trim($line);
                if (preg_match('#^HTTP/\S+\s+(\d+)#',$trim,$m)) {
                    $meta['code']=(int)$m[1]; $meta['type']='video/mp4'; $meta['length']=''; $meta['range']=''; $meta['started']=false; $meta['invalid']=false;
                }
                $p=strpos($line,':');
                if ($p!==false) {
                    $key=strtolower(trim(substr($line,0,$p))); $value=trim(substr($line,$p+1));
                    if ($key==='content-type') $meta['type']=$value;
                    if ($key==='content-length') $meta['length']=$value;
                    if ($key==='content-range') $meta['range']=$value;
                }
                if ($trim==='' && !$meta['started']) {
                    if ($meta['code']>=300 && $meta['code']<400) return strlen($line);
                    $meta['started']=true;
                    $type=strtolower($meta['type']);
                    $meta['invalid']=($meta['code']>=400 || strpos($type,'text/html')!==false || strpos($type,'json')!==false);
                    if (!$meta['invalid'] && !headers_sent()) {
                        http_response_code($meta['code']===206?206:200);
                        header('Content-Type: '.(strpos($type,'video/')===0?$meta['type']:'video/mp4'));
                        header('Content-Disposition: inline; filename="unicybers-teams-recording.mp4"');
                        header('X-Content-Type-Options: nosniff');
                        header('Cache-Control: private, no-store, no-cache, must-revalidate');
                        header('Accept-Ranges: bytes');
                        if ($meta['length']!=='') header('Content-Length: '.$meta['length']);
                        if ($meta['range']!=='') header('Content-Range: '.$meta['range']);
                    }
                }
                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION=>function($curl,$chunk) use (&$meta) {
                if ($meta['invalid']) return 0;
                echo $chunk;
                if (function_exists('flush')) flush();
                return strlen($chunk);
            },
        ]);
        $ok=curl_exec($ch);
        $error=curl_error($ch);
        $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($ok===false || $meta['invalid'] || $code>=400) {
            if (!headers_sent()) { status_header($code>=400?$code:502); header('Content-Type: text/plain; charset=utf-8'); }
            if (!headers_sent()) echo 'Unable to stream this Teams recording. '.sanitize_text_field($error);
        }
        exit;
    }

    public static function sync_recordings() {
        global $wpdb;
        if (get_transient('uc_lms_teams_recording_lock')) return 0;
        $user = trim((string)get_option('uc_ms_user',''));
        if (!$user) return 0;
        $token = self::graph_token();
        if (is_wp_error($token)) return $token;
        set_transient('uc_lms_teams_recording_lock',1,4*MINUTE_IN_SECONDS);
        $table = UC_LMS_Database::table('sessions');
        $rows = $wpdb->get_results("SELECT id,provider_meeting_id,calendar_event_id,join_url,recording_status,recording_url FROM {$table} WHERE platform='teams' AND session_date>=DATE_SUB(CURDATE(),INTERVAL 60 DAY) AND session_date<=CURDATE() ORDER BY session_date DESC LIMIT 60");
        $found = 0;
        foreach ((array)$rows as $row) {
            if ($row->recording_url || strtolower((string)$row->recording_status)==='available') continue;
            $meeting_id = (string)$row->provider_meeting_id;
            if ($meeting_id === '' && !empty($row->join_url)) {
                $meeting_id = self::lookup_online_meeting_id($token, $user, (string)$row->join_url);
                if ($meeting_id !== '') $wpdb->update($table, ['provider_meeting_id'=>$meeting_id], ['id'=>(int)$row->id]);
            }
            if ($meeting_id === '') continue;
            $recording = self::recording_content_url($token, $user, $meeting_id);
            if (is_wp_error($recording)) continue;
            $wpdb->update($table, [
                'recording_status'=>'available',
                'recording_notes'=>'Teams cloud recording is available. Playback is streamed from Microsoft 365 through the authenticated LMS viewer.',
                'recording_at'=>$recording['created'] ? gmdate('Y-m-d H:i:s', strtotime($recording['created'])) : current_time('mysql'),
            ], ['id'=>(int)$row->id]);
            $found++;
        }
        delete_transient('uc_lms_teams_recording_lock');
        return $found;
    }

    public static function keep_ms_secret($value){
            $value = is_string($value) ? trim($value) : '';
            return $value !== '' ? $value : (string)get_option('uc_ms_client_secret', '');
        }
}
