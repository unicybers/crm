<?php
/**
 * UniCybers Academy LMS: Recordings & Media Sync Handlers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Handler_Media {

    public static function drive_materials_sync($portal){
        $portal->guard('uc_portal_drive_materials_sync',['super_admin','coordinator']);
        if (!class_exists('UC_LMS_Drive_Materials')) {
            $portal->set_flash('Google Drive materials module is not available.','warn');
            $portal->back('materials');
        }
        $result = UC_LMS_Drive_Materials::sync();
        if (is_wp_error($result)) {
            $portal->set_flash('Google Drive sync failed: '.$result->get_error_message(),'warn');
        } else {
            $message = (int)$result['created'].' added, '.(int)$result['updated'].' updated, '.(int)$result['skipped'].' unchanged.';
            if (!empty($result['unmapped'])) $message .= ' '.$result['unmapped'].' batch folder(s) did not match an LMS batch name. Check that Drive folder names exactly match LMS batch names.';
            if (!empty($result['protected'])) $message .= ' Google download, print and copy restrictions applied to '.$result['protected'].' file(s).';
            if (!empty($result['protection_unavailable'])) $message .= ' Restrictions could not be applied to '.$result['protection_unavailable'].' file(s) because the connected account cannot change their Drive restriction.';
            if (!empty($result['errors'])) $message .= ' First issue: '.$result['errors'][0];
            $portal->set_flash('Google Drive sync completed. '.$message, !empty($result['errors']) ? 'warn' : 'ok');
        }
        $portal->back('materials');
    }

    public static function sync_recordings($portal){
        $portal->guard('uc_portal_sync_recordings',['super_admin','coordinator']);
        if (function_exists('set_time_limit')) @set_time_limit(0);
        $s = class_exists('UC_Academy_LMS') ? UC_Academy_LMS::instance()->portal_sync_recordings_now() : ['pulled'=>0,'linked'=>0,'processing'=>0,'missed'=>0,'intel'=>0,'errors'=>[]];
        $bits = [];
        if (!empty($s['pulled'])) $bits[] = (int)$s['pulled'].' playable file'.(((int)$s['pulled']===1)?'':'s').' on the academy';
        if (!empty($s['linked'])) $bits[] = (int)$s['linked'].' found at Zoom (file still copying)';
        if (!empty($s['processing'])) $bits[] = (int)$s['processing'].' still processing at Zoom';
        if (!empty($s['missed'])) $bits[] = (int)$s['missed'].' ended class'.(((int)$s['missed']===1)?'':'es').' with no Zoom file yet';
        if (!empty($s['intel'])) $bits[] = (int)$s['intel'].' class room'.(((int)$s['intel']===1)?'':'s').' checked for summary, tasks, polls and attendance';
        $msg = $bits ? 'Sync finished: '.implode(', ', $bits).'.' : 'Sync finished. No ended class in the last 14 days needed a Zoom file.';
        $msg .= ' Existing recordings, materials and classes stay in the portal.';
        if (!empty($s['errors'])) $msg .= ' '.$s['errors'][0];
        $meet_count = class_exists('UC_LMS_Meeting') ? UC_LMS_Meeting::instance()->portal_sync_meet_folder() : 0;
        $zoho_count = get_option('uc_zoho_refresh_token') && class_exists('UC_LMS_Meeting_Zoho') ? UC_LMS_Meeting_Zoho::sync_recordings() : 0;
        $teams_count = get_option('uc_ms_client_id') && class_exists('UC_LMS_Meeting_Teams') ? UC_LMS_Meeting_Teams::sync_recordings() : 0;
        if (is_numeric($meet_count) && $meet_count > 0) $msg .= ' '.$meet_count.' Google Meet recording(s) linked.';
        if (is_numeric($zoho_count) && $zoho_count > 0) $msg .= ' '.$zoho_count.' Zoho recording(s) linked.';
        if (is_numeric($teams_count) && $teams_count > 0) $msg .= ' '.$teams_count.' Teams recording(s) detected. Add a OneDrive or SharePoint viewer link to publish playback.';
        $portal->set_flash($msg, (!empty($s['pulled']) || !empty($s['linked']) || (is_numeric($meet_count) && $meet_count > 0) || (is_numeric($zoho_count) && $zoho_count > 0) || (is_numeric($teams_count) && $teams_count > 0)) ? 'ok' : 'warn');
        $portal->back('materials');
    }

    public static function recording_pull($portal){
        $portal->guard('uc_portal_recording_pull',['super_admin','coordinator','trainer']);
        $id = absint($_POST['session_id'] ?? 0);
        global $wpdb;
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d AND hidden=0", $id));
        if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) {
            $portal->set_flash('That class is not in your batches.','warn');
            $portal->back('materials');
        }
        if (!class_exists('UC_Academy_LMS')) {
            $portal->set_flash('The academy plugin is not loaded.','warn');
            $portal->back('materials');
        }
        if (function_exists('set_time_limit')) @set_time_limit(0);
        $path = UC_Academy_LMS::instance()->portal_pull_recording($s);
        $fresh = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d", $id));
        if ($fresh) do_action('uc_lms_session_recording_synced', $fresh);
        if (is_wp_error($path)) $portal->set_flash($path->get_error_message(),'warn');
        elseif ($path) $portal->set_flash('Recording file is on the academy. Press play.');
        else $portal->set_flash('Zoom did not return a video file. Enable Cloud Recording scopes, then Pull from Zoom again. Drive embed is the fallback.','warn');
        wp_safe_redirect(home_url('/lms-view/recording/'.$id.'/'));
        exit;
    }

    public static function recording_upload($portal){
        $portal->guard('uc_portal_recording_upload',['super_admin','coordinator','trainer']);
        $id = absint($_POST['session_id'] ?? 0);
        global $wpdb;
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d AND hidden=0", $id));
        if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) {
            $portal->set_flash('That class is not in your batches.','warn');
            $portal->back('materials');
        }
        if (!class_exists('UC_Academy_LMS')) {
            $portal->set_flash('The academy plugin is not loaded.','warn');
            $portal->back('materials');
        }
        if (function_exists('set_time_limit')) @set_time_limit(0);
        $path = UC_Academy_LMS::instance()->portal_store_uploaded_recording($s, $_FILES['file'] ?? []);
        if (is_wp_error($path)) $portal->set_flash($path->get_error_message(),'warn');
        else $portal->set_flash('Recording file is on the academy. Press play.');
        wp_safe_redirect(home_url('/lms-view/recording/'.$id.'/'));
        exit;
    }

    public static function recording_link($portal){
        $portal->guard('uc_portal_recording_link',['super_admin','coordinator','trainer']);
        $id = absint($_POST['session_id'] ?? 0);
        global $wpdb;
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d AND hidden=0", $id));
        if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) {
            $portal->set_flash('That class is not in your batches.','warn');
            $portal->back('materials');
        }
        $raw = trim((string)wp_unslash($_POST['recording_url'] ?? ''));
        $url = $raw === '' ? '' : esc_url_raw($raw);
        if ($raw !== '' && !$url) $url = esc_url_raw('https://'.$raw);
        if ($url === '' || stripos($url, 'zoom.us') !== false) {
            $portal->set_flash('Paste a Google Drive file link, not a Zoom recording URL. Share the file as Anyone with the link (Viewer).','warn');
            wp_safe_redirect(home_url('/lms-view/recording/'.$id.'/'));
            exit;
        }
        if ($portal->embed($url) === '') {
            $portal->set_flash('That link cannot play here. Use a Google Drive file link (not a folder) shared as Anyone with the link (Viewer).','warn');
            wp_safe_redirect(home_url('/lms-view/recording/'.$id.'/'));
            exit;
        }
        $ok = $portal->update_row('sessions', [
            'recording_url' => $url,
            'recording_status' => 'available',
            'recording_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ], ['id'=>$id]);
        if ($ok === false) $portal->db_fail('materials');
        $portal->log_audit('class',$id,'recording','Drive recording linked');
        $portal->set_flash('Drive recording is on the class. Students press Watch.');
        wp_safe_redirect(home_url('/lms-view/recording/'.$id.'/'));
        exit;
    }

    public static function recording_hide($portal){
        $portal->guard('uc_portal_recording_hide',['super_admin','coordinator']);
        $id = absint($_POST['session_id'] ?? 0);
        global $wpdb;
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d AND hidden=0", $id));
        if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) {
            $portal->set_flash('That class is not in your batches.','warn');
            $portal->back('materials');
        }
        if (class_exists('UC_Academy_LMS')) UC_Academy_LMS::instance()->portal_discard_recording($s);
        else $wpdb->update($portal->t('sessions'), ['recording_url'=>null,'recording_status'=>'discarded','recording_duration'=>0,'updated_at'=>current_time('mysql')], ['id'=>$id]);
        $portal->set_flash('Recording removed from the library. The class is still on Classes.');
        $portal->back('materials');
    }

    public static function recording_hide_short($portal){
        $portal->guard('uc_portal_recording_hide_short',['super_admin','coordinator']);
        global $wpdb;
        $ids = $portal->batch_ids();
        if (!$ids) { $portal->set_flash('No batches.','warn'); $portal->back('materials'); }
        $rows = $wpdb->get_results("SELECT * FROM {$portal->t('sessions')} WHERE batch_id IN (".$portal->in_ids($ids).") AND hidden=0 AND LOWER(IFNULL(recording_status,''))<>'discarded' AND IFNULL(recording_duration,0)>0 AND recording_duration<1200");
        $n = 0;
        foreach ((array)$rows as $s) {
            if (class_exists('UC_Academy_LMS')) UC_Academy_LMS::instance()->portal_discard_recording($s);
            else $wpdb->update($portal->t('sessions'), ['recording_url'=>null,'recording_status'=>'discarded','recording_duration'=>0,'updated_at'=>current_time('mysql')], ['id'=>$s->id]);
            $n++;
        }
        $portal->set_flash($n ? $n.' short recording'.($n===1?'':'s').' hidden from the library.' : 'No recordings under 20 minutes to hide.');
        $portal->back('materials');
    }

    public static function recording_details($portal){
        $portal->guard('uc_portal_recording_details',['super_admin','coordinator','trainer']);
        $id = absint($_POST['id'] ?? $_POST['session_id'] ?? 0);
        global $wpdb;
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('sessions')} WHERE id=%d AND hidden=0", $id));
        if (!$s || !in_array((int)$s->batch_id, $portal->batch_ids(), true)) {
            $portal->set_flash('That class is not in your batches.','warn');
            $portal->back('materials');
        }
        $label = sanitize_text_field(wp_unslash($_POST['recording_label'] ?? ''));
        $notes = sanitize_textarea_field(wp_unslash($_POST['recording_notes'] ?? ''));
        $ok = $wpdb->update($portal->t('sessions'), [
            'recording_label' => $label !== '' ? $label : null,
            'recording_notes' => $notes !== '' ? $notes : null,
            'updated_at' => current_time('mysql'),
        ], ['id'=>$id]);
        if ($ok === false) {
            if (class_exists('UC_Academy_LMS')) UC_Academy_LMS::instance()->maybe_upgrade();
            $ok = $wpdb->update($portal->t('sessions'), [
                'recording_label' => $label !== '' ? $label : null,
                'recording_notes' => $notes !== '' ? $notes : null,
                'updated_at' => current_time('mysql'),
            ], ['id'=>$id]);
        }
        if ($ok === false) $portal->db_fail('classes');
        $portal->set_flash('Recording details saved. The Zoom name is unchanged.');
        $back = sanitize_key($_POST['back'] ?? 'materials');
        if ($back === 'classroom') {
            wp_safe_redirect(home_url('/lms-class/'.$id.'/'));
            exit;
        }
        $portal->back('materials');
    }
}
