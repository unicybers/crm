<?php
/**
 * UniCybers Academy LMS: Portal Login Lifecycle Coordinator & Facade.
 */
if (!defined('ABSPATH')) exit;

if (!class_exists('UC_LMS_Login')) {
final class UC_LMS_Login {
    const LOGIN_PAGE_SLUG = 'login';
    const LOGIN_PAGE_TITLE = 'UniCybers LMS Login';

    public static function instance() {
        static $instance = null;
        if (null === $instance) {
            $instance = new self();
        }
        return $instance;
    }

    public static function init() {
        $inst = self::instance();
        add_action('init', [$inst, 'handle_front_login'], 1);
        add_action('admin_post_nopriv_uc_lms_login', [$inst, 'handle_front_login']);
        add_action('admin_post_uc_lms_login', [$inst, 'handle_front_login']);
        add_action('login_init', [$inst, 'protect_wp_login_entry']);
        add_action('admin_init', [$inst, 'restrict_frontend_roles']);
        add_action('wp_enqueue_scripts', [$inst, 'frontend_assets']);
        add_action('login_enqueue_scripts', [$inst, 'login_page_styles']);
        add_filter('show_admin_bar', [$inst, 'hide_front_admin_bar']);
        add_filter('login_redirect', [$inst, 'login_redirect'], 10, 3);
        add_filter('body_class', [$inst, 'login_body_class']);
        add_action('template_redirect', [$inst, 'serve_standalone_login'], 0);
        add_action('template_redirect', [$inst, 'serve_shortcode_login_standalone'], 0);
        add_action('init', [$inst, 'frontend_bootstrap'], 99);
        add_shortcode('unicybers_login', [$inst, 'login_page_shortcode']);
        add_shortcode('uc_student_dashboard', [$inst, 'student_dashboard']);
        add_shortcode('uc_trainer_dashboard', [$inst, 'trainer_dashboard']);
        add_shortcode('uc_course_catalog', [$inst, 'course_catalog']);
    }

    public function table($name) {
        global $wpdb;
        return $wpdb->prefix . 'uc_' . $name;
    }

    public function table_exists($name) {
        global $wpdb;
        $table_name = $this->table($name);
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_name)) === $table_name;
    }

    public function hide_front_admin_bar($show) {
        if (!is_user_logged_in()) return false;
        $user = wp_get_current_user();
        if (in_array('uc_student', (array)$user->roles, true) || in_array('uc_trainer', (array)$user->roles, true) || in_array('uc_coordinator', (array)$user->roles, true) || in_array('uc_hr', (array)$user->roles, true)) {
            return false;
        }
        return $show;
    }

    public function ensure_login_page() {
        $slug = self::LOGIN_PAGE_SLUG;
        $cached_id = (int) get_option('uc_lms_login_page_id', 0);
        if ($cached_id > 0) {
            $cached = get_post($cached_id);
            if ($cached && $cached->post_type === 'page' && $cached->post_status === 'publish' && $cached->post_name === $slug) {
                return $cached_id;
            }
        }
        $page = get_page_by_path($slug);
        if ($page && 'trash' !== $page->post_status) {
            update_option('uc_lms_login_page_id', (int) $page->ID, false);
            return (int) $page->ID;
        }
        $id = wp_insert_post([
            'post_title'     => self::LOGIN_PAGE_TITLE,
            'post_name'      => $slug,
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'post_content'   => '[unicybers_login]',
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
        ]);
        if ($id && !is_wp_error($id)) {
            update_option('uc_lms_login_page_id', (int) $id, false);
            return (int) $id;
        }
        return 0;
    }

    public function login_page_url() {
        $page_id = $this->ensure_login_page();
        if ($page_id > 0) {
            $permalink = get_permalink($page_id);
            if ($permalink) return $permalink;
        }
        $slug = self::LOGIN_PAGE_SLUG;
        $page = get_page_by_path($slug);
        if ($page && 'publish' === $page->post_status) {
            update_option('uc_lms_login_page_id', (int) $page->ID, false);
            return get_permalink($page->ID);
        }
        return home_url('/' . $slug . '/');
    }

    public function login_body_class($classes) {
        if ($this->is_standalone_login_request()) {
            $classes[] = 'uc-login-standalone';
        }
        return $classes;
    }

    public function frontend_bootstrap() {
        if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) return;
        $cached_id = (int) get_option('uc_lms_login_page_id', 0);
        $cached = $cached_id > 0 ? get_post($cached_id) : null;
        if (!$cached || $cached->post_status !== 'publish' || $cached->post_name !== self::LOGIN_PAGE_SLUG) {
            $this->ensure_login_page();
        }
    }

    public static function is_standalone_login_request() {
        if (is_admin()) return false;
        $request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        $path = trim((string) wp_parse_url($request_uri, PHP_URL_PATH), '/');
        if ('' === $path) return false;
        foreach (['login', 'student-login', 'lms-login'] as $slug) {
            if ($path === $slug || 0 === strpos($path, $slug . '/')) return true;
        }
        return false;
    }

    // Delegations to Assets
    public function standalone_login_css($scene = '') { return UC_LMS_Login_Assets::standalone_login_css($scene); }
    public function login_css_payload() { return UC_LMS_Login_Assets::login_css_payload(); }
    public function login_page_styles() { UC_LMS_Login_Assets::login_page_styles(); }
    public function frontend_assets() { UC_LMS_Login_Assets::frontend_assets(); }

    // Delegations to Views
    public function standalone_login_document() { return UC_LMS_Login_View::standalone_login_document(); }
    public function site_icon_html() { return UC_LMS_Login_View::site_icon_html(); }
    public function access_help_html() { return UC_LMS_Login_View::access_help_html(); }
    public function login_error_message() { return UC_LMS_Login_View::login_error_message(); }
    public function login_page_shortcode() { return UC_LMS_Login_View::login_page_shortcode(); }
    public function serve_standalone_login() { UC_LMS_Login_View::serve_standalone_login(); }
    public function serve_shortcode_login_standalone() { UC_LMS_Login_View::serve_shortcode_login_standalone(); }

    // Delegations to Handlers
    public function handle_front_login() { UC_LMS_Login_Handler::handle_front_login(); }
    public function resolve_login_user($email) { return UC_LMS_Login_Handler::resolve_login_user($email); }
    public function login_redirect($redirect_to, $requested_redirect_to, $user) { return UC_LMS_Login_Handler::login_redirect($redirect_to, $requested_redirect_to, $user); }
    public function protect_wp_login_entry() { UC_LMS_Login_Handler::protect_wp_login_entry(); }
    public function restrict_frontend_roles() { UC_LMS_Login_Handler::restrict_frontend_roles(); }
    public function role_dashboard_url($user) { return UC_LMS_Login_Handler::role_dashboard_url($user); }

    // Dashboard shortcode fallbacks
    public function student_dashboard() {
        return class_exists('UC_LMS_Portal') ? do_shortcode('[uc_portal page="dashboard"]') : '';
    }
    public function trainer_dashboard() {
        return class_exists('UC_LMS_Portal') ? do_shortcode('[uc_portal page="dashboard"]') : '';
    }
    public function course_catalog() {
        return class_exists('UC_LMS_Portal') ? do_shortcode('[uc_portal page="courses"]') : '';
    }
}
}
