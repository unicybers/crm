<?php
/**
 * UniCybers Academy LMS Portal Helpers.
 *
 * Provides database utilities, date/time formatting, flash messaging,
 * security guards, and data transformers for the portal.
 */
if (!defined('ABSPATH')) exit;

class UC_LMS_Portal_Helpers {

    public static function forbid_cache() {
        return UC_LMS_Portal_Flash::forbid_cache();
    }

    public static function purge_portal_cache($portal) {
        return UC_LMS_Portal_Flash::purge_portal_cache($portal);
    }

    public static function flash($portal) {
        return UC_LMS_Portal_Flash::flash($portal);
    }

    public static function set_flash($portal, $msg,$type='ok',$secret='',$wa='') {
        return UC_LMS_Portal_Flash::set_flash($portal, $msg, $type, $secret, $wa);
    }

    public static function brand() {
        if (class_exists('UC_Academy_LMS')) return UC_Academy_LMS::instance()->brand_pack(get_current_user_id());
        return (object)['name'=>'UniCybers','legal_name'=>'UniCybers Academy','product_label'=>'ACADEMY','logo_url'=>'','accent'=>'#FF6B1A','accent2'=>'#FF8A3D'];
    }

    public static function hero_edge(){ return ''; }

    public static function wa_credentials_url($user, $password){
        $phone = preg_replace('/\D+/', '', (string)get_user_meta($user->ID, 'uc_phone', true));
        if (strlen($phone) === 10) $phone = '91'.$phone;
        if (strlen($phone) < 11) return '';
        $text = "UniCybers Academy LMS\nSign in: ".home_url('/login/')."\nEmail: ".$user->user_email;
        if ($password) $text .= "\nTemporary password: ".$password."\nChange this password the first time you sign in.";
        else $text .= "\nPlease activate your login. If you did not get the email from academy@unicybers.com, reply here and we will resend it.";
        return 'https://wa.me/'.$phone.'?text='.rawurlencode($text);
    }

    public static function issue_credentials($user, $note = ''){
        $pw = UC_LMS_Security::temp_password();
        wp_set_password($pw, $user->ID);
        update_user_meta($user->ID, 'uc_must_change', 1);
        $sent = UC_LMS_Security::send_credentials($user, $pw, $note);
        return [$pw, $sent, self::wa_credentials_url($user, $pw)];
    }

    public static function wants_ajax() {
        return UC_LMS_Portal_Flash::wants_ajax();
    }

    public static function back($portal, $page,$args=[]) {
        return UC_LMS_Portal_Flash::back($portal, $page, $args);
    }

    public static function column_meta($portal, $name){
        global $wpdb;
        static $cache = [];
        $t = $portal->t($name);
        if (!isset($cache[$t])) {
            $rows = $wpdb->get_results("SHOW COLUMNS FROM {$t}");
            $cache[$t] = is_array($rows) ? $rows : [];
        }
        return $cache[$t];
    }

    public static function filter_row($portal, $name, $data){
        $cols = [];
        foreach (self::column_meta($portal, $name) as $c) $cols[strtolower((string)$c->Field)] = true;
        $out = [];
        foreach ((array)$data as $k=>$v) {
            if (!empty($cols[strtolower((string)$k)])) $out[$k] = $v;
        }
        return $out;
    }

    public static function fill_required($portal, $name, $row){
        $have = [];
        foreach ($row as $k=>$v) $have[strtolower((string)$k)] = true;
        foreach (self::column_meta($portal, $name) as $c) {
            $f = (string)$c->Field;
            if (isset($have[strtolower($f)])) continue;
            if (stripos((string)$c->Extra, 'auto_increment') !== false) continue;
            if (strtoupper((string)$c->Null) === 'YES') continue;
            if ($c->Default !== null) continue;
            $type = strtolower((string)$c->Type);
            if (strpos($type, 'datetime') !== false || strpos($type, 'timestamp') !== false) $row[$f] = current_time('mysql');
            elseif (strpos($type, 'date') !== false) $row[$f] = current_time('Y-m-d');
            elseif (strpos($type, 'time') !== false) $row[$f] = '00:00:00';
            elseif (preg_match('/int|decimal|float|double|bit/', $type)) $row[$f] = 0;
            else $row[$f] = '';
        }
        return $row;
    }

    public static function insert_row($portal, $name, $data){
        global $wpdb;
        $row = self::fill_required($portal, $name, self::filter_row($portal, $name, $data));
        if (!$row) return false;
        return $wpdb->insert($portal->t($name), $row);
    }

    public static function update_row($portal, $name, $data, $where){
        global $wpdb;
        $row = self::filter_row($portal, $name, $data);
        if (!$row) return false;
        return $wpdb->update($portal->t($name), $row, $where);
    }

    public static function batch_ids($portal) {
        global $wpdb; static $ids = null; if ($ids !== null) return $ids;
        $uid = get_current_user_id(); $r = $portal->role();
        if ($r==='super_admin' || $r==='coordinator') $ids = array_map('intval', $wpdb->get_col("SELECT id FROM {$portal->t('batches')}"));
        elseif ($r==='trainer') $ids = array_map('intval', $wpdb->get_col($wpdb->prepare("SELECT id FROM {$portal->t('batches')} WHERE trainer_user_id=%d UNION SELECT DISTINCT batch_id FROM {$portal->t('sessions')} WHERE trainer_user_id=%d", $uid, $uid)));
        else $ids = array_map('intval', $wpdb->get_col($wpdb->prepare("SELECT batch_id FROM {$portal->t('enrolments')} WHERE user_id=%d AND status='active'", $uid)));
        return $ids;
    }

    public static function in_ids($ids){ $ids = array_filter(array_map('intval',$ids)); return $ids ? implode(',',$ids) : '0'; }

    public static function demo_sql($col='u.user_email'){ return "{$col} NOT REGEXP '^demo[0-9]{2}@unicybers\\\\.com$'"; }

    public static function academy_tz() {
        return UC_LMS_Portal_Dates::academy_tz();
    }

    public static function valid_tz($tz) {
        return UC_LMS_Portal_Dates::valid_tz($tz);
    }

    public static function session_tz($portal, $s) {
        return UC_LMS_Portal_Dates::session_tz($portal, $s);
    }

    public static function now_in_tz($tz='') {
        return UC_LMS_Portal_Dates::now_in_tz($tz);
    }

    public static function ts($date,$time,$tz='') {
        return UC_LMS_Portal_Dates::ts($date, $time, $tz);
    }

    public static function class_finished_sql($alias='s') {
        return UC_LMS_Portal_Dates::class_finished_sql($alias);
    }

    public static function ymd($raw) {
        return UC_LMS_Portal_Dates::ymd($raw);
    }

    public static function fdate($d,$f='D, j M') {
        return UC_LMS_Portal_Dates::fdate($d, $f);
    }

    public static function t12($t) {
        return UC_LMS_Portal_Dates::t12($t);
    }

    public static function initials($name){ $p=preg_split('/\s+/',trim((string)$name)); $o=strtoupper(substr($p[0]??'U',0,1)); if(count($p)>1)$o.=strtoupper(substr(end($p),0,1)); return $o; }

    public static function e($s){ return esc_html((string)$s); }

    public static function support_ref($email){ return 'UC'.strtoupper(substr(hash('sha256',strtolower((string)$email)),0,6)); }

    public static function guard($portal, $action,$roles){
        if (is_user_logged_in() && get_user_meta(get_current_user_id(), 'uc_client_preview', true) === '1' && $action !== 'uc_portal_password') {
            wp_die('This seat only shows sample data.', 'Preview', 403);
        }
        $ok_user = is_user_logged_in() && in_array($portal->role(),$roles,true);
        $nonce = isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '';
        $ok_nonce = $nonce !== '' && wp_verify_nonce($nonce, $action);
        if ($ok_user && $ok_nonce) return;
        $msg = !$ok_user ? 'Not allowed.' : 'This form expired. Reload the page and try again.';
        if (self::wants_ajax()) { self::set_flash($portal, $msg,'warn'); self::back($portal, 'dashboard'); }
        wp_die(esc_html($msg), $ok_user ? 400 : 403);
    }

    public static function generate_link_button($portal, $s){
        $p = strtolower((string)($s->platform ?: ''));
        if (!empty($s->join_url) || !$portal->staff()) return '';
        if (!in_array($p, ['google_meet','meet','google meet','teams','microsoft_teams','ms_teams'], true)) return '';
        return '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form"><input type="hidden" name="action" value="uc_portal_generate_link">'.wp_nonce_field('uc_portal_generate_link','_wpnonce',true,false).'<input type="hidden" name="session_id" value="'.(int)$s->id.'"><button class="btn ghost sm" type="submit">Generate link</button></form>';
    }

    public static function ensure_portal_extras($portal){
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $prev = $wpdb->suppress_errors(true);
        ob_start();
        $p = $wpdb->prefix.'uc_';
        dbDelta("CREATE TABLE {$p}practice (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            batch_id bigint unsigned NOT NULL,
            kind varchar(20) NOT NULL DEFAULT 'assignment',
            title varchar(255) NOT NULL,
            body longtext NULL,
            due_at datetime NULL,
            starts_at datetime NULL,
            ends_at datetime NULL,
            url text NULL,
            created_by bigint unsigned NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY batch_id (batch_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}practice_done (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            practice_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            completed_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY one_done (practice_id, user_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}opens (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NOT NULL,
            kind varchar(20) NOT NULL,
            ref_id bigint unsigned NOT NULL,
            opened_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_kind (user_id, kind, ref_id)
        ) $c;");
        $mat = $p.'materials';
        $col = $wpdb->get_results("SHOW COLUMNS FROM {$mat} LIKE 'student_locked'");
        if (!$col) $wpdb->query("ALTER TABLE {$mat} ADD student_locked tinyint(1) NOT NULL DEFAULT 0");
        $prac = $p.'practice';
        $done = $p.'practice_done';
        if (!$wpdb->get_results("SHOW COLUMNS FROM {$prac} LIKE 'paper'")) $wpdb->query("ALTER TABLE {$prac} ADD paper longtext NULL");
        if (!$wpdb->get_results("SHOW COLUMNS FROM {$prac} LIKE 'brief_url'")) $wpdb->query("ALTER TABLE {$prac} ADD brief_url text NULL");
        if (!$wpdb->get_results("SHOW COLUMNS FROM {$done} LIKE 'answers'")) $wpdb->query("ALTER TABLE {$done} ADD answers longtext NULL");
        if (!$wpdb->get_results("SHOW COLUMNS FROM {$done} LIKE 'file_url'")) $wpdb->query("ALTER TABLE {$done} ADD file_url text NULL");
        ob_end_clean();
        $wpdb->suppress_errors($prev);
    }

    public static function viewer($portal, $kind,$id){
        global $wpdb; $ids = $portal->batch_ids();
        $direct = false;
        $url = '';
        $pass = '';
        if ($kind==='material') {
            $x = $wpdb->get_row($wpdb->prepare("SELECT m.*, b.name batch_name FROM {$portal->t('materials')} m JOIN {$portal->t('batches')} b ON b.id=m.batch_id WHERE m.id=%d", $id));
            if (!$x || !in_array((int)$x->batch_id,$ids,true) || (!$x->visible && !$portal->staff()) || (!empty($x->student_locked) && !$portal->staff())) return $portal->empty_state('Not available','This material is not shared with your batch.','materials');
            if ($portal->role()==='student') $portal->note_open('material', (int)$x->id);
            $title = $x->title; $meta = $x->batch_name; $url = $x->url;
        } else {
            $x = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.name batch_name, b.zoom_passcode FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.id=%d AND s.hidden=0", $id));
            if (!$x || !in_array((int)$x->batch_id,$ids,true)) return $portal->empty_state('Not available','This recording is not available for your batch.','play');
            $title = $x->title; $meta = $x->batch_name.' · '.self::fdate($x->session_date,'j M Y'); $url = $x->recording_url;
            if ($portal->role()==='student' && $url) $portal->note_open('recording', (int)$x->id);
            $pass = trim((string)($x->passcode ?: $x->zoom_passcode ?: ''));
            if (!$portal->recording_playable($x)) {
                $portal->maybe_auto_pull_recording($x);
                $x = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.name batch_name, b.zoom_passcode FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.id=%d AND s.hidden=0", $id));
                $url = $x ? $x->recording_url : $url;
            }
        }
        $src = $portal->embed($url, $pass);
        $direct = $src && (preg_match('~\.(mp4|webm|m4v)(\?|$)~i', $src) || preg_match('~/rec/download/~i', $src));
        $local = false;
        $mk = $kind==='material' ? $portal->material_kind($url) : '';
        $media = $kind==='material' ? home_url('/lms-media/material/'.(int)$id.'/') : '';
        $open = $url;
        if ($kind==='material' && in_array($mk, ['pdf','image','video','office','zip'], true) && $portal->local_upload_path($url)) $open = $media;
        if ($kind==='material') {
            $hosted = $portal->academy_media_url('material', (int)$id, (string)$url);
            $framed = $portal->embed($url, $pass);
            if ($hosted) { $src = $hosted; $direct = true; $mk = 'filevideo'; }
            elseif ($mk==='pdf' || $mk==='image') $src = $portal->local_upload_path($url) ? $media : ($framed ?: $url);
            elseif ($framed && $portal->framed_player($framed) && !$portal->drive_file_id($url)) { $src = $framed; $direct = false; $mk = 'embed'; }
            elseif ($mk==='video') { $src = $portal->local_upload_path($url) ? $media : ($hosted ?: $url); $direct = true; $mk = 'filevideo'; }
            elseif ($mk==='office') {
                $src = $framed;
                if (!$src && preg_match('~^https?://~i', $url)) $src = 'https://view.officeapps.live.com/op/embed.aspx?src='.rawurlencode($url);
                $direct = false;
            }
            elseif ($mk==='web') $src = '';
        }
        if ($kind==='recording' && $portal->recording_ready($x)) {
            $src = home_url('/lms-media/recording/'.(int)$id.'/');
            $direct = true;
            $local = true;
        } elseif ($kind==='recording') {
            $hosted = $portal->academy_media_url('recording', (int)$id, (string)$url);
            if ($hosted) { $src = $hosted; $direct = true; }
        }
        $o = '<div class="viewer"><div class="v-head"><a class="btn ghost sm" href="'.esc_url($portal->url('materials')).'" data-back-library>← Library</a><div><strong>'.self::e($title).'</strong><small>'.self::e($meta).'</small></div>';
        if ($kind==='material' && $mk==='web' && $url && $portal->staff()) $o .= '<a class="btn ghost sm" href="'.esc_url($url).'" target="_blank" rel="noopener">Open page</a>';
        $o .= '</div>';
        $again = '<a class="btn ghost sm" href="'.esc_url(home_url('/lms-view/'.($kind==='recording'?'recording':'material').'/'.(int)$id.'/')).'">Try again</a>';
        $link = ($kind==='recording' && $portal->staff()) ? $portal->recording_link_form($id, $url) : '';
        $pull = '';
        $upload = '';
        if ($kind==='recording' && $portal->staff()) {
            $pull = '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uc_portal_recording_pull"><input type="hidden" name="session_id" value="'.(int)$id.'">'.wp_nonce_field('uc_portal_recording_pull','_wpnonce',true,false).'<button class="btn primary sm" type="submit">Pull from Zoom</button></form>';
            $upload = '<form class="rec-up" method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data"><input type="hidden" name="action" value="uc_portal_recording_upload"><input type="hidden" name="session_id" value="'.(int)$id.'">'.wp_nonce_field('uc_portal_recording_upload','_wpnonce',true,false).'<span class="file-btn"><input type="file" name="file" accept="video/mp4,video/webm,.mp4,.m4v,.webm" required><span class="file-pick">Choose File</span><span class="file-name" data-file-name>No File Chosen</span></span><button class="btn ghost sm" type="submit">Upload to host</button></form>';
        }
        $o .= '<div class="v-frame" oncontextmenu="return false">';
        if ($kind==='recording' && $local) {
            $o .= '<video src="'.esc_url($src).'" controls playsinline controlslist="nodownload noplaybackrate" disablepictureinpicture oncontextmenu="return false" onerror="this.hidden=true;var f=this.parentNode.querySelector(\'.v-overlay\');if(f)f.hidden=false"></video>';
            $o .= '<div class="v-overlay" hidden><p>The academy file could not be played. Pull from Zoom again.</p>'.$pull.$again.'</div>';
        } elseif ($kind==='recording' && $src && $direct) {
            $o .= '<video src="'.esc_url($src).'" controls playsinline controlslist="nodownload noplaybackrate" disablepictureinpicture oncontextmenu="return false" onerror="this.hidden=true;var f=this.parentNode.querySelector(\'.v-overlay\');if(f)f.hidden=false"></video>';
            $o .= '<div class="v-overlay" hidden><p>This file could not be played.</p>'.$again.'</div>';
        } elseif ($kind==='recording' && $src) {
            $o .= '<iframe src="'.esc_url($src).'" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen referrerpolicy="origin" loading="eager"></iframe>';
        } elseif ($kind==='recording') {
            $msg = $portal->staff()
                ? 'This class is not playable yet. Pull from Zoom if the cloud file exists.'
                : 'This recording is not available.';
            $o .= '<div class="v-overlay"><p>'.self::e($msg).'</p>'.($portal->staff()?$pull:'').$again.'</div>';
        } elseif ($kind==='material' && $mk==='zip' && $open) {
            $o .= $portal->staff()
                ? '<div class="v-overlay"><p>This is a ZIP file. Open it on your computer if you need the archive.</p><a class="btn primary sm" href="'.esc_url($open).'" target="_blank" rel="noopener">Open file</a>'.$again.'</div>'
                : '<div class="v-overlay"><p>Students cannot download files. Ask your trainer if you need this archive in class.</p>'.$again.'</div>';
        } elseif ($kind==='material' && $mk==='embed' && $src) {
            $o .= '<iframe src="'.esc_url($src).'" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen referrerpolicy="origin" loading="eager"></iframe>';
        } elseif ($kind==='material' && $mk==='web' && $url) {
            $o .= '<div class="v-overlay"><p>This page cannot play inside the portal.</p>'.($portal->staff()?'<a class="btn primary sm" href="'.esc_url($url).'" target="_blank" rel="noopener">Open page</a>':'').$again.'</div>';
        } elseif ($kind==='material' && $mk==='image' && $src) {
            $o .= '<img class="v-img" src="'.esc_url($src).'" alt="'.self::e($title).'">';
        } elseif ($src && $direct) {
            $o .= '<video src="'.esc_url($src).'" controls playsinline controlslist="nodownload noplaybackrate" disablepictureinpicture oncontextmenu="return false" onerror="this.hidden=true;var f=this.parentNode.querySelector(\'.v-overlay\');if(f)f.hidden=false"></video>';
            $o .= '<div class="v-overlay" hidden><p>This file could not be played.</p>'.$again.'</div>';
        } elseif ($src) {
            $o .= '<iframe src="'.esc_url($src).'" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen referrerpolicy="origin" loading="eager"></iframe>';
        } else {
            $extra = ($kind==='material' && $open && $portal->staff()) ? '<a class="btn primary sm" href="'.esc_url($open).'" target="_blank" rel="noopener">Open</a>' : '';
            $o .= '<div class="v-overlay"><p>This item cannot be shown inside the portal. Use Open to view the file or page.</p>'.$extra.$again.'</div>';
        }
        $o .= '<div class="v-mark" aria-hidden="true">'.self::e(wp_get_current_user()->user_email).'</div></div>';
        if ($portal->staff() && $kind==='recording' && !$local && !$src) {
            $o .= '<div class="v-tools">'.$pull.'</div>';
        }
        return $o.'</div>';
    }

    public static function device_map($portal){
        global $wpdb; if (!$portal->has_table('devices')) return [];
        $m = [];
        foreach ($wpdb->get_results("SELECT id,user_id,label,first_seen,last_seen FROM {$portal->t('devices')} ORDER BY last_seen DESC") as $d) $m[(int)$d->user_id][] = ['id'=>(int)$d->id,'label'=>$d->label ?: 'Device','last'=>self::fdate($d->last_seen,'j M Y, g:i A')];
        return $m;
    }

    public static function notice_rows($portal, $limit, $manage = false){
        $rows = $portal->notice_query($limit);
        if (!$rows) return $portal->empty_state('No announcements','Academy announcements will appear here.','announcements');
        $can = $manage && $portal->ops();
        $post = esc_url(admin_url('admin-post.php'));
        $nonce = $can ? wp_nonce_field('uc_portal_notice_delete','_wpnonce',true,false) : '';
        $o = '<div class="nrows">';
        foreach ($rows as $x) {
            $o .= '<article class="nrow" data-q="'.esc_attr(strtolower($x->title)).'"><div class="n-top">'.$portal->pill($portal->aud_label($x),'info').'<small>'.self::e(self::fdate($x->created_at,'j M Y')).($x->by_name?' · '.self::e($x->by_name):'').'</small>';
            if ($can) $o .= '<form method="post" action="'.$post.'" class="n-del"><input type="hidden" name="action" value="uc_portal_notice_delete">'.$nonce.'<input type="hidden" name="id" value="'.(int)$x->id.'"><button class="btn ghost sm" data-confirm="Delete this announcement? It leaves the academy feed.">Delete</button></form>';
            $o .= '</div><strong>'.self::e($x->title).'</strong><p>'.self::e(wp_strip_all_tags($x->body)).'</p></article>';
        }
        return $o.'</div>';
    }

    public static function att_data($portal, $batch){
        global $wpdb;
        $sess = $wpdb->get_results($wpdb->prepare("SELECT id,title,session_date,start_time,end_time FROM {$portal->t('sessions')} WHERE batch_id=%d AND hidden=0 AND LOWER(status)<>'cancelled' AND session_date<=CURDATE() ORDER BY session_date,start_time", $batch));
        $roster = $wpdb->get_results($wpdb->prepare("SELECT u.ID,u.display_name,u.user_email FROM {$portal->t('enrolments')} e JOIN {$wpdb->users} u ON u.ID=e.user_id WHERE e.batch_id=%d AND e.status='active' AND ".$portal->demo_sql()." ORDER BY u.display_name", $batch));
        $roster = $portal->hide_testers($roster);
        $map = [];
        if ($portal->has_table('attendance')) foreach ($wpdb->get_results($wpdb->prepare("SELECT user_id,session_id,status,minutes FROM {$portal->t('attendance')} WHERE batch_id=%d", $batch)) as $a) $map[(int)$a->user_id][(int)$a->session_id] = $a;
        return [$sess,$roster,$map];
    }

    public static function log_audit($portal, $entity,$id,$action,$detail=''){
        global $wpdb;
        if (!$portal->has_table('audit')) return;
        $wpdb->insert($portal->t('audit'), [
            'entity'=>$entity,
            'entity_id'=>$id ? (int)$id : null,
            'action'=>$action,
            'by_user_id'=>get_current_user_id(),
            'at_time'=>current_time('mysql'),
            'detail'=>$detail,
        ]);
    }

    public static function db_fail($portal, $page){
        global $wpdb;
        $err = $wpdb->last_error ? $wpdb->last_error : 'The change was not saved.';
        self::set_flash($portal, $err,'warn');
        self::back($portal, $page);
    }

    public static function api($portal) {
        register_rest_route(UC_LMS_Portal::REST_NS,'/me',['methods'=>'GET','permission_callback'=>function() use ($portal){return is_user_logged_in() && $portal->role()!=='guest';},'callback'=>function() use ($portal){ $u=wp_get_current_user(); return ['id'=>(int)$u->ID,'name'=>$u->display_name,'role'=>$portal->role()]; }]);
        if (class_exists('UC_LMS_Portal_Search')) {
            UC_LMS_Portal_Search::register_routes($portal);
        }
        register_rest_route(UC_LMS_Portal::REST_NS,'/privacy-alert',['methods'=>'POST','permission_callback'=>function(){ return is_user_logged_in(); },'callback'=>function($req) use ($portal){
            $kind = sanitize_key((string)$req->get_param('kind'));
            $page = sanitize_text_field((string)$req->get_param('page'));
            $portal->log_audit('privacy', get_current_user_id(), 'blocked_'.$kind, 'Blocked '.$kind.' on '.$page);
            update_option('uc_privacy_alert', current_time('mysql').' · user '.get_current_user_id().' · '.$kind.' · '.$page, false);
            return ['ok'=>true];
        }]);
    }

    public static function cr_trainer_strip($portal, $pack, $st, $s) {
        $sum = $pack['summary'];
        $row = function ($label, $ok) {
            return '<li class="'.($ok?'':'off').'">'.$label.'</li>';
        };
        $o = '<section class="cr-card cr-trainer"><h3>Trainer View</h3><div class="cr-trainer-grid"><ul class="cr-checks">';
        $o .= $row('Recording Available', ($st->recording_state ?? '') === 'available' || $portal->recording_playable($s));
        $o .= $row('Transcript Available', !empty($pack['transcript']));
        $o .= $row('AI Summary Generated', !empty($sum));
        $o .= $row('Tasks Generated', !empty($pack['tasks']));
        $o .= $row('Poll Results Available', !empty($pack['polls']));
        $o .= $row('Attendance Processed', !empty($pack['stats']['total']));
        $o .= '</ul><div>';
        $draft = $portal->is_meet_platform($s) ? 'Sync Meet notes after class, then publish.' : 'Sync Zoom after class, then publish.';
        $o .= '<p class="muted">Summary (Draft)</p><p>'.($sum ? nl2br(self::e(wp_strip_all_tags($sum->recap))) : $draft).'</p>';
        $o .= '<div class="cr-review-acts">';
        if ($sum) {
            $on = !empty($sum->published);
            $o .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="inline-form">'.wp_nonce_field('uc_portal_intel_publish','_wpnonce',true,false).'<input type="hidden" name="action" value="uc_portal_intel_publish"><input type="hidden" name="session_id" value="'.(int)$s->id.'"><input type="hidden" name="what" value="summary">';
            $o .= $on ? '<input type="hidden" name="on" value="0"><button class="btn ghost sm" type="submit">Edit</button>' : '<input type="hidden" name="on" value="1"><button class="btn primary sm" type="submit">Publish to Students</button>';
            $o .= '</form>';
        }
        $o .= '</div></div></div></section>';
        return $o;
    }

    public static function note_open($portal, $kind, $id){
        if ($portal->role() !== 'student' || !$id || !$portal->has_table('opens')) return;
        global $wpdb;
        $uid = get_current_user_id();
        $have = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$portal->t('opens')} WHERE user_id=%d AND kind=%s AND ref_id=%d LIMIT 1", $uid, $kind, $id));
        if (!$have) $wpdb->insert($portal->t('opens'), ['user_id'=>$uid,'kind'=>$kind,'ref_id'=>$id,'opened_at'=>current_time('mysql')]);
    }

    public static function academy_media_url($portal, $kind, $id, $url){
        if ($portal->drive_file_id($url) || preg_match('~\.(mp4|webm|m4v)(\?|$)~i', (string)$url)) {
            $which = $kind === 'recording' ? 'recording' : 'material';
            return home_url('/lms-media/'.$which.'/'.(int)$id.'/');
        }
        return '';
    }

    public static function notice_query($portal, $limit){
        if (is_user_logged_in() && class_exists('UC_LMS_Security') && UC_LMS_Security::is_demo(wp_get_current_user())) return [];
        global $wpdb;
        $ids = $portal->in_ids($portal->batch_ids());
        $w = $portal->staff() ? '1=1' : "(audience IN ('all','student','students') OR (audience='batch' AND batch_id IN ({$ids})))";
        return $wpdb->get_results("SELECT a.*, u.display_name by_name, b.name batch_name FROM {$portal->t('announcements')} a LEFT JOIN {$wpdb->users} u ON u.ID=a.by_user_id LEFT JOIN {$portal->t('batches')} b ON b.id=a.batch_id WHERE {$w} ORDER BY a.id DESC LIMIT ".(int)$limit);
    }

    public static function aud_label($x){
        return $x->audience === 'batch' ? ($x->batch_name ?: 'Batch') : (in_array($x->audience, ['staff'], true) ? 'Staff' : ($x->audience === 'all' ? 'Everyone' : 'Students'));
    }

    public static function recent_notice_count($portal){
        $n = 0;
        foreach ($portal->notice_query(20) as $x) {
            if (strtotime($x->created_at) > current_time('timestamp') - 7 * DAY_IN_SECONDS) $n++;
        }
        return $n;
    }

    public static function session_hours($s){
        if (empty($s->start_time)) return 1.0;
        $mins = !empty($s->end_time) ? max(0, (strtotime($s->end_time) - strtotime($s->start_time)) / 60) : 60;
        return (float)($mins / 60);
    }
}
