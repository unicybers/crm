<?php
/**
 * UniCybers Academy LMS: Portal Public Sharing, Verification & Internal Testing Engine.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Public {

    public static function public_programme($portal, $id){
        global $wpdb;
        $c = $id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('courses')} WHERE id=%d", $id)) : null;
        $asset = plugins_url('assets/', UC_LMS_FILE);
        $sent = isset($_GET['sent']);
        $err = isset($_GET['err']);
        status_header($c ? 200 : 404);
        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.($c?$portal->e($c->name):'Programme').' · UniCybers Academy</title>';
        echo class_exists('UC_LMS_Portal_Layout') ? UC_LMS_Portal_Layout::favicon_html() : '';
        echo '<link rel="stylesheet" href="'.esc_url($asset.'portal.min.css?v='.UC_LMS_Portal::VERSION).'">';
        echo '<script>try{var t=localStorage.getItem("uc_lms_theme");if(!t)t=window.matchMedia("(prefers-color-scheme: light)").matches?"light":"dark";document.documentElement.setAttribute("data-theme",t)}catch(e){document.documentElement.setAttribute("data-theme","dark")}</script>';
        echo '</head><body class="pub-body"><main class="pub">';
        echo '<div class="pub-top"><p class="eyebrow">UNICYBERS ACADEMY</p><button type="button" class="iconbtn" id="themeToggle" aria-label="Switch theme"><span class="t-sun">'.$portal->icon('sun').'</span><span class="t-moon">'.$portal->icon('moon').'</span></button></div>';
        echo '<div class="pub-card">';
        if (!$c) { echo '<h1>Programme not found</h1><p>Ask the academy for a current link.</p></div></main><script>document.getElementById("themeToggle").onclick=function(){var t=document.documentElement.getAttribute("data-theme")==="dark"?"light":"dark";document.documentElement.setAttribute("data-theme",t);try{localStorage.setItem("uc_lms_theme",t)}catch(e){}}</script></body></html>'; return; }
        $facts = array_filter([$c->category ?: '', $c->level ?: '', $c->mode ? ucfirst((string)$c->mode) : '', $c->duration ?: '']);
        echo '<h1>'.$portal->e($c->name).'</h1>';
        if ($facts) { echo '<div class="pub-facts">'; foreach ($facts as $f) echo '<span>'.$portal->e($f).'</span>'; echo '</div>'; }
        if (!empty($c->description)) echo '<p class="lead">'.$portal->e($c->description).'</p>';
        $mods = $portal->outline_items($c->outline ?? '');
        if ($mods) {
            echo '<h2 style="font-size:18px;margin:0 0 10px">What you will cover</h2><ol class="pub-mods">';
            $n = 1;
            foreach ($mods as $m) echo '<li><b>'.$n++.'</b><span>'.$portal->e($m).'</span></li>';
            echo '</ol>';
        }
        if ($sent) echo '<p><strong>Interest received.</strong> A coordinator will write to you. This does not enrol you by itself.</p>';
        else {
            if ($err) echo '<p class="hint">Enter your name, email and phone, then try again.</p>';
            echo '<h2 style="font-size:18px;margin-top:8px">I want this programme</h2><p class="hint">Your coordinator or trainer shared this page because it fits what you asked about. The academy desk receives what you send.</p>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form"><input type="hidden" name="action" value="uc_portal_course_interest">'.wp_nonce_field('uc_portal_course_interest','_wpnonce',true,false).'<input type="hidden" name="course_id" value="'.(int)$c->id.'">';
            echo '<div class="fgrid"><label>Full name<input name="name" required></label><label>Email<input type="email" name="email" required></label><label>Phone<input name="phone" required placeholder="WhatsApp or mobile"></label></div>';
            echo '<label>Note<textarea name="note" rows="3" placeholder="Timing, country, or anything we should know"></textarea></label>';
            echo '<input name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">';
            echo '<div class="right"><button class="btn primary">Send interest</button></div></form>';
        }
        echo '</div><p class="hint" style="margin-top:16px">Looking at other programmes? <a href="https://learn.unicybers.com/courses">Browse the full catalogue</a>.</p></main>';
        echo '<script>document.getElementById("themeToggle").onclick=function(){var t=document.documentElement.getAttribute("data-theme")==="dark"?"light":"dark";document.documentElement.setAttribute("data-theme",t);try{localStorage.setItem("uc_lms_theme",t)}catch(e){}}</script></body></html>';
    }

    public static function public_candidate($portal, $token){
        $token = preg_replace('/[^A-Za-z0-9]/', '', (string)$token);
        $users = $token ? get_users(['meta_key'=>'uc_pack_token','meta_value'=>$token,'number'=>1]) : [];
        $u = $users ? $users[0] : null;
        global $wpdb;
        $p = ($u && $portal->has_table('student_profiles')) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('student_profiles')} WHERE user_id=%d", $u->ID)) : null;
        $miss = $u ? $portal->pack_missing($p, $u->ID) : ['missing'];
        $asset = plugins_url('assets/', UC_LMS_FILE);
        status_header(($u && !$miss) ? 200 : 404);
        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Candidate · UniCybers Academy</title>';
        echo class_exists('UC_LMS_Portal_Layout') ? UC_LMS_Portal_Layout::favicon_html() : '';
        echo '<link rel="stylesheet" href="'.esc_url($asset.'portal.min.css?v='.UC_LMS_Portal::VERSION).'"></head><body><main class="pub"><div class="pub-card">';
        if (!$u || $miss) { echo '<h1>Candidate pack is not current</h1><p>This link stays closed until every field and document a client asks for is on file.</p></div></main></body></html>'; return; }
        $g = function($k) use ($p){ return $p && isset($p->$k) ? (string)$p->$k : ''; };
        echo '<p class="eyebrow">'.$portal->e($g('career_id')).'</p><h1>'.$portal->e($u->display_name).'</h1>';
        echo '<p class="muted">'.$portal->e($g('preferred_role')).' · '.$portal->e($g('city')).', '.$portal->e($g('country')).' · '.$portal->e($g('experience_years')).' years</p>';
        echo '<p>'.$portal->e($g('professional_summary')).'</p>';
        echo '<p><strong>Email</strong><br>'.$portal->e($u->user_email).'</p><p><strong>Phone</strong><br>'.$portal->e($g('phone')).'</p>';
        echo '<p><strong>LinkedIn</strong><br>'.$portal->e($g('linkedin')).'</p>';
        echo '<p><strong>Qualification</strong><br>'.$portal->e($g('highest_qualification').', '.$g('institution').' ('.$g('graduation_year').')').'</p>';
        echo '<p><strong>Skills</strong><br>'.$portal->e($g('skills')).'</p><p><strong>Certifications</strong><br>'.$portal->e($g('certifications')).'</p>';
        echo '<p class="hint">Documents on file with the academy: resume, government ID, degree or marksheet, cybersecurity certificate. The files themselves stay inside the portal.</p>';
        echo '</div></main></body></html>';
    }

    public static function pack_missing($portal, $p, $uid = 0){
        global $wpdb;
        $uid = $uid ? (int)$uid : (int)($p->user_id ?? 0);
        $need = [
            'phone'=>'Phone','city'=>'City','country'=>'Country','linkedin'=>'LinkedIn',
            'highest_qualification'=>'Highest Qualification','institution'=>'Institution','graduation_year'=>'Graduation Year',
            'professional_summary'=>'Professional Summary','skills'=>'Skills','certifications'=>'Certifications',
            'experience_years'=>'Experience','employment_status'=>'Employment Status','preferred_role'=>'Preferred Role',
            'preferred_location'=>'Preferred Location','work_preference'=>'Work Preference','availability'=>'Availability',
            'notice_period'=>'Notice Period','languages'=>'Languages','work_authorization'=>'Work Authorization','tools'=>'Tools','headline'=>'Headline','field_of_study'=>'Field of Study',
        ];
        $miss = [];
        foreach ($need as $k=>$lab) if (!$p || trim((string)($p->$k ?? '')) === '') $miss[] = $lab;
        $docs = ($uid && $portal->has_table('student_documents')) ? $wpdb->get_col($wpdb->prepare("SELECT document_type FROM {$portal->t('student_documents')} WHERE user_id=%d AND status<>'rejected'", $uid)) : [];
        $have = array_map('strtolower', array_map('strval', $docs ?: []));
        $want = ['resume'=>'Resume / CV','id_proof'=>'Government ID','degree'=>'Degree / Marksheet','certificate'=>'Cybersecurity Certificate'];
        foreach ($want as $key=>$lab) {
            $ok = false;
            foreach ($have as $h) {
                if ($h === $key) $ok = true;
                if ($key==='resume' && (strpos($h,'resume')!==false || $h==='cv')) $ok = true;
                if ($key==='id_proof' && (strpos($h,'id')!==false || strpos($h,'passport')!==false)) $ok = true;
                if ($key==='degree' && (strpos($h,'degree')!==false || strpos($h,'mark')!==false)) $ok = true;
                if ($key==='certificate' && strpos($h,'cert')!==false) $ok = true;
            }
            if (!$ok) $miss[] = $lab;
        }
        return $miss;
    }

    public static function pack_token($portal, $uid = 0){
        $uid = $uid ? (int)$uid : get_current_user_id();
        $token = (string)get_user_meta($uid, 'uc_pack_token', true);
        if (!preg_match('/^[A-Za-z0-9]{12,}$/', $token)) {
            $token = wp_generate_password(20, false, false);
            update_user_meta($uid, 'uc_pack_token', $token);
        }
        return $token;
    }

    public static function file_control($portal, $name, $accept = ''){
        return '<span class="file-btn"><input type="file" name="'.esc_attr($name).'" accept="'.esc_attr($accept).'"><span class="file-pick">Choose File</span><span class="file-name" data-file-name>No File Chosen</span></span>';
    }

    public static function exam_catalog($portal){
        return [
            'CompTIA' => ['Security+','CySA+','CASP+','Network+','PenTest+'],
            'EC-Council' => ['CEH','CPENT','CHFI'],
            'ISC2' => ['CISSP','CCSP','SSCP'],
            'ISACA' => ['CISM','CISA','CRISC'],
            'AWS' => ['Cloud Practitioner','Solutions Architect'],
            'Cisco' => ['CCNA','CyberOps'],
            'Microsoft' => ['SC-900','AZ-900','AZ-104'],
            'PMI' => ['PMP','CAPM'],
        ];
    }

    public static function exam_fields($portal, $uid = 0){
        $uid = $uid ? (int)$uid : get_current_user_id();
        $parts = explode('|', (string)get_user_meta($uid, 'uc_exam_choice', true), 2);
        $vendor = $parts[0] ?? '';
        $exam = $parts[1] ?? '';
        $cat = $portal->exam_catalog();
        $o = '<fieldset class="profile-block profile-exam"><legend>Certification Interest</legend><div class="fgrid">';
        $o .= '<label>Vendor<select name="exam_vendor" id="examVendor"><option value="">Not Now</option>';
        foreach (array_keys($cat) as $v) $o .= '<option value="'.esc_attr($v).'"'.selected($vendor, $v, false).'>'.$portal->e($v).'</option>';
        $o .= '</select></label><label>Exam<select name="exam_name" id="examName"><option value="">Select An Exam</option>';
        foreach ($cat as $v => $exams) foreach ($exams as $ex) {
            $hide = ($vendor && $vendor !== $v) ? ' hidden' : '';
            $o .= '<option data-vendor="'.esc_attr($v).'" value="'.esc_attr($ex).'"'.selected($exam, $ex, false).$hide.'>'.$portal->e($ex).'</option>';
        }
        $o .= '</select></label></div></fieldset>';
        $o .= '<script>(function(){var v=document.getElementById("examVendor"),n=document.getElementById("examName");if(!v||!n)return;function f(){Array.prototype.forEach.call(n.options,function(o){if(!o.value)return;o.hidden=!!v.value&&o.getAttribute("data-vendor")!==v.value;});if(n.selectedOptions[0]&&n.selectedOptions[0].hidden)n.value="";}v.addEventListener("change",f);f();})();</script>';
        return $o;
    }

    public static function placement_labels(){
        return [
            'recommended'=>'Recommended','saved'=>'Saved','preparing'=>'Preparing','ready_to_apply'=>'Ready to apply',
            'applied'=>'Applied','interview'=>'Interview','offer'=>'Offer','joined'=>'Joined','closed'=>'Closed',
        ];
    }

    public static function placement_profile_pct($portal, $row){
        if (!$row) return 0;
        $keys = ['phone','city','country','highest_qualification','skills','preferred_role','professional_summary','experience_years'];
        $n = 0;
        foreach ($keys as $k) if (trim((string)($row->$k ?? '')) !== '') $n++;
        return (int) round($n * 100 / count($keys));
    }

    public static function ensure_profile_flag($portal){
        global $wpdb;
        $t = $portal->t('student_profiles');
        $has = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$t` LIKE %s", 'placement_excluded'));
        if (!$has) $wpdb->query("ALTER TABLE `$t` ADD `placement_excluded` tinyint(1) NOT NULL DEFAULT 0");
    }

    public static function tester_emails($portal){ return ['sofia@unicybers.com','sofia@unicybers.online','mohammedrafi786@gmail.com']; }

    public static function want_internal($portal){ return !empty($_REQUEST['internal']); }

    public static function is_internal_tester($portal, $user = null){
        if ($user === null) $user = wp_get_current_user();
        $email = strtolower(is_object($user) ? (string)($user->user_email ?? '') : (string)$user);
        if (in_array($email, $portal->tester_emails(), true)) return true;
        $id = is_object($user) ? (int)($user->ID ?? 0) : 0;
        if ($id && get_user_meta($id, 'uc_internal_test', true)) return true;
        $name = is_object($user) ? strtolower((string)($user->display_name ?? '')) : '';
        return (bool)preg_match('/test[- ]student|student-test/', $name);
    }

    public static function hide_testers($portal, $rows = []){
        if ($portal->want_internal() || empty($rows)) return $rows;
        return array_values(array_filter((array)$rows, function($r) use ($portal) { return !$portal->is_internal_tester($r); }));
    }

    public static function include_testers_toggle($portal, $view = ''){
        $on = $portal->want_internal();
        return '<label class="check" style="margin:0 0 0 8px"><input type="checkbox" name="internal" value="1"'.($on?' checked':'').' onchange="this.form.submit()"> Include UniCybers test accounts</label>';
    }
}
