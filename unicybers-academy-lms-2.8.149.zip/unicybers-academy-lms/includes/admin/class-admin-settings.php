<?php
/**
 * UniCybers Academy LMS: Admin Settings & Zoom Maintenance.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Admin_Settings extends UC_LMS_Admin_Base {
    public static function instance() {
        static $i = null;
        if (!$i) $i = new self();
        return $i;
    }

    public function settings_page() {
        if (!$this->can_manage()) return;

        $default_logo = 'https://lms.unicybers.com/wp-content/uploads/2026/09/7-Copy.webp';
        $custom_logo = get_option('uc_logo_url', '');
        $current_logo = $custom_logo ?: $default_logo;
        $academy_name = get_option('uc_academy_name', 'UniCybers');
        $legal_name = get_option('uc_academy_legal_name', 'UniCybers Academy');
        $product_label = get_option('uc_product_label', 'ACADEMY');
        $tagline = get_option('uc_tagline', 'Learn · Practice · Prove · Advance');

        echo '<div class="wrap"><h1>' . esc_html($academy_name) . ' LMS Settings</h1>';
        $this->render_notice();
        echo '<form method="post" action="options.php">';
        settings_fields('uc_lms_settings');

        // 1. Branding & Identity
        echo '<h2 style="margin-top:24px;border-bottom:1px solid #c3c4c7;padding-bottom:8px">Branding &amp; Portal Identity</h2>';
        echo '<p class="description">Customize the logo, academy title, and brand identity displayed across the student portal, sidebar, and login page. Defaults to UniCybers if left empty.</p>';
        echo '<table class="form-table" role="presentation">';

        // Logo Upload Row
        echo '<tr>';
        echo '<th scope="row"><label for="uc_logo_url">Academy Logo</label></th>';
        echo '<td>';
        echo '<div style="display:flex;align-items:center;gap:18px;margin-bottom:8px">';
        $is_default_brand_logo = (empty($custom_logo) || $custom_logo === $default_logo);
        echo '<style>
            .uc-admin-brand-preview{position:relative;width:260px;max-width:100%;aspect-ratio:2.115/1;overflow:hidden;background:#07090C;border:1px solid #263241;border-radius:12px;display:block}
            .uc-admin-brand-preview img{position:absolute;inset:0;width:100%;height:100%;max-width:none;object-fit:cover;object-position:center;display:block}
            .uc-admin-brand-preview .uc-source-academy{position:absolute;left:32.2%;top:62.5%;width:52%;height:17%;box-sizing:border-box;display:flex;align-items:center;justify-content:space-between;padding:0 .2%;border-radius:1px;background:#061B3A;color:#FF6B1A;font:900 11px/1 Arial,sans-serif;letter-spacing:0;text-transform:uppercase}
            .uc-admin-brand-preview .uc-source-academy span{display:block;flex:0 0 auto}
        </style>';
        echo '  <div id="uc_logo_preview_wrap" style="display:inline-flex;align-items:center;justify-content:center;margin-bottom:8px">';
        if ($is_default_brand_logo) {
            echo '    <div class="uc-admin-brand-preview"><img id="uc_logo_preview" src="' . esc_url($default_logo) . '" alt="UniCybers"><span class="uc-source-academy" aria-label="Academy"><span>A</span><span>C</span><span>A</span><span>D</span><span>E</span><span>M</span><span>Y</span></span></div>';
        } else {
            echo '    <img id="uc_logo_preview" src="' . esc_url($current_logo) . '" alt="' . esc_attr($academy_name) . '" style="max-height:68px;max-width:260px;height:auto;width:auto;object-fit:contain;display:block">';
        }
        echo '  </div>';
        echo '  <div style="display:flex;flex-direction:column;align-items:flex-start;gap:8px">';
        echo '    <input type="hidden" id="uc_logo_url" name="uc_logo_url" value="' . esc_attr($custom_logo) . '">';
        echo '    <button type="button" class="button button-secondary" id="uc_upload_logo_btn">';
        echo '      <span class="dashicons dashicons-upload" style="vertical-align:middle;margin-right:4px"></span>Select or Upload Logo';
        echo '    </button>';
        echo '    <button type="button" class="button-link-delete" id="uc_remove_logo_btn" style="' . ((empty($custom_logo) || $custom_logo === $default_logo) ? 'display:none;' : '') . 'padding:4px 0;text-decoration:none">';
        echo '      Reset to Default Logo';
        echo '    </button>';
        echo '  </div>';
        echo '</div>';
        echo '<p class="description">The sidebar shows the globe on the left, with UNICYBERS above ACADEMY. Both words use normal letter spacing and the same width. Client logos stay on their own academies.</p>';
        echo '</td>';
        echo '</tr>';

        // Title / Short Name
        echo '<tr>';
        echo '<th scope="row"><label for="uc_academy_name">Academy Short Name / Title</label></th>';
        echo '<td>';
        echo '<input class="regular-text" id="uc_academy_name" name="uc_academy_name" value="' . esc_attr($academy_name) . '">';
        echo '<p class="description">Main brand name displayed in the portal header, sidebar top row, and notifications (default: <code>UniCybers</code>).</p>';
        echo '</td>';
        echo '</tr>';

        // Full / Legal Name
        echo '<tr>';
        echo '<th scope="row"><label for="uc_academy_legal_name">Full / Legal Name</label></th>';
        echo '<td>';
        echo '<input class="regular-text" id="uc_academy_legal_name" name="uc_academy_legal_name" value="' . esc_attr($legal_name) . '">';
        echo '<p class="description">Used in browser tab titles, document footers, and copyright statements (default: <code>UniCybers Academy</code>).</p>';
        echo '</td>';
        echo '</tr>';

        // Subtitle / Product Label
        echo '<tr>';
        echo '<th scope="row"><label for="uc_product_label">Portal Subtitle / Product Label</label></th>';
        echo '<td>';
        echo '<input class="regular-text" id="uc_product_label" name="uc_product_label" value="' . esc_attr($product_label) . '">';
        echo '<p class="description">The small highlighted tag beneath the title in the sidebar rail (default: <code>ACADEMY</code>).</p>';
        echo '</td>';
        echo '</tr>';

        // Tagline
        echo '<tr>';
        echo '<th scope="row"><label for="uc_tagline">Tagline</label></th>';
        echo '<td>';
        echo '<input class="regular-text" id="uc_tagline" name="uc_tagline" value="' . esc_attr($tagline) . '">';
        echo '<p class="description">Brand motto or mission (default: <code>Learn · Practice · Prove · Advance</code>).</p>';
        echo '</td>';
        echo '</tr>';

        echo '</table>';

        // 2. General & Localization Settings
        echo '<h2 style="margin-top:28px;border-bottom:1px solid #c3c4c7;padding-bottom:8px">General Settings</h2>';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th>Default timezone</th><td><input class="regular-text" name="uc_default_timezone" value="' . esc_attr(get_option('uc_default_timezone', 'Asia/Kolkata')) . '"></td></tr>';
        echo '</table>';

        // Lightweight integrations: Drive source folder, Google Meet, Teams and Zoho.
        echo '<h2 style="margin-top:28px;border-bottom:1px solid #c3c4c7;padding-bottom:8px">Materials &amp; Meeting Integrations</h2>';
        echo '<p class="description">Connect providers once. The LMS stores provider links and metadata, not duplicate meeting videos. Zoom stays on its existing working connection.</p>';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th>Google Drive materials folder ID</th><td><input class="regular-text" name="uc_drive_materials_folder" value="' . esc_attr(get_option('uc_drive_materials_folder', '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi')) . '"><p class="description">Use the ID from the shared folder URL. Viewer access is enough to index files. The connected account needs Owner or Editor rights on files where you want LMS to apply Google download, print and copy restrictions.</p><input type="hidden" name="uc_drive_sync_enabled" value="0"><label><input type="checkbox" name="uc_drive_sync_enabled" value="1" ' . checked(get_option('uc_drive_sync_enabled','1'), '1', false) . '> Enable automatic incremental Drive sync every 10 minutes</label><br><input type="hidden" name="uc_drive_protect_downloads" value="0"><label><input type="checkbox" name="uc_drive_protect_downloads" value="1" ' . checked(get_option('uc_drive_protect_downloads','1'), '1', false) . '> Restrict download, print and copy for Drive readers when Google allows it</label><p class="description">This changes the Drive file restriction for viewers and commenters. It does not prevent filming the screen.</p></td></tr>'; 
        // Existing Zoom Server-to-Server OAuth connection. Keep the same option names so saved credentials and meetings are reused.
        echo '<tr><th colspan="2"><h3 style="margin:8px 0 0">Existing Zoom connection</h3><p class="description">Your current Zoom integration remains the default meeting provider where a batch uses Zoom. These are the existing Server-to-Server OAuth credentials; do not create a second Zoom connection.</p></th></tr>';
        echo '<tr><th>Zoom Account ID</th><td><input class="regular-text" name="uc_zoom_account_id" value="' . esc_attr(get_option('uc_zoom_account_id','')) . '"></td></tr>';
        echo '<tr><th>Zoom Client ID</th><td><input class="regular-text" name="uc_zoom_client_id" value="' . esc_attr(get_option('uc_zoom_client_id','')) . '"></td></tr>';
        echo '<tr><th>Zoom Client Secret</th><td><input class="regular-text" type="password" name="uc_zoom_client_secret" value="" placeholder="Saved securely. Enter only to replace." autocomplete="new-password"></td></tr>';
        echo '<tr><th>Zoom Webhook Secret Token</th><td><input class="regular-text" type="password" name="uc_zoom_webhook_secret" value="" placeholder="Optional. Saved securely; leave blank to keep existing." autocomplete="new-password"><p class="description">Used to validate Zoom recording event notifications when a webhook is configured.</p></td></tr>';
        echo '<tr><th>Google Workspace OAuth Client ID</th><td><input class="regular-text" name="uc_google_client_id" value="' . esc_attr(get_option('uc_google_client_id','')) . '"></td></tr>';
        echo '<tr><th>Google Workspace OAuth Client Secret</th><td><input class="regular-text" type="password" name="uc_google_client_secret" value="" placeholder="Saved securely. Enter only to replace." autocomplete="new-password"></td></tr>';
        echo '<tr><th>Google Calendar ID</th><td><input class="regular-text" name="uc_google_calendar_id" value="' . esc_attr(get_option('uc_google_calendar_id','primary')) . '"></td></tr>';
        echo '<tr><th>Microsoft Teams Tenant ID</th><td><input class="regular-text" name="uc_ms_tenant" value="' . esc_attr(get_option('uc_ms_tenant','')) . '"></td></tr>';
        echo '<tr><th>Microsoft Teams Application Client ID</th><td><input class="regular-text" name="uc_ms_client_id" value="' . esc_attr(get_option('uc_ms_client_id','')) . '"></td></tr>';
        echo '<tr><th>Microsoft Teams Application Secret</th><td><input class="regular-text" type="password" name="uc_ms_client_secret" value="" placeholder="Saved securely. Enter only to replace." autocomplete="new-password"></td></tr>';
        echo '<tr><th>Teams meeting organizer user</th><td><input class="regular-text" name="uc_ms_user" value="' . esc_attr(get_option('uc_ms_user','')) . '"><p class="description">User principal name or Microsoft 365 user ID used to create online meetings.</p></td></tr>';
        $dc = get_option('uc_zoho_dc','in');
        echo '<tr><th>Zoho data centre</th><td><select name="uc_zoho_dc">';
        foreach (['in'=>'India (.in)','com'=>'United States (.com)','eu'=>'Europe (.eu)','com.au'=>'Australia (.com.au)','jp'=>'Japan (.jp)','ca'=>'Canada (.ca)','sa'=>'Saudi Arabia (.sa)'] as $v=>$label) echo '<option value="'.esc_attr($v).'" '.selected($dc,$v,false).'>'.esc_html($label).'</option>';
        echo '</select></td></tr>';
        echo '<tr><th>Zoho OAuth Client ID</th><td><input class="regular-text" name="uc_zoho_client_id" value="' . esc_attr(get_option('uc_zoho_client_id','')) . '"></td></tr>';
        echo '<tr><th>Zoho OAuth Client Secret</th><td><input class="regular-text" type="password" name="uc_zoho_client_secret" value="" placeholder="Saved securely. Enter only to replace." autocomplete="new-password"></td></tr>';
        echo '<tr><th>Zoho Organization ID (zsoid)</th><td><input class="regular-text" name="uc_zoho_zsoid" value="' . esc_attr(get_option('uc_zoho_zsoid','')) . '"></td></tr>';
        echo '<tr><th>Zoho Presenter User ID</th><td><input class="regular-text" name="uc_zoho_presenter_id" value="' . esc_attr(get_option('uc_zoho_presenter_id','')) . '"><p class="description">Required by Zoho when creating meetings. Use the Zoho Meeting presenter user ID.</p></td></tr>';
        echo '<tr><th colspan="2"><h3 style="margin:8px 0 0">Placement AI and role access</h3><p class="description">These settings stay on this page. WordPress shows LMS Settings to administrators only. Coordinators, trainers and students do not get this screen.</p></th></tr>';
        echo '<tr><th>AI API key</th><td><input class="regular-text" type="password" name="uc_ai_api_key" value="" placeholder="Saved securely. Enter only to replace." autocomplete="new-password"><p class="description">Used for placement AI. Leave blank to keep the saved key. Record the credit balance yourself. The LMS does not invent one.</p></td></tr>';
        echo '<tr><th>AI credit balance</th><td><input class="regular-text" name="uc_ai_credit_balance" value="' . esc_attr(get_option('uc_ai_credit_balance','0')) . '"></td></tr>';
        echo '<tr><th>Jobs API URL</th><td><input class="regular-text" name="uc_jobs_api_url" value="' . esc_attr(get_option('uc_jobs_api_url','')) . '"><p class="description">Optional jobs feed. Placement Desk pull uses this address when it is saved. Openings still need a review before students see them.</p></td></tr>';
        echo '<tr><th>Jobs shared token</th><td><input class="regular-text" type="password" name="uc_career_shared_token" value="" placeholder="Saved securely. Enter only to replace." autocomplete="new-password"><p class="description">Required with the jobs API. Leave blank to keep the saved token. The pull does not invent jobs.</p></td></tr>';
        $flags = get_option('uc_role_features', []);
        if (!is_array($flags)) $flags = [];
        $roles = ['coordinator'=>'Coordinator','trainer'=>'Trainer','student'=>'Student'];
        $pages = ['dashboard'=>'Dashboard','courses'=>'Courses','batches'=>'Batches','classes'=>'Classes','practice'=>'Practice','materials'=>'Materials','people'=>'People','placement'=>'Placement','announcements'=>'Announcements','messages'=>'Messages','reports'=>'Reports','profile'=>'Profile'];
        echo '<tr><th>Features by role</th><td>';
        foreach ($roles as $role=>$label) {
            echo '<p><strong>'.esc_html($label).'</strong></p><p>';
            foreach ($pages as $page=>$name) {
                if ($role === 'student' && in_array($page, ['batches','people'], true)) continue;
                if ($role === 'trainer' && $page === 'people') continue;
                $on = !isset($flags[$role][$page]) || !empty($flags[$role][$page]);
                echo '<label style="display:inline-block;min-width:140px;margin:0 8px 6px 0"><input type="checkbox" name="uc_role_features['.esc_attr($role).']['.esc_attr($page).']" value="1" '.checked($on, true, false).'> '.esc_html($name).'</label>';
            }
            echo '</p>';
        }
        echo '<p class="description">Super Admin always keeps every feature. Uncheck a box to hide that menu from the role.</p></td></tr>';
        echo '</table>';

        submit_button('Save Settings');
        echo '</form>';
        $zoom_configured = (get_option('uc_zoom_account_id') && get_option('uc_zoom_client_id') && get_option('uc_zoom_client_secret'));
        echo '<div class="uc-panel" style="max-width:860px"><h3>Connect provider accounts</h3><p>Zoom continues through its existing Server-to-Server OAuth app. Google authorization is used for Meet links and Drive materials. Zoho authorization enables meeting creation and recording lookup. Teams uses the saved Microsoft application credentials.</p>';
        echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;padding:10px 0;border-bottom:1px solid #e2e8f0"><div><strong>Zoom</strong><p class="description" style="margin:3px 0 0">Existing connection: ' . ($zoom_configured ? '<span class="uc-ok">Credentials configured</span>' : '<span class="uc-warn">Credentials incomplete</span>') . '</p></div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block"><input type="hidden" name="action" value="uc_test_zoom">'.wp_nonce_field('uc_test_zoom','_wpnonce',true,false).'<button class="button button-primary">Test existing Zoom connection</button></form></div>';
        echo '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block"><input type="hidden" name="action" value="uc_google_connect">'.wp_nonce_field('uc_google_connect','_wpnonce',true,false).'<button class="button">Connect Google Workspace</button></form>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block"><input type="hidden" name="action" value="uc_zoho_connect">'.wp_nonce_field('uc_zoho_connect','_wpnonce',true,false).'<button class="button">Connect Zoho Meeting</button></form></div>';
        echo '<p class="description" style="margin-top:12px">Google authorization: '.(get_option('uc_google_refresh_token') ? '<span class="uc-ok">Connected</span>' : '<span class="uc-warn">Not yet connected</span>').' &nbsp; Zoho authorization: '.(get_option('uc_zoho_refresh_token') ? '<span class="uc-ok">Connected</span>' : '<span class="uc-warn">Not yet connected</span>').' &nbsp; Teams app credentials: '.(get_option('uc_ms_tenant') && get_option('uc_ms_client_id') && get_option('uc_ms_client_secret') ? '<span class="uc-ok">Configured</span>' : '<span class="uc-warn">Incomplete</span>').'</p></div>';

        // Media Uploader Script
        ?>
        <script>
        jQuery(document).ready(function($){
            var file_frame;
            var defaultLogo = <?php echo wp_json_encode($default_logo); ?>;
            var defaultPreview = '<div class="uc-admin-brand-preview"><img id="uc_logo_preview" src="' + defaultLogo + '" alt="UniCybers"><span class="uc-source-academy" aria-label="Academy"><span>A</span><span>C</span><span>A</span><span>D</span><span>E</span><span>M</span><span>Y</span></span></div>';

            $('#uc_upload_logo_btn').on('click', function(e){
                e.preventDefault();
                if (file_frame) {
                    file_frame.open();
                    return;
                }
                file_frame = wp.media({
                    title: 'Select or Upload Academy Logo',
                    button: { text: 'Use As Academy Logo' },
                    multiple: false,
                    library: { type: 'image' }
                });
                file_frame.on('select', function(){
                    var attachment = file_frame.state().get('selection').first().toJSON();
                    if (attachment && attachment.url) {
                        $('#uc_logo_url').val(attachment.url);
                        if (attachment.url === defaultLogo) {
                            $('#uc_logo_preview_wrap').html(defaultPreview);
                        } else {
                            $('#uc_logo_preview_wrap').html($('<img>', {id:'uc_logo_preview', src:attachment.url, alt:'Academy logo'}).css({maxHeight:'68px',maxWidth:'260px',height:'auto',width:'auto',objectFit:'contain',display:'block'}));
                        }
                        $('#uc_remove_logo_btn').show();
                    }
                });
                file_frame.open();
            });

            $('#uc_remove_logo_btn').on('click', function(e){
                e.preventDefault();
                $('#uc_logo_url').val('');
                $('#uc_logo_preview_wrap').html(defaultPreview);
                $(this).hide();
            });
        });
        </script>
        <?php
        echo '</div>';
    }

    public function integrity_page() {
        if (!$this->can_manage()) return;
        global $wpdb;
        $dupes = $wpdb->get_results("SELECT course_id, name, COUNT(*) cnt, GROUP_CONCAT(id ORDER BY id) ids FROM {$this->table('batches')} GROUP BY course_id, name HAVING COUNT(*) > 1");
        echo '<div class="wrap"><h1>Data Integrity</h1>';
        $this->render_notice();
        echo '<div class="uc-panel"><h2>Duplicate batch names</h2>';
        if (!$dupes) echo '<p class="uc-ok">No duplicate batch names detected.</p>';
        else {
            echo '<p class="uc-danger">Duplicates were detected. Review them before deleting anything.</p><table class="widefat"><thead><tr><th>Course</th><th>Batch</th><th>Records</th><th>IDs</th></tr></thead><tbody>';
            foreach ($dupes as $d) echo '<tr><td>' . esc_html($d->course_id) . '</td><td>' . esc_html($d->name) . '</td><td>' . esc_html($d->cnt) . '</td><td>' . esc_html($d->ids) . '</td></tr>';
            echo '</tbody></table>';
        }
        echo '</div><div class="uc-panel"><h2>Legacy migration</h2><p>The original custom LMS tables are retained. Legacy class records are copied into the new sessions table with a legacy reference. Nothing is automatically erased.</p></div></div>';
    }

    public function migration_page() {
        if (!$this->can_manage()) return;
        echo '<div class="wrap"><h1>Migration</h1>';
        $this->render_notice();
        echo '<div class="uc-panel"><h2>Legacy LMS migration plan</h2><p>This WordPress LMS does not touch the existing Apps Script LMS. Use this page as the controlled migration checkpoint after workflow testing.</p><ol><li>Keep the existing Apps Script LMS live.</li><li>Validate courses, batches, students, classes, attendance and materials in WordPress.</li><li>Import legacy data only after the new workflow passes.</li><li>Compare record counts before switching users.</li><li>Keep the legacy data as read only backup until the WordPress LMS is accepted.</li></ol></div>';
        global $wpdb;
        $checks = [
            'Courses'     => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->table('courses')}"),
            'Batches'     => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->table('batches')}"),
            'Enrollments' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->table('enrolments')}"),
            'Sessions'    => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->table('sessions')}"),
            'Attendance'  => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->table('attendance')}"),
            'Materials'   => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$this->table('materials')}")
        ];
        echo '<div class="uc-panel"><h2>Current WordPress records</h2><table class="widefat striped"><thead><tr><th>Area</th><th>Records</th></tr></thead><tbody>';
        foreach ($checks as $k => $v) echo '<tr><td>' . esc_html($k) . '</td><td>' . absint($v) . '</td></tr>';
        echo '</tbody></table></div></div>';
    }

    public function create_zoom() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_POST['batch_id'] ?? 0);
        check_admin_referer('uc_create_zoom_' . $id);
        if (class_exists('UC_LMS_Zoom')) {
            $r = UC_LMS_Zoom::provision_batch_zoom($id);
            $this->redirect('uc-batches', ['edit' => $id] + $this->notice($r['status'] === 'error' ? 'error' : 'success', $r['message']));
        }
    }

    public function update_zoom() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_POST['batch_id'] ?? 0);
        check_admin_referer('uc_update_zoom_' . $id);
        if (class_exists('UC_LMS_Zoom')) {
            $r = UC_LMS_Zoom::provision_batch_zoom($id);
            $this->redirect('uc-batches', ['edit' => $id] + $this->notice($r['status'] === 'error' ? 'error' : 'success', $r['status'] === 'ready' ? 'Zoom meeting updated.' : $r['message']));
        }
    }

    public function test_zoom() {
        if (!$this->can_manage() || !check_admin_referer('uc_test_zoom')) wp_die('Not allowed');
        $r = class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::request('GET', '/users/me') : new WP_Error('zoom', 'Zoom class missing');
        if (is_wp_error($r)) $this->redirect('uc-settings', $this->notice('error', $r->get_error_message()));
        $email = $r['email'] ?? $r['display_name'] ?? 'account';
        $this->redirect('uc-settings', $this->notice('success', 'Zoom connected as ' . $email . '.'));
    }

    public function sync_recording() {
        if (!$this->can_manage()) wp_die('Not allowed');
        $id = absint($_POST['session_id'] ?? 0);
        check_admin_referer('uc_sync_recording_' . $id);
        global $wpdb;
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('sessions')} WHERE id=%d", $id));
        $r = ($s && class_exists('UC_LMS_Zoom')) ? UC_LMS_Zoom::sync_one_recording_safe($s) : new WP_Error('recording', 'Session not found.');
        if (is_wp_error($r)) $this->redirect('uc-sessions', ['edit' => $id] + $this->notice('error', $r->get_error_message()));
        $this->redirect('uc-sessions', ['edit' => $id] + $this->notice('success', 'Recording synced.'));
    }

    public function sync_all_recordings() {
        if (!$this->can_manage() || !check_admin_referer('uc_sync_all_recordings')) wp_die('Not allowed');
        $s = class_exists('UC_LMS_Zoom') ? UC_LMS_Zoom::portal_sync_recordings_now() : ['pulled' => 0, 'linked' => 0];
        $this->redirect('uc-sessions', $this->notice('success', ((int)($s['pulled'] ?? 0) + (int)($s['linked'] ?? 0)) . ' recordings synced.'));
    }

    public function cleanup_duplicates() {
        if (!$this->can_manage()) wp_die('Not allowed');
        check_admin_referer('uc_cleanup_duplicates');
        $this->redirect('uc-settings', $this->notice('success', 'Duplicate check completed.'));
    }
}
