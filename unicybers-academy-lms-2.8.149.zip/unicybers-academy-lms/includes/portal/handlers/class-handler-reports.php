<?php
/**
 * UniCybers Academy LMS: Operations report email handlers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Handler_Reports {
    public static function weekly_email($portal) {
        $portal->guard('uc_portal_weekly_email', ['super_admin']);
        $week = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_POST['week'] ?? '')) ? sanitize_text_field(wp_unslash($_POST['week'])) : '';
        $ok = $portal->send_weekly_digest($week, true);
        $portal->set_flash($ok ? 'Weekly report emailed. Full copy to rafi@unicybers.com. Attendance only to coordinator@unicybers.com.' : 'The weekly report could not be sent. Check the site mail setup.', $ok ? 'ok' : 'warn');
        $portal->back('reports', $week ? ['view' => 'weekly', 'week' => $week] : ['view' => 'weekly']);
    }

    public static function monthly_email($portal) {
        $portal->guard('uc_portal_monthly_email', ['super_admin']);
        $month = preg_match('/^\d{4}-\d{2}$/', (string)($_POST['month'] ?? '')) ? sanitize_text_field(wp_unslash($_POST['month'])) : '';
        $ok = $portal->send_monthly_digest($month, true);
        $portal->set_flash($ok ? 'Monthly report emailed. Full copy to rafi@unicybers.com. Attendance only to coordinator@unicybers.com.' : 'The monthly report could not be sent. Check the site mail setup.', $ok ? 'ok' : 'warn');
        $portal->back('reports', $month ? ['view' => 'monthly', 'month' => $month] : ['view' => 'monthly']);
    }
}
