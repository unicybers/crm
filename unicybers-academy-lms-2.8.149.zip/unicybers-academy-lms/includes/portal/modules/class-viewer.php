<?php
/**
 * UniCybers Academy LMS: Document Viewer Module.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Module_Viewer {
    public static function render($kind_or_portal = null, $id_or_kind = null, $portal_or_id = null){
        $portal = null;
        $kind = '';
        $id = 0;

        if ($kind_or_portal instanceof UC_LMS_Portal) {
            $portal = $kind_or_portal;
            $kind = is_string($id_or_kind) ? $id_or_kind : '';
            $id = is_numeric($portal_or_id) ? (int)$portal_or_id : 0;
        } elseif ($portal_or_id instanceof UC_LMS_Portal) {
            $portal = $portal_or_id;
            $kind = is_string($kind_or_portal) ? $kind_or_portal : '';
            $id = is_numeric($id_or_kind) ? (int)$id_or_kind : 0;
        } else {
            $portal = class_exists('UC_LMS_Portal') ? UC_LMS_Portal::instance() : null;
            $kind = is_string($kind_or_portal) && !empty($kind_or_portal) ? $kind_or_portal : sanitize_key(get_query_var('uc_kind'));
            $id = is_numeric($id_or_kind) && $id_or_kind > 0 ? (int)$id_or_kind : (int)get_query_var('uc_id');
        }

        if (!$portal && class_exists('UC_LMS_Portal')) {
            $portal = UC_LMS_Portal::instance();
        }
        if (!$kind) $kind = sanitize_key(get_query_var('uc_kind'));
        if (!$id) $id = (int)get_query_var('uc_id');

        global $wpdb;
        $ids = $portal ? $portal->batch_ids() : [];
        $direct = false;
        $url = '';
        $pass = '';
        if ($kind==='material') {
            $x = $wpdb->get_row($wpdb->prepare("SELECT m.*, b.name batch_name FROM {$portal->t('materials')} m JOIN {$portal->t('batches')} b ON b.id=m.batch_id WHERE m.id=%d", $id));
            if (!$x || !in_array((int)$x->batch_id,$ids,true) || (empty($x->visible) && !$portal->staff()) || (!empty($x->student_locked) && !$portal->staff())) return $portal->empty_state('Not available','This material is not shared with your batch.','materials');
            $title = $x->title; $meta = $x->batch_name; $url = $x->url;
        } else {
            $x = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.name batch_name, b.zoom_passcode FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.id=%d AND s.hidden=0", $id));
            if (!$x || !in_array((int)$x->batch_id,$ids,true)) return $portal->empty_state('Not available','This recording is not available for your batch.','play');
            $title = $x->title; $meta = $x->batch_name.' · '.$portal->fdate($x->session_date,'j M Y'); $url = $x->recording_url;
            $pass = trim((string)($x->passcode ?: $x->zoom_passcode ?: ''));
            if (!$portal->recording_playable($x)) {
                $portal->maybe_auto_pull_recording($x);
                $x = $wpdb->get_row($wpdb->prepare("SELECT s.*, b.name batch_name, b.zoom_passcode FROM {$portal->t('sessions')} s JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.id=%d AND s.hidden=0", $id));
                $url = $x ? $x->recording_url : $url;
            }
        }
        $src = $portal->embed($url, $pass);
        $direct = $src && (preg_match('~\.(mp4|webm|m4v)(\?|$)~i', $src) || preg_match('~/rec/download/~i', $src));
        $local = false;
        $mk = $kind==='material' ? $portal->material_kind($url) : '';
        $media = $kind==='material' ? home_url('/lms-media/material/'.(int)$id.'/') : '';
        $open = $url;
        if ($kind==='material' && in_array($mk, ['pdf','image','video','office','zip'], true) && $portal->local_upload_path($url)) $open = $media;
        if ($kind==='material') {
            if ($mk==='pdf' || $mk==='image') $src = $portal->local_upload_path($url) ? $media : ($src ?: $url);
            elseif ($mk==='video') {
                $src = $portal->local_upload_path($url) ? $media : ($src ?: $url);
                $direct = !empty($src) && (preg_match('~\.(mp4|webm|m4v)(\?|$)~i', $src) || $portal->local_upload_path($url));
            }
            elseif ($mk==='office') {
                if (!$src) $src = $portal->embed($url);
                if (!$src && preg_match('~^https?://~i', $url)) $src = 'https://view.officeapps.live.com/op/embed.aspx?src='.rawurlencode($url);
                $direct = false;
            }
            elseif ($mk==='web') {
                $emb = $portal->embed($url);
                $src = ($emb && $emb !== $url) ? $emb : '';
                $direct = false;
            }
        }
        if ($kind==='recording') {
            $media_stream = home_url('/lms-media/recording/'.(int)$id.'/');
            $framed = $src && class_exists('UC_LMS_Portal_Stream') && UC_LMS_Portal_Stream::framed_player($src);
            if ($framed) {
                $direct = false;
                $local = false;
            } elseif ($portal->recording_ready($x)) {
                $src = $media_stream;
                $direct = true;
                $local = true;
            } elseif ($url) {
                if (!$src) $src = $portal->embed($url, $pass);
                if (!$src && ($portal->recording_playable($x) || stripos($url, 'zoom.us') !== false)) {
                    $src = $media_stream;
                    $direct = true;
                }
            }
        }
        $o = '<div class="viewer"><div class="v-head"><a class="btn ghost sm" href="'.esc_url($portal->url('materials')).'" data-back-library>← Library</a><div><strong>'.$portal->e($title).'</strong><small>'.$portal->e($meta).'</small></div>';
        if ($kind==='material' && $mk==='web' && !$src && $url) $o .= '<a class="btn ghost sm" href="'.esc_url($url).'" target="_blank" rel="noopener">Open page</a>';
        $o .= '</div>';
        $again = '<a class="btn ghost sm" href="'.esc_url(home_url('/lms-view/'.($kind==='recording'?'recording':'material').'/'.(int)$id.'/')).'">Try again</a>';
        $link = ($kind==='recording' && $portal->staff()) ? $portal->recording_link_form($id, $url) : '';
        $pull = '';
        $upload = '';
        if ($kind==='recording' && $portal->staff()) {
            if (strtolower((string)($x->platform ?? '')) === 'zoom') {
                $pull = '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uc_portal_recording_pull"><input type="hidden" name="session_id" value="'.(int)$id.'">'.wp_nonce_field('uc_portal_recording_pull','_wpnonce',true,false).'<button class="btn primary sm" type="submit">Sync Zoom recording</button></form>';
            }
            $upload = '<form class="rec-up" method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data"><input type="hidden" name="action" value="uc_portal_recording_upload"><input type="hidden" name="session_id" value="'.(int)$id.'">'.wp_nonce_field('uc_portal_recording_upload','_wpnonce',true,false).'<span class="file-btn"><input type="file" name="file" accept="video/mp4,video/webm,.mp4,.m4v,.webm" required><span class="file-pick">Choose File</span><span class="file-name" data-file-name>No File Chosen</span></span><button class="btn ghost sm" type="submit">Upload to host</button></form>';
        }
        $o .= '<div class="v-frame" oncontextmenu="return false">';
        $o .= '<div class="v-guard-topright" aria-hidden="true"></div>';
        if ($kind==='recording' && strtolower((string)($x->platform ?? '')) === 'teams' && strtolower((string)($x->recording_status ?? '')) === 'available') {
            $src = home_url('/lms-media/recording/'.(int)$id.'/');
            $direct = true;
        }
        if ($kind==='recording' && $local) {
            $o .= '<video src="'.esc_url($src).'" controls playsinline controlslist="nodownload noplaybackrate" disablepictureinpicture oncontextmenu="return false" onerror="this.hidden=true;var f=this.parentNode.querySelector(\'.v-overlay\');if(f)f.hidden=false"></video>';
            $fallback_text = strtolower((string)($x->platform ?? '')) === 'zoom' ? 'The academy file could not be played. Sync the Zoom recording again.' : 'The recording could not be played. Check the provider connection and sync status.';
            $o .= '<div class="v-overlay" hidden><p>'.$portal->e($fallback_text).'</p>'.$pull.$again.'</div>';
        } elseif ($kind==='recording' && $src && $direct) {
            $o .= '<video src="'.esc_url($src).'" controls playsinline controlslist="nodownload noplaybackrate" disablepictureinpicture oncontextmenu="return false" onerror="this.hidden=true;var f=this.parentNode.querySelector(\'.v-overlay\');if(f)f.hidden=false"></video>';
            $o .= '<div class="v-overlay" hidden><p>This file could not be played.</p>'.$again.'</div>';
        } elseif ($kind==='recording' && $src) {
            $o .= '<iframe src="'.esc_url($src).'"'.((class_exists('UC_LMS_Portal_Stream') && UC_LMS_Portal_Stream::framed_player($src)) ? '' : ' sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-presentation"').' allow="autoplay; fullscreen; picture-in-picture" referrerpolicy="origin" loading="eager" style="width:100%;height:100%;border:none;min-height:550px"></iframe>';
        } elseif ($kind==='recording' && !empty($x->recording_status) && $x->recording_status==='pending_share') {
            $o .= '<div class="v-overlay"><p>Recording detected in Microsoft Teams. Your trainer is preparing its OneDrive or SharePoint viewing access.</p>'.$again.'</div>';
        } elseif ($kind==='recording') {
            $msg = $portal->staff()
                ? (strtolower((string)($x->platform ?? '')) === 'zoom' ? 'This class is not playable yet. Sync the Zoom recording if the cloud file exists.' : 'This recording is not available yet. Check the provider connection and run Sync Recordings again after processing completes.')
                : 'This recording is not available.';
            $o .= '<div class="v-overlay"><p>'.$portal->e($msg).'</p>'.($portal->staff()?$pull:'').$again.'</div>';
        } elseif ($kind==='material' && $mk==='zip' && $open) {
            $o .= $portal->staff()
                ? '<div class="v-overlay"><p>This is a ZIP file. Open it on your computer if you need the archive.</p><a class="btn primary sm" href="'.esc_url($open).'" target="_blank" rel="noopener">Open file</a>'.$again.'</div>'
                : '<div class="v-overlay"><p>Students cannot download files. Ask your trainer if you need this archive in class.</p>'.$again.'</div>';
        } elseif ($kind==='material' && $mk==='image' && $src) {
            $o .= '<img class="v-img" src="'.esc_url($src).'" alt="'.$portal->e($title).'">';
        } elseif ($src && $direct) {
            $o .= '<video src="'.esc_url($src).'" controls playsinline controlslist="nodownload noplaybackrate" disablepictureinpicture oncontextmenu="return false" onerror="this.hidden=true;var f=this.parentNode.querySelector(\'.v-overlay\');if(f)f.hidden=false"></video>';
            $o .= '<div class="v-overlay" hidden><p>This file could not be played.</p>'.$again.'</div>';
        } elseif ($src) {
            $o .= '<iframe src="'.esc_url($src).'"'.((class_exists('UC_LMS_Portal_Stream') && UC_LMS_Portal_Stream::framed_player($src)) ? '' : ' sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-presentation"').' allow="autoplay; fullscreen; picture-in-picture" referrerpolicy="origin" loading="eager" style="width:100%;height:100%;border:none;min-height:550px"></iframe>';
        } elseif ($kind==='material' && $mk==='web' && $url) {
            $o .= '<div class="v-overlay"><p>This is a web page. Sites such as Exploit Database or CVSS block the in-portal frame. Open it in a new tab.</p><a class="btn primary sm" href="'.esc_url($url).'" target="_blank" rel="noopener">Open page</a>'.$again.'</div>';
        } else {
            $extra = ($kind==='material' && $open) ? '<a class="btn primary sm" href="'.esc_url($open).'" target="_blank" rel="noopener">Open</a>' : '';
            $o .= '<div class="v-overlay"><p>This item cannot be shown inside the portal. Use Open to view the file or page.</p>'.$extra.$again.'</div>';
        }
        $viewer = wp_get_current_user();
        $watermark = trim((string)get_option('uc_watermark_text', 'UNICYBERS'));
        if ($watermark === '') $watermark = 'UNICYBERS';
        $o .= '<div class="v-watermark" aria-hidden="true">';
        for ($wi=0; $wi<4; $wi++) $o .= '<span>'.$portal->e($watermark).'</span>';
        $o .= '</div></div>';
        if ($portal->staff() && $kind==='recording' && !$local && !$src) {
            $o .= '<div class="v-tools">'.$pull.'</div>';
        }
        return $o.'</div>';
    }

}
