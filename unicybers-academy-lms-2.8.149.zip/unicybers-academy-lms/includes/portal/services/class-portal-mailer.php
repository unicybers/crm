<?php
/**
 * UniCybers Academy LMS: Portal Mailer & Digest Engine.
 *
 * Compiles and dispatches weekly/monthly operational digests.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Mailer {

    /**
     * Send weekly operations & attendance digest.
     *
     * @param UC_LMS_Portal $portal
     * @param string $week
     * @param bool $force
     * @return bool
     */
    public static function send_weekly_digest($portal, $week = '', $force = false) {
        global $wpdb;
        try { $tz = new DateTimeZone('Asia/Kolkata'); } catch (Exception $e) { $tz = new DateTimeZone('UTC'); }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$week)) {
            $start = new DateTime('now', $tz);
            $start->modify('monday this week')->modify('-7 days');
            $week = $start->format('Y-m-d');
        }
        if (!$force && get_option('uc_weekly_report_week') === $week) return true;
        $end = date('Y-m-d', strtotime($week . ' +6 days'));

        $finished_sql = "(s.session_date < CURDATE() OR (s.session_date=CURDATE() AND IFNULL(s.end_time,'23:59:00') < CURTIME()) OR LOWER(s.status) IN ('completed','finished'))";
        $held = $wpdb->get_results($wpdb->prepare("SELECT s.*, b.name batch_name, tu.display_name trainer_name FROM {$portal->t('sessions')} s LEFT JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$wpdb->users} tu ON tu.ID=b.trainer_user_id WHERE s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND {$finished_sql} ORDER BY s.session_date, s.start_time", $week, $end));
        $coming = $wpdb->get_results($wpdb->prepare("SELECT s.*, b.name batch_name, tu.display_name trainer_name FROM {$portal->t('sessions')} s LEFT JOIN {$portal->t('batches')} b ON b.id=s.batch_id LEFT JOIN {$wpdb->users} tu ON tu.ID=b.trainer_user_id WHERE s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND NOT ({$finished_sql}) ORDER BY s.session_date, s.start_time", $week, $end));

        $hours = 0.0;
        $byTrainer = [];
        $byBatch = [];
        foreach ($held as $s) {
            $h = $portal->session_hours($s);
            $hours += $h;
            $tid = (int)($s->trainer_user_id ?? 0);
            $tname = $s->trainer_name ?: 'Unassigned';
            if (!isset($byTrainer[$tname])) $byTrainer[$tname] = ['name' => $tname, 'hours' => 0.0, 'classes' => 0, 'batches' => []];
            $byTrainer[$tname]['hours'] += $h;
            $byTrainer[$tname]['classes']++;
            $byTrainer[$tname]['batches'][$s->batch_name] = true;

            $bid = (int)$s->batch_id;
            if (!isset($byBatch[$bid])) $byBatch[$bid] = ['name' => $s->batch_name, 'hours' => 0.0, 'classes' => 0, 'present' => 0, 'expected' => 0];
            $byBatch[$bid]['hours'] += $h;
            $byBatch[$bid]['classes']++;
        }

        $present = 0; $expected = 0; $absent = [];
        foreach ($held as $s) {
            $bid = (int)$s->batch_id;
            list($ignore, $roster, $map) = $portal->att_data($bid);
            foreach ($roster as $st) {
                $expected++; $byBatch[$bid]['expected']++;
                $a = $map[$st->ID][$s->id] ?? null;
                if ($a && $a->status === 'present') {
                    $present++; $byBatch[$bid]['present']++;
                } elseif (count($absent) < 25) {
                    $absent[] = $st->display_name . ' · ' . $s->title . ' · ' . $portal->fdate($s->session_date, 'j M');
                }
            }
        }
        $pct = $expected ? round($present * 100 / $expected) : 0;
        $enquiries = array_values(array_filter((array)get_option('uc_course_enquiries'), function($r) use ($week, $end) {
            $at = substr((string)($r['at'] ?? ''), 0, 10);
            return $at >= $week && $at <= $end;
        }));
        $enrolled = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('enrolments')} e JOIN {$wpdb->users} u ON u.ID=e.user_id WHERE e.status='active' AND e.enrolled_at BETWEEN %s AND %s AND " . $portal->demo_sql(), $week . ' 00:00:00', $end . ' 23:59:59'));
        $materials = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$portal->t('materials')} WHERE created_at BETWEEN %s AND %s", $week . ' 00:00:00', $end . ' 23:59:59'));
        $open_requests = $portal->has_table('access_requests') ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$portal->t('access_requests')} WHERE status='open'") : 0;
        $range = $portal->fdate($week, 'j M Y') . ' to ' . $portal->fdate($end, 'j M Y');
        $lines = function($rows) { return $rows ? implode("\n", $rows) : 'None'; };
        $trainer_lines = [];
        foreach ($byTrainer as $r) $trainer_lines[] = $r['name'] . ' — ' . $r['classes'] . ' classes, ' . number_format($r['hours'], 1) . ' h, ' . count($r['batches']) . ' batches';
        $batch_lines = [];
        foreach ($byBatch as $r) {
            $bp = $r['expected'] ? round($r['present'] * 100 / $r['expected']) . '%' : 'no roster';
            $batch_lines[] = $r['name'] . ' — ' . $r['classes'] . ' classes, ' . number_format($r['hours'], 1) . ' h, ' . $r['present'] . '/' . $r['expected'] . ' (' . $bp . ')';
        }
        $class_lines = [];
        foreach ($held as $s) $class_lines[] = $portal->fdate($s->session_date, 'j M') . ' · ' . $s->title . ' · ' . $s->batch_name . ' · ' . ($s->trainer_name ?: 'Unassigned') . ' · finished';
        $coming_lines = [];
        foreach ($coming as $s) $coming_lines[] = $portal->fdate($s->session_date, 'j M') . ' · ' . $s->title . ' · ' . $s->batch_name . ' · ' . ($s->trainer_name ?: 'Unassigned');
        $enquiry_lines = [];
        foreach (array_slice($enquiries, -15) as $r) $enquiry_lines[] = ($r['name'] ?? '') . ' · ' . ($r['email'] ?? '') . ' · ' . ($r['course'] ?? '') . (!empty($r['phone']) ? ' · ' . $r['phone'] : '');
        $shared = "UniCybers Academy week {$range}\n\n"
            . "Classes held: " . count($held) . "\n"
            . "Attendance: {$pct}% ({$present} of {$expected})\n"
            . "New students enrolled: {$enrolled}\n"
            . "Materials added: {$materials}\n"
            . "Course enquiries: " . count($enquiries) . "\n"
            . "Open access requests: {$open_requests}\n\n"
            . "Batches\n" . $lines($batch_lines) . "\n\n"
            . "Finished classes\n" . $lines($class_lines) . "\n\n"
            . "Absent\n" . $lines($absent) . "\n\n"
            . "Course enquiries\n" . $lines($enquiry_lines) . "\n\n"
            . "Coming up\n" . $lines($coming_lines) . "\n";
        $miss_lines = []; $short_lines = [];
        foreach ($held as $s) {
            $kind = $portal->rec_issue($s);
            if ($kind === 'missing') $miss_lines[] = $portal->fdate($s->session_date, 'j M') . ' · ' . $s->title . ' · ' . $s->batch_name;
            if ($kind === 'short') $short_lines[] = $portal->fdate($s->session_date, 'j M') . ' · ' . $s->title . ' · ' . $s->batch_name . ' · ' . round(((int)($s->recording_duration ?? 0)) / 60) . ' min';
        }
        $rafi = $shared . "\nMissing recordings\n" . $lines($miss_lines) . "\n\nShort recordings (under 20 min)\n" . $lines($short_lines) . "\n\nTrainers\n" . $lines($trainer_lines) . "\n\nTrainer hours: " . number_format($hours, 1) . "\n\nOpen Reports → Weekly Ops in the LMS for the same tables.\n";
        $coord = "UniCybers Academy attendance · {$range}\n\n"
            . "Attendance: {$pct}% ({$present} of {$expected})\n\n"
            . "Batches\n" . $lines($batch_lines) . "\n\n"
            . "Absent\n" . $lines($absent) . "\n\n"
            . "Open Reports → Attendance in the LMS.\n";
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        $subject = 'UniCybers Academy · Week of ' . $portal->fdate($week, 'j M Y');
        $ok_r = wp_mail('rafi@unicybers.com', $subject, $rafi, $headers);
        $ok_c = wp_mail('coordinator@unicybers.com', 'UniCybers Academy · Attendance ' . $portal->fdate($week, 'j M Y'), $coord, $headers);
        if ($ok_r || $ok_c) update_option('uc_weekly_report_week', $week, false);
        return (bool)($ok_r || $ok_c);
    }

    /**
     * Send monthly operations & attendance digest.
     *
     * @param UC_LMS_Portal $portal
     * @param string $month
     * @param bool $force
     * @return bool
     */
    public static function send_monthly_digest($portal, $month = '', $force = false) {
        global $wpdb;
        if (!preg_match('/^\d{4}-\d{2}$/', (string)$month)) {
            $month = date('Y-m', strtotime(current_time('Y-m-01') . ' -1 month'));
        }
        if (!$force && get_option('uc_monthly_report_month') === $month) return true;
        $start = $month . '-01';
        $end = date('Y-m-t', strtotime($start));
        $finished_sql = "(s.session_date < CURDATE() OR (s.session_date=CURDATE() AND IFNULL(s.end_time,'23:59:00') < CURTIME()) OR LOWER(s.status) IN ('completed','finished'))";
        $held = $wpdb->get_results($wpdb->prepare("SELECT s.*, b.name batch_name FROM {$portal->t('sessions')} s LEFT JOIN {$portal->t('batches')} b ON b.id=s.batch_id WHERE s.hidden=0 AND LOWER(s.status)<>'cancelled' AND s.session_date BETWEEN %s AND %s AND {$finished_sql} ORDER BY s.session_date, s.start_time", $start, $end));
        $present = 0; $expected = 0; $miss = []; $short = []; $absent = [];
        foreach ($held as $s) {
            list($ignore, $roster, $map) = $portal->att_data((int)$s->batch_id);
            foreach ($roster as $st) {
                $expected++;
                $a = $map[$st->ID][$s->id] ?? null;
                if ($a && $a->status === 'present') $present++;
                elseif (count($absent) < 40) $absent[] = $st->display_name . ' · ' . $s->title . ' · ' . $portal->fdate($s->session_date, 'j M');
            }
            $kind = $portal->rec_issue($s);
            if ($kind === 'missing') $miss[] = $portal->fdate($s->session_date, 'j M') . ' · ' . $s->title . ' · ' . $s->batch_name;
            if ($kind === 'short') $short[] = $portal->fdate($s->session_date, 'j M') . ' · ' . $s->title . ' · ' . $s->batch_name . ' · ' . round(((int)($s->recording_duration ?? 0)) / 60) . ' min';
        }
        $pct = $expected ? round($present * 100 / $expected) : 0;
        $range = $portal->fdate($start, 'j M Y') . ' to ' . $portal->fdate($end, 'j M Y');
        $lines = function($rows) { return $rows ? implode("\n", $rows) : 'None'; };
        $rafi = "UniCybers Academy month {$range}\n\nClasses held: " . count($held) . "\nAttendance: {$pct}% ({$present} of {$expected})\nMissing recordings: " . count($miss) . "\nShort recordings: " . count($short) . "\n\nMissing recordings\n" . $lines($miss) . "\n\nShort recordings (under 20 min)\n" . $lines($short) . "\n\nAbsent\n" . $lines($absent) . "\n";
        $coord = "UniCybers Academy attendance · {$range}\n\nAttendance: {$pct}% ({$present} of {$expected})\n\nAbsent\n" . $lines($absent) . "\n";
        $headers = ['Content-Type: text/plain; charset=UTF-8'];
        $ok_r = wp_mail('rafi@unicybers.com', 'UniCybers Academy · Month ' . $month, $rafi, $headers);
        $ok_c = wp_mail('coordinator@unicybers.com', 'UniCybers Academy · Attendance ' . $month, $coord, $headers);
        if ($ok_r || $ok_c) update_option('uc_monthly_report_month', $month, false);
        return (bool)($ok_r || $ok_c);
    }

}
