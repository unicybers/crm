<?php
/**
 * UniCybers Academy LMS: Course Materials & Practice Lab Handlers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Handler_Materials {

    public static function material_save($portal){
        $portal->guard('uc_portal_material_save',['super_admin','coordinator','trainer']);
        global $wpdb;
        $batch_id = absint($_POST['batch_id'] ?? 0);
        if (!in_array($batch_id, $portal->batch_ids(), true)) wp_die('That batch is not yours.',403);
        $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        $url = esc_url_raw(wp_unslash($_POST['url'] ?? ''));
        $id = absint($_POST['id'] ?? 0);
        $allowed = array_keys($portal->content_cats());
        $kind = sanitize_key(wp_unslash($_POST['type'] ?? 'notes'));
        if (!in_array($kind, $allowed, true)) $kind = 'notes';
        if ($id) {
            $m = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('materials')} WHERE id=%d", $id));
            if (!$m || !in_array((int)$m->batch_id, $portal->batch_ids(), true)) wp_die('That material is not yours.',403);
            if (!$title) { $portal->set_flash('Enter a display name.','warn'); $portal->back('materials'); }
            $wpdb->update($portal->t('materials'), ['title'=>$title,'type'=>$kind,'batch_id'=>$batch_id], ['id'=>$id]);
            $portal->set_flash('Display name saved.'); $portal->back('materials');
        }
        if (!empty($_FILES['file']['name'])) {
            if ((int)$_FILES['file']['size'] > 50 * 1024 * 1024) { $portal->set_flash('That file is over 50 MB. Paste a Drive link instead.','warn'); $portal->back('materials'); }
            require_once ABSPATH.'wp-admin/includes/file.php';
            $move = wp_handle_upload($_FILES['file'], ['test_form'=>false]);
            if (!empty($move['error'])) { $portal->set_flash($move['error'],'warn'); $portal->back('materials'); }
            if (!$title) $title = sanitize_file_name(wp_basename($move['file']));
            $folder = sanitize_text_field(wp_unslash($_POST['drive_folder'] ?? ''));
            $pushed = self::push_material_to_drive($portal, $move['file'], $title, $batch_id, $folder);
            if (is_wp_error($pushed)) {
                if (!empty($move['file']) && is_file($move['file'])) @unlink($move['file']);
                $portal->set_flash($pushed->get_error_message(),'warn');
                $portal->back('materials');
            }
            $url = $pushed;
        }
        if (!$title || !$url) { $portal->set_flash('Add a file or a link, and a display name.','warn'); $portal->back('materials'); }
        if ($portal->is_video_material((object)['type'=>$kind,'url'=>$url,'title'=>$title])) $kind = 'recording';
        $ok = $portal->insert_row('materials', ['batch_id'=>$batch_id,'title'=>$title,'type'=>$kind,'url'=>$url,'added_by'=>get_current_user_id(),'visible'=>1,'created_at'=>current_time('mysql')]);
        if (!$ok) $portal->db_fail('materials');
        $portal->set_flash('Material added to the library.'); $portal->back('materials');
    }

    public static function material_delete($portal){
        $portal->guard('uc_portal_material_delete',['super_admin','coordinator']);
        global $wpdb;
        $id = absint($_POST['id'] ?? 0);
        $m = $wpdb->get_row($wpdb->prepare("SELECT batch_id FROM {$portal->t('materials')} WHERE id=%d", $id));
        if (!$m || !in_array((int)$m->batch_id, $portal->batch_ids(), true)) wp_die('That material is not yours.',403);
        $wpdb->delete($portal->t('materials'), ['id'=>$id]);
        $portal->set_flash('Material deleted.'); $portal->back('materials');
    }

    public static function material_lock($portal){
            $portal->guard('uc_portal_material_lock',['super_admin','coordinator','trainer']);
            global $wpdb;
            $id = absint($_POST['id'] ?? 0);
            $m = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('materials')} WHERE id=%d", $id));
            if (!$m || !in_array((int)$m->batch_id, $portal->batch_ids(), true)) wp_die('That material is not yours.',403);
            $locked = !empty($_POST['locked']) ? 1 : 0;
            $wpdb->update($portal->t('materials'), ['student_locked'=>$locked], ['id'=>$id]);
            $portal->set_flash($locked ? 'Hidden from students. Staff can still open it.' : 'Opened. Students in the batch can see it now.');
            $portal->back('materials');
        }

    public static function practice_save($portal){
            $portal->guard('uc_portal_practice_save',['super_admin','coordinator','trainer']);
            global $wpdb;
            $batch_id = absint($_POST['batch_id'] ?? 0);
            if (!in_array($batch_id, $portal->batch_ids(), true)) wp_die('That batch is not yours.',403);
            $kind = sanitize_key(wp_unslash($_POST['kind'] ?? 'assignment'));
            if (!in_array($kind, ['assignment','mock','aptitude'], true)) $kind = 'assignment';
            $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
            if (!$title) { $portal->set_flash('Enter a title.','warn'); $portal->back('practice'); }
            $url = esc_url_raw(wp_unslash($_POST['url'] ?? ''));
            $paper = '';
            $brief_url = '';
            if ($kind === 'mock') {
                $body = sanitize_textarea_field(wp_unslash($_POST['body'] ?? ''));
                $day = sanitize_text_field(wp_unslash($_POST['mock_date'] ?? ''));
                $st = sanitize_text_field(wp_unslash($_POST['mock_start'] ?? ''));
                $en = sanitize_text_field(wp_unslash($_POST['mock_end'] ?? ''));
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) || !preg_match('/^\d{2}:\d{2}$/', $st) || $url==='') {
                    $portal->set_flash('Set the mock date, start time, and paste the meeting link.','warn');
                    $portal->back('practice');
                }
                $start = $day.' '.$st.':00';
                $end = (preg_match('/^\d{2}:\d{2}$/', $en) ? $day.' '.$en.':00' : null);
                $mock_days = array_values(array_unique(array_intersect(array_map('sanitize_text_field', (array)($_POST['mock_days'] ?? [])), ['1','2','3','4','5','6','7'])));
                $mock_until = sanitize_text_field(wp_unslash($_POST['mock_until'] ?? ''));
                $mock_extra = [];
                foreach (preg_split('/[\s,;]+/', (string)wp_unslash($_POST['mock_dates'] ?? '')) as $raw_day) {
                    $raw_day = trim($raw_day);
                    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $raw_day) && $raw_day !== $day) $mock_extra[$raw_day] = $raw_day;
                }
            } elseif ($kind === 'aptitude') {
                $body = 'Scheduled first-round aptitude. Students see it only while it is open.';
                $day = sanitize_text_field(wp_unslash($_POST['apt_date'] ?? ''));
                $st = sanitize_text_field(wp_unslash($_POST['apt_start'] ?? ''));
                $en = sanitize_text_field(wp_unslash($_POST['apt_end'] ?? ''));
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) || !preg_match('/^\d{2}:\d{2}$/', $st) || !preg_match('/^\d{2}:\d{2}$/', $en)) {
                    $portal->set_flash('Set the aptitude date, open time, and close time.','warn');
                    $portal->back('practice');
                }
                $start = $day.' '.$st.':00';
                $end = $day.' '.$en.':00';
                if (strtotime($end) <= strtotime($start)) { $portal->set_flash('Close time must be after the open time.','warn'); $portal->back('practice'); }
                $url = '';
                $paper = self::clean_paper(wp_unslash($_POST['paper'] ?? ''));
                $decoded = json_decode($paper, true);
                $has = false;
                if (is_array($decoded)) foreach ($decoded as $q) { if (($q['type'] ?? '') === 'mcq' && trim((string)($q['key'] ?? '')) !== '') $has = true; }
                if (!$has) { $portal->set_flash('Add at least one multiple-choice question with a correct option.','warn'); $portal->back('practice'); }
            } else {
                $body = sanitize_textarea_field(wp_unslash($_POST['body_asg'] ?? ''));
                $day = sanitize_text_field(wp_unslash($_POST['due_date'] ?? ''));
                $start = preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) ? $day.' 23:59:00' : null;
                $end = null;
                $paper = self::clean_paper(wp_unslash($_POST['paper'] ?? ''));
                if (!empty($_FILES['brief']['name'])) {
                    if ((int)$_FILES['brief']['size'] > 20 * 1024 * 1024) { $portal->set_flash('That brief is over 20 MB.','warn'); $portal->back('practice'); }
                    require_once ABSPATH.'wp-admin/includes/file.php';
                    $move = wp_handle_upload($_FILES['brief'], ['test_form'=>false]);
                    if (!empty($move['error'])) { $portal->set_flash($move['error'],'warn'); $portal->back('practice'); }
                    $brief_url = esc_url_raw($move['url']);
                }
            }
            $data = ['batch_id'=>$batch_id,'kind'=>$kind,'title'=>$title,'body'=>$body,'url'=>$url,'paper'=>$paper,'brief_url'=>$brief_url,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')];
            if ($start) { $data['due_at'] = $start; $data['starts_at'] = $start; }
            if ($end) $data['ends_at'] = $end;
            $ok = $portal->insert_row('practice', $data);
            if (!$ok) $portal->db_fail('practice');
            $made = 1;
            if ($kind === 'mock') {
                $more = $mock_extra;
                if ($mock_days && preg_match('/^\d{4}-\d{2}-\d{2}$/', $mock_until) && $mock_until > $day) {
                    $map = ['0'=>'1','1'=>'2','2'=>'3','3'=>'4','4'=>'5','5'=>'6','6'=>'7'];
                    $cursor = strtotime($day.' +1 day');
                    $stop = strtotime($mock_until);
                    $safety = 0;
                    while ($cursor && $cursor <= $stop && $safety < 120) {
                        $safety++;
                        $ucd = $map[date('w', $cursor)] ?? '';
                        if (in_array($ucd, $mock_days, true)) $more[date('Y-m-d', $cursor)] = date('Y-m-d', $cursor);
                        $cursor = strtotime('+1 day', $cursor);
                    }
                }
                foreach ($more as $extra_day) {
                    $copy = $data;
                    $copy['due_at'] = $extra_day.' '.$st.':00';
                    $copy['starts_at'] = $copy['due_at'];
                    $copy['ends_at'] = $end ? $extra_day.' '.$en.':00' : null;
                    $copy['created_at'] = current_time('mysql');
                    if ($portal->insert_row('practice', $copy)) $made++;
                }
            }
            $portal->set_flash($kind==='mock' ? ($made === 1 ? 'Mock scheduled for the batch.' : $made.' mocks scheduled for the batch.') : ($kind==='aptitude' ? 'Aptitude scheduled. Students see it only while it is open.' : 'Assignment added for the batch.'));
            $portal->back('practice');
        }

    public static function practice_done($portal){
            $portal->guard('uc_portal_practice_done',['student']);
            global $wpdb;
            $id = absint($_POST['id'] ?? 0);
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$portal->t('practice')} WHERE id=%d", $id));
            if (!$row || !in_array($row->kind, ['assignment','aptitude'], true) || !in_array((int)$row->batch_id, $portal->batch_ids(), true)) wp_die('That practice is not yours.',403);
            if ($row->kind === 'aptitude') {
                $now = current_time('timestamp');
                $open = $row->starts_at && $now >= strtotime($row->starts_at) && (!$row->ends_at || $now <= strtotime($row->ends_at));
                if (!$open) { $portal->set_flash('This aptitude is not open.','warn'); $portal->back('practice'); }
            }
            $uid = get_current_user_id();
            $paper = json_decode((string)($row->paper ?? ''), true);
            $answers = [];
            if (is_array($paper)) {
                foreach ($paper as $i=>$q) $answers[] = sanitize_textarea_field(wp_unslash($_POST['answer_'.$i] ?? ''));
            }
            $file_url = '';
            if (!empty($_FILES['work']['name'])) {
                if ((int)$_FILES['work']['size'] > 20 * 1024 * 1024) { $portal->set_flash('That file is over 20 MB.','warn'); $portal->back('practice'); }
                require_once ABSPATH.'wp-admin/includes/file.php';
                $move = wp_handle_upload($_FILES['work'], ['test_form'=>false]);
                if (!empty($move['error'])) { $portal->set_flash($move['error'],'warn'); $portal->back('practice'); }
                $file_url = esc_url_raw($move['url']);
            }
            $have = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$portal->t('practice_done')} WHERE practice_id=%d AND user_id=%d", $id, $uid));
            $save = ['answers'=>wp_json_encode($answers),'completed_at'=>current_time('mysql')];
            if ($file_url) $save['file_url'] = $file_url;
            if ($have) $wpdb->update($portal->t('practice_done'), $save, ['id'=>$have]);
            else $wpdb->insert($portal->t('practice_done'), $save + ['practice_id'=>$id,'user_id'=>$uid]);
            $portal->set_flash($row->kind === 'aptitude' ? 'Aptitude submitted. Your score is on the Placement Desk.' : 'Assignment submitted.');
            $portal->back('practice');
        }

    private static function clean_paper($raw){
        $decoded = json_decode((string)$raw, true);
        $clean = [];
        if (is_array($decoded)) {
            foreach (array_slice($decoded, 0, 40) as $q) {
                if (!is_array($q)) continue;
                $type = in_array(($q['type'] ?? ''), ['mcq','short','diagram'], true) ? $q['type'] : 'short';
                $prompt = sanitize_text_field($q['q'] ?? '');
                if ($prompt === '') continue;
                $row = ['type'=>$type,'q'=>$prompt];
                if ($type === 'mcq') {
                    $opts = [];
                    foreach (array_slice((array)($q['options'] ?? []), 0, 4) as $opt) {
                        $opt = sanitize_text_field($opt);
                        if ($opt !== '') $opts[] = $opt;
                    }
                    $row['options'] = $opts;
                    $row['key'] = sanitize_text_field($q['key'] ?? '');
                }
                $clean[] = $row;
            }
        }
        return wp_json_encode($clean);
    }

    private static function push_material_to_drive($portal, $path, $title, $batch_id, $folder){
        global $wpdb;
        if (!class_exists('UC_Academy_LMS') || !is_file($path)) return new WP_Error('drive', 'The file could not be sent to Drive.');
        $token = UC_Academy_LMS::instance()->portal_google_token();
        if ($token === '') return new WP_Error('drive', 'Connect Google in LMS Settings so materials can be stored in Drive. The file was not kept on WordPress.');
        $parent = trim($folder) !== '' ? trim($folder) : trim((string)get_option('uc_drive_materials_folder', '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi'));
        $batch_name = (string)$wpdb->get_var($wpdb->prepare("SELECT name FROM {$portal->t('batches')} WHERE id=%d", (int)$batch_id));
        if ($batch_name !== '') {
            $child = self::drive_child($token, $parent, $batch_name);
            if (!is_wp_error($child) && $child !== '') $parent = $child;
        }
        $meta = wp_json_encode(['name'=>$title, 'parents'=>[$parent]]);
        $boundary = 'uc'.wp_generate_password(12, false);
        $body = "--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n".file_get_contents($path)."\r\n--$boundary--";
        $response = wp_remote_post('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true', [
            'timeout'=>60,
            'headers'=>['Authorization'=>'Bearer '.$token, 'Content-Type'=>'multipart/related; boundary='.$boundary],
            'body'=>$body,
        ]);
        $data = is_wp_error($response) ? [] : json_decode(wp_remote_retrieve_body($response), true);
        $code = is_wp_error($response) ? 0 : (int)wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300 || empty($data['id'])) {
            $msg = is_array($data) ? (string)($data['error']['message'] ?? '') : '';
            return new WP_Error('drive', 'Drive did not store this file'.($msg ? ': '.$msg : '.').' Reconnect Google with Drive file access, or paste a Drive link. Nothing was kept on WordPress.');
        }
        return 'https://drive.google.com/file/d/'.$data['id'].'/view';
    }

    private static function drive_child($token, $parent, $name){
        $q = "'".str_replace("'", "\\'", $parent)."' in parents and name = '".str_replace("'", "\\'", $name)."' and mimeType = 'application/vnd.google-apps.folder' and trashed = false";
        $found = wp_remote_get('https://www.googleapis.com/drive/v3/files?'.http_build_query(['q'=>$q,'pageSize'=>5,'fields'=>'files(id)','supportsAllDrives'=>'true','includeItemsFromAllDrives'=>'true']), ['timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$token]]);
        $data = is_wp_error($found) ? [] : json_decode(wp_remote_retrieve_body($found), true);
        if (!empty($data['files'][0]['id'])) return (string)$data['files'][0]['id'];
        $made = wp_remote_post('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true', [
            'timeout'=>20,
            'headers'=>['Authorization'=>'Bearer '.$token, 'Content-Type'=>'application/json'],
            'body'=>wp_json_encode(['name'=>$name,'mimeType'=>'application/vnd.google-apps.folder','parents'=>[$parent]]),
        ]);
        $row = is_wp_error($made) ? [] : json_decode(wp_remote_retrieve_body($made), true);
        return !empty($row['id']) ? (string)$row['id'] : $parent;
    }
}
