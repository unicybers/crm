<?php
/**
 * UniCybers Academy LMS: Portal User & Access Context.
 *
 * Encapsulates role resolution, batch scoping, and timezones.
 * Shared across all portal modules for consistent access control.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Context {
    const KNOWN_ROLES = [
        'rafi@unicybers.com'        => 'super_admin',
        'coordinator@unicybers.com' => 'coordinator',
        'sofia@unicybers.com'       => 'coordinator',
        'noori@unicybers.com'       => 'coordinator',
        'ranjan@unicybers.com'      => 'trainer',
        'shoaib@unicybers.com'      => 'trainer',
    ];

    private static $batch_ids_cache = null;

    public static function user() {
        return wp_get_current_user();
    }

    public static function user_id() {
        return get_current_user_id();
    }

    public static function user_email() {
        $u = self::user();
        return strtolower((string)($u->user_email ?? ''));
    }

    public static function user_name() {
        $u = self::user();
        return $u->display_name ?: $u->user_login;
    }

    public static function role() {
        if (!is_user_logged_in()) return 'guest';
        if (get_user_meta(get_current_user_id(), 'uc_client_preview', true) === '1' && class_exists('UC_LMS_Portal')) {
            return UC_LMS_Portal::preview_view_role();
        }
        $email = self::user_email();
        if (isset(self::KNOWN_ROLES[$email])) return self::KNOWN_ROLES[$email];

        $u = self::user();
        $roles = (array)$u->roles;
        if (in_array('uc_coordinator', $roles, true)) return 'coordinator';
        if (in_array('uc_hr', $roles, true)) return 'hr';
        if (in_array('uc_trainer', $roles, true)) return 'trainer';
        if (in_array('uc_student', $roles, true)) return 'student';
        if (user_can($u, 'manage_options') || in_array('administrator', $roles, true)) return 'super_admin';

        return 'student';
    }

    public static function role_label() {
        $map = [
            'super_admin' => 'Super Admin',
            'coordinator' => 'Coordinator',
            'hr'          => 'Placement HR',
            'trainer'     => 'Trainer',
            'student'     => 'Student',
            'guest'       => 'Guest'
        ];
        return $map[self::role()] ?? 'Member';
    }

    public static function staff() {
        return in_array(self::role(), ['super_admin', 'coordinator', 'trainer'], true);
    }

    public static function ops() {
        return in_array(self::role(), ['super_admin', 'coordinator'], true);
    }

    public static function batch_ids() {
        if (self::$batch_ids_cache !== null) return self::$batch_ids_cache;
        global $wpdb;
        $uid = self::user_id();
        $r   = self::role();
        $tb  = UC_LMS_Database::table('batches');
        $ts  = UC_LMS_Database::table('sessions');
        $te  = UC_LMS_Database::table('enrolments');

        if ($r === 'super_admin' || $r === 'coordinator') {
            self::$batch_ids_cache = array_map('intval', (array)$wpdb->get_col("SELECT id FROM `$tb`"));
        } elseif ($r === 'trainer') {
            self::$batch_ids_cache = array_map('intval', (array)$wpdb->get_col($wpdb->prepare("SELECT id FROM `$tb` WHERE trainer_user_id=%d UNION SELECT DISTINCT batch_id FROM `$ts` WHERE trainer_user_id=%d", $uid, $uid)));
        } else {
            self::$batch_ids_cache = array_map('intval', (array)$wpdb->get_col($wpdb->prepare("SELECT batch_id FROM `$te` WHERE user_id=%d AND status='active'", $uid)));
        }
        return self::$batch_ids_cache;
    }

    public static function in_ids($ids = null) {
        if ($ids === null) $ids = self::batch_ids();
        $ids = array_filter(array_map('intval', (array)$ids));
        return $ids ? implode(',', $ids) : '0';
    }

    public static function demo_sql($col = 'u.user_email') {
        return "{$col} NOT REGEXP '^demo[0-9]{2}@unicybers\\\\.com$'";
    }

    public static function academy_tz() {
        return 'Asia/Kolkata';
    }

    public static function valid_tz($tz) {
        $tz  = trim((string)$tz);
        $key = strtolower($tz);
        $utc = ['', 'utc', 'gmt', 'gmt+0', 'gmt0', 'etc/utc', 'etc/gmt', 'etc/gmt+0', 'utc+0', 'utc+00', '+00:00', '+00', '0', 'z'];
        if (in_array($key, $utc, true) || $key === 'ist' || $key === 'india' || $key === 'asia/calcutta') {
            return self::academy_tz();
        }
        try { new DateTimeZone($tz); return $tz; } catch (Exception $e) { return self::academy_tz(); }
    }

    public static function now_in_tz($tz = '') {
        $tz = self::valid_tz($tz ?: self::academy_tz());
        try { return new DateTime('now', new DateTimeZone($tz)); }
        catch (Exception $e) { return new DateTime('now', new DateTimeZone('Asia/Kolkata')); }
    }
}
