<?php
/**
 * UniCybers Academy LMS: Intelligence Schema & Database Installer.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Intelligence_Schema {
    public static function t($n) {
        global $wpdb;
        return $wpdb->prefix.'uc_'.$n;
    }

    public static function has($n) {
        global $wpdb;
        static $c = [];
        if (!isset($c[$n])) $c[$n] = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', self::t($n))) === self::t($n));
        return $c[$n];
    }

    public static function install() {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        $p = $wpdb->prefix.'uc_';
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE {$p}intel_status (
            session_id bigint unsigned NOT NULL,
            recording_state varchar(20) NOT NULL DEFAULT 'unavailable',
            transcript_state varchar(20) NOT NULL DEFAULT 'unavailable',
            summary_state varchar(20) NOT NULL DEFAULT 'unavailable',
            attendance_state varchar(20) NOT NULL DEFAULT 'unavailable',
            participants_state varchar(20) NOT NULL DEFAULT 'unavailable',
            tasks_state varchar(20) NOT NULL DEFAULT 'unavailable',
            polls_state varchar(20) NOT NULL DEFAULT 'unavailable',
            chapters_state varchar(20) NOT NULL DEFAULT 'unavailable',
            last_error text NULL,
            last_sync datetime NULL,
            PRIMARY KEY  (session_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}intel_participants (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            session_id bigint unsigned NOT NULL,
            user_id bigint unsigned NULL,
            zoom_user_id varchar(80) NULL,
            display_name varchar(190) NOT NULL DEFAULT '',
            email varchar(190) NULL,
            join_time datetime NULL,
            leave_time datetime NULL,
            duration_seconds int unsigned NOT NULL DEFAULT 0,
            attendance_status varchar(20) NOT NULL DEFAULT 'absent',
            PRIMARY KEY  (id),
            UNIQUE KEY session_zoom (session_id, zoom_user_id),
            KEY session_id (session_id),
            KEY user_id (user_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}intel_cues (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            session_id bigint unsigned NOT NULL,
            kind varchar(20) NOT NULL DEFAULT 'transcript',
            t_seconds int unsigned NOT NULL DEFAULT 0,
            heading varchar(255) NULL,
            body longtext NULL,
            PRIMARY KEY  (id),
            KEY session_kind (session_id, kind)
        ) $c;");
        dbDelta("CREATE TABLE {$p}intel_summaries (
            session_id bigint unsigned NOT NULL,
            recap longtext NULL,
            topics longtext NULL,
            next_steps longtext NULL,
            published tinyint(1) NOT NULL DEFAULT 0,
            updated_at datetime NULL,
            PRIMARY KEY  (session_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}intel_tasks (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            session_id bigint unsigned NOT NULL,
            title varchar(255) NOT NULL,
            body longtext NULL,
            status varchar(20) NOT NULL DEFAULT 'draft',
            zoom_ref varchar(80) NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_ref (session_id, zoom_ref),
            KEY session_id (session_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}intel_polls (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            session_id bigint unsigned NOT NULL,
            zoom_poll_id varchar(80) NULL,
            question varchar(255) NOT NULL,
            options_json longtext NULL,
            published tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY session_poll (session_id, zoom_poll_id),
            KEY session_id (session_id)
        ) $c;");
        dbDelta("CREATE TABLE {$p}intel_views (
            session_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            viewed_at datetime NULL,
            PRIMARY KEY  (session_id, user_id),
            KEY user_id (user_id)
        ) $c;");
        $mat = $p.'materials';
        $col = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM {$mat} LIKE %s", 'session_id'));
        if (!$col) $wpdb->query("ALTER TABLE {$mat} ADD session_id bigint unsigned NULL, ADD KEY session_id (session_id)");
        add_option('uc_attend_present_pct', 90);
        add_option('uc_attend_partial_pct', 50);
        add_option('uc_zoom_webhook_secret', '');
    }
}
