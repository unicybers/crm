<?php
/**
 * UniCybers Academy LMS: Google Workspace & Google Meet Provider.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Meeting_Google {

    public static function google_connect(){
            if (!UC_LMS_Meeting::instance()->can_manage()) wp_die('Not allowed');
            check_admin_referer('uc_google_connect');
            $id = trim((string)get_option('uc_google_client_id', ''));
            if ($id === '') UC_LMS_Meeting::instance()->redirect('uc-settings', UC_LMS_Meeting::instance()->notice('error', 'Save the Google client ID first.'));
            $url = 'https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query([
                'client_id' => $id,
                'redirect_uri' => admin_url('admin-post.php?action=uc_google_oauth'),
                'response_type' => 'code',
                'access_type' => 'offline',
                'prompt' => 'consent',
                'login_hint' => 'rafi@unicybers.com',
                'scope' => implode(' ', [
                    'https://www.googleapis.com/auth/calendar.events',
                    'https://www.googleapis.com/auth/drive', // Needed only when the optional Drive download restriction is enabled.
                    
                    'https://www.googleapis.com/auth/drive.meet.readonly',
                    'https://www.googleapis.com/auth/meetings.space.settings',
                    'https://www.googleapis.com/auth/meetings.space.readonly',
                ]),
            ]);
            wp_redirect($url);
            exit;
        }

    public static function google_oauth(){
            if (!UC_LMS_Meeting::instance()->can_manage()) wp_die('Not allowed');
            $code = sanitize_text_field(wp_unslash($_GET['code'] ?? ''));
            if ($code === '') UC_LMS_Meeting::instance()->redirect('uc-settings', UC_LMS_Meeting::instance()->notice('error', 'Google did not return a connection code.'));
            $id = trim((string)get_option('uc_google_client_id', ''));
            $secret = trim((string)get_option('uc_google_client_secret', ''));
            $response = wp_remote_post('https://oauth2.googleapis.com/token', ['timeout'=>20, 'body'=>[
                'code' => $code,
                'client_id' => $id,
                'client_secret' => $secret,
                'redirect_uri' => admin_url('admin-post.php?action=uc_google_oauth'),
                'grant_type' => 'authorization_code',
            ]]);
            $data = is_wp_error($response) ? [] : json_decode(wp_remote_retrieve_body($response), true);
            if (empty($data['refresh_token']) && empty($data['access_token'])) {
                $msg = is_wp_error($response) ? $response->get_error_message() : (string)($data['error_description'] ?? 'Google did not connect.');
                UC_LMS_Meeting::instance()->redirect('uc-settings', UC_LMS_Meeting::instance()->notice('error', $msg));
            }
            if (!empty($data['refresh_token'])) update_option('uc_google_refresh_token', $data['refresh_token']);
            if (!empty($data['access_token'])) set_transient('uc_google_access', $data['access_token'], 50 * MINUTE_IN_SECONDS);
            UC_LMS_Meeting::instance()->redirect('uc-settings', UC_LMS_Meeting::instance()->notice('success', 'Google Workspace is connected for rafi@unicybers.com. New Meet classes can record automatically, and Sync recordings can read Meet files in Drive.'));
        }

    public static function google_access_token(){
            $cached = get_transient('uc_google_access');
            if (is_string($cached) && $cached !== '') return $cached;
            $id = trim((string)get_option('uc_google_client_id', ''));
            $secret = trim((string)get_option('uc_google_client_secret', ''));
            $refresh = trim((string)get_option('uc_google_refresh_token', ''));
            if (!$id || !$secret || !$refresh) return new WP_Error('google', 'Connect rafi@unicybers.com in LMS Settings, then press Generate link. The class is saved.');
            $response = wp_remote_post('https://oauth2.googleapis.com/token', ['timeout'=>20, 'body'=>[
                'client_id' => $id,
                'client_secret' => $secret,
                'refresh_token' => $refresh,
                'grant_type' => 'refresh_token',
            ]]);
            $data = is_wp_error($response) ? [] : json_decode(wp_remote_retrieve_body($response), true);
            if (empty($data['access_token'])) {
                $msg = is_wp_error($response) ? $response->get_error_message() : (string)($data['error_description'] ?? 'Google refused the saved connection.');
                return new WP_Error('google', $msg);
            }
            set_transient('uc_google_access', $data['access_token'], 50 * MINUTE_IN_SECONDS);
            return $data['access_token'];
        }

    public static function portal_google_token(){
            $token = self::google_access_token();
            return is_wp_error($token) ? '' : (string)$token;
        }

    public static function google_create_meet($title, $date, $start, $end, $tz){
            $token = self::google_access_token();
            if (is_wp_error($token)) return $token;
            $cal = trim((string)get_option('uc_google_calendar_id', 'rafi@unicybers.com'));
            if ($cal === '') $cal = 'rafi@unicybers.com';
            $tz = $tz ?: 'Asia/Kolkata';
            try { $zone = new DateTimeZone($tz); } catch (Exception $e) { $zone = new DateTimeZone('Asia/Kolkata'); $tz = 'Asia/Kolkata'; }
            $startDt = DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$start, 0, 5), $zone);
            if (!$startDt) return new WP_Error('google', 'Class date or start time is not valid for Google Calendar.');
            $endDt = $end ? DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$end, 0, 5), $zone) : false;
            if (!$endDt || $endDt <= $startDt) { $endDt = clone $startDt; $endDt->modify('+90 minutes'); }
            $body = [
                'summary' => 'UniCybers: '.$title,
                'description' => "UniCybers Academy LMS\n\nStudents should join through the UniCybers LMS.",
                'start' => ['dateTime' => $startDt->format(DateTime::RFC3339), 'timeZone' => $tz],
                'end' => ['dateTime' => $endDt->format(DateTime::RFC3339), 'timeZone' => $tz],
                'conferenceData' => ['createRequest' => [
                    'requestId' => 'unicybers-'.wp_generate_password(12, false),
                    'conferenceSolutionKey' => ['type' => 'hangoutsMeet'],
                ]],
            ];
            $url = 'https://www.googleapis.com/calendar/v3/calendars/'.rawurlencode($cal).'/events?conferenceDataVersion=1&sendUpdates=none';
            $event = self::google_calendar_call($token, 'POST', $url, $body);
            if (is_wp_error($event)) return $event;
            $link = self::meet_link_from_event($event);
            $eventId = (string)($event['id'] ?? '');
            for ($i = 0; $i < 3 && $link === '' && $eventId !== ''; $i++) {
                sleep(1);
                $again = self::google_calendar_call($token, 'GET', 'https://www.googleapis.com/calendar/v3/calendars/'.rawurlencode($cal).'/events/'.rawurlencode($eventId), null);
                if (!is_wp_error($again)) { $event = $again; $link = self::meet_link_from_event($event); }
            }
            if ($link === '') return new WP_Error('google', 'Google Calendar saved the class but Meet was not ready. Press Generate link again.');
            $code = self::meet_code_from_url($link);
            $space = $code !== '' ? 'spaces/'.$code : '';
            $record = self::meet_set_auto_record($token, $code);
            $note = '';
            if (is_wp_error($record)) $note = $record->get_error_message();
            return [
                'join_url' => $link,
                'calendar_event_id' => $eventId,
                'meet_code' => $code,
                'meet_space_name' => $space,
                'record_note' => $note,
            ];
        }

    public static function google_update_meet_event($event_id, $title, $date, $start, $end, $tz){
        $event_id = trim((string)$event_id);
        if ($event_id === '') return new WP_Error('google_event', 'Google Calendar event ID is missing.');
        $token = self::google_access_token();
        if (is_wp_error($token)) return $token;
        $cal = trim((string)get_option('uc_google_calendar_id', 'primary')) ?: 'primary';
        try { $zone = new DateTimeZone($tz ?: 'Asia/Kolkata'); } catch (Exception $e) { $zone = new DateTimeZone('Asia/Kolkata'); $tz = 'Asia/Kolkata'; }
        $start_dt = DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$start,0,5), $zone);
        if (!$start_dt) return new WP_Error('google_event', 'Class date or start time is invalid.');
        $end_dt = $end ? DateTime::createFromFormat('Y-m-d H:i', $date.' '.substr((string)$end,0,5), $zone) : false;
        if (!$end_dt || $end_dt <= $start_dt) { $end_dt = clone $start_dt; $end_dt->modify('+90 minutes'); }
        $url = 'https://www.googleapis.com/calendar/v3/calendars/'.rawurlencode($cal).'/events/'.rawurlencode($event_id);
        $body = ['summary'=>'UniCybers: '.$title,'start'=>['dateTime'=>$start_dt->format(DateTime::RFC3339),'timeZone'=>$tz ?: 'Asia/Kolkata'],'end'=>['dateTime'=>$end_dt->format(DateTime::RFC3339),'timeZone'=>$tz ?: 'Asia/Kolkata']];
        $event = self::google_calendar_call($token, 'PATCH', $url, $body);
        if (is_wp_error($event)) return $event;
        $link = self::meet_link_from_event($event);
        return ['join_url'=>$link,'calendar_event_id'=>$event_id,'meet_code'=>self::meet_code_from_url($link),'meet_space_name'=>self::meet_code_from_url($link) ? 'spaces/'.self::meet_code_from_url($link) : ''];
    }

    public static function meet_code_from_url($url){
            if (preg_match('~meet\.google\.com/([a-z]{3}-[a-z]{4}-[a-z]{3})~i', (string)$url, $m)) return strtolower($m[1]);
            return '';
        }

    public static function meet_set_auto_record($token, $code){
            $code = strtolower(trim((string)$code));
            if ($code === '') return new WP_Error('meet_record', 'This Meet room has no meeting code, so automatic recording was not turned on.');
            $url = 'https://meet.googleapis.com/v2/spaces/'.rawurlencode($code).'?updateMask='.rawurlencode('config.artifactConfig.recordingConfig.autoRecordingGeneration');
            $response = wp_remote_request($url, [
                'timeout' => 25,
                'method' => 'PATCH',
                'headers' => ['Authorization'=>'Bearer '.$token, 'Content-Type'=>'application/json'],
                'body' => wp_json_encode(['config'=>['artifactConfig'=>['recordingConfig'=>['autoRecordingGeneration'=>'ON']]]]),
            ]);
            if (is_wp_error($response)) return $response;
            $status = (int)wp_remote_retrieve_response_code($response);
            if ($status >= 200 && $status < 300) return true;
            $data = json_decode(wp_remote_retrieve_body($response), true);
            $msg = is_array($data) ? (string)($data['error']['message'] ?? '') : '';
            if ($status === 403 || stripos($msg, 'insufficient') !== false || stripos($msg, 'permission') !== false) {
                return new WP_Error('meet_record', 'Automatic Meet recording needs a fresh Google connection. In LMS Settings press Connect rafi@unicybers.com again, and allow Meet recording for that account in the Workspace admin.');
            }
            return new WP_Error('meet_record', $msg !== '' ? $msg : 'Google did not turn on automatic recording for this Meet room.');
        }

    public static function meet_link_from_event($event){
            if (!empty($event['hangoutLink'])) return (string)$event['hangoutLink'];
            foreach ((array)($event['conferenceData']['entryPoints'] ?? []) as $point) {
                if (($point['entryPointType'] ?? '') === 'video' && !empty($point['uri'])) return (string)$point['uri'];
            }
            return '';
        }

    public static function google_calendar_call($token, $method, $url, $body){
            $args = ['timeout'=>30, 'method'=>$method, 'headers'=>['Authorization'=>'Bearer '.$token, 'Content-Type'=>'application/json']];
            if ($body !== null) $args['body'] = wp_json_encode($body);
            $response = wp_remote_request($url, $args);
            if (is_wp_error($response)) return $response;
            $code = (int)wp_remote_retrieve_response_code($response);
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if ($code < 200 || $code >= 300) {
                $msg = is_array($data) ? (string)($data['error']['message'] ?? 'Google Calendar refused the room.') : 'Google Calendar refused the room.';
                return new WP_Error('google', $msg);
            }
            return is_array($data) ? $data : [];
        }

    public static function now() {
        return current_time('mysql');
    }

    public static function meet_code_from_session($session) {
        return UC_LMS_Meeting_Drive::meet_code_from_session($session);
    }

    public static function meet_arm_upcoming(){
            $token = self::google_access_token();
            if (is_wp_error($token)) return $token;
            global $wpdb;
            $table = UC_LMS_Meeting::instance()->table('sessions');
            $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE hidden=0 AND LOWER(IFNULL(status,''))<>'cancelled' AND LOWER(IFNULL(platform,'')) IN ('google_meet','meet') AND session_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 21 DAY AND IFNULL(join_url,'')<>'' LIMIT 40");
            $last = null;
            foreach ((array)$rows as $s) {
                $code = self::meet_code_from_session($s);
                if ($code === '') continue;
                if (empty($s->meet_code)) $wpdb->update($table, ['meet_code'=>$code, 'meet_space_name'=>'spaces/'.$code, 'updated_at'=>self::now()], ['id'=>(int)$s->id]);
                if (get_transient('uc_meet_arm_'.$code)) continue;
                $set = self::meet_set_auto_record($token, $code);
                if (is_wp_error($set)) { if (!$last) $last = $set; }
                else set_transient('uc_meet_arm_'.$code, 1, 12 * HOUR_IN_SECONDS);
            }
            return $last ?: true;
        }

    public static function keep_google_secret($value){
            $value = is_string($value) ? trim($value) : '';
            return $value !== '' ? $value : (string)get_option('uc_google_client_secret', '');
        }
}
