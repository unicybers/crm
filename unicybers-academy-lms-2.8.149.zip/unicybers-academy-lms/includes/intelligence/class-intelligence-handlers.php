<?php
/**
 * UniCybers Academy LMS: Intelligence Webhook & Action Handlers.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Intelligence_Handlers {

    public static function routes() {
        register_rest_route('uc-lms/v1', '/zoom/webhook', [
            'methods' => 'POST',
            'permission_callback' => '__return_true',
            'callback' => [__CLASS__, 'webhook'],
        ]);
    }

    public static function webhook(WP_REST_Request $req) {
        $secret = (string) get_option('uc_zoom_webhook_secret', '');
        $hdr = (string) $req->get_header('x-zm-signature');
        $ts = (string) $req->get_header('x-zm-request-timestamp');
        $raw = $req->get_body();
        $data = json_decode($raw, true);
        if (!empty($data['event']) && $data['event'] === 'endpoint.url_validation') {
            $plain = (string)($data['payload']['plainToken'] ?? '');
            $hash = hash_hmac('sha256', $plain, $secret);
            return new WP_REST_Response(['plainToken' => $plain, 'encryptedToken' => $hash], 200);
        }
        if ($secret !== '') {
            $expect = 'v0='.hash_hmac('sha256', 'v0:'.$ts.':'.$raw, $secret);
            if (!hash_equals($expect, $hdr)) {
                return new WP_Error('zoom_hook', 'Invalid signature', ['status' => 401]);
            }
        } else {
            return ['ok' => true, 'ignored' => 'Webhook secret is not set'];
        }
        $event = (string)($data['event'] ?? '');
        $uuid = (string)($data['payload']['object']['uuid'] ?? $data['payload']['object']['id'] ?? '');
        if ($uuid === '') return ['ok' => true];
        global $wpdb;
        $t_sessions = self::t('sessions');
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t_sessions} WHERE zoom_uuid=%s LIMIT 1", $uuid));
        if (!$s && !empty($data['payload']['object']['id'])) {
            $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t_sessions} WHERE zoom_meeting_id=%s ORDER BY session_date DESC LIMIT 1", (string)$data['payload']['object']['id']));
        }
        if ($s) {
            if (strpos($event, 'recording') !== false && class_exists('UC_Academy_LMS') && method_exists('UC_Academy_LMS', 'sync_one_recording_safe')) {
                UC_Academy_LMS::instance()->sync_one_recording_safe($s);
            } else {
                UC_LMS_Intelligence_Sync::sync_session($s);
            }
        }
        return ['ok' => true, 'event' => $event];
    }

    public static function guard_staff($nonce) {
        if (!is_user_logged_in() || !wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', $nonce) || !self::staff_user()) wp_die('Not allowed');
    }

    public static function staff_user() {
        if (!is_user_logged_in()) return false;
        $u = wp_get_current_user();
        $email = strtolower((string)$u->user_email);
        if (isset(UC_LMS_Portal::KNOWN_ROLES[$email])) return UC_LMS_Portal::KNOWN_ROLES[$email] !== 'student';
        $roles = (array)$u->roles;
        if (array_intersect($roles, ['administrator','uc_coordinator','uc_trainer'])) return true;
        return user_can($u, 'manage_options');
    }

    public static function h_sync() {
        self::guard_staff('uc_portal_intel_sync');
        $id = absint($_POST['session_id'] ?? 0);
        global $wpdb;
        $t_sessions = self::t('sessions');
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t_sessions} WHERE id=%d", $id));
        if (!$s) wp_die('Missing class');
        if (class_exists('UC_Academy_LMS') && method_exists('UC_Academy_LMS', 'sync_one_recording_safe')) {
            UC_Academy_LMS::instance()->sync_one_recording_safe($s);
        }
        $platform = strtolower((string)($s->platform ?? ''));
        if ($platform === 'google_meet' && class_exists('UC_LMS_Meeting')) UC_LMS_Meeting::instance()->portal_sync_meet_folder();
        if (in_array($platform, ['zoho','zoho_meeting'], true) && class_exists('UC_LMS_Meeting_Zoho')) UC_LMS_Meeting_Zoho::sync_recordings();
        if ($platform === 'teams' && class_exists('UC_LMS_Meeting_Teams')) UC_LMS_Meeting_Teams::sync_recordings();
        $s = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t_sessions} WHERE id=%d", $id));
        UC_LMS_Intelligence_Sync::sync_session($s);
        $has = $wpdb->get_var($wpdb->prepare("SELECT recap FROM ".self::t('intel_summaries')." WHERE session_id=%d", $id));
        if (!$has && class_exists('UC_LMS_Placement') && $s) {
            list($provider, $key) = UC_LMS_Placement::ai_provider();
            if ($key !== '') {
                $notes = trim((string)($s->recording_notes ?? ''));
                $raw = UC_LMS_Placement::ai_ask($provider, $key, 'Class title: '.$s->title."\nTrainer notes: ".$notes."\nWrite a short recap under 120 words from this title and these notes only. Do not invent attendance, quotes, or topics that are not in the notes. If the notes are empty, say the class title and that a transcript was not returned.");
                if (!is_wp_error($raw) && trim((string)$raw) !== '') {
                    $wpdb->replace(self::t('intel_summaries'), [
                        'session_id' => $id,
                        'recap' => wp_kses_post($raw.($notes !== '' ? "\n\nNotes: ".$notes : '')),
                        'topics' => '[]',
                        'next_steps' => '[]',
                        'published' => 0,
                        'updated_at' => current_time('mysql'),
                    ]);
                }
            }
        }
        wp_safe_redirect(home_url('/lms-class/'.$id.'/'));
        exit;
    }

    public static function h_publish() {
        self::guard_staff('uc_portal_intel_publish');
        $id = absint($_POST['session_id'] ?? 0);
        $what = sanitize_key($_POST['what'] ?? '');
        $on = !empty($_POST['on']) ? 1 : 0;
        global $wpdb;
        if ($what === 'summary') $wpdb->update(self::t('intel_summaries'), ['published' => $on], ['session_id' => $id]);
        if ($what === 'polls') $wpdb->update(self::t('intel_polls'), ['published' => $on], ['session_id' => $id]);
        wp_safe_redirect(home_url('/lms-class/'.$id.'/'));
        exit;
    }

    public static function h_summary() {
        self::guard_staff('uc_portal_intel_summary');
        $id = absint($_POST['session_id'] ?? 0);
        $recap = wp_kses_post(wp_unslash($_POST['recap'] ?? ''));
        $topics = array_values(array_filter(array_map('trim', preg_split('/\r\n|\n|\r/', wp_unslash($_POST['topics'] ?? '')))));
        $steps = array_values(array_filter(array_map('trim', preg_split('/\r\n|\n|\r/', wp_unslash($_POST['steps'] ?? '')))));
        global $wpdb;
        $t_summaries = self::t('intel_summaries');
        $pub = (int) $wpdb->get_var($wpdb->prepare("SELECT published FROM {$t_summaries} WHERE session_id=%d", $id));
        $wpdb->replace(self::t('intel_summaries'), [
            'session_id' => $id,
            'recap' => $recap,
            'topics' => wp_json_encode($topics),
            'next_steps' => wp_json_encode($steps),
            'published' => $pub,
            'updated_at' => current_time('mysql'),
        ]);
        wp_safe_redirect(home_url('/lms-class/'.$id.'/'));
        exit;
    }

    public static function h_task() {
        self::guard_staff('uc_portal_intel_task');
        $id = absint($_POST['id'] ?? 0);
        $sid = absint($_POST['session_id'] ?? 0);
        $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        $status = sanitize_key($_POST['status'] ?? 'draft');
        if (!in_array($status, ['draft', 'published'], true)) $status = 'draft';
        global $wpdb;
        $wpdb->update(self::t('intel_tasks'), ['title' => $title, 'status' => $status], ['id' => $id, 'session_id' => $sid]);
        wp_safe_redirect(home_url('/lms-class/'.$sid.'/'));
        exit;
    }

    public static function h_csv() {
        self::guard_staff('uc_portal_intel_csv');
        $id = absint($_GET['session_id'] ?? 0);
        global $wpdb;
        $t_parts = self::t('intel_participants');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t_parts} WHERE session_id=%d ORDER BY display_name", $id));
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="class-'.$id.'-participants.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Name', 'Email', 'Join', 'Leave', 'Minutes', 'Status']);
        foreach ($rows as $r) {
            fputcsv($out, [$r->display_name, $r->email, $r->join_time, $r->leave_time, round($r->duration_seconds / 60), $r->attendance_status]);
        }
        fclose($out);
        exit;
    }

    public static function t($n) {
        global $wpdb;
        return $wpdb->prefix.'uc_'.$n;
    }
}
