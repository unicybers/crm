<?php
/**
 * UniCybers Academy LMS: Database Access & Upgrade Manager.
 *
 * Provides table name resolution, table existence caching, and
 * coordinates schema installation and version migrations.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Database {
    private static $table_cache = [];

    public static function table($name) {
        global $wpdb;
        return $wpdb->prefix . 'uc_' . $name;
    }

    public static function has_table($name) {
        global $wpdb;
        if (!isset(self::$table_cache[$name])) {
            $table = self::table($name);
            self::$table_cache[$name] = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
        }
        return self::$table_cache[$name];
    }

    public static function invalidate_table_cache() {
        self::$table_cache = [];
    }

    public static function maybe_upgrade($target_version) {
        $current = get_option('uc_lms_db_version', '0.0.0');
        if (version_compare($current, $target_version, '>=')) {
            return;
        }

        // run_full_migration() already installs roles and schema. Avoid running
        // dbDelta twice during a single upgrade request.
        self::run_full_migration();

        update_option('uc_lms_db_version', $target_version);
        self::invalidate_table_cache();
    }

    public static function run_full_migration() {
        self::install_roles();
        self::install_schema();
        self::ensure_indexes();

        // Run version patches via Migrations engine
        UC_LMS_Database_Migrations::ensure_profile_columns();
        UC_LMS_Database_Migrations::ensure_job_columns();
        UC_LMS_Database_Migrations::ensure_batch_group_columns();
        UC_LMS_Database_Migrations::ensure_ist_batch_timezones();
        UC_LMS_Database_Migrations::migrate_legacy_classes();
        UC_LMS_Database_Migrations::migrate_com_emails();
        UC_LMS_Database_Migrations::clear_staff_password_wall_now();
        UC_LMS_Database_Migrations::ensure_noori_coordinator();
        UC_LMS_Database_Migrations::ensure_home_tenant();
        UC_LMS_Database_Migrations::seed_home_tenant();
        UC_LMS_Database_Migrations::ensure_home_tenant_sidebar_brand();
        UC_LMS_Database_Migrations::ensure_academy_super_admin();
        UC_LMS_Database_Migrations::ensure_meet_session_columns();
        UC_LMS_Database_Migrations::ensure_integrations_columns();
        UC_LMS_Database_Migrations::ensure_portal_extras();
        UC_LMS_Database_Migrations::flag_internal_testers();
        UC_LMS_Database_Migrations::remove_legacy_finance_data();

        if (class_exists('UC_LMS_Intelligence')) {
            UC_LMS_Intelligence::instance()->install();
        }

        self::invalidate_table_cache();
    }

    // Schema Delegations
    public static function install_roles() { return UC_LMS_Database_Schema::install_roles(); }
    public static function install_schema() { return UC_LMS_Database_Schema::install_schema(); }
    public static function ensure_indexes() { return UC_LMS_Database_Schema::ensure_indexes(); }

    // Migration Delegations
    public static function add_column_if_missing($table, $column, $definition) {
        return UC_LMS_Database_Migrations::add_column_if_missing($table, $column, $definition);
    }
    public static function ensure_batch_group_columns() { return UC_LMS_Database_Migrations::ensure_batch_group_columns(); }
    public static function ensure_ist_batch_timezones() { return UC_LMS_Database_Migrations::ensure_ist_batch_timezones(); }
    public static function migrate_legacy_classes() { return UC_LMS_Database_Migrations::migrate_legacy_classes(); }
    public static function migrate_com_emails() { return UC_LMS_Database_Migrations::migrate_com_emails(); }
    public static function clear_staff_password_wall_now() { return UC_LMS_Database_Migrations::clear_staff_password_wall_now(); }
    public static function clear_staff_password_wall() { return UC_LMS_Database_Migrations::clear_staff_password_wall(); }
    public static function ensure_noori_coordinator() { return UC_LMS_Database_Migrations::ensure_noori_coordinator(); }
    public static function ensure_home_tenant() { return UC_LMS_Database_Migrations::ensure_home_tenant(); }
    public static function seed_home_tenant() { return UC_LMS_Database_Migrations::seed_home_tenant(); }
    public static function ensure_academy_super_admin() { return UC_LMS_Database_Migrations::ensure_academy_super_admin(); }
    public static function ensure_meet_session_columns() { return UC_LMS_Database_Migrations::ensure_meet_session_columns(); }
    public static function ensure_portal_extras() { return UC_LMS_Database_Migrations::ensure_portal_extras(); }
    public static function flag_internal_testers() { return UC_LMS_Database_Migrations::flag_internal_testers(); }
}
