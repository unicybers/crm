<?php
/**
 * UniCybers LMS: lightweight Google Drive materials indexer.
 * Stores metadata and Drive links only. Uses the Drive Changes feed after the first scan.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Drive_Materials {
    const ROOT_DEFAULT = '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi';
    const CHANGES_OPTION = 'uc_drive_changes_page_token';

    public static function sync() {
        if (get_transient('uc_lms_drive_materials_lock')) return new WP_Error('drive_busy', 'A Google Drive sync is already running.');
        $root = trim((string)get_option('uc_drive_materials_folder', self::ROOT_DEFAULT));
        if ($root === '') return new WP_Error('drive_folder', 'Add the Google Drive materials folder ID in LMS Settings.');
        if (!class_exists('UC_LMS_Meeting_Google')) return new WP_Error('drive_google', 'Google Workspace integration is not loaded.');
        $token = UC_LMS_Meeting_Google::google_access_token();
        if (is_wp_error($token)) return $token;
        set_transient('uc_lms_drive_materials_lock', 1, 5 * MINUTE_IN_SECONDS);
        try {
            $previous_root = (string)get_option('uc_drive_materials_scanned_root', '');
            if ($previous_root !== '' && $previous_root !== $root) {
                global $wpdb;
                $wpdb->update(UC_LMS_Database::table('materials'), ['visible'=>0], ['source'=>'drive']);
                delete_option(self::CHANGES_OPTION);
            }
            update_option('uc_drive_materials_scanned_root', $root, false);
            $page_token = (string)get_option(self::CHANGES_OPTION, '');
            if ($page_token === '') {
                // Capture the change cursor before the first scan so uploads during the scan are not missed.
                $start = self::start_page_token($token);
                if (is_wp_error($start)) return $start;
                $result = self::full_scan($token, $root);
                if (empty($result['errors'])) update_option(self::CHANGES_OPTION, $start, false);
            } else {
                $result = self::incremental_scan($token, $root, $page_token);
                if (is_wp_error($result) && in_array($result->get_error_code(), ['drive_token_expired','drive_bad_token'], true)) {
                    delete_option(self::CHANGES_OPTION);
                    $start = self::start_page_token($token);
                    if (is_wp_error($start)) return $start;
                    $result = self::full_scan($token, $root);
                    if (empty($result['errors'])) update_option(self::CHANGES_OPTION, $start, false);
                }
            }
            if (!is_wp_error($result)) {
                $result['synced_at'] = current_time('mysql');
                update_option('uc_drive_materials_last_sync', $result, false);
            }
            return $result;
        } finally {
            delete_transient('uc_lms_drive_materials_lock');
        }
    }

    private static function blank_result() {
        return ['created'=>0,'updated'=>0,'skipped'=>0,'unmapped'=>0,'removed'=>0,'protected'=>0,'protection_unavailable'=>0,'errors'=>[]];
    }

    private static function full_scan($token, $root) {
        $result = self::blank_result();
        $batch_map = self::batch_map();
        $root_items = self::children($token, $root);
        if (is_wp_error($root_items)) return $root_items;
        foreach ($root_items as $folder) {
            if (($folder['mimeType'] ?? '') !== 'application/vnd.google-apps.folder') continue;
            $folder_name = trim((string)($folder['name'] ?? ''));
            // The existing Meet recording importer owns this folder. Avoid duplicate material rows.
            if (self::normalise($folder_name) === 'meet recordings') continue;
            $batch_id = $batch_map[self::normalise($folder_name)] ?? 0;
            if (!$batch_id) { $result['unmapped']++; continue; }
            $cats = self::children($token, (string)$folder['id']);
            if (is_wp_error($cats)) { $result['errors'][] = $folder_name.': '.$cats->get_error_message(); continue; }
            foreach ($cats as $cat_folder) {
                if (($cat_folder['mimeType'] ?? '') !== 'application/vnd.google-apps.folder') continue;
                $category = self::category((string)($cat_folder['name'] ?? '')) ?: 'other';
                self::walk_category($token, (string)$cat_folder['id'], $batch_id, $category, $folder_name.'/'.(string)$cat_folder['name'], $result);
            }
        }
        return $result;
    }

    private static function incremental_scan($token, $root, $page_token) {
        $result = self::blank_result();
        $next = $page_token;
        $new_start = '';
        do {
            $query = [
                'pageToken'=>$next,
                'pageSize'=>1000,
                'supportsAllDrives'=>'true',
                'includeItemsFromAllDrives'=>'true',
                'fields'=>'nextPageToken,newStartPageToken,changes(fileId,removed,file(id,name,mimeType,modifiedTime,webViewLink,size,md5Checksum,parents,trashed,downloadRestrictions,capabilities(canChangeItemDownloadRestriction)))'
            ];
            $url = 'https://www.googleapis.com/drive/v3/changes?'.http_build_query($query, '', '&', PHP_QUERY_RFC3986);
            $response = wp_remote_get($url, ['timeout'=>25,'headers'=>['Authorization'=>'Bearer '.$token]]);
            if (is_wp_error($response)) return $response;
            $status = (int)wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if ($status === 410) return new WP_Error('drive_token_expired','Google Drive change cursor expired. A full scan will rebuild it.');
            if ($status === 400 && stripos((string)($body['error']['message'] ?? ''), 'page token') !== false) return new WP_Error('drive_bad_token','Google Drive change cursor is invalid.');
            if ($status < 200 || $status >= 300) return new WP_Error('drive_changes',(string)($body['error']['message'] ?? 'Google Drive change scan failed.').' (HTTP '.$status.')');
            foreach ((array)($body['changes'] ?? []) as $change) {
                $file_id = sanitize_text_field((string)($change['fileId'] ?? ''));
                if (!$file_id) continue;
                if (!empty($change['removed']) || !empty($change['file']['trashed'])) {
                    $result['removed'] += self::hide_file($file_id);
                    continue;
                }
                $file = $change['file'] ?? [];
                if (!$file || ($file['mimeType'] ?? '') === 'application/vnd.google-apps.folder') continue;
                $map = self::resolve_mapping($token, $file, $root, $result);
                if (!$map) {
                    $result['removed'] += self::hide_file($file_id);
                    $result['unmapped']++;
                    continue;
                }
                self::save_file($token, $file, $map['batch_id'], $map['category'], $map['path'], $result);
            }
            $next = (string)($body['nextPageToken'] ?? '');
            $new_start = (string)($body['newStartPageToken'] ?? $new_start);
        } while ($next !== '');
        if ($new_start !== '') update_option(self::CHANGES_OPTION, $new_start, false);
        return $result;
    }

    private static function batch_map() {
        global $wpdb;
        $table = UC_LMS_Database::table('batches');
        $rows = $wpdb->get_results("SELECT id,name FROM {$table} WHERE status IS NULL OR status<>'archived'");
        $map = [];
        foreach ((array)$rows as $batch) $map[self::normalise($batch->name)] = (int)$batch->id;
        return $map;
    }

    private static function walk_category($token, $folder_id, $batch_id, $category, $path, &$result) {
        $items = self::children($token, $folder_id);
        if (is_wp_error($items)) { $result['errors'][] = $path.': '.$items->get_error_message(); return; }
        foreach ($items as $item) {
            $mime = (string)($item['mimeType'] ?? '');
            if ($mime === 'application/vnd.google-apps.folder') {
                self::walk_category($token, (string)$item['id'], $batch_id, $category, $path.'/'.(string)$item['name'], $result);
                continue;
            }
            if (empty($item['id']) || empty($item['name'])) { $result['skipped']++; continue; }
            self::save_file($token, $item, $batch_id, $category, $path, $result);
        }
    }

    private static function children($token, $folder_id) {
        $items = []; $page = '';
        do {
            $query = [
                'q'=>"'".str_replace("'", "\\'", $folder_id)."' in parents and trashed=false",
                'pageSize'=>1000,
                'orderBy'=>'name',
                'fields'=>'nextPageToken,files(id,name,mimeType,modifiedTime,webViewLink,size,md5Checksum,downloadRestrictions,capabilities(canChangeItemDownloadRestriction))',
                'supportsAllDrives'=>'true',
                'includeItemsFromAllDrives'=>'true'
            ];
            if ($page !== '') $query['pageToken'] = $page;
            $url = 'https://www.googleapis.com/drive/v3/files?'.http_build_query($query, '', '&', PHP_QUERY_RFC3986);
            $response = wp_remote_get($url, ['timeout'=>25,'headers'=>['Authorization'=>'Bearer '.$token]]);
            if (is_wp_error($response)) return $response;
            $code = (int)wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if ($code < 200 || $code >= 300) return new WP_Error('drive_list',(string)($body['error']['message'] ?? 'Google Drive could not list this folder.').' (HTTP '.$code.')');
            if (!empty($body['files']) && is_array($body['files'])) $items = array_merge($items, $body['files']);
            $page = (string)($body['nextPageToken'] ?? '');
        } while ($page !== '');
        return $items;
    }

    private static function start_page_token($token) {
        $url = 'https://www.googleapis.com/drive/v3/changes/startPageToken?supportsAllDrives=true';
        $response = wp_remote_get($url, ['timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$token]]);
        if (is_wp_error($response)) return $response;
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ((int)wp_remote_retrieve_response_code($response) >= 300 || empty($data['startPageToken'])) return new WP_Error('drive_cursor',(string)($data['error']['message'] ?? 'Google Drive could not initialise incremental sync.'));
        return (string)$data['startPageToken'];
    }

    private static function resolve_mapping($token, $file, $root, &$result) {
        $parents = (array)($file['parents'] ?? []);
        if (!$parents) return null;
        $parts = [];
        $parent_id = (string)$parents[0];
        for ($depth=0; $depth<8 && $parent_id && $parent_id !== $root; $depth++) {
            $folder = self::get_file($token, $parent_id);
            if (is_wp_error($folder)) { $result['errors'][] = $folder->get_error_message(); return null; }
            if (empty($folder['name'])) return null;
            array_unshift($parts, (string)$folder['name']);
            $folder_parents = (array)($folder['parents'] ?? []);
            $parent_id = $folder_parents ? (string)$folder_parents[0] : '';
        }
        if ($parent_id !== $root || count($parts) < 2) return null;
        $batch_name = array_shift($parts);
        $category_name = array_shift($parts);
        $batch_map = self::batch_map();
        $batch_id = $batch_map[self::normalise($batch_name)] ?? 0;
        $category = self::category($category_name);
        if (!$batch_id || !$category) return null;
        return ['batch_id'=>$batch_id,'category'=>$category,'path'=>implode('/',$parts) ? $batch_name.'/'.$category_name.'/'.implode('/',$parts) : $batch_name.'/'.$category_name];
    }

    private static function get_file($token, $file_id) {
        $url = 'https://www.googleapis.com/drive/v3/files/'.rawurlencode($file_id).'?'.http_build_query(['supportsAllDrives'=>'true','fields'=>'id,name,mimeType,parents,trashed'], '', '&', PHP_QUERY_RFC3986);
        $response = wp_remote_get($url, ['timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$token]]);
        if (is_wp_error($response)) return $response;
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ((int)wp_remote_retrieve_response_code($response) >= 300) return new WP_Error('drive_file',(string)($data['error']['message'] ?? 'Cannot resolve Google Drive folder path.'));
        return is_array($data) ? $data : [];
    }

    private static function save_file($token, $file, $batch_id, $category, $path, &$result) {
        global $wpdb;
        $table = UC_LMS_Database::table('materials');
        $id = sanitize_text_field((string)$file['id']);
        $mime = sanitize_text_field((string)($file['mimeType'] ?? 'application/octet-stream'));
        $name = sanitize_text_field((string)$file['name']);
        $title = preg_replace('/\\.[A-Za-z0-9]{1,8}$/', '', $name);
        $url = !empty($file['webViewLink']) ? esc_url_raw($file['webViewLink']) : 'https://drive.google.com/open?id='.rawurlencode($id);
        $modified = !empty($file['modifiedTime']) ? gmdate('Y-m-d H:i:s', strtotime($file['modifiedTime'])) : null;
        $row = [
            'batch_id'=>(int)$batch_id,'title'=>$title ?: $name,'type'=>$category,'url'=>$url,
            'visible'=>1,'student_locked'=>0,'source'=>'drive','drive_file_id'=>$id,'mime_type'=>$mime,
            'modified_time'=>$modified,'drive_path'=>$path
        ];
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE drive_file_id=%s LIMIT 1", $id));
        if ($existing) {
            $ok = $wpdb->update($table, $row, ['id'=>(int)$existing]);
            if ($ok === false) { $result['errors'][] = $name.': database update failed.'; return false; }
            if ($ok > 0) $result['updated']++; else $result['skipped']++;
        } else {
            $row['added_by'] = get_current_user_id() ?: null;
            $row['created_at'] = current_time('mysql');
            $ok = $wpdb->insert($table, $row);
            if (!$ok) { $result['errors'][] = $name.': database insert failed.'; return false; }
            $result['created']++;
        }
        if (get_option('uc_drive_protect_downloads', '1') === '1') {
            $protected = self::protect_file($token, $file);
            if ($protected === true) $result['protected']++;
            elseif ($protected === false) $result['protection_unavailable']++;
            elseif (is_wp_error($protected)) $result['errors'][] = $name.': '.$protected->get_error_message();
        }
        return true;
    }

    private static function protect_file($token, $file) {
        if (empty($file['capabilities']['canChangeItemDownloadRestriction'])) return false;
        if (!empty($file['downloadRestrictions']['itemDownloadRestriction']['restrictedForReaders'])) return true;
        $id = rawurlencode((string)$file['id']);
        $url = 'https://www.googleapis.com/drive/v3/files/'.$id.'?supportsAllDrives=true&fields=id,downloadRestrictions';
        $response = wp_remote_request($url, ['method'=>'PATCH','timeout'=>20,'headers'=>['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],'body'=>wp_json_encode(['downloadRestrictions'=>['itemDownloadRestriction'=>['restrictedForReaders'=>true,'restrictedForWriters'=>false]]])]);
        if (is_wp_error($response)) return $response;
        $code = (int)wp_remote_retrieve_response_code($response);
        if ($code >= 200 && $code < 300) return true;
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return new WP_Error('drive_restrict',(string)($data['error']['message'] ?? 'Could not apply Drive download restrictions.').' (HTTP '.$code.')');
    }

    private static function hide_file($file_id) {
        global $wpdb;
        return (int)$wpdb->update(UC_LMS_Database::table('materials'), ['visible'=>0], ['drive_file_id'=>sanitize_text_field($file_id),'source'=>'drive']);
    }

    private static function category($name) {
        $key = self::normalise($name);
        $map = ['note'=>'notes','notes'=>'notes','reading'=>'notes','readings'=>'notes','slide'=>'slide','slides'=>'slide','presentation'=>'slide','presentations'=>'slide','lab'=>'lab','labs'=>'lab','practical'=>'lab','practicals'=>'lab','assignment'=>'assignment','assignments'=>'assignment','homework'=>'assignment','recording'=>'recording','recordings'=>'recording','video'=>'recording','videos'=>'recording','link'=>'link','links'=>'link','resources'=>'link','other'=>'other','others'=>'other','misc'=>'other','miscellaneous'=>'other'];
        return $map[$key] ?? '';
    }

    private static function normalise($value) {
        $value = strtolower(trim((string)$value));
        $value = preg_replace('/[^a-z0-9]+/', ' ', $value);
        return trim(preg_replace('/\\s+/', ' ', $value));
    }
}
