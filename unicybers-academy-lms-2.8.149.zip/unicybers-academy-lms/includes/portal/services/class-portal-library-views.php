<?php
/**
 * UniCybers Academy LMS: Portal Library Template & Card Components.
 */
if (!defined('ABSPATH')) exit;

final class UC_LMS_Portal_Library_Views {

public static function document_cards($portal, $docs, $del_nonce){
        $o = '<div class="lib-grid">';
        foreach ($docs as $m) {
            $k = $portal->file_category($m);
            $name = $portal->e($m->title);
            $title = $portal->library_name_link($m, $name);
            $o .= '<article class="lib-card f-'.$k.'" data-shelf="docs" data-libcat="'.$k.'" data-q="'.esc_attr(strtolower($m->title.' '.$m->batch_name.' '.$k)).'">';
            $o .= '<div class="lib-card-top"><span class="lib-card-mark f-'.$k.'">'.$portal->icon('materials').'</span>';
            $o .= '<span class="lib-card-copy">'.$title.'<small>'.$portal->e($portal->file_cat_label($k)).' · '.$portal->e($m->batch_name).' · '.$portal->e($portal->fdate($m->created_at,'j M Y')).(!$m->visible?' · hidden':'').'</small></span></div>';
            if ($portal->ops() && $del_nonce) $o .= '<span class="lib-card-actions"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uc_portal_material_delete"><input type="hidden" name="_wpnonce" value="'.$del_nonce.'"><input type="hidden" name="id" value="'.(int)$m->id.'"><button type="submit" class="btn ghost sm danger-hover" data-confirm="Delete this material? Students will no longer see it.">Delete</button></form></span>';
            $o .= '</article>';
        }
        return $o.'</div>';
    }

public static function video_material_card($portal, $m){
        $name = $portal->e($m->title);
        $title = $portal->library_name_link($m, $name);
        $o = '<article class="lib-card lib-card-vid" data-shelf="vids" data-libcat="video" data-q="'.esc_attr(strtolower($m->title.' '.$m->batch_name.' video')).'">';
        $o .= '<div class="lib-card-top"><span class="lib-poster">'.$portal->icon('play').'</span>';
        $o .= '<span class="lib-card-copy">'.$title.'<small>Video · '.$portal->e($m->batch_name).' · '.$portal->e($portal->fdate($m->created_at,'j M Y')).'</small></span></div>';
        return $o.'</article>';
    }

public static function zoom_card($portal, $r, $play){
        $d=(int)$r->recording_duration; $dur=$d?($d>=3600?floor($d/3600).'h ':'').floor(($d%3600)/60).'m':'';
        $st = strtolower((string)($r->recording_status ?? ''));
        $plat = $portal->recording_platform_label($r);
        $wait = $st==='processing' ? $plat.' is still processing this file' : 'Waiting on the '.$plat.' recording. Press Sync recordings.';
        $meta = $portal->e($plat).' · '.$portal->e($r->batch_name).' · '.$portal->e($portal->fdate($r->session_date,'j M Y')).($dur?' · '.$dur:'').($play?'':' · '.$wait);
        $heading = $portal->recording_heading($r);
        $notes = trim((string)($r->recording_notes ?? ''));
        $view_url = home_url('/lms-view/recording/'.(int)$r->id.'/');
        $inner = '<a class="lib-poster'.($play?'':' is-wait').'" href="'.esc_url($view_url).'">'.$portal->icon('play').'</a><span class="lib-card-copy"><a class="lib-name" href="'.esc_url($view_url).'"><strong>'.$portal->e($heading).'</strong></a><small>'.$meta.($notes!==''?' · '.$portal->e($notes):'').'</small></span>';
        $o = '<article class="lib-card lib-card-vid'.($play?'':' is-wait').'" data-shelf="vids" data-libcat="zoom" data-q="'.esc_attr(strtolower($heading.' '.$r->title.' '.$r->batch_name.' zoom')).'">';
        $o .= '<div class="lib-card-top">'.$inner.'</div><span class="lib-card-actions">';
        $o .= '<a class="btn primary sm" href="'.esc_url($view_url).'">Watch</a>';
        $o .= '<a class="btn ghost sm" href="'.esc_url(home_url('/lms-class/'.(int)$r->id.'/')).'">Class Room</a>';
        $o .= $portal->recording_details_button($r);
        if ($portal->ops()) $o .= $portal->recording_hide_form((int)$r->id);
        $o .= '</span>';
        return $o.'</article>';
    }

public static function recording_hide_form($portal, $id){
        return '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="uc_portal_recording_hide"><input type="hidden" name="_wpnonce" value="'.esc_attr(wp_create_nonce('uc_portal_recording_hide')).'"><input type="hidden" name="session_id" value="'.(int)$id.'"><button type="submit" class="btn ghost sm danger-hover" data-confirm="Remove this recording from the library? The class stays on Classes. Sync will not pull this file again.">Remove</button></form>';
    }

public static function material_modal_tpl($portal, $batches){
        $o = '<template id="tplMaterial"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form" enctype="multipart/form-data"><input type="hidden" name="action" value="uc_portal_material_save"><input type="hidden" name="id" value="0">'.wp_nonce_field('uc_portal_material_save','_wpnonce',true,false);
        $o .= $portal->mhead('LIBRARY','Add material').'<div class="fgrid">';
        $o .= '<label>Batch<select name="batch_id" required><option value="">Select a batch</option>'; foreach ($batches as $b) $o .= '<option value="'.(int)$b->id.'">'.$portal->e($b->name).'</option>'; $o .= '</select></label>';
        $o .= '<label>Category<select name="type">';
        foreach ($portal->content_cats() as $id=>$label) $o .= '<option value="'.esc_attr($id).'">'.$portal->e($label).'</option>';
        $o .= '</select></label></div>';
        $o .= '<label>Display name<input name="title" placeholder="Shown in the library" required></label>';
        $default_folder = (string)get_option('uc_drive_materials_folder', '1RjzNHeasyuCvRVKVqzAR29gN4OffRHWi');
        $o .= '<div data-newonly><label>File<span class="file-btn"><input type="file" name="file" accept=".pdf,.ppt,.pptx,.doc,.docx,.xls,.xlsx,.zip,.png,.jpg,.jpeg"><span class="file-pick">Choose File</span><span class="file-name" data-file-name>No File Chosen</span></span></label>';
        $o .= '<label>Drive folder<input name="drive_folder" value="'.esc_attr($default_folder).'" placeholder="Folder ID"></label>';
        $o .= '<label>Or add a link<input name="url" placeholder="https://…"></label></div>';
        $o .= '<p class="hint">Put files in the Google Drive folders by category, then press Sync Drive. Use this form to add a link. A pasted link is not uploaded again. Class recordings come from the class, with Sync recording or the recording link.</p>';
        $o .= '<div class="mfoot"><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary">Save</button></div></form></template>';
        return $o;
    }

public static function recording_modal_tpl($portal){
        $o = '<template id="tplRecording"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="form"><input type="hidden" name="action" value="uc_portal_recording_details"><input type="hidden" name="id" value="0"><input type="hidden" name="back" value="materials">'.wp_nonce_field('uc_portal_recording_details','_wpnonce',true,false);
        $o .= $portal->mhead('RECORDING','Recording details');
        $o .= '<label>Zoom name<input name="zoom_title" readonly></label>';
        $o .= '<label>Display name<input name="recording_label" placeholder="Topic students should see"></label>';
        $o .= '<label>Details<textarea name="recording_notes" rows="4" placeholder="What this recording covers. Sync Zoom will not overwrite this."></textarea></label>';
        $o .= '<p class="hint">The Zoom topic stays on the class. This display name and details are what the library and class room show.</p>';
        $o .= '<div class="mfoot"><button type="button" class="btn ghost" data-close>Cancel</button><button type="submit" class="btn primary">Save details</button></div></form></template>';
        return $o;
    }
}
