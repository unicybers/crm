<?php
/**
 * UniCybers Academy LMS Portal Facade Trait.
 *
 * Provides backward-compatible method delegation for all portal submodules,
 * handlers, and helper utilities.
 */
if (!defined('ABSPATH')) exit;

trait UC_LMS_Portal_Facade {
    /* ── Helper Delegations ───────────────────────────────── */
    public function forbid_cache() { return UC_LMS_Portal_Flash::forbid_cache(); }
    public function purge_portal_cache() { return UC_LMS_Portal_Flash::purge_portal_cache($this); }
    public function flash() { return UC_LMS_Portal_Flash::flash($this); }
    public function set_flash($msg,$type='ok',$secret='',$wa='') { return UC_LMS_Portal_Flash::set_flash($this, $msg, $type, $secret, $wa); }
    public function wants_ajax() { return UC_LMS_Portal_Flash::wants_ajax(); }
    public function back($page,$args=[]) { return UC_LMS_Portal_Flash::back($this, $page, $args); }

    public function brand() { return UC_LMS_Portal_Helpers::brand(); }
    public function hero_edge() { return UC_LMS_Portal_Helpers::hero_edge(); }
    public function wa_credentials_url($user, $password) { return UC_LMS_Portal_Helpers::wa_credentials_url($user, $password); }
    public function issue_credentials($user, $note = '') { return UC_LMS_Portal_Helpers::issue_credentials($user, $note); }
    public function column_meta($name) { return UC_LMS_Portal_Helpers::column_meta($this, $name); }
    public function filter_row($name, $data) { return UC_LMS_Portal_Helpers::filter_row($this, $name, $data); }
    public function fill_required($name, $row) { return UC_LMS_Portal_Helpers::fill_required($this, $name, $row); }
    public function insert_row($name, $data) { return UC_LMS_Portal_Helpers::insert_row($this, $name, $data); }
    public function update_row($name, $data, $where) { return UC_LMS_Portal_Helpers::update_row($this, $name, $data, $where); }
    public function batch_ids() { return UC_LMS_Portal_Helpers::batch_ids($this); }
    public function in_ids($ids) { return UC_LMS_Portal_Helpers::in_ids($ids); }
    public function demo_sql($col='u.user_email') { return UC_LMS_Portal_Helpers::demo_sql($col); }

    public function academy_tz() { return UC_LMS_Portal_Dates::academy_tz(); }
    public function valid_tz($tz) { return UC_LMS_Portal_Dates::valid_tz($tz); }
    public function session_tz($s) { return UC_LMS_Portal_Dates::session_tz($this, $s); }
    public function now_in_tz($tz='') { return UC_LMS_Portal_Dates::now_in_tz($tz); }
    public function ts($date,$time,$tz='') { return UC_LMS_Portal_Dates::ts($date, $time, $tz); }
    public function class_finished_sql($alias='s') { return UC_LMS_Portal_Dates::class_finished_sql($alias); }
    public function ymd($raw) { return UC_LMS_Portal_Dates::ymd($raw); }
    public function fdate($d,$f='D, j M') { return UC_LMS_Portal_Dates::fdate($d, $f); }
    public function t12($t) { return UC_LMS_Portal_Dates::t12($t); }

    public function initials($name) { return UC_LMS_Portal_Helpers::initials($name); }
    public function e($s) { return UC_LMS_Portal_Helpers::e($s); }
    public function support_ref($email) { return UC_LMS_Portal_Helpers::support_ref($email); }
    public function guard($action,$roles) { return UC_LMS_Portal_Helpers::guard($this, $action, $roles); }
    public function generate_link_button($s) { return UC_LMS_Portal_Helpers::generate_link_button($this, $s); }
    public function ensure_portal_extras() { return UC_LMS_Portal_Helpers::ensure_portal_extras($this); }
    public function viewer($kind = '', $id = 0) { return UC_LMS_Module_Viewer::render($kind, $id, $this); }
    public function device_map() { return UC_LMS_Portal_Helpers::device_map($this); }
    public function notice_rows($limit, $manage = false) { return UC_LMS_Portal_Helpers::notice_rows($this, $limit, $manage); }
    public function att_data($batch) { return UC_LMS_Portal_Helpers::att_data($this, $batch); }
    public function log_audit($entity,$id,$action,$detail='') { return UC_LMS_Portal_Helpers::log_audit($this, $entity, $id, $action, $detail); }
    public function db_fail($page) { return UC_LMS_Portal_Helpers::db_fail($this, $page); }
    public function api() { return UC_LMS_Portal_Helpers::api($this); }

    public function note_open($kind, $id) { return UC_LMS_Portal_Helpers::note_open($this, $kind, $id); }
    public function academy_media_url($kind, $id, $url) { return UC_LMS_Portal_Helpers::academy_media_url($this, $kind, $id, $url); }
    public function notice_query($limit) { return UC_LMS_Portal_Helpers::notice_query($this, $limit); }
    public function aud_label($x) { return UC_LMS_Portal_Helpers::aud_label($x); }
    public function recent_notice_count() { return UC_LMS_Portal_Helpers::recent_notice_count($this); }
    public function session_hours($s) { return UC_LMS_Portal_Helpers::session_hours($s); }

    /* ── Icons & Vectors ─────────────────────────────────── */
    public function icon($p) { return UC_LMS_Portal_Icons::get($p); }
    public function mhead($eyebrow, $title, $named = false) { return UC_LMS_Portal_Icons::mhead($eyebrow, $title, $named, $this); }
    public function outline_items($text) { return UC_LMS_Portal_Icons::outline_items($text); }
    public function circuit($cls = 'circuit') { return UC_LMS_Portal_Icons::circuit($cls); }

    /* ── Document Shell & Layout ─────────────────────────── */
    public function document($page) { UC_LMS_Portal_Layout::render_shell($this, $page); }
    public function page_action_button($page) { return UC_LMS_Portal_Layout::page_action_button($this, $page); }
    public function footer() { return UC_LMS_Portal_Layout::footer($this); }
    public function empty_state($title, $text, $icon = 'file') { return UC_LMS_Portal_Layout::empty_state($this, $title, $text, $icon); }
    public function pill($text, $tone = 'mut') { return UC_LMS_Portal_Layout::pill($this, $text, $tone); }

    /* ── Schedule & Live Classes ─────────────────────────── */
    public function sessions($where = '', $order = 's.session_date,s.start_time', $limit = 50) { return UC_LMS_Portal_Schedule::sessions($this, $where, $order, $limit); }
    public function window($s) { return UC_LMS_Portal_Schedule::window($this, $s); }
    public function cancelled($s) { return UC_LMS_Portal_Schedule::cancelled($this, $s); }
    public function platform_chip($s) { return UC_LMS_Portal_Schedule::platform_chip($this, $s); }
    public function tz_options($selected = 'Asia/Kolkata') { return UC_LMS_Portal_Schedule::tz_options($this, $selected); }
    public function batch_trainers() { return UC_LMS_Portal_Schedule::batch_trainers($this); }
    public function with_pwd($url, $passcode = '') { return UC_LMS_Portal_Schedule::with_pwd($this, $url, $passcode); }
    public function session_host_url($s) { return UC_LMS_Portal_Schedule::session_host_url($this, $s); }
    public function join_button($s, $w) { return UC_LMS_Portal_Schedule::join_button($this, $s, $w); }
    public function join($id) { return UC_LMS_Portal_Schedule::join($this, $id); }
    public function greeting() { return UC_LMS_Portal_Schedule::greeting($this); }
    public function ops_junk($text) { return UC_LMS_Portal_Schedule::ops_junk($this, $text); }
    public function upcoming_rows($limit = 16) { return UC_LMS_Portal_Schedule::upcoming_rows($this, $limit); }
    public function next_session() { return UC_LMS_Portal_Schedule::next_session($this); }
    public function hero($name) { return UC_LMS_Portal_Schedule::hero($this, $name); }
    public function kpi($label, $value, $sub, $icon, $tone = 'flat', $href = '') { return UC_LMS_Portal_Schedule::kpi($this, $label, $value, $sub, $icon, $tone, $href); }
    public function attention() { return UC_LMS_Portal_Schedule::attention($this); }
    public function class_rows($rows, $editable = false, $list = false) { return UC_LMS_Portal_Schedule::class_rows($this, $rows, $editable, $list); }
    public function session_has_join($s) { return UC_LMS_Portal_Schedule::session_has_join($this, $s); }
    public function platform_label($p) { return UC_LMS_Portal_Schedule::platform_label($this, $p); }
    public function is_meet_platform($p) { return UC_LMS_Portal_Schedule::is_meet_platform($this, $p); }
    public function recording_platform_label($p) { return UC_LMS_Portal_Schedule::recording_platform_label($this, $p); }

    /* ── Public Candidate & Programme ────────────────────── */
    public function public_programme($id) { return UC_LMS_Portal_Public::public_programme($this, $id); }
    public function public_candidate($kind) { return UC_LMS_Portal_Public::public_candidate($this, $kind); }
    public function pack_missing($p, $uid = 0) { return UC_LMS_Portal_Public::pack_missing($this, $p, $uid); }
    public function pack_token($uid = 0) { return UC_LMS_Portal_Public::pack_token($this, $uid); }
    public function file_control($name, $accept = '') { return UC_LMS_Portal_Public::file_control($this, $name, $accept); }
    public function exam_catalog() { return UC_LMS_Portal_Public::exam_catalog($this); }
    public function exam_fields($uid = 0) { return UC_LMS_Portal_Public::exam_fields($this, $uid); }
    public function placement_labels() { return UC_LMS_Portal_Public::placement_labels($this); }
    public function placement_profile_pct($u) { return UC_LMS_Portal_Public::placement_profile_pct($this, $u); }
    public function ensure_profile_flag() { return UC_LMS_Portal_Public::ensure_profile_flag($this); }
    public function tester_emails() { return UC_LMS_Portal_Public::tester_emails($this); }
    public function want_internal() { return UC_LMS_Portal_Public::want_internal($this); }
    public function is_internal_tester($u = null) { return UC_LMS_Portal_Public::is_internal_tester($this, $u); }
    public function hide_testers($rows = []) { return UC_LMS_Portal_Public::hide_testers($this, $rows); }
    public function include_testers_toggle($view = '') { return UC_LMS_Portal_Public::include_testers_toggle($this, $view); }

    /* ── Materials & Media Library ───────────────────────── */
    public function is_video_material($m) { return UC_LMS_Portal_Library::is_video_material($this, $m); }
    public function file_category($m) { return UC_LMS_Portal_Library::file_category($this, $m); }
    public function file_cat_label($k) { return UC_LMS_Portal_Library::file_cat_label($this, $k); }
    public function content_cats() { return UC_LMS_Portal_Library::content_cats($this); }
    public function mime_icon($f = '') { return ''; }
    public function pretty_size($b = 0) { return size_format($b) ?: '0 B'; }
    public function material_download_url($m = null) { return ''; }
    public function material_view_url($m = null) { return ''; }
    public function material_card($m = null) { return ''; }
    public function material_rows($list = []) { return ''; }
    public function materials_grid($list = []) { return ''; }
    public function stream_material($id) { return UC_LMS_Portal_Stream::stream_material($this, $id); }
    public function stream_recording($id) { return UC_LMS_Portal_Stream::stream_recording($this, $id); }
    public function library_stats() { return []; }
    public function storage_label() { return ''; }

    public function recording_playable($r) { return UC_LMS_Portal_Library::recording_playable($this, $r); }
    public function recording_playable_fast($r) { return UC_LMS_Portal_Library::recording_playable_fast($this, $r); }
    public function maybe_auto_pull_recording($r) { return UC_LMS_Portal_Library::maybe_auto_pull_recording($this, $r); }
    public function embed($url, $passcode='') { return UC_LMS_Portal_Library::embed($this, $url, $passcode); }
    public function material_kind($m) { return UC_LMS_Portal_Library::material_kind($this, $m); }
    public function recording_ready($r) { return UC_LMS_Portal_Library::recording_ready($this, $r); }
    public function recording_hide_form($r) { return UC_LMS_Portal_Library_Views::recording_hide_form($this, $r); }
    public function recording_link_form($id, $url='') { return UC_LMS_Portal_Library::recording_link_form($this, $id, $url); }
    public function library_item_href($m) { return UC_LMS_Portal_Library::library_item_href($this, $m); }
    public function recording_heading($r) { return UC_LMS_Portal_Library::recording_heading($this, $r); }
    public function recording_details_button($r, $back='materials') { return UC_LMS_Portal_Library::recording_details_button($this, $r, $back); }
    public function recording_modal_tpl() { return UC_LMS_Portal_Library_Views::recording_modal_tpl($this); }
    public function playable_recording_count($ids) { return UC_LMS_Portal_Library::playable_recording_count($this, $ids); }
    public function library_desk($mats, $zoom, $del_nonce, $toolbar = '') { return UC_LMS_Portal_Library::library_desk($this, $mats, $zoom, $del_nonce, $toolbar); }
    public function material_modal_tpl($batches) { return UC_LMS_Portal_Library_Views::material_modal_tpl($this, $batches); }
    public function library_name_link($m, $name) { return UC_LMS_Portal_Library::library_name_link($this, $m, $name); }
    public function content_category($m) { return UC_LMS_Portal_Library::content_category($this, $m); }
    public function material_open_url($m) { return UC_LMS_Portal_Library::material_open_url($this, $m); }
    public function library_file_row($m, $open, $cat, $del_nonce) { return UC_LMS_Portal_Library::library_file_row($this, $m, $open, $cat, $del_nonce); }
    public function library_zoom_row($r, $play) { return UC_LMS_Portal_Library::library_zoom_row($this, $r, $play); }
    public function recording_name_cell($r) { return UC_LMS_Portal_Library::recording_name_cell($this, $r); }
    public function video_material_card($m) { return UC_LMS_Portal_Library_Views::video_material_card($this, $m); }
    public function zoom_card($r, $play) { return UC_LMS_Portal_Library_Views::zoom_card($this, $r, $play); }
    public function sort_pills($shelf, $cats) { return UC_LMS_Portal_Library::sort_pills($this, $shelf, $cats); }
    public function document_cards($docs, $del_nonce) { return UC_LMS_Portal_Library_Views::document_cards($this, $docs, $del_nonce); }

    /* ── Stream & Video Player ───────────────────────────── */
    public function framed_player($title, $video_url, $sub = '') { return UC_LMS_Portal_Stream::framed_player($this, $title, $video_url, $sub); }
    public function stream_drive_file($file_id) { return UC_LMS_Portal_Stream::stream_drive_file($this, $file_id); }
    public function drive_cookie_jar($file_id = '') { return UC_LMS_Portal_Stream::drive_cookie_jar($file_id); }
    public function drive_stream_url($file_id) { return UC_LMS_Portal_Stream::drive_stream_url($this, $file_id); }
    public function stream_remote_video($url) { return UC_LMS_Portal_Stream::stream_remote_video($this, $url); }
    public function drive_file_id($url) { return UC_LMS_Portal_Stream::drive_file_id($url); }
    public function local_upload_path($url) { return UC_LMS_Portal_Stream::local_upload_path($url); }

    /* ── Reports Engine ──────────────────────────────────── */
    public function report_cards() { return UC_LMS_Portal_Reports_Engine::report_cards($this); }
    public function one_report_card($uid, $bid) { return UC_LMS_Portal_Reports_Engine::one_report_card($this, $uid, $bid); }
    public function progress_note($hours, $mats = 0, $mats_open = 0, $recs = 0, $recs_open = 0, $asg = 0, $asg_pct = 0) { return UC_LMS_Portal_Reports_Engine::progress_note($hours, $mats, $mats_open, $recs, $recs_open, $asg, $asg_pct); }
    public function practice() { return UC_LMS_Module_Practice::render($this); }
    public function student_progress_panel($uid = 0, $ids = '') { return UC_LMS_Portal_Reports_Engine::student_progress_panel($this, $uid, is_array($ids) ? $this->in_ids($ids) : (string)$ids); }
    public function class_end_report() { return UC_LMS_Portal_Reports_Engine::class_end_report($this); }
    public function weekly_ops_report() { return UC_LMS_Portal_Reports_Engine::weekly_ops_report($this); }
    public function monthly_ops_report() { return UC_LMS_Portal_Reports_Engine::monthly_ops_report($this); }
    public function trainer_hours_report() { return UC_LMS_Portal_Reports_Engine::trainer_hours_report($this); }
    public function rec_issue($s) { return UC_LMS_Portal_Reports_Engine::rec_issue($this, $s); }
    public function rec_watch_table($missing, $short) { return UC_LMS_Portal_Reports_Engine::rec_watch_table($this, $missing, $short); }
    public function rec_label($s) { return UC_LMS_Portal_Reports_Engine::rec_label($this, $s); }

    /* ── Mailer ──────────────────────────────────────────── */
    public function send_weekly_digest($week = '', $force = false) { return UC_LMS_Portal_Mailer::send_weekly_digest($this, $week, $force); }
    public function send_monthly_digest($month = '', $force = false) { return UC_LMS_Portal_Mailer::send_monthly_digest($this, $month, $force); }

    /* ── Domain Page Renderers ───────────────────────────── */
    public function dashboard() { return UC_LMS_Module_Dashboard::render($this); }
    public function courses() { return UC_LMS_Module_Courses::render($this); }
    public function course_modal_tpl() { return UC_LMS_Module_Courses::modal_tpl($this); }
    public function batches() { return UC_LMS_Module_Batches::render($this); }
    public function batch_modal_tpl() { return UC_LMS_Module_Batches::modal_tpl($this); }
    public function batch_class_history($for_classroom = false) { return UC_LMS_Module_Batches::batch_class_history($this, $for_classroom); }
    public function course_interest_list() { return UC_LMS_Module_Batches::course_interest_list($this); }
    public function support_hosts() { return UC_LMS_Module_Batches::support_hosts($this); }
    public function zoom_alt_hosts($batch_id = 0) { return UC_LMS_Module_Batches::zoom_alt_hosts($this, $batch_id); }
    public function batch_next_session($batch_id = 0) { return UC_LMS_Module_Batches::batch_next_session($this, $batch_id); }
    public function batch_students_panel() { return UC_LMS_Module_Batches::students_panel($this); }
    public function classes() { return UC_LMS_Module_Classes::render($this); }
    public function class_modal_tpl() { return UC_LMS_Module_Classes::modal_tpl($this); }
    public function materials() { return UC_LMS_Module_Materials::render($this); }
    public function people() { return UC_LMS_Module_People::render($this); }
    public function student_modal_tpl() { return ''; }
    public function trainer_modal_tpl() { return ''; }
    public function coordinator_modal_tpl() { return ''; }
    public function tenant_modal_tpl() { return ''; }
    public function people_counts() { return []; }
    public function people_stats_strip() { return ''; }
    public function announcements() { return UC_LMS_Module_Messages::render_notices($this); }
    public function notices() { return UC_LMS_Module_Messages::render_notices($this); }
    public function messages() { return UC_LMS_Module_Messages::render($this); }
    public function notice_modal_tpl() { return ''; }
    public function reports() { return UC_LMS_Module_Reports::render($this); }
    public function report_card_tpl() { return ''; }
    public function progress_note_tpl() { return ''; }
    public function evaluation_grade_badge($grade = '') { return ''; }
    public function evaluation_status_pill($status = '') { return ''; }
    public function tenants() { return UC_LMS_Module_Tenants::render($this); }
    public function tenant_switch_url($tid = 0) { return ''; }
    public function placement() { return class_exists('UC_LMS_Module_Placement') ? UC_LMS_Module_Placement::render($this) : ''; }
    public function placement_student() { return class_exists('UC_LMS_Module_Placement') ? UC_LMS_Module_Placement::placement_student($this) : ''; }
    public function placement_staff() { return class_exists('UC_LMS_Module_Placement') ? UC_LMS_Module_Placement::placement_staff($this) : ''; }
    public function job_modal_tpl() { return ''; }
    public function candidate_modal_tpl() { return ''; }
    public function placement_counts() { return []; }
    public function guide() { return UC_LMS_Module_Support::render_guide($this); }
    public function help() { return UC_LMS_Module_Support::render_help($this); }
    public function staff_desk() { return UC_LMS_Module_Support::staff_desk($this); }
    public function profile() { return UC_LMS_Module_Profile::render($this); }
    public function audit() { return UC_LMS_Module_Audit::render_audit($this); }
    public function inventory() { return UC_LMS_Module_Audit::render_inventory($this); }
    public function setpassword() { return UC_LMS_Module_Auth::render_setpassword($this); }
    public function classroom($id = 0) { return UC_LMS_Module_Classroom::render($id, $this); }
    public function classroom_player($s, $chapters = '') { return UC_LMS_Module_Classroom::classroom_player($this, $s, $chapters); }
    public function cr_summary_card($pack, $staff, $s, $intel = null, $full = false) { return UC_LMS_Classroom_Cards::cr_summary_card($this, $pack, $staff, $s, $intel, $full); }
    public function cr_summary_full($pack, $staff, $s) { return UC_LMS_Classroom_Cards::cr_summary_full($this, $pack, $staff, $s); }
    public function cr_tasks_card($pack, $staff, $s, $full = false) { return UC_LMS_Classroom_Cards::cr_tasks_card($this, $pack, $staff, $s, $full); }
    public function cr_polls_card($pack, $staff, $s, $full = false) { return UC_LMS_Classroom_Cards::cr_polls_card($this, $pack, $staff, $s, $full); }
    public function cr_transcript($pack, $intel, $accordion = false) { return UC_LMS_Classroom_Cards::cr_transcript($this, $pack, $intel, $accordion); }
    public function cr_ring($label, $pct = 0, $sub = '') { return is_numeric($label) ? UC_LMS_Classroom_Cards::cr_ring($this, $label) : UC_LMS_Classroom_Cards::cr_ring($this, $pct); }
    public function cr_attendance($pack, $staff, $s, $intel) { return UC_LMS_Classroom_Cards::cr_attendance($this, $pack, $staff, $s, $intel); }
    public function cr_participants($pack, $s, $staff = true) { return UC_LMS_Classroom_Cards::cr_participants($this, $pack, $s, $staff); }
    public function cr_materials($batch_id, $session_id) { return UC_LMS_Classroom_Cards::cr_materials($this, $batch_id, $session_id); }
    public function cr_trainer_strip($pack, $st, $s) { return UC_LMS_Classroom_Cards::cr_trainer_strip($this, $pack, $st, $s); }

    /* ── People & Passwords ──────────────────────────────── */
    public function reset_password($user, $send = false) { return UC_LMS_Handler_People::reset_password($this, $user, $send); }
    public function demo_password_make() { return UC_LMS_Handler_People::demo_password_make($this); }
    public function ensure_demo_seats($password) { return UC_LMS_Handler_People::ensure_demo_seats($this, $password); }

    /* ── Action Handlers ─────────────────────────────────── */
    public function h_course_save() { UC_LMS_Handler_Academic::course_save($this); }
    public function h_batch_save() { UC_LMS_Handler_Academic::batch_save($this); }
    public function h_batch_links() { UC_LMS_Handler_Academic::batch_links($this); }
    public function h_notice() { UC_LMS_Handler_Academic::notice($this); }
    public function h_notice_delete() { UC_LMS_Handler_Academic::notice_delete($this); }
    public function h_course_interest() { UC_LMS_Handler_Academic::course_interest($this); }
    public function h_enquiry_status() { UC_LMS_Handler_Academic::enquiry_status($this); }

    public function fill_class_zoom(&$join_url, &$passcode, &$zoom_id, $title, $date, $start, $end, $tz, $platform, $batch_id = 0, &$start_url = '') { return UC_LMS_Handler_Sessions::fill_class_zoom($this, $join_url, $passcode, $zoom_id, $title, $date, $start, $end, $tz, $platform, $batch_id, $start_url); }
    public function class_saved_flash($base, $zoom_note, $join_url, $platform) { return UC_LMS_Handler_Sessions::class_saved_flash($this, $base, $zoom_note, $join_url, $platform); }
    public function ensure_room_link(&$join_url, $platform, $title, $date, $start, $end, $tz, &$meta = null) { return UC_LMS_Handler_Sessions::ensure_room_link($this, $join_url, $platform, $title, $date, $start, $end, $tz, $meta); }
    public function apply_meet_meta(&$data, $meta) { UC_LMS_Handler_Sessions::apply_meet_meta($this, $data, $meta); }
    public function meet_save_tail($platform, $join_url, $room_note) { return UC_LMS_Handler_Sessions::meet_save_tail($this, $platform, $join_url, $room_note); }
    public function h_session_save() { UC_LMS_Handler_Sessions::session_save($this); }
    public function h_generate_link() { UC_LMS_Handler_Sessions::generate_link($this); }
    public function h_meet_notes() { UC_LMS_Handler_Sessions::meet_notes($this); }
    public function h_attendance_toggle() { UC_LMS_Handler_Sessions::attendance_toggle($this); }
    public function h_att_csv() { UC_LMS_Handler_Sessions::att_csv($this); }

    public function h_drive_materials_sync() { UC_LMS_Handler_Media::drive_materials_sync($this); }
    public function h_sync_recordings() { UC_LMS_Handler_Media::sync_recordings($this); }
    public function h_recording_pull() { UC_LMS_Handler_Media::recording_pull($this); }
    public function h_recording_upload() { UC_LMS_Handler_Media::recording_upload($this); }
    public function h_recording_link() { UC_LMS_Handler_Media::recording_link($this); }
    public function h_recording_hide() { UC_LMS_Handler_Media::recording_hide($this); }
    public function h_recording_hide_short() { UC_LMS_Handler_Media::recording_hide_short($this); }
    public function h_recording_details() { UC_LMS_Handler_Media::recording_details($this); }

    public function h_material_save() { UC_LMS_Handler_Materials::material_save($this); }
    public function h_material_delete() { UC_LMS_Handler_Materials::material_delete($this); }
    public function h_material_lock() { UC_LMS_Handler_Materials::material_lock($this); }
    public function h_practice_save() { UC_LMS_Handler_Materials::practice_save($this); }
    public function h_practice_done() { UC_LMS_Handler_Materials::practice_done($this); }

    public function h_password() { UC_LMS_Handler_People::password($this); }
    public function h_person_save() { UC_LMS_Handler_People::person_save($this); }
    public function h_person_delete() { UC_LMS_Handler_People::person_delete($this); }
    public function h_person_reset() { UC_LMS_Handler_People::person_reset($this); }
    public function h_person_archive() { UC_LMS_Handler_People::person_archive($this); }
    public function h_person_remind() { UC_LMS_Handler_People::person_remind($this); }
    public function h_placement_remind() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::placement_remind($this); }
    public function h_placement_stage() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::placement_stage($this); }
    public function h_placement_doc_ask() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::placement_doc_ask($this); }
    public function h_device_remove() { UC_LMS_Handler_People::device_remove($this); }
    public function h_device_reset() { UC_LMS_Handler_People::device_reset($this); }
    public function h_device_limit() { UC_LMS_Handler_People::device_limit($this); }
    public function h_request_resolve() { UC_LMS_Handler_People::request_resolve($this); }
    public function h_student_add() { UC_LMS_Handler_People::student_add($this); }
    public function h_student_remove() { UC_LMS_Handler_People::student_remove($this); }
    public function h_student_import() { UC_LMS_Handler_People::student_import($this); }
    public function h_demo_gate() { UC_LMS_Handler_People::demo_gate($this); }
    public function h_student_save() { UC_LMS_Handler_People::person_save($this); }
    public function h_trainer_save() { UC_LMS_Handler_People::person_save($this); }
    public function h_coordinator_save() { UC_LMS_Handler_People::person_save($this); }
    public function h_user_reset() { UC_LMS_Handler_People::person_reset($this); }

    public function h_weekly_email() { UC_LMS_Handler_Reports::weekly_email($this); }
    public function h_monthly_email() { UC_LMS_Handler_Reports::monthly_email($this); }

    public function h_profile_save() { UC_LMS_Handler_People::profile_save($this); }
    public function h_document_upload() { UC_LMS_Handler_People::document_upload($this); }
    public function h_job_save() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::job_save($this); }
    public function h_job_delete() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::job_delete($this); }
    public function h_application_save() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::application_save($this); }
    public function h_job_feed() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::job_feed($this); }
    public function h_ai_credits() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::ai_credits($this); }
    public function h_settings_save() { UC_LMS_Module_Settings::save($this); }
    public function h_ats_run() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::ats_run($this); }
    public function h_career_proxy() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::career_proxy($this); }
    public function h_placement_optout() { if (class_exists('UC_LMS_Handler_Placement')) UC_LMS_Handler_Placement::placement_optout($this); }
    public function h_candidate_save() { UC_LMS_Handler_People::profile_save($this); }
    public function h_candidate_status() { UC_LMS_Handler_People::profile_save($this); }

    public function h_tenant_save() { UC_LMS_Handler_Tenants::tenant_save($this); }
    public function h_client_preview() { UC_LMS_Handler_Tenants::client_preview($this); }
    public function h_preview_role() { UC_LMS_Handler_Tenants::preview_role($this); }
    public function h_training_interest() { UC_LMS_Handler_Academic::training_interest($this); }
    public function h_training_interest_status() { UC_LMS_Handler_Academic::training_interest_status($this); }
    public function h_tenant_preview() { UC_LMS_Handler_Tenants::tenant_preview($this); }
    public function h_footer_links() { UC_LMS_Handler_Tenants::footer_links($this); }
    public function h_message_send() { UC_LMS_Handler_Tenants::message_send($this); }
}
